#include "stdint.h"

//#include "led.h"
//#include "delay.h"
//#include "usart3.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include "math.h"
#include "lon_lat.h"
//#include "common.h"
//#include "attitude_ekf.h"
#include "gps1.h"
double R = 6371;//km
double v=0;
double acc_e;
double acc_n;
double acc_d;
/**
 * @param acc_x (m/s^2)
 * @param acc_y (m/s^2)
 * @param acc_z (m/s^2)
 * @param pitch (degree)
 * @param roll (degree)
 *
 * @retval (m/s^2)
 */
double cal_horizontal_acc(double acc_x,double acc_y,double acc_z,double pitch,double roll){
	pitch=degree_to_radian(pitch);
	roll=degree_to_radian(roll);

	acc_e=-acc_x*cos(pitch)-acc_y*sin(pitch)*sin(roll)+acc_z*cos(roll)*sin(pitch);

	acc_n=-acc_y*cos(roll)-acc_z*sin(roll);
	//gps.vel_e=gps.vel_e+
	double acc_hori=sqrt(acc_e*acc_e+acc_n*acc_n);//*0.00048;
	return acc_hori;
	//return (acc_hori>0.01) ? acc_hori : 0;
}
void acc_remove_gravity(double acc_x,double acc_y,double acc_z,double pitch,double roll,double yaw){
	pitch=degree_to_radian(pitch);
	roll=degree_to_radian(roll);
	yaw=degree_to_radian(yaw);

	acc_x=acc_x-sin(pitch)*9.81;
	acc_y=acc_y+cos(pitch)*sin(roll)*9.81;
	acc_z=acc_z+cos(pitch)*cos(roll)*9.81;
	if(acc_x>-0.2 && acc_x<0.2){
		acc_x=0;
	}
	if(acc_y>-0.2 && acc_y<0.2){
		acc_y=0;
	}
	if(acc_z>-0.2 && acc_z<0.2){
		acc_z=0;
	}
	vel_bodytoNED(acc_x,acc_y,acc_z,pitch,roll,yaw);
}
/**
 * @param t (s)
 * @param acc_horizontal (m/s^2)
 * @param v (m/s)
 *
 * @retval (m/s)
 */
double cal_velocity(double t,double acc_horizontal,double v){
	return v=v+acc_horizontal*t;
}
/**
 * @param t (s)
 * @param acc_horizontal (m/s^2)
 *  @param v (m/s)
 *
 * @retval (m)
 */
double cal_distance(double t,double acc_horizontal,double v){
	return v*t;//+(1/2)*acc_horizontal*t*t;
}
void vel_bodytoNED(double vel_x,double vel_y,double vel_z,double pitch,double roll,double yaw){
	double theta=degree_to_radian(pitch);
	double phi=degree_to_radian(roll);
	double psi=degree_to_radian(yaw);
	//vel_n=vel_x*(cos(pitch+yaw)+cos(pitch-yaw))/2 + vel_y*(-sin(pitch+yaw)+sin(pitch-yaw))/2 + vel_z*sin(pitch);
	//vel_e=vel_x*(cos(pitch-)-cos(pitch+)+2*sin())/4 + vel_y*(2*cos()-2*sin(pitch)+sin(pitch-)+sin(pitch+))/4 + vel_z*(-sin(pitch+)+sin(pitch-))/2;
	//vel_d=
	double vel_n=vel_x*cos(theta)*cos(psi)+vel_y*cos(theta)*sin(psi)+vel_z*-sin(theta);
	double vel_e=vel_x*(-cos(phi)*sin(psi)+sin(phi)*sin(theta)*cos(psi))+vel_y*(cos(phi)*cos(psi)+sin(psi)*sin(phi)*sin(theta))+vel_z*sin(phi)*cos(theta);
	acc_n=vel_n;
	acc_e=vel_e;
}

/**
 * @param lon (radian)
 * @param lat (radian)
 * @param  bearing (degree)
 * @param distance (km)
 *
 * @retval (radian)
 */
struct lon_lat cal_longitude_latitude(double lon,double lat,double bearing,double distance)
{


	 bearing=degree_to_radian(bearing);
	double c = (distance / R);
	double a = acos(cos(PI/2-lat)*cos(c)+sin(PI / 2 - lat) *sin(c)*cos(bearing));

	double C = asin(sin(c)*sin(bearing)/sin(a));
	struct lon_lat lon_lat1;
	lon_lat1.lon = lon+C;
	lon_lat1.lat = PI/2-a;
//	if(lon_lat.lon<0)
//		lon_lat.lon=-lon_lat.lon;
	return lon_lat1;

}

double degree_to_radian(double degree){
	if(degree>=360)
		degree=degree-360;
	if(degree<=-360)
		degree=degree+360;
	return degree/180*PI;
}

