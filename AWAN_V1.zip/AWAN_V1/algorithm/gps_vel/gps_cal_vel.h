/*
 * gps_cal_vel.h
 *
 *  Created on: 2023年3月23日
 *      Author: rich
 */

#ifndef GPS_VEL_GPS_CAL_VEL_H_
#define GPS_VEL_GPS_CAL_VEL_H_
#include<stdbool.h>
#define VAR_LENGTH 200



void gps_cal_vel(double deltat,float *acc,float *angle,float *gyro,float *vel,double * lon,double *lat );
float cal_avg(float* data);
float cal_variance(float* data,float cur_data,int counter);
bool zupt(float *acc,float *angle,float *gyro);
float Filter_Factor_Cal(float SampleTime, float Freq_cut);
float LPF_oneOrder(float input, float output, float Fc, float deltaT);
void body_to_ned(float *acc_rls);
void kalman( float* x,float* P, float z, float R,float acc,float deltat);
void kalman_aX( float* x,float* P, float z, float R,float acc);
#endif /* GPS_VEL_GPS_CAL_VEL_H_ */
