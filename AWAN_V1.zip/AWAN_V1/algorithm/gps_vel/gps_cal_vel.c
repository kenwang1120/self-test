#include<gps_cal_vel.h>
#include <math.h>
#include <stdio.h>
#include <gps1.h>
#include <scheduler.h>

uint8_t judge_stop(float xAccVarn , float pitchVarn , float gpsVelVarn);

extern float initMagYaw;
extern float posMagYaw;
extern float negMagYaw;
float accn_buffer[200];
float gyro_buffer[200];
float gyroZ_buffer[200];
float bias_buffer[200];
float pitch_buffer[200];
float gpsvel_buffer[200];
int var_counter=0;
int bias_counter=0;
int zupt_counter=0;
float vn=0;
float dis_n=0;
float dis_kal=0;
float vn_kal=0,vn_kal_lpf=0,vn_kal_raw=0,vn_kal_mdyAx=0,vn_kal_mag=0,vn_kal_Pmag=0,vn_kal_Nmag=0;
float var_kal=0.01,var_kal_lpf=0.01,var_kal_raw=0.01,var_kal_mdyAx=0.01,var_kal_mag=0.01,var_kal_Pmag=0.01,var_kal_Nmag=0.01;
float vn_fuse=0;
float vn_posVel=0,vn_biasVel=0;
float bias=0;
struct lon_lat lon_lat;
int zputFlag = 0;
int biasFlag = 0;
float lpfPitch=0,pitch_last=0;
float diffEstGpsYaw=0;
float gpsImuAcc=0,accXInt=0;
double dLON=0,dLAT=0;
double accX=0,accXLpf=0;
double accXLast=0;
double vn_rawVel=0,vn_lpfVel=0;
float vn_fuse_pitch=0,vn_fuse_bias=0,vn_fuse_raw=0,vn_fuse_lpf=0;
float gpsvel_buffer_bias[200];
float gpsvel_buffer_raw[200];
float gpsvel_buffer_lpf[200];
float gpsvel_buffer_mdyAx[200];
float gpsvel_buffer_mag[200];
double nDis = 0,eDis=0,lastLat=0,lastLon=0;
double lastGPSLat=0,lastGPSLon=0;
uint8_t flagGPS=0;
double nDiff = 0,eDiff=0;
float aX_Buffer[200];
float kal_Ax=0,var_kal_Ax=0.01,lastGPSVel=0,aveAccX=0,fuAccX=0;
uint16_t cntGPS=0;
float bias_buffer_y[200];
float bias_y = 0;
double accY=0,accYLpf=0,accYLast=0;
double gyroZ=0,gyroZLpf=0,gyroZLast=0;
double mdyYVel = 0,vn_fuse_mdyAx=0;
bool flagMdyYVel = 0;
double mdyAy=0;
float gyroZ_variance=0;
float gyro_variance = 0;
float accn_variance = 0;
uint16_t gVelTest=0,fuVelTest=0;
float gpsBias=0;
double accn_rg_bias=0;
float accPitGpsV_bias=0;
uint8_t flagStop=0;//1=stop
float pitchVarn_buffer[200];
float xAccVarn_buffer[200];
float gpsVelVarn_buffer[200];
float twoXAccVarn=0,twoPitchVarn=0,gpsVelVarn=0;
float bw=0,dT=0,coef=0;

void gps_cal_vel(double deltat,float *acc,float *angle,float *gyro,float *vel,double * lon,double *lat ){
//determine stable and calculate bias
	if(zupt(acc,angle,gyro) || flagStop==1){
		vn=0;
		dis_n=0;
		vn_fuse=0;
		//vn_kal=0;
		zputFlag = 1;
		vn_posVel = 0;
		vn_biasVel =0;
		vn_rawVel =0;
		vn_lpfVel =0;
		vn_fuse_pitch=0;
		vn_fuse_bias=0;
		vn_fuse_raw=0;
		vn_kal = 0;

		mdyYVel = 0;
	}
	else
		zputFlag = 0;

	lpfPitch =  LPF_oneOrder(angle[1],pitch_last, 1, deltat);//1，10，100
	pitch_last = lpfPitch;

	accX = acc[0];
	accXLpf =  LPF_oneOrder(accX,accXLast, 1, deltat);//1，10，100
	accXLast = accXLpf;

	accY = acc[1];
	accYLpf =  LPF_oneOrder(accY,accYLast, 1, deltat);//1，10，100
	accYLast = accYLpf;

	gyroZ = gyro[2];
	gyroZLpf =  LPF_oneOrder(gyroZ,gyroZLast, 200, deltat);//1，10，100
	gyroZLast = gyroZLpf;

	mdyAy = accYLpf - gyroZLpf * vn_kal * 0.017453292;
	if (fabs(gyroZLpf * 0.017453292) > 0.1)//5.25 degree //當轉速超過5度，才做加速度積分=速度(mdyYVel)
    {
        mdyYVel += mdyAy * deltat; ;// mdyYVel += mdyAy * 0.01;//(mdyAy- biasY) * dT
        flagMdyYVel = 1;
    }
	else if(fabs(gyroZLpf * 0.017453292) < 0.0523)//轉速<3(threshold)，YVel拉成0
    {
        mdyYVel = 0;
        flagMdyYVel = 0;
    }

	//judge_stop
	flagStop = judge_stop(twoXAccVarn,twoPitchVarn,gpsVelVarn);
	//

//	double accn_rg=acc[0]-bias;//fabs(acc[0]-bias) < 0.2
	double accn_rg=acc[0] - 9.80665f * sin(lpfPitch*D2R);//fabs(acc[0]-bias) < 0.2
//	double accn_rg=(acc[0] - 9.80665f * sin(lpfPitch*D2R))/cos(lpfPitch*D2R);
//	accn_rg_bias=acc[0] -bias;
	if(gps.gps_timeValid==0 && gps.vel >5.5 )//accn_rg_bias > -0.2 && accn_rg_bias < 0.2 or 0.1
	{
		accn_rg_bias=acc[0] - gpsBias;
	}
	else
	{
		if(flagStop == 1)
		{
			accPitGpsV_bias = accXLpf;
		}
//		accn_rg_bias=acc[0] - accXLpf;
//		accn_rg_bias=acc[0] - (9.80665f * sin(lpfPitch*D2R));
		accn_rg_bias=acc[0] - accPitGpsV_bias;
		//if (accn_variance < 0.1) , find bias(accXLpf or gSin),when moving ,use last bias
	}


	double accn_rg_yVel_bias = (acc[0] + gyroZLpf * mdyYVel * 0.017453292 - bias) * deltat;
//	double accn_rg_yVel_bias = (accXLpf + gyroZLpf * mdyYVel * 0.017453292 - bias) * deltat;

	if(accn_rg > -0.2 && accn_rg < 0.2)
		accn_rg = 0;

	//stop:<0.2 , move:<0.1
	if(accn_rg_bias > -0.1 && accn_rg_bias < 0.1)//another method : if (Math.Abs(accXLpf - gyro_x) < 0.2)
	{
		accn_rg_bias = 0;
	}
	if(accn_rg > -0.2 && accn_rg < 0.2 && gyroZ_variance < 0.2)//almost still
	{
		accn_rg_yVel_bias = 0;
	}

	if(accX > -0.2 && accX < 0.2)
		accX = 0;
//	if(accXLpf > -0.2 && accXLpf < 0.2)
//		accXLpf = 0;

// calculate raw acc speed
	vn+=accn_rg*deltat;
	dis_n+=vn*deltat;
	vn_posVel += (accn_rg/cos(lpfPitch*D2R))*deltat;
	vn_biasVel += accn_rg_bias*deltat;
	vn_rawVel += accX*deltat;
	vn_lpfVel += accXLpf*deltat;



//	if(gps.gps_lost >= 1)
//	{
//
//		if(vn_kal <= 0)
//			vn_kal = 0;
//		lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2] - diffEstGpsYaw,vn_kal*deltat/1000);
//	}
//	else
//	{
//		if(vn_kal <= 0)
//			vn_kal = 0;
//		lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2],vn_kal*deltat/1000);
//	}//0718 test

//use different kalman vel to calculate lon and lat
//	lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2],vn_kal*deltat/1000);//0718 test
	lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2],vn_kal_mdyAx*deltat/1000);//vn_kal_mdyAx
//	lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2],vn_kal_raw*deltat/1000);//0726 test
//	lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2],vn_kal_lpf*deltat/1000);//0726 test


// fuse speed and lon lat when gps active(former algorithm)
//	if(gps.valid==true){
//		vn_fuse=gps.vel;
//		lon_lat.lon=gps_lon_lat.lon*0.0174533;;//lon_lat.lon=(double)gps.lon/10000000*0.0174533;
//		lon_lat.lat=gps_lon_lat.lat*0.0174533;;//lon_lat.lat=(double)gps.lat/10000000*0.0174533;
////		lon_lat.lon=(double)gps.lon/10000000;
////		lon_lat.lat=(double)gps.lat/10000000;
//		gps.valid=false;
//		diffEstGpsYaw = angle[2] - gps.heading;
//	}
//	else{
//		vn_fuse+=accn_rg*deltat;
//	}


//// fuse speed and lon lat when gps active(present algorithm)
	if(gps.valid==true && gps.gps_timeValid==1){

		//nDiff eDiff
		nDiff = (gps_lon_lat.lat*0.0174533 - lon_lat.lat)*57.2957795*111300;//gps - IMU_calculate
		eDiff = (gps_lon_lat.lon*0.0174533 - lon_lat.lon)*57.2957795*100000;
		//

		if(gps.gps_psuedoLost == 0)//valid
		{
			vn_fuse=gps.vel;
			vn_fuse_raw=gps.vel;
			lon_lat.lon=gps_lon_lat.lon*0.0174533;//lon_lat.lon=(double)gps.lon/10000000*0.0174533;
			lon_lat.lat=gps_lon_lat.lat*0.0174533;//lon_lat.lat=(double)gps.lat/10000000*0.0174533;
		}
		else if(gps.gps_psuedoLost == 1)//invalid
		{
	//		vn_fuse+=accn_rg*deltat;
			vn_fuse+=accn_rg_bias*deltat;//vn_fuse+=accn_rg*deltat;
	//		vn_fuse_lpf+=accXLpf*deltat;//accXLpf
			vn_fuse_raw+=accX*deltat;//acc[0]
//			vn_fuse_raw+=kal_Ax*deltat;//kal_Ax as acc[0]
			vn_fuse_mdyAx +=accn_rg_yVel_bias*deltat;
		}
//		gpsImuAcc = (vn_biasVel - gps.vel);
		if(cntGPS == 0)
		{
			gpsBias = 0;
		}
		else
		{
			gpsImuAcc = (gps.vel - lastGPSVel)/(cntGPS*0.005);//gps.gps_timeValid = 2;//gps lost set cntGPS = 0
			//true = read - bias
			gpsBias = accXLpf - gpsImuAcc;//acc[0] - gpsImuAcc
		}

		dLON = gps_lon_lat.lon*0.0174533;
		dLAT = gps_lon_lat.lat*0.0174533;
//		lon_lat.lon=(double)gps.lon/10000000;
//		lon_lat.lat=(double)gps.lat/10000000;
		gps.valid=false;

		aveAccX = accXInt/cntGPS;
		accXInt=0;

		gps_lon_lat.lon = dLON*57.2957795;
		gps_lon_lat.lat = dLAT*57.2957795;

		set_heading(gps.heading);
		diffEstGpsYaw = angle[2] - gps.heading*57.2957795;
//		diffEstGpsYaw = diffEstGpsYaw *0.8;

		dis_kal = 0 ;		nDis = 0;		eDis = 0;

		cntGPS = 0;//1S = 200 cnt,maybe more or less,reset here
		if(gps.vel == 0)
		{
			lastGPSVel = vn_fuse;
		}
		else
		{
			lastGPSVel = gps.vel;
		}

	}
	else{
//		vn_fuse+=accn_rg*deltat;
		vn_fuse+=accn_rg_bias*deltat;//vn_fuse+=accn_rg*deltat;
//		vn_fuse_lpf+=accXLpf*deltat;//accXLpf
		vn_fuse_raw+=accX*deltat;//acc[0]
//		vn_fuse_raw+=kal_Ax*deltat;//kal_Ax as acc[0]
		vn_fuse_mdyAx +=accn_rg_yVel_bias*deltat;

		accXInt += acc[0];//*0.005;
//		gpsImuAcc=0;
//		gps_lon_lat.lon = gps_lon_lat.lon*0.0174533;
//		gps_lon_lat.lat = gps_lon_lat.lat*0.0174533;

		//nDis eDis
		nDis = (lon_lat.lat - lastLat)*57.2957795*111300;//IMU_calculate
		eDis = (lon_lat.lon - lastLon)*57.2957795*100000;
		lastLat = lon_lat.lat;
		lastLon = lon_lat.lon;
//		gps.gps_psuedoLost = 2;
		//nDis eDis

		//GPS period
		cntGPS ++;
		//GPS period
	}

//	lon_lat=cal_longitude_latitude(lon_lat.lon,lon_lat.lat,angle[2],vn_kal*deltat/1000);

//	double R=cal_variance(gpsvel_buffer,vn_fuse,var_counter);//accn_rg
//	kalman(&vn_kal,&var_kal,vn_fuse,R,accn_rg,deltat);
//	dis_kal+=vn_kal*deltat;

//	if(gyro_variance < 0.1 && gps.vel < 0.1)
//	{
////		gps.vel = 0;
//		vn_fuse = 0;
//	}
	if(vn_fuse < 0)
		vn_fuse = 0;
	double R=cal_variance(gpsvel_buffer_bias,vn_fuse,var_counter);//accn_rg_bias
	kalman(&vn_kal,&var_kal,vn_fuse,R,accn_rg_bias,deltat);
	dis_kal+=vn_fuse*deltat;;//dis_kal+=vn_kal*deltat;
//	gps.distance+=gps.vel*delta_t;
	if(vn_kal <= 0)
		vn_kal = 0;

	if(vn_fuse_mdyAx < 0)
		vn_fuse_mdyAx = 0;
	double R_mdyAx=cal_variance(gpsvel_buffer_mdyAx,vn_fuse_mdyAx,var_counter);//accn_rg_bias
	kalman(&vn_kal_mdyAx,&var_kal_mdyAx,vn_fuse_mdyAx,R_mdyAx,accn_rg_yVel_bias,deltat);
//	dis_kal+=vn_fuse_mdyAx*deltat;;//dis_kal+=vn_kal*deltat;
//	gps.distance+=gps.vel*delta_t;
	if(vn_kal_mdyAx <= 0)
		vn_kal_mdyAx = 0;

	double R_raw=cal_variance(gpsvel_buffer_raw,vn_fuse_raw,var_counter);//accX
	kalman(&vn_kal_raw,&var_kal_raw,vn_fuse_raw,R_raw,accX,deltat);
	if(vn_kal_raw <= 0)
		vn_kal_raw = 0;

//	fuAccX = (gpsImuAcc+aveAccX+accX)/3;//fuAccX = (gpsImuAcc+aveAccX)/2;
//	double R_accn = cal_variance(aX_Buffer,acc[0],var_counter);
//	kalman_aX(&kal_Ax,&var_kal_Ax,fuAccX,R_accn,accX);//

//	double R_lpf=cal_variance(gpsvel_buffer_lpf,vn_fuse_lpf,var_counter);//accXLpf
//	kalman(&vn_kal_lpf,&var_kal_lpf,vn_fuse_lpf,R_lpf,accXLpf,deltat);
//	if(vn_kal_lpf <= 0)
//		vn_kal_lpf = 0;

	///////////////////////////////////////////mag_angle & est_angle fusion///////////////////////////////////
	double R_angle=cal_variance(gpsvel_buffer_mag,initMagYaw,var_counter);
	//kalman(&vn_kal_mag,&var_kal_mag,initMagYaw,R_angle,gyro[2],deltat);//rate_out

	kalman(&vn_kal_Pmag,&var_kal_Pmag,negMagYaw,R_angle,gyro[2],deltat);//rate_out,positive
	kalman(&vn_kal_Nmag,&var_kal_Nmag,posMagYaw,R_angle,gyro[2],deltat);//rate_out,negative

//	double R_angle=cal_variance(gpsvel_buffer_mag,posMagYaw,var_counter);
//	kalman(&vn_kal_mag,&var_kal_mag,posMagYaw,R_angle,gyro[2],deltat);//rate_out

	///////////////////////////////////////////mag_angle & est_angle fusion///////////////////////////////////

/// sendout result
	*lon=lon_lat.lon*57.2957795;
	*lat=lon_lat.lat*57.2957795;
//	*lon=lon_lat.lon;
//	*lat=lon_lat.lat;

	vel[0]=flagStop;//accXLpf;//gpsBias;//vn_biasVel;//vn_kal;
	vel[1]=9.80665f * sin(lpfPitch*D2R);//accXLpf;//gps.vel;
	vel[2]=vn_fuse;//gps->heading;//bias;
	vel[3]=gps.rGPSHeading;//accn_rg_bias;//gVelTest;//gps.vel;//var_counter;//vn_fuse_raw;//vn_posVel;
	vel[4]=gps.vel;//gps.vel_n;//diffEstGpsYaw;//gps.distance*0.1;//vn_rawVel;//accXInt;//gps.distance*0.1;//lpfPitch;accXInt
	vel[5]=gps.rGPSCnt;//gps.vel_e;//dis_kal;//accn_rg;
	vel[6]=vn_fuse;//vn_kal_raw;//vn_lpfVel;//gpsImuAcc;//gps.heading;//gpsImuAcc

	//gVelTest++;
	fuVelTest++;
    if(gVelTest>200)
    	gVelTest = 0;
    if(fuVelTest>200)
    {
    	gVelTest++;
    	fuVelTest = 0;
    }

	//dis[0]=dis_kal;
	//dis[1]=vn_kal;
	//dis[2]=dis_kal;
}

//calculate bias of vn and determine  moving or stable
bool zupt(float *acc,float *angle,float *gyro){
	float acc_sqrt=sqrt(acc[0]*acc[0]+acc[1]*acc[1]+acc[2]*acc[2]);
	float gyro_sqrt=sqrt(gyro[0]*gyro[0]+gyro[1]*gyro[1]+gyro[2]*gyro[2]);



	accn_variance = cal_variance(accn_buffer,acc[0],var_counter);
	gyro_variance= cal_variance(gyro_buffer,gyro_sqrt,var_counter);
	gyroZ_variance= cal_variance(gyroZ_buffer,gyro[2],var_counter);
	//twoPitchVarn,twoXAccVarn,gpsVelVarn
	twoPitchVarn= cal_variance(pitchVarn_buffer,angle[1] - lpfPitch,var_counter);
	twoXAccVarn= cal_variance(xAccVarn_buffer,acc[0] - accXLpf,var_counter);
	gpsVelVarn= cal_variance(gpsVelVarn_buffer,gps.vel,var_counter);
	//

	float pitch_variance = cal_variance(pitch_buffer,angle[1],var_counter);
	var_counter++;
	if (var_counter >= VAR_LENGTH)
	{
		var_counter = 0;
	}

	bool bool_acc_sqrt = false;
	bool bool_acc_var = false;
	bool bool_accn_bias = false;
	bool bool_gyro_variance = false;
	bool bool_gyro_sqrt = false;
	if (gyro_sqrt < 0.5) {
		bool_gyro_sqrt = true;
	}
	if (fabs(acc_sqrt - 9.8) < 0.5)
	{
		bool_acc_sqrt = true;
	}
	if (accn_variance < 0.1)
	{
		bool_acc_var = true;
	}

	if (gyro_variance < 0.1)
	{
		bool_gyro_variance = true;
	}
	if (fabs(acc[0]-bias) < 0.2)
	{
		bool_accn_bias = true;
	}

	if (bool_acc_sqrt && bool_acc_var && bool_gyro_variance && pitch_variance<0.02&& bool_gyro_sqrt)
	{
		bias_buffer[bias_counter] = acc[0];
		bias_buffer_y[bias_counter] = acc[1];
		bias_counter++;
	}
	else
	{
		bias_counter = 0;
		biasFlag = 0;
	}
	if (bias_counter > 200)
	{
		bias_counter=0;
		bias = cal_avg(bias_buffer);
		bias_y = cal_avg(bias_buffer_y);
		biasFlag = 1;
		return true;
	}
	if (bool_acc_sqrt && bool_acc_var && bool_gyro_variance && bool_accn_bias&& bool_gyro_sqrt)
	{
		zupt_counter++;
	}
	else
	{
		zupt_counter = 0;
	}
	if (zupt_counter > 200)
	{
		zupt_counter=200;
		return true;
	}
	return false;

}

//store current data in buffer and then calculate variance
float cal_variance(float* data,float cur_data,int counter) {
	data[counter]=cur_data;
	float avg = cal_avg(data);

	float var_total = 0;

	for (int i = 0; i < VAR_LENGTH; i++)
	{
		var_total += (data[i] - avg) * (data[i] - avg);

	}





	return sqrt(var_total / VAR_LENGTH);

}
float cal_avg(float* data) {
	float total = 0;
	for (int i = 0; i < VAR_LENGTH; i++)
	{
		total += data[i];

	}
	return  total / VAR_LENGTH;
}
float Filter_Factor_Cal(float SampleTime, float Freq_cut){
	/* tau=1/(2*pi*Fc)=Factor*dT/(1-Factor) => Factor=1/(1+2*pi*Fc*dT) 1st_Factor*/
	return 1/(1.0 + 2.0*3.14159*Freq_cut*SampleTime);
}
float LPF_oneOrder(float input, float output, float Fc, float deltaT){
	float LPF_Coeff;
	float _output=0;
	LPF_Coeff = Filter_Factor_Cal(deltaT, Fc);
	_output = LPF_Coeff*output + (1.0 - LPF_Coeff)*input;
	bw = Fc;
	dT = deltaT;
	coef = LPF_Coeff;
	return _output;
}
void kalman( float* x,float* P, float z, float R,float acc,float deltat) {
	*x = *x + acc * deltat;
	*P = *P + 0.00005f;

	float k = *P / (*P + R);
	*x = *x + k * (z-*x);
	float temp = *P;
	*P = *P - k * *P;
	if (*P < 0)
		*P = temp;
}
void kalman_aX( float* x,float* P, float z, float R,float acc) {

	*P = *P + 0.00005f;//try diff num

	float k = *P / (*P + R);
	*x = *x + k * (z-*x);
	float temp = *P;
	*P = *P - k * *P;
	if (*P < 0)
		*P = temp;
}
void body_to_ned(float *acc_rls){
//	float temp0,temp1,temp2;
//	temp0=acc_rls[0]*cos(theta)*cos(psi)+acc_rls[1]*(-cos(phi)*sin(psi)+sin(phi)*sin(theta)*cos(psi))+acc_rls[2]*(sin(psi)*sin(phi)+cos(phi)*sin(theta)*cos(psi));
//	temp1=acc_rls[0]*cos(theta)*sin(psi)+acc_rls[1]*(cos(phi)*cos(psi)+sin(psi)*sin(phi)*sin(theta))+acc_rls[2]*(-sin(phi)*cos(psi)+cos(phi)*sin(theta)*sin(psi));
//	temp2=acc_rls[0]*-sin(theta)+acc_rls[1]*sin(phi)*cos(theta)+acc_rls[2]*(cos(phi)*cos(theta));
//	acc_rls[0]=temp0;
//	acc_rls[1]=temp1;
//	acc_rls[2]=temp2;
}

uint8_t judge_stop(float xAccVarn , float pitchVarn , float gpsVelVarn)
{
	uint8_t status=0,flagXAcc=0,flagPitch=0,flagGpsV=0;
	static int cntFXAcc=0,cntFPitch=0,cntFGpsV=0;
    if (xAccVarn < 0.01)
    	cntFXAcc++;
    else
    {
    	cntFXAcc = 0;
        flagXAcc = 0;
    }
    if(cntFXAcc >= 200)
    {
    	cntFXAcc = 200;
        flagXAcc = 1;
    }

    if (pitchVarn < 0.01)
    	cntFPitch++;
    else
    {
    	cntFPitch = 0;
    	flagPitch = 0;
    }
    if(cntFPitch >= 200)
    {
    	cntFPitch = 200;
    	flagPitch = 1;
    }

    if (gpsVelVarn < 0.1)
    	cntFGpsV++;
    else
    {
    	cntFGpsV = 0;
    	flagGpsV = 0;
    }
    if(cntFGpsV >= 200)
    {
    	cntFGpsV = 200;
    	flagGpsV = 1;
    }

    status = flagXAcc*flagPitch*flagGpsV;
	return status;
}
