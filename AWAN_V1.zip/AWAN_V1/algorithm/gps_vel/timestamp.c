#include "stdint.h"


#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include "math.h"

#include "timestamp.h"


uint32_t timestamp_sec;
struct tm time_stamp;
int gps_update;
uint64_t timestamp_usec;
uint64_t  get_usec(){
	return timestamp_usec;
}
void usec_plus_one(){
	timestamp_usec++;
}
void update_time(){
	if(time_stamp.tm_sec==60){
		time_stamp.tm_sec=0;
		time_stamp.tm_min++;
	}
	if(time_stamp.tm_min==60){
		time_stamp.tm_min=0;
		time_stamp.tm_hour++;

	}
	if(time_stamp.tm_hour==24){
		time_stamp.tm_hour=0;
		time_stamp.tm_mday++;
	}

}
uint32_t get_timestamp_sec()
{

	return mktime(&time_stamp);

}
void set_timestamp(uint64_t usec,uint16_t sec,uint16_t min,uint16_t hour,uint16_t day,uint16_t month,uint16_t year)
{

	timestamp_usec=usec;
	time_stamp.tm_sec=sec;
	time_stamp.tm_min=min;
	time_stamp.tm_hour=hour;
    time_stamp.tm_mday=day;
    time_stamp.tm_mon=month-1;
    time_stamp.tm_year=year+2000-1900;
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  /* Prevent unused argument(s) compilation warning */
  //UNUSED(GPIO_Pin);
	time_stamp.tm_sec++;
    gps_update++;

     if(gps_update==5 && (gps.time_sec!=time_stamp.tm_sec) && gps.valid==true){
		set_timestamp(0,gps.time_sec,gps.time_min,gps.time_hour,gps.time_day,gps.time_month,gps.time_year);
		//gps_isreceived=false;

	}
     if(gps_update==5)
     {
    	 gps_update=0;
     }
	update_time();
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_GPIO_EXTI_Callback could be implemented in the user file
   */
}

