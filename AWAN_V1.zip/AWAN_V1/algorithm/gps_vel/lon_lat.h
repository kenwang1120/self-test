#ifndef __LONLAT_H
#define __LONLAT_H
//#include "stdbool.h"
//#include <stdint.h>
#include <math.h>
#define PI acos(-1)


double degree_to_radian(double degree);
struct lon_lat {
	double lon;//radius
	double lat;//radius
};

struct lon_lat cal_longitude_latitude(double lon,double lat,double bearing,double distance);
double cal_horizontal_acc(double acc_x,double acc_y,double acc_z,double pitch_angle,double roll_angle);
double cal_velocity(double t,double acc_horizontal,double v);
double cal_distance(double t,double acc_horizontal,double v);
void vel_bodytoNED(double vel_x,double vel_y,double vel_z,double pitch,double roll,double yaw);
//double cal_velocity(double t,double acc_horizontal,double v);
//double cal_distance(double t,double acc_horizontal,double v);

#endif

