#ifndef __TIMESTAMP_H
#define __TIMESTAMP
#include "stdbool.h"
#include <stdint.h>
#include <math.h>
#include "gps1.h"
#include <time.h>
//struct TIME_STAMP {
//	uint64_t usec;
//	uint16_t sec;
//	uint16_t min;
//	uint16_t hour;
//	uint16_t day;
//	uint16_t month;
//	uint16_t year;
//}time_stamp;

uint64_t get_usec();
void update_time();
void set_timestamp(uint64_t usec,uint16_t sec,uint16_t min,uint16_t hour,uint16_t day,uint16_t month,uint16_t year);
void usec_plus_one();
uint32_t get_timestamp_sec();
#endif

