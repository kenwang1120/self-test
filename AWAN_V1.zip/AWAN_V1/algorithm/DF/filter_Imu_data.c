/*
 * File: filter_Imu_data.c
 *
 * Code generated for Simulink model 'DF_filter'.
 *
 * Model version                  : 1.88
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 29 17:04:34 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "filter_Imu_data.h"

/* Initial conditions for atomic system: '<Root>/filter_Imu_data' */
void DF_filter_filter_Imu_data_Init(DW_filter_Imu_data_DF_filter_T *localDW)
{
  /* InitializeConditions for MATLAB Function: '<S1>/LowPass_Filter1' */
  localDW->X1_delay1 = 0.0f;
  localDW->Y1_delay1 = 0.0f;
  localDW->Z1_delay1 = 0.0f;
  localDW->Xin_delay1 = 0.0f;
  localDW->Yin_delay1 = 0.0f;
  localDW->Zin_delay1 = 0.0f;

  /* InitializeConditions for MATLAB Function: '<S1>/LowPass_Filter' */
  localDW->X1_delay2 = 0.0f;
  localDW->Y1_delay2 = 0.0f;
  localDW->Z1_delay2 = 0.0f;
  localDW->Xin_delay2 = 0.0f;
  localDW->Yin_delay2 = 0.0f;
  localDW->Zin_delay2 = 0.0f;
}

/* Output and update for atomic system: '<Root>/filter_Imu_data' */
void DF_filter_filter_Imu_data(real_T rtu_f2, real_T rtu_f1, real_T rtu_T,
  real_T rtu_Xdata, real_T rtu_Ydata, real_T rtu_Zdata,
  DW_filter_Imu_data_DF_filter_T *localDW)
{
  real_T X1;
  real_T Y1;
  real_T Z1;
  real_T PT;

  /* MATLAB Function: '<S1>/LowPass_Filter1' */
  /* MATLAB Function 'filter_Imu_data/LowPass_Filter1': '<S3>:1' */
  /* '<S3>:1:3' */
  /* '<S3>:1:34' */
  PT = 2.0f * rtu_f1 * rtu_T;

  /* '<S3>:1:35' */
  X1 = ((2.0f - PT) * localDW->X1_delay1 + (localDW->Xin_delay1 + rtu_Xdata) * PT)
    / (2.0f + PT);

  /* '<S3>:1:36' */
  Y1 = ((2.0f - PT) * localDW->Y1_delay1 + (localDW->Yin_delay1 + rtu_Ydata) * PT)
    / (2.0f + PT);

  /* '<S3>:1:37' */
  Z1 = ((2.0f - PT) * localDW->Z1_delay1 + (localDW->Zin_delay1 + rtu_Zdata) * PT)
    / (2.0f + PT);

  /* '<S3>:1:39' */
  localDW->X1_delay1 = X1;

  /* '<S3>:1:40' */
  localDW->Y1_delay1 = Y1;

  /* '<S3>:1:41' */
  localDW->Z1_delay1 = Z1;

  /* '<S3>:1:43' */
  localDW->Xin_delay1 = rtu_Xdata;

  /* '<S3>:1:44' */
  localDW->Yin_delay1 = rtu_Ydata;

  /* '<S3>:1:45' */
  localDW->Zin_delay1 = rtu_Zdata;

  /* MATLAB Function: '<S1>/LowPass_Filter' incorporates:
   *  MATLAB Function: '<S1>/LowPass_Filter1'
   */
  /* MATLAB Function 'filter_Imu_data/LowPass_Filter': '<S2>:1' */
  /* '<S2>:1:3' */
  /* '<S2>:1:34' */
  PT = 2.0f * rtu_f2 * rtu_T;

  /* '<S2>:1:35' */
  /* '<S2>:1:36' */
  /* '<S2>:1:37' */
  /* '<S2>:1:39' */
  localDW->X1_delay2 = ((2.0f - PT) * localDW->X1_delay2 + (localDW->Xin_delay2 +
    X1) * PT) / (2.0f + PT);

  /* '<S2>:1:40' */
  localDW->Y1_delay2 = ((2.0f - PT) * localDW->Y1_delay2 + (localDW->Yin_delay2 +
    Y1) * PT) / (2.0f + PT);

  /* '<S2>:1:41' */
  localDW->Z1_delay2 = ((2.0f - PT) * localDW->Z1_delay2 + (localDW->Zin_delay2 +
    Z1) * PT) / (2.0f + PT);

  /* '<S2>:1:43' */
  localDW->Xin_delay2 = X1;

  /* '<S2>:1:44' */
  localDW->Yin_delay2 = Y1;

  /* '<S2>:1:45' */
  localDW->Zin_delay2 = Z1;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
