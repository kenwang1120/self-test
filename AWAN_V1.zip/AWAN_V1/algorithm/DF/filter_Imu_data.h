/*
 * File: filter_Imu_data.h
 *
 * Code generated for Simulink model 'DF_filter'.
 *
 * Model version                  : 1.88
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 29 17:04:34 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_filter_Imu_data_h_
#define RTW_HEADER_filter_Imu_data_h_

#include "rtwtypes.h"

/* Block states (auto storage) for system '<Root>/filter_Imu_data' */
typedef struct {
  real_T X1_delay1;                    /* '<S1>/LowPass_Filter1' */
  real_T Y1_delay1;                    /* '<S1>/LowPass_Filter1' */
  real_T Z1_delay1;                    /* '<S1>/LowPass_Filter1' */
  real_T Xin_delay1;                   /* '<S1>/LowPass_Filter1' */
  real_T Yin_delay1;                   /* '<S1>/LowPass_Filter1' */
  real_T Zin_delay1;                   /* '<S1>/LowPass_Filter1' */
  real_T X1_delay2;                    /* '<S1>/LowPass_Filter' */
  real_T Y1_delay2;                    /* '<S1>/LowPass_Filter' */
  real_T Z1_delay2;                    /* '<S1>/LowPass_Filter' */
  real_T Xin_delay2;                   /* '<S1>/LowPass_Filter' */
  real_T Yin_delay2;                   /* '<S1>/LowPass_Filter' */
  real_T Zin_delay2;                   /* '<S1>/LowPass_Filter' */
} DW_filter_Imu_data_DF_filter_T;

extern void DF_filter_filter_Imu_data_Init(DW_filter_Imu_data_DF_filter_T
  *localDW);
extern void DF_filter_filter_Imu_data(real_T rtu_f2, real_T rtu_f1, real_T rtu_T,
  real_T rtu_Xdata, real_T rtu_Ydata, real_T rtu_Zdata,
  DW_filter_Imu_data_DF_filter_T *localDW);

#endif                                 /* RTW_HEADER_filter_Imu_data_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
