#include "expfcn.h"

/* exp function  */
float myexp(float x)
{
	int i,k,m,t;
	int xm=(int)x;    // xm:integer places, x:all places
	float sum;
	float e ;
	float ef;
	float z ;
	float sub=x-xm;   // separate integer places, sub = all places - integer places = decimal places
	m=1;
	e=1.0;
	ef=1.0;
	t=10;
	z=1;
	sum=1;

	if (xm<0)
	{
		xm=(-xm);
		for(k=0;k<xm;k++)
		{
			ef*=2.718281;
		}
		e/=ef;
	}
	else
	{
		for(k=0;k<xm;k++)
		{
			e*=2.718281;
		}
	}

	for(i=1;i<t;i++)
	{
		m*=i;
		z*=sub;
		sum+=z/m;
	}
	return sum*e;
}
