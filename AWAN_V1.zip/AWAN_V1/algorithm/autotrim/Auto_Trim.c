/*
 * File: Auto_Trim.c
 *
 * Code generated for Simulink model 'Auto_Trim_Fcn'.
 *
 * Model version                  : 1.242
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 27 11:02:49 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Auto_Trim.h"

/* Include model header file for global data */
#include "Auto_Trim_Fcn.h"
#include "Auto_Trim_Fcn_private.h"
#include "expfcn.h"

/* Output and update for atomic system: '<Root>/Auto_Trim' */
void IMU_Auto_Trim(real32_T rtu_INIT_IC, real32_T rtu_GX_In, real32_T rtu_GY_In,
                   real32_T rtu_GZ_In, B_IMU_Auto_Trim_T *localB,
                   DW_IMU_Auto_Trim_T *localDW, P_Auto_Trim_Fcn_T
                   *Auto_Trim_Fcn_P)
{
  real32_T rtb_S2;
  real32_T rtb_Abs_G2;
  real32_T rtb_S2_k;
  real32_T rtb_S2_c;
  real32_T rtb_Abs_G1;
  boolean_T rtb_GT_G1;
  boolean_T rtb_OUT_g;
  boolean_T rtb_GT_G1_am;
  boolean_T rtb_OUT_o;
  boolean_T rtb_GT_G1_h;
  boolean_T rtb_OUT_f;
  real32_T rtb_Sum4;
  real32_T rtb_Sum4_d;
  real32_T rtb_Sum4_i;
  real32_T rtb_Delay;
  real32_T rtb_Delay1;
  real32_T rtb_Delay2;
  real32_T rtb_Delay3;
  real32_T rtb_Delay4;
  real32_T rtb_Delay5;
  real32_T rtb_Delay6;
  real32_T rtb_Delay7;
  real32_T rtb_Delay8;
  real32_T rtb_Delay9;
  real32_T rtb_Delay10;
  real32_T rtb_Delay11;
  real32_T rtb_Delay12;
  real32_T rtb_Delay13;
  real32_T rtb_Delay14;
  real32_T rtb_Delay15;
  real32_T rtb_Delay16;
  real32_T rtb_Delay17;
  real32_T rtb_Delay18;
  real32_T rtb_Delay19;
  real32_T rtb_Delay20;
  real32_T rtb_Delay21;
  real32_T rtb_Delay22;
  real32_T rtb_Delay23;
  real32_T rtb_Delay24;
  real32_T rtb_Delay25;
  real32_T rtb_Delay26;
  real32_T rtb_Delay27;
  real32_T rtb_Delay_b;
  real32_T rtb_Delay1_e;
  real32_T rtb_Delay2_a;
  real32_T rtb_Delay3_m;
  real32_T rtb_Delay4_j;
  real32_T rtb_Delay5_e;
  real32_T rtb_Delay6_c;
  real32_T rtb_Delay7_p;
  real32_T rtb_Delay8_i;
  real32_T rtb_Delay9_d;
  real32_T rtb_Delay10_f;
  real32_T rtb_Delay11_nn;
  real32_T rtb_Delay12_b;
  real32_T rtb_Delay13_b;
  real32_T rtb_Delay14_e;
  real32_T rtb_Delay15_i;
  real32_T rtb_Delay16_j;
  real32_T rtb_Delay17_j;
  real32_T rtb_Delay18_m;
  real32_T rtb_Delay19_d;
  real32_T rtb_Delay20_c;
  real32_T rtb_Delay21_d;
  real32_T rtb_Delay22_i;
  real32_T rtb_Delay23_py;
  real32_T rtb_Delay24_h;
  real32_T rtb_Delay25_d;
  real32_T rtb_Delay26_e;
  real32_T rtb_Delay27_m;
  real32_T rtb_Delay_d;
  real32_T rtb_Delay1_n;
  real32_T rtb_Delay2_f;
  real32_T rtb_Delay3_j;
  real32_T rtb_Delay4_o;
  real32_T rtb_Delay5_j;
  real32_T rtb_Delay6_b;
  real32_T rtb_Delay7_j;
  real32_T rtb_Delay8_m;
  real32_T rtb_Delay9_k;
  real32_T rtb_Delay10_j;
  real32_T rtb_Delay11_p;
  real32_T rtb_Delay12_k;
  real32_T rtb_Delay13_o;
  real32_T rtb_Delay14_m;
  real32_T rtb_Delay15_o;
  real32_T rtb_Delay16_f;
  real32_T rtb_Delay17_f;
  real32_T rtb_Delay18_b;
  real32_T rtb_Delay19_i;
  real32_T rtb_Delay20_d;
  real32_T rtb_Delay21_i;
  real32_T rtb_Delay22_k;
  real32_T rtb_Delay23_m;
  real32_T rtb_Delay24_kl;
  real32_T rtb_Delay25_p;
  real32_T rtb_Delay26_i;
  real32_T rtb_Delay27_a;
  real32_T rtb_Xn_d;
  real32_T rtb_Xn;

  /* Delay: '<S15>/Delay' */
  rtb_Delay = localDW->Delay_DSTATE;

  /* Delay: '<S15>/Delay1' */
  rtb_Delay1 = localDW->Delay1_DSTATE;

  /* Delay: '<S15>/Delay2' */
  rtb_Delay2 = localDW->Delay2_DSTATE;

  /* Delay: '<S15>/Delay3' */
  rtb_Delay3 = localDW->Delay3_DSTATE;

  /* Delay: '<S15>/Delay4' */
  rtb_Delay4 = localDW->Delay4_DSTATE;

  /* Delay: '<S15>/Delay5' */
  rtb_Delay5 = localDW->Delay5_DSTATE;

  /* Delay: '<S15>/Delay6' */
  rtb_Delay6 = localDW->Delay6_DSTATE;

  /* Delay: '<S15>/Delay7' */
  rtb_Delay7 = localDW->Delay7_DSTATE;

  /* Delay: '<S15>/Delay8' */
  rtb_Delay8 = localDW->Delay8_DSTATE;

  /* Delay: '<S15>/Delay9' */
  rtb_Delay9 = localDW->Delay9_DSTATE;

  /* Delay: '<S15>/Delay10' */
  rtb_Delay10 = localDW->Delay10_DSTATE;

  /* Delay: '<S15>/Delay11' */
  rtb_Delay11 = localDW->Delay11_DSTATE;

  /* Delay: '<S15>/Delay12' */
  rtb_Delay12 = localDW->Delay12_DSTATE;

  /* Delay: '<S15>/Delay13' */
  rtb_Delay13 = localDW->Delay13_DSTATE;

  /* Delay: '<S15>/Delay14' */
  rtb_Delay14 = localDW->Delay14_DSTATE;

  /* Delay: '<S15>/Delay15' */
  rtb_Delay15 = localDW->Delay15_DSTATE;

  /* Delay: '<S15>/Delay16' */
  rtb_Delay16 = localDW->Delay16_DSTATE;

  /* Delay: '<S15>/Delay17' */
  rtb_Delay17 = localDW->Delay17_DSTATE;

  /* Delay: '<S15>/Delay18' */
  rtb_Delay18 = localDW->Delay18_DSTATE;

  /* Delay: '<S15>/Delay19' */
  rtb_Delay19 = localDW->Delay19_DSTATE;

  /* Delay: '<S15>/Delay20' */
  rtb_Delay20 = localDW->Delay20_DSTATE;

  /* Delay: '<S15>/Delay21' */
  rtb_Delay21 = localDW->Delay21_DSTATE;

  /* Delay: '<S15>/Delay22' */
  rtb_Delay22 = localDW->Delay22_DSTATE;

  /* Delay: '<S15>/Delay23' */
  rtb_Delay23 = localDW->Delay23_DSTATE;

  /* Delay: '<S15>/Delay24' */
  rtb_Delay24 = localDW->Delay24_DSTATE;

  /* Delay: '<S15>/Delay25' */
  rtb_Delay25 = localDW->Delay25_DSTATE;

  /* Delay: '<S15>/Delay26' */
  rtb_Delay26 = localDW->Delay26_DSTATE;

  /* Delay: '<S15>/Delay27' */
  rtb_Delay27 = localDW->Delay27_DSTATE;

  /* Switch: '<S2>/S2' incorporates:
   *  Constant: '<S2>/C_2'
   *  Constant: '<S3>/C_2'
   *  Switch: '<S3>/S2'
   */
  if (rtu_INIT_IC > 0.5F) {
    rtb_S2 = 0.0F;
    rtb_S2_k = 0.0F;
  } else {
    rtb_S2 = rtu_GX_In;
    rtb_S2_k = rtu_GY_In;
  }

  /* End of Switch: '<S2>/S2' */

  /* Delay: '<S17>/Delay' */
  rtb_Delay_b = localDW->Delay_DSTATE_e;

  /* Delay: '<S17>/Delay1' */
  rtb_Delay1_e = localDW->Delay1_DSTATE_k;

  /* Delay: '<S17>/Delay2' */
  rtb_Delay2_a = localDW->Delay2_DSTATE_k;

  /* Delay: '<S17>/Delay3' */
  rtb_Delay3_m = localDW->Delay3_DSTATE_h;

  /* Delay: '<S17>/Delay4' */
  rtb_Delay4_j = localDW->Delay4_DSTATE_b;

  /* Delay: '<S17>/Delay5' */
  rtb_Delay5_e = localDW->Delay5_DSTATE_k;

  /* Delay: '<S17>/Delay6' */
  rtb_Delay6_c = localDW->Delay6_DSTATE_m;

  /* Delay: '<S17>/Delay7' */
  rtb_Delay7_p = localDW->Delay7_DSTATE_p;

  /* Delay: '<S17>/Delay8' */
  rtb_Delay8_i = localDW->Delay8_DSTATE_d;

  /* Delay: '<S17>/Delay9' */
  rtb_Delay9_d = localDW->Delay9_DSTATE_b;

  /* Delay: '<S17>/Delay10' */
  rtb_Delay10_f = localDW->Delay10_DSTATE_m;

  /* Delay: '<S17>/Delay11' */
  rtb_Delay11_nn = localDW->Delay11_DSTATE_b;

  /* Delay: '<S17>/Delay12' */
  rtb_Delay12_b = localDW->Delay12_DSTATE_g;

  /* Delay: '<S17>/Delay13' */
  rtb_Delay13_b = localDW->Delay13_DSTATE_h;

  /* Delay: '<S17>/Delay14' */
  rtb_Delay14_e = localDW->Delay14_DSTATE_j;

  /* Delay: '<S17>/Delay15' */
  rtb_Delay15_i = localDW->Delay15_DSTATE_o;

  /* Delay: '<S17>/Delay16' */
  rtb_Delay16_j = localDW->Delay16_DSTATE_d;

  /* Delay: '<S17>/Delay17' */
  rtb_Delay17_j = localDW->Delay17_DSTATE_o;

  /* Delay: '<S17>/Delay18' */
  rtb_Delay18_m = localDW->Delay18_DSTATE_b;

  /* Delay: '<S17>/Delay19' */
  rtb_Delay19_d = localDW->Delay19_DSTATE_n;

  /* Delay: '<S17>/Delay20' */
  rtb_Delay20_c = localDW->Delay20_DSTATE_g;

  /* Delay: '<S17>/Delay21' */
  rtb_Delay21_d = localDW->Delay21_DSTATE_b;

  /* Delay: '<S17>/Delay22' */
  rtb_Delay22_i = localDW->Delay22_DSTATE_d;

  /* Delay: '<S17>/Delay23' */
  rtb_Delay23_py = localDW->Delay23_DSTATE_b;

  /* Delay: '<S17>/Delay24' */
  rtb_Delay24_h = localDW->Delay24_DSTATE_h;

  /* Delay: '<S17>/Delay25' */
  rtb_Delay25_d = localDW->Delay25_DSTATE_k;

  /* Delay: '<S17>/Delay26' */
  rtb_Delay26_e = localDW->Delay26_DSTATE_l;

  /* Delay: '<S17>/Delay27' */
  rtb_Delay27_m = localDW->Delay27_DSTATE_e;

  /* Delay: '<S19>/Delay' */
  rtb_Delay_d = localDW->Delay_DSTATE_g;

  /* Delay: '<S19>/Delay1' */
  rtb_Delay1_n = localDW->Delay1_DSTATE_b;

  /* Delay: '<S19>/Delay2' */
  rtb_Delay2_f = localDW->Delay2_DSTATE_g;

  /* Delay: '<S19>/Delay3' */
  rtb_Delay3_j = localDW->Delay3_DSTATE_b;

  /* Delay: '<S19>/Delay4' */
  rtb_Delay4_o = localDW->Delay4_DSTATE_e;

  /* Delay: '<S19>/Delay5' */
  rtb_Delay5_j = localDW->Delay5_DSTATE_a;

  /* Delay: '<S19>/Delay6' */
  rtb_Delay6_b = localDW->Delay6_DSTATE_mc;

  /* Delay: '<S19>/Delay7' */
  rtb_Delay7_j = localDW->Delay7_DSTATE_c;

  /* Delay: '<S19>/Delay8' */
  rtb_Delay8_m = localDW->Delay8_DSTATE_b;

  /* Delay: '<S19>/Delay9' */
  rtb_Delay9_k = localDW->Delay9_DSTATE_p;

  /* Delay: '<S19>/Delay10' */
  rtb_Delay10_j = localDW->Delay10_DSTATE_c;

  /* Delay: '<S19>/Delay11' */
  rtb_Delay11_p = localDW->Delay11_DSTATE_e;

  /* Delay: '<S19>/Delay12' */
  rtb_Delay12_k = localDW->Delay12_DSTATE_c;

  /* Delay: '<S19>/Delay13' */
  rtb_Delay13_o = localDW->Delay13_DSTATE_o;

  /* Delay: '<S19>/Delay14' */
  rtb_Delay14_m = localDW->Delay14_DSTATE_h;

  /* Delay: '<S19>/Delay15' */
  rtb_Delay15_o = localDW->Delay15_DSTATE_k;

  /* Delay: '<S19>/Delay16' */
  rtb_Delay16_f = localDW->Delay16_DSTATE_m;

  /* Delay: '<S19>/Delay17' */
  rtb_Delay17_f = localDW->Delay17_DSTATE_g;

  /* Delay: '<S19>/Delay18' */
  rtb_Delay18_b = localDW->Delay18_DSTATE_a;

  /* Delay: '<S19>/Delay19' */
  rtb_Delay19_i = localDW->Delay19_DSTATE_k;

  /* Delay: '<S19>/Delay20' */
  rtb_Delay20_d = localDW->Delay20_DSTATE_e;

  /* Delay: '<S19>/Delay21' */
  rtb_Delay21_i = localDW->Delay21_DSTATE_j;

  /* Delay: '<S19>/Delay22' */
  rtb_Delay22_k = localDW->Delay22_DSTATE_g;

  /* Delay: '<S19>/Delay23' */
  rtb_Delay23_m = localDW->Delay23_DSTATE_o;

  /* Delay: '<S19>/Delay24' */
  rtb_Delay24_kl = localDW->Delay24_DSTATE_a;

  /* Delay: '<S19>/Delay25' */
  rtb_Delay25_p = localDW->Delay25_DSTATE_b;

  /* Delay: '<S19>/Delay26' */
  rtb_Delay26_i = localDW->Delay26_DSTATE_d;

  /* Delay: '<S19>/Delay27' */
  rtb_Delay27_a = localDW->Delay27_DSTATE_l;

  /* Switch: '<S4>/S2' incorporates:
   *  Constant: '<S4>/C_2'
   */
  if (rtu_INIT_IC > 0.5F) {
    rtb_S2_c = 0.0F;
  } else {
    rtb_S2_c = rtu_GZ_In;
  }

  /* End of Switch: '<S4>/S2' */

  /* Sum: '<S5>/Sum4' incorporates:
   *  Delay: '<S5>/Delay'
   */
  rtb_Sum4 = rtb_S2 - localDW->Delay_DSTATE_gs;

  /* Sum: '<S6>/Sum4' incorporates:
   *  Delay: '<S6>/Delay'
   */
  rtb_Sum4_d = rtb_S2_k - localDW->Delay_DSTATE_f;

  /* Sum: '<S7>/Sum4' incorporates:
   *  Delay: '<S7>/Delay'
   */
  rtb_Sum4_i = rtb_S2_c - localDW->Delay_DSTATE_c;

  /* Abs: '<S8>/Abs_G1' */
  rtb_Abs_G2 = (real32_T)fabs(rtb_S2);

  /* Gain: '<S11>/Gain' incorporates:
   *  Memory: '<S11>/M1'
   *  Sum: '<S11>/Sum3'
   *  Switch: '<S11>/S1'
   *  Switch: '<S11>/S2'
   */
  rtb_Xn_d = (rtb_Sum4 + localDW->M1_PreviousInput) * 0.5F;

  /* Switch: '<S11>/S1' incorporates:
   *  Constant: '<S11>/P_LAG'
   *  Constant: '<S11>/P_LAG1'
   *  Fcn: '<S11>/Fcn'
   *  Memory: '<S11>/M2'
   *  Product: '<S11>/Product2'
   *  Sum: '<S11>/Sum5'
   *  Sum: '<S11>/Sum6'
   *  Switch: '<S11>/S2'
   */
  rtb_Xn_d += (real32_T)myexp(-Auto_Trim_Fcn_P->SIMTIME_DT /
    Auto_Trim_Fcn_P->G_tau3) * (localDW->M2_PreviousInput - rtb_Xn_d);

  /* RelationalOperator: '<S8>/GT_G1' incorporates:
   *  Constant: '<S8>/G_C3'
   */
  rtb_GT_G1 = (rtb_Abs_G2 > Auto_Trim_Fcn_P->G_up_Pos_limit);

  /* Logic: '<S20>/Logical Operator' incorporates:
   *  Abs: '<S8>/Abs_G2'
   *  Constant: '<S8>/G_C1'
   *  Constant: '<S8>/G_C6'
   *  Delay: '<S20>/Delay'
   *  Delay: '<S21>/Delay'
   *  Logic: '<S20>/Logical Operator1'
   *  Logic: '<S20>/Logical Operator2'
   *  Logic: '<S21>/AND'
   *  Logic: '<S8>/And_G2'
   *  RelationalOperator: '<S8>/LE_G3'
   *  RelationalOperator: '<S8>/LE_G4'
   */
  rtb_OUT_g = ((localDW->Delay_DSTATE_fd || ((rtb_Abs_G2 <=
    Auto_Trim_Fcn_P->G_low_Pos_limit) && ((real32_T)fabs(rtb_Xn_d) <=
    Auto_Trim_Fcn_P->G_low_Rate_limit))) && (!(rtb_GT_G1 &&
    localDW->Delay_DSTATE_i)));

  /* Abs: '<S9>/Abs_G1' */
  rtb_Abs_G1 = (real32_T)fabs(rtb_S2_k);

  /* Gain: '<S12>/Gain' incorporates:
   *  Memory: '<S12>/M1'
   *  Sum: '<S12>/Sum3'
   *  Switch: '<S12>/S1'
   *  Switch: '<S12>/S2'
   */
  rtb_Abs_G2 = (rtb_Sum4_d + localDW->M1_PreviousInput_h) * 0.5F;
  //rtb_Abs_G2 = (rtb_Sum4_d + localDW->M1_PreviousInput_h) * 2.5F;//timchen gyro limit 20210107

  /* Switch: '<S12>/S1' incorporates:
   *  Constant: '<S12>/P_LAG'
   *  Constant: '<S12>/P_LAG1'
   *  Fcn: '<S12>/Fcn'
   *  Memory: '<S12>/M2'
   *  Product: '<S12>/Product2'
   *  Sum: '<S12>/Sum5'
   *  Sum: '<S12>/Sum6'
   *  Switch: '<S12>/S2'
   */
  rtb_Abs_G2 += (real32_T)myexp(-Auto_Trim_Fcn_P->SIMTIME_DT /
    Auto_Trim_Fcn_P->G_tau3) * (localDW->M2_PreviousInput_n - rtb_Abs_G2);

  /* RelationalOperator: '<S9>/GT_G1' incorporates:
   *  Constant: '<S9>/G_C3'
   */
  rtb_GT_G1_am = (rtb_Abs_G1 > Auto_Trim_Fcn_P->G_up_Pos_limit);

  /* Logic: '<S22>/Logical Operator' incorporates:
   *  Abs: '<S9>/Abs_G2'
   *  Constant: '<S9>/G_C1'
   *  Constant: '<S9>/G_C6'
   *  Delay: '<S22>/Delay'
   *  Delay: '<S23>/Delay'
   *  Logic: '<S22>/Logical Operator1'
   *  Logic: '<S22>/Logical Operator2'
   *  Logic: '<S23>/AND'
   *  Logic: '<S9>/And_G2'
   *  RelationalOperator: '<S9>/LE_G3'
   *  RelationalOperator: '<S9>/LE_G4'
   */
  rtb_OUT_o = ((localDW->Delay_DSTATE_h || ((rtb_Abs_G1 <=
    Auto_Trim_Fcn_P->G_low_Pos_limit) && ((real32_T)fabs(rtb_Abs_G2) <=
    Auto_Trim_Fcn_P->G_low_Rate_limit))) && (!(rtb_GT_G1_am &&
    localDW->Delay_DSTATE_d)));

  /* Abs: '<S10>/Abs_G1' */
  rtb_Abs_G1 = (real32_T)fabs(rtb_S2_c);

  /* Gain: '<S13>/Gain' incorporates:
   *  Memory: '<S13>/M1'
   *  Sum: '<S13>/Sum3'
   *  Switch: '<S13>/S1'
   *  Switch: '<S13>/S2'
   */
  rtb_Xn = (rtb_Sum4_i + localDW->M1_PreviousInput_k) * 0.5F;

  /* Switch: '<S13>/S1' incorporates:
   *  Constant: '<S13>/P_LAG'
   *  Constant: '<S13>/P_LAG1'
   *  Fcn: '<S13>/Fcn'
   *  Memory: '<S13>/M2'
   *  Product: '<S13>/Product2'
   *  Sum: '<S13>/Sum5'
   *  Sum: '<S13>/Sum6'
   *  Switch: '<S13>/S2'
   */
  rtb_Xn += (real32_T)myexp(-Auto_Trim_Fcn_P->SIMTIME_DT / Auto_Trim_Fcn_P->G_tau3)
    * (localDW->M2_PreviousInput_a - rtb_Xn);

  /* RelationalOperator: '<S10>/GT_G1' incorporates:
   *  Constant: '<S10>/G_C3'
   */
  rtb_GT_G1_h = (rtb_Abs_G1 > Auto_Trim_Fcn_P->G_up_Pos_limit);

  /* Logic: '<S24>/Logical Operator' incorporates:
   *  Abs: '<S10>/Abs_G2'
   *  Constant: '<S10>/G_C1'
   *  Constant: '<S10>/G_C6'
   *  Delay: '<S24>/Delay'
   *  Delay: '<S25>/Delay'
   *  Logic: '<S10>/And_G2'
   *  Logic: '<S24>/Logical Operator1'
   *  Logic: '<S24>/Logical Operator2'
   *  Logic: '<S25>/AND'
   *  RelationalOperator: '<S10>/LE_G3'
   *  RelationalOperator: '<S10>/LE_G4'
   */
  rtb_OUT_f = ((localDW->Delay_DSTATE_k || ((rtb_Abs_G1 <=
    Auto_Trim_Fcn_P->G_low_Pos_limit) && ((real32_T)fabs(rtb_Xn) <=
    Auto_Trim_Fcn_P->G_low_Rate_limit))) && (!(rtb_GT_G1_h &&
    localDW->Delay_DSTATE_l)));

  /* Switch: '<S1>/S_GX' incorporates:
   *  Gain: '<S1>/K_Ax12'
   *  Sum: '<S1>/Sum4'
   */
  if ((rtb_OUT_g << 7) > 64) {
    /* Switch: '<S2>/S1' incorporates:
     *  Constant: '<S2>/C_2'
     *  Delay: '<S15>/Delay'
     *  Delay: '<S15>/Delay1'
     *  Delay: '<S15>/Delay10'
     *  Delay: '<S15>/Delay11'
     *  Delay: '<S15>/Delay12'
     *  Delay: '<S15>/Delay13'
     *  Delay: '<S15>/Delay14'
     *  Delay: '<S15>/Delay15'
     *  Delay: '<S15>/Delay16'
     *  Delay: '<S15>/Delay17'
     *  Delay: '<S15>/Delay18'
     *  Delay: '<S15>/Delay19'
     *  Delay: '<S15>/Delay2'
     *  Delay: '<S15>/Delay20'
     *  Delay: '<S15>/Delay21'
     *  Delay: '<S15>/Delay22'
     *  Delay: '<S15>/Delay23'
     *  Delay: '<S15>/Delay24'
     *  Delay: '<S15>/Delay25'
     *  Delay: '<S15>/Delay26'
     *  Delay: '<S15>/Delay27'
     *  Delay: '<S15>/Delay28'
     *  Delay: '<S15>/Delay3'
     *  Delay: '<S15>/Delay4'
     *  Delay: '<S15>/Delay5'
     *  Delay: '<S15>/Delay6'
     *  Delay: '<S15>/Delay7'
     *  Delay: '<S15>/Delay8'
     *  Delay: '<S15>/Delay9'
     *  Gain: '<S15>/Gain'
     *  Sum: '<S15>/Add'
     */
    if (rtu_INIT_IC > 0.5F) {
      rtb_Abs_G1 = 0.0F;
    } else {
      rtb_Abs_G1 = (((((((((((((((((((((((((((((rtu_GX_In +
        localDW->Delay_DSTATE) + localDW->Delay1_DSTATE) +
        localDW->Delay2_DSTATE) + localDW->Delay3_DSTATE) +
        localDW->Delay4_DSTATE) + localDW->Delay5_DSTATE) +
        localDW->Delay6_DSTATE) + localDW->Delay7_DSTATE) +
        localDW->Delay8_DSTATE) + localDW->Delay9_DSTATE) +
        localDW->Delay10_DSTATE) + localDW->Delay11_DSTATE) +
        localDW->Delay12_DSTATE) + localDW->Delay13_DSTATE) +
        localDW->Delay14_DSTATE) + localDW->Delay15_DSTATE) +
        localDW->Delay16_DSTATE) + localDW->Delay17_DSTATE) +
        localDW->Delay18_DSTATE) + localDW->Delay19_DSTATE) +
                            localDW->Delay20_DSTATE) + localDW->Delay21_DSTATE)
                          + localDW->Delay22_DSTATE) + localDW->Delay23_DSTATE)
                        + localDW->Delay24_DSTATE) + localDW->Delay25_DSTATE) +
                      localDW->Delay26_DSTATE) + localDW->Delay27_DSTATE) +
                    localDW->Delay28_DSTATE) * 0.0333333351F;
    }

    /* End of Switch: '<S2>/S1' */
    localB->S_GX = rtb_S2 - rtb_Abs_G1;
  
  } else {
    localB->S_GX = rtb_S2;
  }

  /* End of Switch: '<S1>/S_GX' */

  /* Switch: '<S1>/S_GY' incorporates:
   *  Gain: '<S1>/K_Ay'
   *  Sum: '<S1>/Sum5'
   */
  if ((rtb_OUT_o << 7) > 64) {
    /* Switch: '<S3>/S1' incorporates:
     *  Constant: '<S3>/C_2'
     *  Delay: '<S17>/Delay'
     *  Delay: '<S17>/Delay1'
     *  Delay: '<S17>/Delay10'
     *  Delay: '<S17>/Delay11'
     *  Delay: '<S17>/Delay12'
     *  Delay: '<S17>/Delay13'
     *  Delay: '<S17>/Delay14'
     *  Delay: '<S17>/Delay15'
     *  Delay: '<S17>/Delay16'
     *  Delay: '<S17>/Delay17'
     *  Delay: '<S17>/Delay18'
     *  Delay: '<S17>/Delay19'
     *  Delay: '<S17>/Delay2'
     *  Delay: '<S17>/Delay20'
     *  Delay: '<S17>/Delay21'
     *  Delay: '<S17>/Delay22'
     *  Delay: '<S17>/Delay23'
     *  Delay: '<S17>/Delay24'
     *  Delay: '<S17>/Delay25'
     *  Delay: '<S17>/Delay26'
     *  Delay: '<S17>/Delay27'
     *  Delay: '<S17>/Delay28'
     *  Delay: '<S17>/Delay3'
     *  Delay: '<S17>/Delay4'
     *  Delay: '<S17>/Delay5'
     *  Delay: '<S17>/Delay6'
     *  Delay: '<S17>/Delay7'
     *  Delay: '<S17>/Delay8'
     *  Delay: '<S17>/Delay9'
     *  Gain: '<S17>/Gain'
     *  Sum: '<S17>/Add'
     */
    if (rtu_INIT_IC > 0.5F) {
      rtb_Abs_G1 = 0.0F;
    } else {
      rtb_Abs_G1 = (((((((((((((((((((((((((((((rtu_GY_In +
        localDW->Delay_DSTATE_e) + localDW->Delay1_DSTATE_k) +
        localDW->Delay2_DSTATE_k) + localDW->Delay3_DSTATE_h) +
        localDW->Delay4_DSTATE_b) + localDW->Delay5_DSTATE_k) +
        localDW->Delay6_DSTATE_m) + localDW->Delay7_DSTATE_p) +
        localDW->Delay8_DSTATE_d) + localDW->Delay9_DSTATE_b) +
        localDW->Delay10_DSTATE_m) + localDW->Delay11_DSTATE_b) +
        localDW->Delay12_DSTATE_g) + localDW->Delay13_DSTATE_h) +
        localDW->Delay14_DSTATE_j) + localDW->Delay15_DSTATE_o) +
        localDW->Delay16_DSTATE_d) + localDW->Delay17_DSTATE_o) +
        localDW->Delay18_DSTATE_b) + localDW->Delay19_DSTATE_n) +
                            localDW->Delay20_DSTATE_g) +
                           localDW->Delay21_DSTATE_b) +
                          localDW->Delay22_DSTATE_d) + localDW->Delay23_DSTATE_b)
                        + localDW->Delay24_DSTATE_h) + localDW->Delay25_DSTATE_k)
                      + localDW->Delay26_DSTATE_l) + localDW->Delay27_DSTATE_e)
                    + localDW->Delay28_DSTATE_e) * 0.0333333351F;
    }

    /* End of Switch: '<S3>/S1' */
    localB->S_GY = rtb_S2_k - rtb_Abs_G1;

  } else {
    localB->S_GY = rtb_S2_k;
  }

  /* End of Switch: '<S1>/S_GY' */

  /* Switch: '<S1>/S_GZ' incorporates:
   *  Gain: '<S1>/K_Az'
   *  Sum: '<S1>/Sum6'
   */
  if ((rtb_OUT_f << 7) > 64) {
    /* Switch: '<S4>/S1' incorporates:
     *  Constant: '<S4>/C_2'
     *  Delay: '<S19>/Delay'
     *  Delay: '<S19>/Delay1'
     *  Delay: '<S19>/Delay10'
     *  Delay: '<S19>/Delay11'
     *  Delay: '<S19>/Delay12'
     *  Delay: '<S19>/Delay13'
     *  Delay: '<S19>/Delay14'
     *  Delay: '<S19>/Delay15'
     *  Delay: '<S19>/Delay16'
     *  Delay: '<S19>/Delay17'
     *  Delay: '<S19>/Delay18'
     *  Delay: '<S19>/Delay19'
     *  Delay: '<S19>/Delay2'
     *  Delay: '<S19>/Delay20'
     *  Delay: '<S19>/Delay21'
     *  Delay: '<S19>/Delay22'
     *  Delay: '<S19>/Delay23'
     *  Delay: '<S19>/Delay24'
     *  Delay: '<S19>/Delay25'
     *  Delay: '<S19>/Delay26'
     *  Delay: '<S19>/Delay27'
     *  Delay: '<S19>/Delay28'
     *  Delay: '<S19>/Delay3'
     *  Delay: '<S19>/Delay4'
     *  Delay: '<S19>/Delay5'
     *  Delay: '<S19>/Delay6'
     *  Delay: '<S19>/Delay7'
     *  Delay: '<S19>/Delay8'
     *  Delay: '<S19>/Delay9'
     *  Gain: '<S19>/Gain'
     *  Sum: '<S19>/Add'
     */
    if (rtu_INIT_IC > 0.5F) {
      rtb_Abs_G1 = 0.0F;
    } else {
      rtb_Abs_G1 = (((((((((((((((((((((((((((((rtu_GZ_In +
        localDW->Delay_DSTATE_g) + localDW->Delay1_DSTATE_b) +
        localDW->Delay2_DSTATE_g) + localDW->Delay3_DSTATE_b) +
        localDW->Delay4_DSTATE_e) + localDW->Delay5_DSTATE_a) +
        localDW->Delay6_DSTATE_mc) + localDW->Delay7_DSTATE_c) +
        localDW->Delay8_DSTATE_b) + localDW->Delay9_DSTATE_p) +
        localDW->Delay10_DSTATE_c) + localDW->Delay11_DSTATE_e) +
        localDW->Delay12_DSTATE_c) + localDW->Delay13_DSTATE_o) +
        localDW->Delay14_DSTATE_h) + localDW->Delay15_DSTATE_k) +
        localDW->Delay16_DSTATE_m) + localDW->Delay17_DSTATE_g) +
        localDW->Delay18_DSTATE_a) + localDW->Delay19_DSTATE_k) +
                            localDW->Delay20_DSTATE_e) +
                           localDW->Delay21_DSTATE_j) +
                          localDW->Delay22_DSTATE_g) + localDW->Delay23_DSTATE_o)
                        + localDW->Delay24_DSTATE_a) + localDW->Delay25_DSTATE_b)
                      + localDW->Delay26_DSTATE_d) + localDW->Delay27_DSTATE_l)
                    + localDW->Delay28_DSTATE_g) * 0.0333333351F;
    }

    /* End of Switch: '<S4>/S1' */
    localB->S_GZ = rtb_S2_c - rtb_Abs_G1;

  } else {
    localB->S_GZ = rtb_S2_c;
  }

  /* End of Switch: '<S1>/S_GZ' */

  /* Update for Delay: '<S15>/Delay' */
  localDW->Delay_DSTATE = rtu_GX_In;

  /* Update for Delay: '<S15>/Delay1' */
  localDW->Delay1_DSTATE = rtb_Delay;

  /* Update for Delay: '<S15>/Delay2' */
  localDW->Delay2_DSTATE = rtb_Delay1;

  /* Update for Delay: '<S15>/Delay3' */
  localDW->Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S15>/Delay4' */
  localDW->Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S15>/Delay5' */
  localDW->Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S15>/Delay6' */
  localDW->Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S15>/Delay7' */
  localDW->Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S15>/Delay8' */
  localDW->Delay8_DSTATE = rtb_Delay7;

  /* Update for Delay: '<S15>/Delay9' */
  localDW->Delay9_DSTATE = rtb_Delay8;

  /* Update for Delay: '<S15>/Delay10' */
  localDW->Delay10_DSTATE = rtb_Delay9;

  /* Update for Delay: '<S15>/Delay11' */
  localDW->Delay11_DSTATE = rtb_Delay10;

  /* Update for Delay: '<S15>/Delay12' */
  localDW->Delay12_DSTATE = rtb_Delay11;

  /* Update for Delay: '<S15>/Delay13' */
  localDW->Delay13_DSTATE = rtb_Delay12;

  /* Update for Delay: '<S15>/Delay14' */
  localDW->Delay14_DSTATE = rtb_Delay13;

  /* Update for Delay: '<S15>/Delay15' */
  localDW->Delay15_DSTATE = rtb_Delay14;

  /* Update for Delay: '<S15>/Delay16' */
  localDW->Delay16_DSTATE = rtb_Delay15;

  /* Update for Delay: '<S15>/Delay17' */
  localDW->Delay17_DSTATE = rtb_Delay16;

  /* Update for Delay: '<S15>/Delay18' */
  localDW->Delay18_DSTATE = rtb_Delay17;

  /* Update for Delay: '<S15>/Delay19' */
  localDW->Delay19_DSTATE = rtb_Delay18;

  /* Update for Delay: '<S15>/Delay20' */
  localDW->Delay20_DSTATE = rtb_Delay19;

  /* Update for Delay: '<S15>/Delay21' */
  localDW->Delay21_DSTATE = rtb_Delay20;

  /* Update for Delay: '<S15>/Delay22' */
  localDW->Delay22_DSTATE = rtb_Delay21;

  /* Update for Delay: '<S15>/Delay23' */
  localDW->Delay23_DSTATE = rtb_Delay22;

  /* Update for Delay: '<S15>/Delay24' */
  localDW->Delay24_DSTATE = rtb_Delay23;

  /* Update for Delay: '<S15>/Delay25' */
  localDW->Delay25_DSTATE = rtb_Delay24;

  /* Update for Delay: '<S15>/Delay26' */
  localDW->Delay26_DSTATE = rtb_Delay25;

  /* Update for Delay: '<S15>/Delay27' */
  localDW->Delay27_DSTATE = rtb_Delay26;

  /* Update for Delay: '<S15>/Delay28' */
  localDW->Delay28_DSTATE = rtb_Delay27;

  /* Update for Delay: '<S17>/Delay' */
  localDW->Delay_DSTATE_e = rtu_GY_In;

  /* Update for Delay: '<S17>/Delay1' */
  localDW->Delay1_DSTATE_k = rtb_Delay_b;

  /* Update for Delay: '<S17>/Delay2' */
  localDW->Delay2_DSTATE_k = rtb_Delay1_e;

  /* Update for Delay: '<S17>/Delay3' */
  localDW->Delay3_DSTATE_h = rtb_Delay2_a;

  /* Update for Delay: '<S17>/Delay4' */
  localDW->Delay4_DSTATE_b = rtb_Delay3_m;

  /* Update for Delay: '<S17>/Delay5' */
  localDW->Delay5_DSTATE_k = rtb_Delay4_j;

  /* Update for Delay: '<S17>/Delay6' */
  localDW->Delay6_DSTATE_m = rtb_Delay5_e;

  /* Update for Delay: '<S17>/Delay7' */
  localDW->Delay7_DSTATE_p = rtb_Delay6_c;

  /* Update for Delay: '<S17>/Delay8' */
  localDW->Delay8_DSTATE_d = rtb_Delay7_p;

  /* Update for Delay: '<S17>/Delay9' */
  localDW->Delay9_DSTATE_b = rtb_Delay8_i;

  /* Update for Delay: '<S17>/Delay10' */
  localDW->Delay10_DSTATE_m = rtb_Delay9_d;

  /* Update for Delay: '<S17>/Delay11' */
  localDW->Delay11_DSTATE_b = rtb_Delay10_f;

  /* Update for Delay: '<S17>/Delay12' */
  localDW->Delay12_DSTATE_g = rtb_Delay11_nn;

  /* Update for Delay: '<S17>/Delay13' */
  localDW->Delay13_DSTATE_h = rtb_Delay12_b;

  /* Update for Delay: '<S17>/Delay14' */
  localDW->Delay14_DSTATE_j = rtb_Delay13_b;

  /* Update for Delay: '<S17>/Delay15' */
  localDW->Delay15_DSTATE_o = rtb_Delay14_e;

  /* Update for Delay: '<S17>/Delay16' */
  localDW->Delay16_DSTATE_d = rtb_Delay15_i;

  /* Update for Delay: '<S17>/Delay17' */
  localDW->Delay17_DSTATE_o = rtb_Delay16_j;

  /* Update for Delay: '<S17>/Delay18' */
  localDW->Delay18_DSTATE_b = rtb_Delay17_j;

  /* Update for Delay: '<S17>/Delay19' */
  localDW->Delay19_DSTATE_n = rtb_Delay18_m;

  /* Update for Delay: '<S17>/Delay20' */
  localDW->Delay20_DSTATE_g = rtb_Delay19_d;

  /* Update for Delay: '<S17>/Delay21' */
  localDW->Delay21_DSTATE_b = rtb_Delay20_c;

  /* Update for Delay: '<S17>/Delay22' */
  localDW->Delay22_DSTATE_d = rtb_Delay21_d;

  /* Update for Delay: '<S17>/Delay23' */
  localDW->Delay23_DSTATE_b = rtb_Delay22_i;

  /* Update for Delay: '<S17>/Delay24' */
  localDW->Delay24_DSTATE_h = rtb_Delay23_py;

  /* Update for Delay: '<S17>/Delay25' */
  localDW->Delay25_DSTATE_k = rtb_Delay24_h;

  /* Update for Delay: '<S17>/Delay26' */
  localDW->Delay26_DSTATE_l = rtb_Delay25_d;

  /* Update for Delay: '<S17>/Delay27' */
  localDW->Delay27_DSTATE_e = rtb_Delay26_e;

  /* Update for Delay: '<S17>/Delay28' */
  localDW->Delay28_DSTATE_e = rtb_Delay27_m;

  /* Update for Delay: '<S19>/Delay' */
  localDW->Delay_DSTATE_g = rtu_GZ_In;

  /* Update for Delay: '<S19>/Delay1' */
  localDW->Delay1_DSTATE_b = rtb_Delay_d;

  /* Update for Delay: '<S19>/Delay2' */
  localDW->Delay2_DSTATE_g = rtb_Delay1_n;

  /* Update for Delay: '<S19>/Delay3' */
  localDW->Delay3_DSTATE_b = rtb_Delay2_f;

  /* Update for Delay: '<S19>/Delay4' */
  localDW->Delay4_DSTATE_e = rtb_Delay3_j;

  /* Update for Delay: '<S19>/Delay5' */
  localDW->Delay5_DSTATE_a = rtb_Delay4_o;

  /* Update for Delay: '<S19>/Delay6' */
  localDW->Delay6_DSTATE_mc = rtb_Delay5_j;

  /* Update for Delay: '<S19>/Delay7' */
  localDW->Delay7_DSTATE_c = rtb_Delay6_b;

  /* Update for Delay: '<S19>/Delay8' */
  localDW->Delay8_DSTATE_b = rtb_Delay7_j;

  /* Update for Delay: '<S19>/Delay9' */
  localDW->Delay9_DSTATE_p = rtb_Delay8_m;

  /* Update for Delay: '<S19>/Delay10' */
  localDW->Delay10_DSTATE_c = rtb_Delay9_k;

  /* Update for Delay: '<S19>/Delay11' */
  localDW->Delay11_DSTATE_e = rtb_Delay10_j;

  /* Update for Delay: '<S19>/Delay12' */
  localDW->Delay12_DSTATE_c = rtb_Delay11_p;

  /* Update for Delay: '<S19>/Delay13' */
  localDW->Delay13_DSTATE_o = rtb_Delay12_k;

  /* Update for Delay: '<S19>/Delay14' */
  localDW->Delay14_DSTATE_h = rtb_Delay13_o;

  /* Update for Delay: '<S19>/Delay15' */
  localDW->Delay15_DSTATE_k = rtb_Delay14_m;

  /* Update for Delay: '<S19>/Delay16' */
  localDW->Delay16_DSTATE_m = rtb_Delay15_o;

  /* Update for Delay: '<S19>/Delay17' */
  localDW->Delay17_DSTATE_g = rtb_Delay16_f;

  /* Update for Delay: '<S19>/Delay18' */
  localDW->Delay18_DSTATE_a = rtb_Delay17_f;

  /* Update for Delay: '<S19>/Delay19' */
  localDW->Delay19_DSTATE_k = rtb_Delay18_b;

  /* Update for Delay: '<S19>/Delay20' */
  localDW->Delay20_DSTATE_e = rtb_Delay19_i;

  /* Update for Delay: '<S19>/Delay21' */
  localDW->Delay21_DSTATE_j = rtb_Delay20_d;

  /* Update for Delay: '<S19>/Delay22' */
  localDW->Delay22_DSTATE_g = rtb_Delay21_i;

  /* Update for Delay: '<S19>/Delay23' */
  localDW->Delay23_DSTATE_o = rtb_Delay22_k;

  /* Update for Delay: '<S19>/Delay24' */
  localDW->Delay24_DSTATE_a = rtb_Delay23_m;

  /* Update for Delay: '<S19>/Delay25' */
  localDW->Delay25_DSTATE_b = rtb_Delay24_kl;

  /* Update for Delay: '<S19>/Delay26' */
  localDW->Delay26_DSTATE_d = rtb_Delay25_p;

  /* Update for Delay: '<S19>/Delay27' */
  localDW->Delay27_DSTATE_l = rtb_Delay26_i;

  /* Update for Delay: '<S19>/Delay28' */
  localDW->Delay28_DSTATE_g = rtb_Delay27_a;

  /* Update for Delay: '<S5>/Delay' */
  localDW->Delay_DSTATE_gs = rtb_S2;

  /* Update for Delay: '<S6>/Delay' */
  localDW->Delay_DSTATE_f = rtb_S2_k;

  /* Update for Delay: '<S7>/Delay' */
  localDW->Delay_DSTATE_c = rtb_S2_c;

  /* Update for Memory: '<S11>/M2' */
  localDW->M2_PreviousInput = rtb_Xn_d;

  /* Update for Memory: '<S11>/M1' */
  localDW->M1_PreviousInput = rtb_Sum4;

  /* Update for Delay: '<S20>/Delay' */
  localDW->Delay_DSTATE_fd = rtb_OUT_g;

  /* Update for Delay: '<S21>/Delay' */
  localDW->Delay_DSTATE_i = rtb_GT_G1;

  /* Update for Memory: '<S12>/M2' */
  localDW->M2_PreviousInput_n = rtb_Abs_G2;

  /* Update for Memory: '<S12>/M1' */
  localDW->M1_PreviousInput_h = rtb_Sum4_d;

  /* Update for Delay: '<S22>/Delay' */
  localDW->Delay_DSTATE_h = rtb_OUT_o;

  /* Update for Delay: '<S23>/Delay' */
  localDW->Delay_DSTATE_d = rtb_GT_G1_am;

  /* Update for Memory: '<S13>/M2' */
  localDW->M2_PreviousInput_a = rtb_Xn;

  /* Update for Memory: '<S13>/M1' */
  localDW->M1_PreviousInput_k = rtb_Sum4_i;

  /* Update for Delay: '<S24>/Delay' */
  localDW->Delay_DSTATE_k = rtb_OUT_f;

  /* Update for Delay: '<S25>/Delay' */
  localDW->Delay_DSTATE_l = rtb_GT_G1_h;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
