/*
 * File: Auto_Trim_Fcn.c
 *
 * Code generated for Simulink model 'Auto_Trim_Fcn'.
 *
 * Model version                  : 1.242
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 27 11:02:49 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Auto_Trim_Fcn.h"
#include "Auto_Trim_Fcn_private.h"

/* Model step function */
void Auto_Trim_Fcn_step(RT_MODEL_Auto_Trim_Fcn_T *const Auto_Trim_Fcn_M,
  real32_T Auto_Trim_Fcn_U_INIT_C, real32_T Auto_Trim_Fcn_U_GX_In, real32_T
  Auto_Trim_Fcn_U_GY_In, real32_T Auto_Trim_Fcn_U_GZ_In, real32_T
  *Auto_Trim_Fcn_Y_GX_out, real32_T *Auto_Trim_Fcn_Y_GY_out, real32_T
  *Auto_Trim_Fcn_Y_GZ_out)
{
  P_Auto_Trim_Fcn_T *Auto_Trim_Fcn_P = ((P_Auto_Trim_Fcn_T *)
    Auto_Trim_Fcn_M->ModelData.defaultParam);
  B_Auto_Trim_Fcn_T *Auto_Trim_Fcn_B = ((B_Auto_Trim_Fcn_T *)
    Auto_Trim_Fcn_M->ModelData.blockIO);
  DW_Auto_Trim_Fcn_T *Auto_Trim_Fcn_DW = ((DW_Auto_Trim_Fcn_T *)
    Auto_Trim_Fcn_M->ModelData.dwork);

  /* Outputs for Atomic SubSystem: '<Root>/Auto_Trim' */

  /* Inport: '<Root>/INIT_C' incorporates:
   *  Inport: '<Root>/GX_In'
   *  Inport: '<Root>/GY_In'
   *  Inport: '<Root>/GZ_In'
   */
  IMU_Auto_Trim(Auto_Trim_Fcn_U_INIT_C, Auto_Trim_Fcn_U_GX_In,
                Auto_Trim_Fcn_U_GY_In, Auto_Trim_Fcn_U_GZ_In,
                &Auto_Trim_Fcn_B->Auto_Trim, &Auto_Trim_Fcn_DW->Auto_Trim,
                Auto_Trim_Fcn_P);

  /* End of Outputs for SubSystem: '<Root>/Auto_Trim' */

  /* Outport: '<Root>/GX_out' */
  *Auto_Trim_Fcn_Y_GX_out = Auto_Trim_Fcn_B->Auto_Trim.S_GX;

  /* Outport: '<Root>/GY_out' */
  *Auto_Trim_Fcn_Y_GY_out = Auto_Trim_Fcn_B->Auto_Trim.S_GY;

  /* Outport: '<Root>/GZ_out' */
  *Auto_Trim_Fcn_Y_GZ_out = Auto_Trim_Fcn_B->Auto_Trim.S_GZ;
}

/* Model initialize function */
void Auto_Trim_Fcn_initialize(RT_MODEL_Auto_Trim_Fcn_T *const Auto_Trim_Fcn_M,
  real32_T *Auto_Trim_Fcn_U_INIT_C, real32_T *Auto_Trim_Fcn_U_GX_In, real32_T
  *Auto_Trim_Fcn_U_GY_In, real32_T *Auto_Trim_Fcn_U_GZ_In, real32_T
  *Auto_Trim_Fcn_Y_GX_out, real32_T *Auto_Trim_Fcn_Y_GY_out, real32_T
  *Auto_Trim_Fcn_Y_GZ_out)
{
  B_Auto_Trim_Fcn_T *Auto_Trim_Fcn_B = ((B_Auto_Trim_Fcn_T *)
    Auto_Trim_Fcn_M->ModelData.blockIO);
  DW_Auto_Trim_Fcn_T *Auto_Trim_Fcn_DW = ((DW_Auto_Trim_Fcn_T *)
    Auto_Trim_Fcn_M->ModelData.dwork);

  /* Registration code */

  /* block I/O */
  (void) memset(((void *) Auto_Trim_Fcn_B), 0,
                sizeof(B_Auto_Trim_Fcn_T));

  /* states (dwork) */
  (void) memset((void *)Auto_Trim_Fcn_DW, 0,
                sizeof(DW_Auto_Trim_Fcn_T));

  /* external inputs */
  (*Auto_Trim_Fcn_U_INIT_C) = 0.0F;
  (*Auto_Trim_Fcn_U_GX_In) = 0.0F;
  (*Auto_Trim_Fcn_U_GY_In) = 0.0F;
  (*Auto_Trim_Fcn_U_GZ_In) = 0.0F;

  /* external outputs */
  (*Auto_Trim_Fcn_Y_GX_out) = 0.0F;
  (*Auto_Trim_Fcn_Y_GY_out) = 0.0F;
  (*Auto_Trim_Fcn_Y_GZ_out) = 0.0F;
}

/* Model terminate function */
void Auto_Trim_Fcn_terminate(RT_MODEL_Auto_Trim_Fcn_T *const Auto_Trim_Fcn_M)
{
  /* (no terminate code required) */
  UNUSED_PARAMETER(Auto_Trim_Fcn_M);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
