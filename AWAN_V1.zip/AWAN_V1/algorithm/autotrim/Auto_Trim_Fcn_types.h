/*
 * File: Auto_Trim_Fcn_types.h
 *
 * Code generated for Simulink model 'Auto_Trim_Fcn'.
 *
 * Model version                  : 1.242
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 27 11:02:49 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Auto_Trim_Fcn_types_h_
#define RTW_HEADER_Auto_Trim_Fcn_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_Auto_Trim_Fcn_T_ P_Auto_Trim_Fcn_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Auto_Trim_Fcn_T RT_MODEL_Auto_Trim_Fcn_T;

#endif                                 /* RTW_HEADER_Auto_Trim_Fcn_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
