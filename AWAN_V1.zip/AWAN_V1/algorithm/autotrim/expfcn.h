#ifndef _EXPFCN_H_
#define _EXPFCN_H_
#include "rtwtypes.h"
float myexp(float x);

#endif //_EXPFCN_H_
