/*
 * File: Auto_Trim.h
 *
 * Code generated for Simulink model 'Auto_Trim_Fcn'.
 *
 * Model version                  : 1.242
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 27 11:02:49 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Auto_Trim_h_
#define RTW_HEADER_Auto_Trim_h_
#include <math.h>
#ifndef Auto_Trim_Fcn_COMMON_INCLUDES_
# define Auto_Trim_Fcn_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* Auto_Trim_Fcn_COMMON_INCLUDES_ */

#include "Auto_Trim_Fcn_types.h"

/* Block signals for system '<Root>/Auto_Trim' */
typedef struct {
  real32_T S_GX;                       /* '<S1>/S_GX' */
  real32_T S_GY;                       /* '<S1>/S_GY' */
  real32_T S_GZ;                       /* '<S1>/S_GZ' */
} B_IMU_Auto_Trim_T;

/* Block states (auto storage) for system '<Root>/Auto_Trim' */
typedef struct {
  real32_T Delay_DSTATE;               /* '<S15>/Delay' */
  real32_T Delay1_DSTATE;              /* '<S15>/Delay1' */
  real32_T Delay2_DSTATE;              /* '<S15>/Delay2' */
  real32_T Delay3_DSTATE;              /* '<S15>/Delay3' */
  real32_T Delay4_DSTATE;              /* '<S15>/Delay4' */
  real32_T Delay5_DSTATE;              /* '<S15>/Delay5' */
  real32_T Delay6_DSTATE;              /* '<S15>/Delay6' */
  real32_T Delay7_DSTATE;              /* '<S15>/Delay7' */
  real32_T Delay8_DSTATE;              /* '<S15>/Delay8' */
  real32_T Delay9_DSTATE;              /* '<S15>/Delay9' */
  real32_T Delay10_DSTATE;             /* '<S15>/Delay10' */
  real32_T Delay11_DSTATE;             /* '<S15>/Delay11' */
  real32_T Delay12_DSTATE;             /* '<S15>/Delay12' */
  real32_T Delay13_DSTATE;             /* '<S15>/Delay13' */
  real32_T Delay14_DSTATE;             /* '<S15>/Delay14' */
  real32_T Delay15_DSTATE;             /* '<S15>/Delay15' */
  real32_T Delay16_DSTATE;             /* '<S15>/Delay16' */
  real32_T Delay17_DSTATE;             /* '<S15>/Delay17' */
  real32_T Delay18_DSTATE;             /* '<S15>/Delay18' */
  real32_T Delay19_DSTATE;             /* '<S15>/Delay19' */
  real32_T Delay20_DSTATE;             /* '<S15>/Delay20' */
  real32_T Delay21_DSTATE;             /* '<S15>/Delay21' */
  real32_T Delay22_DSTATE;             /* '<S15>/Delay22' */
  real32_T Delay23_DSTATE;             /* '<S15>/Delay23' */
  real32_T Delay24_DSTATE;             /* '<S15>/Delay24' */
  real32_T Delay25_DSTATE;             /* '<S15>/Delay25' */
  real32_T Delay26_DSTATE;             /* '<S15>/Delay26' */
  real32_T Delay27_DSTATE;             /* '<S15>/Delay27' */
  real32_T Delay28_DSTATE;             /* '<S15>/Delay28' */
  real32_T Delay_DSTATE_e;             /* '<S17>/Delay' */
  real32_T Delay1_DSTATE_k;            /* '<S17>/Delay1' */
  real32_T Delay2_DSTATE_k;            /* '<S17>/Delay2' */
  real32_T Delay3_DSTATE_h;            /* '<S17>/Delay3' */
  real32_T Delay4_DSTATE_b;            /* '<S17>/Delay4' */
  real32_T Delay5_DSTATE_k;            /* '<S17>/Delay5' */
  real32_T Delay6_DSTATE_m;            /* '<S17>/Delay6' */
  real32_T Delay7_DSTATE_p;            /* '<S17>/Delay7' */
  real32_T Delay8_DSTATE_d;            /* '<S17>/Delay8' */
  real32_T Delay9_DSTATE_b;            /* '<S17>/Delay9' */
  real32_T Delay10_DSTATE_m;           /* '<S17>/Delay10' */
  real32_T Delay11_DSTATE_b;           /* '<S17>/Delay11' */
  real32_T Delay12_DSTATE_g;           /* '<S17>/Delay12' */
  real32_T Delay13_DSTATE_h;           /* '<S17>/Delay13' */
  real32_T Delay14_DSTATE_j;           /* '<S17>/Delay14' */
  real32_T Delay15_DSTATE_o;           /* '<S17>/Delay15' */
  real32_T Delay16_DSTATE_d;           /* '<S17>/Delay16' */
  real32_T Delay17_DSTATE_o;           /* '<S17>/Delay17' */
  real32_T Delay18_DSTATE_b;           /* '<S17>/Delay18' */
  real32_T Delay19_DSTATE_n;           /* '<S17>/Delay19' */
  real32_T Delay20_DSTATE_g;           /* '<S17>/Delay20' */
  real32_T Delay21_DSTATE_b;           /* '<S17>/Delay21' */
  real32_T Delay22_DSTATE_d;           /* '<S17>/Delay22' */
  real32_T Delay23_DSTATE_b;           /* '<S17>/Delay23' */
  real32_T Delay24_DSTATE_h;           /* '<S17>/Delay24' */
  real32_T Delay25_DSTATE_k;           /* '<S17>/Delay25' */
  real32_T Delay26_DSTATE_l;           /* '<S17>/Delay26' */
  real32_T Delay27_DSTATE_e;           /* '<S17>/Delay27' */
  real32_T Delay28_DSTATE_e;           /* '<S17>/Delay28' */
  real32_T Delay_DSTATE_g;             /* '<S19>/Delay' */
  real32_T Delay1_DSTATE_b;            /* '<S19>/Delay1' */
  real32_T Delay2_DSTATE_g;            /* '<S19>/Delay2' */
  real32_T Delay3_DSTATE_b;            /* '<S19>/Delay3' */
  real32_T Delay4_DSTATE_e;            /* '<S19>/Delay4' */
  real32_T Delay5_DSTATE_a;            /* '<S19>/Delay5' */
  real32_T Delay6_DSTATE_mc;           /* '<S19>/Delay6' */
  real32_T Delay7_DSTATE_c;            /* '<S19>/Delay7' */
  real32_T Delay8_DSTATE_b;            /* '<S19>/Delay8' */
  real32_T Delay9_DSTATE_p;            /* '<S19>/Delay9' */
  real32_T Delay10_DSTATE_c;           /* '<S19>/Delay10' */
  real32_T Delay11_DSTATE_e;           /* '<S19>/Delay11' */
  real32_T Delay12_DSTATE_c;           /* '<S19>/Delay12' */
  real32_T Delay13_DSTATE_o;           /* '<S19>/Delay13' */
  real32_T Delay14_DSTATE_h;           /* '<S19>/Delay14' */
  real32_T Delay15_DSTATE_k;           /* '<S19>/Delay15' */
  real32_T Delay16_DSTATE_m;           /* '<S19>/Delay16' */
  real32_T Delay17_DSTATE_g;           /* '<S19>/Delay17' */
  real32_T Delay18_DSTATE_a;           /* '<S19>/Delay18' */
  real32_T Delay19_DSTATE_k;           /* '<S19>/Delay19' */
  real32_T Delay20_DSTATE_e;           /* '<S19>/Delay20' */
  real32_T Delay21_DSTATE_j;           /* '<S19>/Delay21' */
  real32_T Delay22_DSTATE_g;           /* '<S19>/Delay22' */
  real32_T Delay23_DSTATE_o;           /* '<S19>/Delay23' */
  real32_T Delay24_DSTATE_a;           /* '<S19>/Delay24' */
  real32_T Delay25_DSTATE_b;           /* '<S19>/Delay25' */
  real32_T Delay26_DSTATE_d;           /* '<S19>/Delay26' */
  real32_T Delay27_DSTATE_l;           /* '<S19>/Delay27' */
  real32_T Delay28_DSTATE_g;           /* '<S19>/Delay28' */
  real32_T Delay_DSTATE_gs;            /* '<S5>/Delay' */
  real32_T Delay_DSTATE_f;             /* '<S6>/Delay' */
  real32_T Delay_DSTATE_c;             /* '<S7>/Delay' */
  real32_T M2_PreviousInput;           /* '<S11>/M2' */
  real32_T M1_PreviousInput;           /* '<S11>/M1' */
  real32_T M2_PreviousInput_n;         /* '<S12>/M2' */
  real32_T M1_PreviousInput_h;         /* '<S12>/M1' */
  real32_T M2_PreviousInput_a;         /* '<S13>/M2' */
  real32_T M1_PreviousInput_k;         /* '<S13>/M1' */
  boolean_T Delay_DSTATE_fd;           /* '<S20>/Delay' */
  boolean_T Delay_DSTATE_i;            /* '<S21>/Delay' */
  boolean_T Delay_DSTATE_h;            /* '<S22>/Delay' */
  boolean_T Delay_DSTATE_d;            /* '<S23>/Delay' */
  boolean_T Delay_DSTATE_k;            /* '<S24>/Delay' */
  boolean_T Delay_DSTATE_l;            /* '<S25>/Delay' */
} DW_IMU_Auto_Trim_T;

extern void IMU_Auto_Trim(real32_T rtu_INIT_IC, real32_T rtu_GX_In, real32_T
  rtu_GY_In, real32_T rtu_GZ_In, B_IMU_Auto_Trim_T *localB, DW_IMU_Auto_Trim_T
  *localDW, P_Auto_Trim_Fcn_T *Auto_Trim_Fcn_P);

#endif                                 /* RTW_HEADER_Auto_Trim_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
