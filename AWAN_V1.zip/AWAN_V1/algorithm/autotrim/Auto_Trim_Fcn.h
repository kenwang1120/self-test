/*
 * File: Auto_Trim_Fcn.h
 *
 * Code generated for Simulink model 'Auto_Trim_Fcn'.
 *
 * Model version                  : 1.242
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Wed May 27 11:02:49 2020
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Auto_Trim_Fcn_h_
#define RTW_HEADER_Auto_Trim_Fcn_h_
#include <string.h>
#ifndef Auto_Trim_Fcn_COMMON_INCLUDES_
# define Auto_Trim_Fcn_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* Auto_Trim_Fcn_COMMON_INCLUDES_ */

#include "Auto_Trim_Fcn_types.h"

/* Child system includes */
#include "Auto_Trim.h"
#include "rt_defines.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (auto storage) */
typedef struct {
  B_IMU_Auto_Trim_T Auto_Trim;         /* '<Root>/Auto_Trim' */
} B_Auto_Trim_Fcn_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  DW_IMU_Auto_Trim_T Auto_Trim;        /* '<Root>/Auto_Trim' */
} DW_Auto_Trim_Fcn_T;

/* Parameters (auto storage) */
struct P_Auto_Trim_Fcn_T_ {
  real32_T G_low_Pos_limit;            /* Variable: G_low_Pos_limit
                                        * Referenced by:
                                        *   '<S8>/G_C1'
                                        *   '<S9>/G_C1'
                                        *   '<S10>/G_C1'
                                        */
  real32_T G_low_Rate_limit;           /* Variable: G_low_Rate_limit
                                        * Referenced by:
                                        *   '<S8>/G_C6'
                                        *   '<S9>/G_C6'
                                        *   '<S10>/G_C6'
                                        */
  real32_T G_tau3;                     /* Variable: G_tau3
                                        * Referenced by:
                                        *   '<S11>/P_LAG'
                                        *   '<S12>/P_LAG'
                                        *   '<S13>/P_LAG'
                                        */
  real32_T G_up_Pos_limit;             /* Variable: G_up_Pos_limit
                                        * Referenced by:
                                        *   '<S8>/G_C3'
                                        *   '<S9>/G_C3'
                                        *   '<S10>/G_C3'
                                        */
  real32_T SIMTIME_DT;                 /* Variable: SIMTIME_DT
                                        * Referenced by:
                                        *   '<S11>/P_LAG1'
                                        *   '<S12>/P_LAG1'
                                        *   '<S13>/P_LAG1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_Auto_Trim_Fcn_T {
  const char_T * volatile errorStatus;

  /*
   * ModelData:
   * The following substructure contains information regarding
   * the data used in the model.
   */
  struct {
    B_Auto_Trim_Fcn_T *blockIO;
    P_Auto_Trim_Fcn_T *defaultParam;
    DW_Auto_Trim_Fcn_T *dwork;
  } ModelData;
};

/* Model entry point functions */
extern void Auto_Trim_Fcn_initialize(RT_MODEL_Auto_Trim_Fcn_T *const
  Auto_Trim_Fcn_M, real32_T *Auto_Trim_Fcn_U_INIT_C, real32_T
  *Auto_Trim_Fcn_U_GX_In, real32_T *Auto_Trim_Fcn_U_GY_In, real32_T
  *Auto_Trim_Fcn_U_GZ_In, real32_T *Auto_Trim_Fcn_Y_GX_out, real32_T
  *Auto_Trim_Fcn_Y_GY_out, real32_T *Auto_Trim_Fcn_Y_GZ_out);
extern void Auto_Trim_Fcn_step(RT_MODEL_Auto_Trim_Fcn_T *const Auto_Trim_Fcn_M,
  real32_T Auto_Trim_Fcn_U_INIT_C, real32_T Auto_Trim_Fcn_U_GX_In, real32_T
  Auto_Trim_Fcn_U_GY_In, real32_T Auto_Trim_Fcn_U_GZ_In, real32_T
  *Auto_Trim_Fcn_Y_GX_out, real32_T *Auto_Trim_Fcn_Y_GY_out, real32_T
  *Auto_Trim_Fcn_Y_GZ_out);
extern void Auto_Trim_Fcn_terminate(RT_MODEL_Auto_Trim_Fcn_T *const
  Auto_Trim_Fcn_M);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Auto_Trim_Fcn'
 * '<S1>'   : 'Auto_Trim_Fcn/Auto_Trim'
 * '<S2>'   : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gx'
 * '<S3>'   : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gy'
 * '<S4>'   : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gy1'
 * '<S5>'   : 'Auto_Trim_Fcn/Auto_Trim/Dev_x'
 * '<S6>'   : 'Auto_Trim_Fcn/Auto_Trim/Dev_y'
 * '<S7>'   : 'Auto_Trim_Fcn/Auto_Trim/Dev_z'
 * '<S8>'   : 'Auto_Trim_Fcn/Auto_Trim/GX_AL'
 * '<S9>'   : 'Auto_Trim_Fcn/Auto_Trim/GY_AL'
 * '<S10>'  : 'Auto_Trim_Fcn/Auto_Trim/GZ_AL'
 * '<S11>'  : 'Auto_Trim_Fcn/Auto_Trim/LAG_AX1'
 * '<S12>'  : 'Auto_Trim_Fcn/Auto_Trim/LAG_AX2'
 * '<S13>'  : 'Auto_Trim_Fcn/Auto_Trim/LAG_AX3'
 * '<S14>'  : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gx/Ave_By_30'
 * '<S15>'  : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gx/Ave_By_30/Ave_By_30 '
 * '<S16>'  : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gy/Ave_By_30'
 * '<S17>'  : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gy/Ave_By_30/Ave_By_30 '
 * '<S18>'  : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gy1/Ave_By_30'
 * '<S19>'  : 'Auto_Trim_Fcn/Auto_Trim/AI_Ave_Trim_Gy1/Ave_By_30/Ave_By_30 '
 * '<S20>'  : 'Auto_Trim_Fcn/Auto_Trim/GX_AL/SRLatch'
 * '<S21>'  : 'Auto_Trim_Fcn/Auto_Trim/GX_AL/one_shot '
 * '<S22>'  : 'Auto_Trim_Fcn/Auto_Trim/GY_AL/SRLatch'
 * '<S23>'  : 'Auto_Trim_Fcn/Auto_Trim/GY_AL/one_shot '
 * '<S24>'  : 'Auto_Trim_Fcn/Auto_Trim/GZ_AL/SRLatch'
 * '<S25>'  : 'Auto_Trim_Fcn/Auto_Trim/GZ_AL/one_shot '
 */
#endif                                 /* RTW_HEADER_Auto_Trim_Fcn_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
