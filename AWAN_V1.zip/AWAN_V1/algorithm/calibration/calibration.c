#include "calibration.h"
#include "asm330lhh.h"
#include "iis2mdc.h"
#include "LiLinEncoder.h"
#include "gps1.h"

extern asm330lhh_data_t asm330lhh_rls_data;
extern iis2mdc_data_t iis2mdc_rls_data;
extern double gZBias1;
float cal_acceleration_g[3];
float cal_angular_rate_dps[3];
float iis2mdc_cal_data_mG[3];
float magnetom[3];
extern float calResult[40];
extern float magXHigh;
extern float magXLow;
extern float magYHigh;
extern float magYLow;
extern uint32_t lilinParamInt[32];

//const float magn_ellipsoid_transform[3][3] = {{0.991568f, 0.014259f, 0.00758507f}, {0.014259f, 0.968597f, -0.00328927f}, {0.00758507f, -0.00328927f, 0.980696f}};

//The gyro and accel Calbriation data for 24 at epsoide 2
float CalRotMatrix1[3] = {0.9999f, -0.0107f, -0.0025f};
float CalRotMatrix2[3] = {0.0107f, 0.9999f, 0.0009f};
float CalRotMatrix3[3] = {0.0025f, -0.0009f, 1.0000f};
float AccelCaloffset1 = -0.0020f;
float AccelCaloffset2 = -0.0030f;
float AccelCaloffset3 = 0.0082f;
float GyroCaloffset1 = 0.2669f;
float GyroCaloffset2 = -0.6634f;
float GyroCaloffset3 = -0.5438f;


//const float magn_ellipsoid_center[3] = {411.0988f, -181.7820f, 21.6438f};
//const float magn_ellipsoid_transform[3][3] = {{0.9542f, 0.0218f, 0.0012f}, {0.0218f, 0.9745f, -0.0129f}, {0.0012f, -0.0129f, 0.9899f}};

//const float magn_ellipsoid_center[3] = {-273.1472f + 384.7947f, 444.2597f - 159.3996f, 29.3733f + 29.3137f};
//const float magn_ellipsoid_transform[3][3] = {{0.9574f, 0.0203f, 0.0013f}, {0.0203f, 0.9759f, -0.0112f}, {0.0013f, -0.0112f, 0.9922f}};
//SEAN    ԭ���������
const float magn_ellipsoid_center[3] = {042.724f,151.9960f+100.0000f,065.3800f};
const float magn_ellipsoid_transform[3][3] = {{0.9654f, 0.2130f, 0.0030f}, {0.2130f, 0.9830f, -0.0117f}, {0.0030f, -0.0117f, 0.9745f}};


void Matrix_Vector_Multiply(const float a[3][3], const float b[3], float out[3])
{
  for(int x = 0; x < 3; x++)
  {
    out[x] = a[x][0] * b[0] + a[x][1] * b[1] + a[x][2] * b[2];
  }
}

// do calibration after RLS
void CalRlsGyroAccelData(void)
{
/******************************************************************************************************/  
//    cal_angular_rate_dps[0] = (asm330lhh_rls_data.angular_rate_dps[0] - calResult[12]) * calResult[0]+
//                   (asm330lhh_rls_data.angular_rate_dps[1] - calResult[13]) * calResult[1]+
//                   (asm330lhh_rls_data.angular_rate_dps[2] - calResult[14]) * calResult[2];
//  cal_angular_rate_dps[1] = (asm330lhh_rls_data.angular_rate_dps[0] - calResult[12]) * calResult[3]+
//                   (asm330lhh_rls_data.angular_rate_dps[1] - calResult[13]) * calResult[4]+
//                   (asm330lhh_rls_data.angular_rate_dps[2] - calResult[14]) * calResult[5];
//  cal_angular_rate_dps[2] = (asm330lhh_rls_data.angular_rate_dps[0] - calResult[12]) * calResult[6]+
//                   (asm330lhh_rls_data.angular_rate_dps[1] - calResult[13]) * calResult[7]+
//                   (asm330lhh_rls_data.angular_rate_dps[2] - calResult[14]) * calResult[8];
//
//  asm330lhh_rls_data.angular_rate_dps[0] = cal_angular_rate_dps[0];
//  asm330lhh_rls_data.angular_rate_dps[1] = cal_angular_rate_dps[1];
//  asm330lhh_rls_data.angular_rate_dps[2] = cal_angular_rate_dps[2];
//	asm330lhh_rls_data.angular_rate_dps[2] = asm330lhh_rls_data.angular_rate_dps[2] - gZBias1;


//	  calResult[0] = 0.990342044;
//	  calResult[1] = -0.013191429;
//	  calResult[2] = -0.005107631;
//	  calResult[3] = 0.020130086;
//	  calResult[4] = 1.014796299;
//	  calResult[5] = -0.000285845;
//	  calResult[6] = -0.004989707;
//	  calResult[7] = -0.006314222;
//	  calResult[8] = 1.001290526;
//	  calResult[12] = 0.812022719;
//	  calResult[13] = -0.85317608;
//	  calResult[14] = -0.262740628;
//	  cal_angular_rate_dps[0] = (asm330lhh_rls_data.angular_rate_dps[0] - calResult[12]) * calResult[0]+
//	                   (asm330lhh_rls_data.angular_rate_dps[1] - calResult[13]) * calResult[1]+
//	                   (asm330lhh_rls_data.angular_rate_dps[2] - calResult[14]) * calResult[2];
//	  cal_angular_rate_dps[1] = (asm330lhh_rls_data.angular_rate_dps[0] - calResult[12]) * calResult[3]+
//	                   (asm330lhh_rls_data.angular_rate_dps[1] - calResult[13]) * calResult[4]+
//	                   (asm330lhh_rls_data.angular_rate_dps[2] - calResult[14]) * calResult[5];
//	  cal_angular_rate_dps[2] = (asm330lhh_rls_data.angular_rate_dps[0] - calResult[12]) * calResult[6]+
//	                   (asm330lhh_rls_data.angular_rate_dps[1] - calResult[13]) * calResult[7]+
//	                   (asm330lhh_rls_data.angular_rate_dps[2] - calResult[14]) * calResult[8];
//
//	  asm330lhh_rls_data.angular_rate_dps[0] = cal_angular_rate_dps[0];
//	  asm330lhh_rls_data.angular_rate_dps[1] = cal_angular_rate_dps[1];
//	  asm330lhh_rls_data.angular_rate_dps[2] = cal_angular_rate_dps[2];
///////////////////////////////////////////////////////////////////////////
	//calResult[0]~calResult[8] = M
	//calResult[9]= x_bias
	//calResult[10]= y_bias
	//calResult[11]= z_bias

//	  calResult[9]=0.02192;//mingChi 20240410
//	  calResult[10]=-0.00659;
//	  calResult[11]=0.00202;
//	  calResult[0]=0.998546;
//	  calResult[1]=0.021535;
//	  calResult[2]=0.010869;
//	  calResult[3]=-0.01942;
//	  calResult[4]=0.99806;
//	  calResult[5]=0.012;
//	  calResult[6]=-0.01192;
//	  calResult[7]=0.01075;
//	  calResult[8]=1.000913;//mingChi 20240410

//  calResult[9]=0.010284802;
//  calResult[10]=-0.022890569;
//  calResult[11]=0.012614853;
//  calResult[0]=1.004920442;
//  calResult[1]=0.00287104;
//  calResult[2]=-0.007150133;
//  calResult[3]=-0.0000456784;
//  calResult[4]=0.998175816;
//  calResult[5]=0.000311912;
//  calResult[6]=0.005211294;
//  calResult[7]=-0.001237493;
//  calResult[8]=1.005085025;//article test1

//  calResult[9]=0.014832;
//  calResult[10]=-0.012655;
//  calResult[11]=0.022839;
//  calResult[0]=1.0107745;
//  calResult[1]=0.00098;
//  calResult[2]=-0.000976;
//  calResult[3]=0.00098;
//  calResult[4]=0.998818;
//  calResult[5]=0.000447;
//  calResult[6]=-0.000977;
//  calResult[7]=0.000447;
//  calResult[8]=1.003057;//0523_1

//  calResult[9]=0.015841;
//  calResult[10]=-0.015221;
//  calResult[11]=0.013654;
//  calResult[0]=1.007295;
//  calResult[1]=0.00012;
//  calResult[2]=-0.000538;
//  calResult[3]=0.000121;
//  calResult[4]=1.001761;
//  calResult[5]=0.000474;
//  calResult[6]=-0.000538;
//  calResult[7]=0.000474;
//  calResult[8]=1.000569;//0523_2

  calResult[9]=0.019904;
  calResult[10]=-0.124496;
  calResult[11]=0.122633;
  calResult[0]=1.000965;
  calResult[1]=0.01065;
  calResult[2]=-0.0162;
  calResult[3]=0.010688;
  calResult[4]=1.005824;
  calResult[5]=0.090634;
  calResult[6]=-0.016167;
  calResult[7]=0.09055;
  calResult[8]=0.99594;//awan LM_1,0523_3


//  calResult[9]=0.004115753;
//  calResult[10]=-0.014691441;
//  calResult[11]=0.020288903;
//  calResult[0]=1.002682739;
//  calResult[1]=0.003699141;
//  calResult[2]=-0.000672781;
//  calResult[3]=-0.005799202;
//  calResult[4]=1.004057181;
//  calResult[5]=0.000135137;
//  calResult[6]=0.001747;
//  calResult[7]=0.003115041;
//  calResult[8]=0.999711846;//article test2

  //  calResult[9]=0.004115753;
  //  calResult[10]=-0.014691441;
  //  calResult[11]=0.020288903;
  //  calResult[0]=1.002682739;
  //  calResult[1]=0.003699141;
  //  calResult[2]=-0.000672781;
  //  calResult[3]=-0.005799202;
  //  calResult[4]=1.004057181;
  //  calResult[5]=0.000135137;
  //  calResult[6]=0.001747;
  //  calResult[7]=0.003115041;
  //  calResult[8]=0.999711846;//awan test2
///////////////////////////////////////////////////////////////////////////

  
  cal_acceleration_g[0] = (asm330lhh_rls_data.acceleration_g[0] - calResult[9]) * calResult[0]+
                         (asm330lhh_rls_data.acceleration_g[1] - calResult[10]) * calResult[1]+
                         (asm330lhh_rls_data.acceleration_g[2] - calResult[11]) * calResult[2];
  cal_acceleration_g[1] = (asm330lhh_rls_data.acceleration_g[0] - calResult[9]) * calResult[3]+
                         (asm330lhh_rls_data.acceleration_g[1] - calResult[10]) * calResult[4]+
                         (asm330lhh_rls_data.acceleration_g[2] - calResult[11]) * calResult[5];
  cal_acceleration_g[2] = (asm330lhh_rls_data.acceleration_g[0] - calResult[9]) * calResult[6]+
                         (asm330lhh_rls_data.acceleration_g[1] - calResult[10]) * calResult[7]+
                         (asm330lhh_rls_data.acceleration_g[2] - calResult[11]) * calResult[8];
  
  asm330lhh_rls_data.acceleration_g[0] = cal_acceleration_g[0];
  asm330lhh_rls_data.acceleration_g[1] = cal_acceleration_g[1];
  asm330lhh_rls_data.acceleration_g[2] = cal_acceleration_g[2];

}

void Cal_RLSMagData(void)
{
//  iis2mdc_cal_data_mG[0] = (iis2mdc_rls_data.magnetic_mG[0] -  calResult[24]) ;
//  iis2mdc_cal_data_mG[1] = (iis2mdc_rls_data.magnetic_mG[1] - calResult[25]);
//  iis2mdc_cal_data_mG[2] = (iis2mdc_rls_data.magnetic_mG[2] - calResult[26]);
//  
//  magnetom[0] =  calResult[15] * iis2mdc_cal_data_mG[0] + calResult[16] * iis2mdc_cal_data_mG[1] +
//    calResult[17] * iis2mdc_cal_data_mG[2];
//  magnetom[1] =  calResult[18] * iis2mdc_cal_data_mG[0] + calResult[19] * iis2mdc_cal_data_mG[1] +
//    calResult[20] * iis2mdc_cal_data_mG[2];
//  magnetom[2] =  calResult[21] * iis2mdc_cal_data_mG[0] + calResult[22] * iis2mdc_cal_data_mG[1] +
//    calResult[23] * iis2mdc_cal_data_mG[2];
//  
//  iis2mdc_rls_data.magnetic_mG[0] = magnetom[0];
//  iis2mdc_rls_data.magnetic_mG[1] = magnetom[1];
//  iis2mdc_rls_data.magnetic_mG[2] = magnetom[2];
//  
//    iis2mdc_cal_data_mG[0] = (iis2mdc_rls_data.magnetic_mG[0] -  411.0988f) ;
//  iis2mdc_cal_data_mG[1] = (iis2mdc_rls_data.magnetic_mG[1] + 181.7820f);
//  iis2mdc_cal_data_mG[2] = (iis2mdc_rls_data.magnetic_mG[2] - 21.6438f);
//  
//  magnetom[0] =  0.9542f * iis2mdc_cal_data_mG[0] + 0.0218f * iis2mdc_cal_data_mG[1] +
//    0.0012f * iis2mdc_cal_data_mG[2];
//  magnetom[1] =  0.0218f * iis2mdc_cal_data_mG[0] + 0.9745f * iis2mdc_cal_data_mG[1] +
//    (-0.0129f) * iis2mdc_cal_data_mG[2];
//  magnetom[2] =  0.0012f * iis2mdc_cal_data_mG[0] + (-0.0129f) * iis2mdc_cal_data_mG[1] +
//    0.9899f * iis2mdc_cal_data_mG[2];
//  
//  iis2mdc_rls_data.magnetic_mG[0] = magnetom[0];
//  iis2mdc_rls_data.magnetic_mG[1] = magnetom[1];
//  iis2mdc_rls_data.magnetic_mG[2] = magnetom[2];
  
   //YuChen setting
   /*iis2mdc_cal_data_mG[0] = (iis2mdc_rls_data.magnetic_mG[0] -  magn_ellipsoid_center[0]) ;
   iis2mdc_cal_data_mG[1] = (iis2mdc_rls_data.magnetic_mG[1] - magn_ellipsoid_center[1]);
   iis2mdc_cal_data_mG[2] = (iis2mdc_rls_data.magnetic_mG[2] - magn_ellipsoid_center[2]);
   Matrix_Vector_Multiply(magn_ellipsoid_transform, iis2mdc_cal_data_mG, magnetom);*/
   //YuChen setting
  
   //Tim setting
   iis2mdc_cal_data_mG[0] = (iis2mdc_rls_data.magnetic_mG[0] -  calResult[24]) ;
   iis2mdc_cal_data_mG[1] = (iis2mdc_rls_data.magnetic_mG[1] - calResult[25]);
   iis2mdc_cal_data_mG[2] = (iis2mdc_rls_data.magnetic_mG[2] - calResult[26]);
   
    magnetom[0] =  calResult[15] * iis2mdc_cal_data_mG[0] + calResult[16] * iis2mdc_cal_data_mG[1] +
                   calResult[17] * iis2mdc_cal_data_mG[2];
    magnetom[1] =  calResult[18] * iis2mdc_cal_data_mG[0] + calResult[19] * iis2mdc_cal_data_mG[1] +
                  calResult[20] * iis2mdc_cal_data_mG[2];
    magnetom[2] =  calResult[21] * iis2mdc_cal_data_mG[0] + calResult[22] * iis2mdc_cal_data_mG[1] +
                   calResult[23] * iis2mdc_cal_data_mG[2];
    //Tim setting
   
  iis2mdc_rls_data.magnetic_mG[0] = magnetom[0];
  iis2mdc_rls_data.magnetic_mG[1] = magnetom[1];
  iis2mdc_rls_data.magnetic_mG[2] = magnetom[2];

}

void calMag(float magX, float magY)
{
	if(magX >= magXHigh)
		magXHigh = magX;
	if(magX < magXLow)
		magXLow = magX;

	if(magY >= magYHigh)
		magYHigh = magY;
	if(magY < magYLow)
		magYLow = magY;
}

void magFromFlash()
{
	float _fMagXHigh=-1,_fMagXLow=1,_fMagYHigh=-1,_fMagYLow=1;

	  if((lilinParamInt[8] & 0x80000000) == 0x80000000)
	  {
		  _fMagXHigh = (float)(lilinParamInt[8] & 0x7fffffff);
		  _fMagXHigh = _fMagXHigh*-1;
	  }
	  else
	  {
		  _fMagXHigh = (float)(lilinParamInt[8] & 0x7fffffff);
	  }
	  magXHigh = _fMagXHigh*0.001;
	  lilin_data.magXHigh=lilinParamInt[8];

	  if((lilinParamInt[9] & 0x80000000) == 0x80000000)
	  {
		  _fMagXLow = (float)(lilinParamInt[9] & 0x7fffffff);
		  _fMagXLow = _fMagXLow*-1;
	  }
	  else
	  {
		  _fMagXLow =(float) (lilinParamInt[9] & 0x7fffffff);
	  }
	  magXLow = _fMagXLow*0.001;
	  lilin_data.magXLow=lilinParamInt[9];

	  if((lilinParamInt[10] & 0x80000000) == 0x80000000)
	  {
		  _fMagYHigh = (float)(lilinParamInt[10] & 0x7fffffff);
		  _fMagYHigh = _fMagYHigh*-1;
	  }
	  else
	  {
		  _fMagYHigh = (float)(lilinParamInt[10] & 0x7fffffff);
	  }
	  magYHigh = _fMagYHigh*0.001;
	  lilin_data.magYHigh=lilinParamInt[10];

	  if((lilinParamInt[11] & 0x80000000) == 0x80000000)
	  {
		  _fMagYLow = (float)(lilinParamInt[11] & 0x7fffffff) ;
		  _fMagYLow = _fMagYLow*-1;
	  }
	  else
	  {
		  _fMagYLow =(float)(lilinParamInt[11] & 0x7fffffff) ;
	  }
	  magYLow = _fMagYLow*0.001;
	  lilin_data.magYLow=lilinParamInt[11];
}
void magToFlash()
{
	   if(magXHigh >= 0)
		lilin_data.magXHigh = (uint32_t)(magXHigh * 1000);
	   else
		{
			lilin_data.magXHigh = ((uint32_t)(magXHigh * -1000)) | 0x80000000;
		}

		if(magXLow >= 0)
			lilin_data.magXLow = (uint32_t)(magXLow * 1000);
		else
		{
			lilin_data.magXLow = ((uint32_t)(magXLow * -1000)) | 0x80000000;
		}

		if(magYHigh >= 0)
			lilin_data.magYHigh = (uint32_t)(magYHigh * 1000);
		else
		{
			lilin_data.magYHigh = ((uint32_t)(magYHigh * -1000)) | 0x80000000;
		}

		if(magYLow >= 0)
			lilin_data.magYLow = (uint32_t)(magYLow * 1000);
		else
		{
			lilin_data.magYLow = ((uint32_t)(magYLow * -1000)) | 0x80000000;
		}
		lilinParamInt[8]=lilin_data.magXHigh;
    	lilinParamInt[9]=lilin_data.magXLow;
    	lilinParamInt[10]=lilin_data.magYHigh;
    	lilinParamInt[11]=lilin_data.magYLow;

		  lilinParamInt[14]=(uint32_t)(gps.id);
		  for(int i = 15; i < 32; i++)
			{
			  lilinParamInt[i] = 0;
			}
}
