

#ifndef CALIBRATION_H
#define CALIBRATION_H

void CalRlsGyroAccelData(void);
void Cal_RLSMagData(void);
void calMag(float, float);
void magFromFlash();
void magToFlash();

#endif
