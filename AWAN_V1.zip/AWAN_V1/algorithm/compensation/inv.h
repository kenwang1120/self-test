/*
 * File: inv.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

#ifndef __INV_H__
#define __INV_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "compensationCode_types.h"

/* Function Declarations */
extern void inv(const float x[9], float y[9]);

#endif

/*
 * File trailer for inv.h
 *
 * [EOF]
 */
