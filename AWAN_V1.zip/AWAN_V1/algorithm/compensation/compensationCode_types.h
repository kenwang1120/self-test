/*
 * File: compensationCode_types.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

#ifndef __COMPENSATIONCODE_TYPES_H__
#define __COMPENSATIONCODE_TYPES_H__

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for compensationCode_types.h
 *
 * [EOF]
 */
