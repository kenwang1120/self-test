/*
 * File: compensationAccel.c
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "compensationAccel.h"
#include "compensationRate.h"
#include "inv.h"
#include "compensationCode_rtwutil.h"

/* Function Definitions */

/*
 * Arguments    : float AccelSensor1
 *                float AccelSensor2
 *                float AccelSensor3
 *                float AccelTemp
 *                const float BiasCoefAccel1[6]
 *                const float BiasCoefAccel2[6]
 *                const float BiasCoefAccel3[6]
 *                const float ScaleFactorCoefAccel1[6]
 *                const float ScaleFactorCoefAccel2[6]
 *                const float ScaleFactorCoefAccel3[6]
 *                const float AligFactorAccel1[3]
 *                const float AligFactorAccel2[3]
 *                const float AligFactorAccel3[3]
 *                float *CompAccelX
 *                float *CompAccelY
 *                float *CompAccelZ
 * Return Type  : void
 */
   /*  compensationAccel.m - Compensation function reads temperatures, computes the polynomials */
  /*  based on coefficients, subtract the bias error and multiply the scale factor correction. */
  /*  Then take the normalized misalignment matrix, compute its inverse and then multiply */
  /*  the inverse as the final operation. */
  /*  PARAMETERS - */
  /*  Input - 'AccelSensor1': Accel 1 reading. */
  /*  'AccelSensor2': Accel 2 reading. */
  /*  'AccelSensor3': Accel 3 reading. */
  /*  'AccelTemp': Accelerometer Board Temperature. */
  /*  'BiasCoefAccel1' : Vector containing Bias Coefficients for Accel_1. */
  /*  'BiasCoefAccel2' : Vector containing Bias Coefficients for Accel_2. */
  /*  'BiasCoefAccel3' : Vector containing Bias Coefficients for Accel_3. */
  /*  'ScaleFactorCoefAccel1': Vector containing Scale Factor Coefficients for Accel_1. */
  /*  'ScaleFactorCoefAccel2': Vector containing Scale Factor Coefficients for Accel_2. */
  /*  'ScaleFactorCoefAccel3': Vector containing Scale Factor Coefficients for Accel_3. */
  /*  'AligFactorAccel1' : Vector containing XYZ Alignment Factors for Accel_1. */
  /*  'AligFactorAccel2' : Vector containing XYZ Alignment Factors for Accel_2. */
  /*  'AligFactorAccel3' : Vector containing XYZ Alignment Factors for Accel_3. */
  /*  Output - 'CompAccelX': Accel of X axis after compensation */
  /*  'CompAccelY': Accel of Y axis after compensation */
  /*  'CompAccelZ': Accel of Z axis after compensation */
void compensationAccel(float AccelSensor1, float AccelSensor2, float
  AccelSensor3, float AccelTemp, const float BiasCoefAccel1[6], const float
  BiasCoefAccel2[6], const float BiasCoefAccel3[6], const float
  ScaleFactorCoefAccel1[6], const float ScaleFactorCoefAccel2[6], const float
  ScaleFactorCoefAccel3[6], const float AligFactorAccel1[3], const float
  AligFactorAccel2[3], const float AligFactorAccel3[3], float *CompAccelX, float
  *CompAccelY, float *CompAccelZ)
{
  float b_AligFactorAccel1[9];
  float fcnOutput[9];
  float WrapperAccelX;
  float WrapperAccelY;
  float WrapperAccelZ;

  /* * initialize inputs for sensor 1--- TBD*/
  /* initialize inputs for sensor 2--- TBD */
  /* initialize inputs for sensor 3--- TBD */
  /* initialize  misalignment parameter */
  /* 5th order polynomial of bias */
  /* 5th order polynomial of scale factor */
  /* normalized misalignment matrix */
  /* inverse of the normalized misalignment matrix */
  b_AligFactorAccel1[0] = AligFactorAccel1[0];
  b_AligFactorAccel1[3] = AligFactorAccel1[1];
  b_AligFactorAccel1[6] = AligFactorAccel1[2];
  b_AligFactorAccel1[1] = AligFactorAccel2[0];
  b_AligFactorAccel1[4] = AligFactorAccel2[1];
  b_AligFactorAccel1[7] = AligFactorAccel2[2];
  b_AligFactorAccel1[2] = AligFactorAccel3[0];
  b_AligFactorAccel1[5] = AligFactorAccel3[1];
  b_AligFactorAccel1[8] = AligFactorAccel3[2];
  inv(b_AligFactorAccel1, fcnOutput);

  /* wrapper code: compute the polynomials based on coefficients, subtract the bias error and multiply the scale factor correction. */
  WrapperAccelX = (AccelSensor1 - (((((BiasCoefAccel1[0] + BiasCoefAccel1[1] *
    AccelTemp) + BiasCoefAccel1[2] * (AccelTemp * AccelTemp)) + BiasCoefAccel1[3]
    * rt_powf_snf(AccelTemp, 3.0F)) + BiasCoefAccel1[4] * rt_powf_snf(AccelTemp,
    4.0F)) + BiasCoefAccel1[5] * rt_powf_snf(AccelTemp, 5.0F))) *
    (((((ScaleFactorCoefAccel1[0] + ScaleFactorCoefAccel1[1] * AccelTemp) +
        ScaleFactorCoefAccel1[2] * (AccelTemp * AccelTemp)) +
       ScaleFactorCoefAccel1[3] * rt_powf_snf(AccelTemp, 3.0F)) +
      ScaleFactorCoefAccel1[4] * rt_powf_snf(AccelTemp, 4.0F)) +
     ScaleFactorCoefAccel1[5] * rt_powf_snf(AccelTemp, 5.0F));
  WrapperAccelY = (AccelSensor2 - (((((BiasCoefAccel2[0] + BiasCoefAccel2[1] *
    AccelTemp) + BiasCoefAccel2[2] * (AccelTemp * AccelTemp)) + BiasCoefAccel2[3]
    * rt_powf_snf(AccelTemp, 3.0F)) + BiasCoefAccel2[4] * rt_powf_snf(AccelTemp,
    4.0F)) + BiasCoefAccel2[5] * rt_powf_snf(AccelTemp, 5.0F))) *
    (((((ScaleFactorCoefAccel2[0] + ScaleFactorCoefAccel2[1] * AccelTemp) +
        ScaleFactorCoefAccel2[2] * (AccelTemp * AccelTemp)) +
       ScaleFactorCoefAccel2[3] * rt_powf_snf(AccelTemp, 3.0F)) +
      ScaleFactorCoefAccel2[4] * rt_powf_snf(AccelTemp, 4.0F)) +
     ScaleFactorCoefAccel2[5] * rt_powf_snf(AccelTemp, 5.0F));
  WrapperAccelZ = (AccelSensor3 - (((((BiasCoefAccel3[0] + BiasCoefAccel3[1] *
    AccelTemp) + BiasCoefAccel3[2] * (AccelTemp * AccelTemp)) + BiasCoefAccel3[3]
    * rt_powf_snf(AccelTemp, 3.0F)) + BiasCoefAccel3[4] * rt_powf_snf(AccelTemp,
    4.0F)) + BiasCoefAccel3[5] * rt_powf_snf(AccelTemp, 5.0F))) *
    (((((ScaleFactorCoefAccel3[0] + ScaleFactorCoefAccel3[1] * AccelTemp) +
        ScaleFactorCoefAccel3[2] * (AccelTemp * AccelTemp)) +
       ScaleFactorCoefAccel3[3] * rt_powf_snf(AccelTemp, 3.0F)) +
      ScaleFactorCoefAccel3[4] * rt_powf_snf(AccelTemp, 4.0F)) +
     ScaleFactorCoefAccel3[5] * rt_powf_snf(AccelTemp, 5.0F));

  /* Output After compensation */
  *CompAccelX = (WrapperAccelX * fcnOutput[0] + WrapperAccelY * fcnOutput[1]) +
    WrapperAccelZ * fcnOutput[2];
  *CompAccelY = (WrapperAccelX * fcnOutput[3] + WrapperAccelY * fcnOutput[4]) +
    WrapperAccelZ * fcnOutput[5];
  *CompAccelZ = (WrapperAccelX * fcnOutput[6] + WrapperAccelY * fcnOutput[7]) +
    WrapperAccelZ * fcnOutput[8];
}

/*
 * File trailer for compensationAccel.c
 *
 * [EOF]
 */
