/*
 * File: compensationCode_terminate.c
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "compensationAccel.h"
#include "compensationRate.h"
#include "compensationCode_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void compensationCode_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for compensationCode_terminate.c
 *
 * [EOF]
 */
