/*
 * File: compensationRate.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

#ifndef __COMPENSATIONRATE_H__
#define __COMPENSATIONRATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "compensationCode_types.h"

/* Function Declarations */
extern void compensationRate(float RateSensor1, float RateSensor2, float
  RateSensor3, const float RateTemp[3], const float BiasCoefRate1[6], const
  float BiasCoefRate2[6], const float BiasCoefRate3[6], const float
  ScaleFactorCoefRate1[6], const float ScaleFactorCoefRate2[6], const float
  ScaleFactorCoefRate3[6], const float AligFactorRate1[3], const float
  AligFactorRate2[3], const float AligFactorRate3[3], const float RateLookup[3],
  float *CompRateX, float *CompRateY, float *CompRateZ);

#endif

/*
 * File trailer for compensationRate.h
 *
 * [EOF]
 */
