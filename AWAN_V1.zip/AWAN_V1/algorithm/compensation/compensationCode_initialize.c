/*
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: compensationCode_initialize.c
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "compensationAccel.h"
#include "compensationRate.h"
#include "compensationCode_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void compensationCode_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for compensationCode_initialize.c
 *
 * [EOF]
 */
