/*
 * File: compensationCode_terminate.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

#ifndef __COMPENSATIONCODE_TERMINATE_H__
#define __COMPENSATIONCODE_TERMINATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "compensationCode_types.h"

/* Function Declarations */
extern void compensationCode_terminate(void);

#endif

/*
 * File trailer for compensationCode_terminate.h
 *
 * [EOF]
 */
