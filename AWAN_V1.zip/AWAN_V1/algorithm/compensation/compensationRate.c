/*
 * File: compensationRate.c
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "compensationAccel.h"
#include "compensationRate.h"
#include "inv.h"
#include "compensationCode_rtwutil.h"

/* Function Definitions */

/*
 * Arguments    : float RateSensor1
 *                float RateSensor2
 *                float RateSensor3
 *                const float RateTemp[3]
 *                const float BiasCoefRate1[6]
 *                const float BiasCoefRate2[6]
 *                const float BiasCoefRate3[6]
 *                const float ScaleFactorCoefRate1[6]
 *                const float ScaleFactorCoefRate2[6]
 *                const float ScaleFactorCoefRate3[6]
 *                const float AligFactorRate1[3]
 *                const float AligFactorRate2[3]
 *                const float AligFactorRate3[3]
 *                const float RateLookup[3]
 *                float *CompRateX
 *                float *CompRateY
 *                float *CompRateZ
 * Return Type  : void
 */

  /*  compensationRate.m - Compensation function reads temperatures, computes the polynomials */
  /*  based on coefficients, subtract the bias error and multiply the scale factor correction. */
  /*  Then take the normalized misalignment matrix, compute its inverse and then multiply */
  /*  the inverse as the final operation. */
  /*  PARAMETERS - */
  /*  Input - 'RateSensor1': Rate Gyro 1 reading. */
  /*  'RateSensor2': Rate Gyro 2 reading. */
  /*  'RateSensor3': Rate Gyro 3 reading. */
  /*  'RateTemp': Vector containing temperture of Rate Gyro 1-3. */
  /*  'BiasCoefRate1' : Vector containing Bias Coefficients for Rate Gyro 1. */
  /*  'BiasCoefRate2' : Vector containing Bias Coefficients for Rate Gyro 2. */
  /*  'BiasCoefRate3' : Vector containing Bias Coefficients for Rate Gyro 3. */
  /*  'ScaleFactorCoefRate1': Vector containing Scale Factor Coefficients for Gyro 1. */
  /*  'ScaleFactorCoefRate2': Vector containing Scale Factor Coefficients for Gyro 2. */
  /*  'ScaleFactorCoefRate3': Vector containing Scale Factor Coefficients for Gyro 3. */
  /*  'AligFactorRate1' : Vector containing XYZ Alignment Factors for Gyro 1. */
  /*  'AligFactorRate2' : Vector containing XYZ Alignment Factors for Gyro 2. */
  /*  'AligFactorRate3' : Vector containing XYZ Alignment Factors for Gyro 3. */
  /*  'RateLookup' : Look up table of rate sensor output -- TBD(default 0) */
  /*  Output - 'CompRateX': Rate of X axis after compensation */
  /*  'CompRateY': Rate of Y axis after compensation */
  /*  'CompRateZ': Rate of Z axis after compensation */
void compensationRate(float RateSensor1, float RateSensor2, float RateSensor3,
                      const float RateTemp[3], const float BiasCoefRate1[6],
                      const float BiasCoefRate2[6], const float BiasCoefRate3[6],
                      const float ScaleFactorCoefRate1[6], const float
                      ScaleFactorCoefRate2[6], const float ScaleFactorCoefRate3
                      [6], const float AligFactorRate1[3], const float
                      AligFactorRate2[3], const float AligFactorRate3[3], const
                      float RateLookup[3], float *CompRateX, float *CompRateY,
                      float *CompRateZ)
{
  float b_AligFactorRate1[9];
  float fcnOutput[9];
  float WrapperRateX;
  float WrapperRateY;
  float WrapperRateZ;

  /* initialize inputs for sensor 1--- TBD*/
  /* initialize inputs for sensor 2--- TBD */
  /* initialize inputs for sensor 3--- TBD */
  /* initialize  misalignment parameter */
  /* 5th order polynomial of bias */
  /* 5th order polynomial of scale factor */
  /* normalized misalignment matrix */
  /* inverse of the normalized misalignment matrix */
  b_AligFactorRate1[0] = AligFactorRate1[0];
  b_AligFactorRate1[3] = AligFactorRate1[1];
  b_AligFactorRate1[6] = AligFactorRate1[2];
  b_AligFactorRate1[1] = AligFactorRate2[0];
  b_AligFactorRate1[4] = AligFactorRate2[1];
  b_AligFactorRate1[7] = AligFactorRate2[2];
  b_AligFactorRate1[2] = AligFactorRate3[0];
  b_AligFactorRate1[5] = AligFactorRate3[1];
  b_AligFactorRate1[8] = AligFactorRate3[2];
  inv(b_AligFactorRate1, fcnOutput);

  /* wrapper code: compute the polynomials based on coefficients, subtract the bias error and multiply the scale factor correction. */
  WrapperRateX = (RateSensor1 - (((((BiasCoefRate1[0] + BiasCoefRate1[1] *
    RateTemp[0]) + BiasCoefRate1[2] * (RateTemp[0] * RateTemp[0])) +
    BiasCoefRate1[3] * rt_powf_snf(RateTemp[0], 3.0F)) + BiasCoefRate1[4] *
    rt_powf_snf(RateTemp[0], 4.0F)) + BiasCoefRate1[5] * rt_powf_snf(RateTemp[0],
    5.0F))) * (((((ScaleFactorCoefRate1[0] + ScaleFactorCoefRate1[1] * RateTemp
                   [0]) + ScaleFactorCoefRate1[2] * (RateTemp[0] * RateTemp[0]))
                 + ScaleFactorCoefRate1[3] * rt_powf_snf(RateTemp[0], 3.0F)) +
                ScaleFactorCoefRate1[4] * rt_powf_snf(RateTemp[0], 4.0F)) +
               ScaleFactorCoefRate1[5] * rt_powf_snf(RateTemp[0], 5.0F)) -
    RateLookup[0];
  WrapperRateY = (RateSensor2 - (((((BiasCoefRate2[0] + BiasCoefRate2[1] *
    RateTemp[1]) + BiasCoefRate2[2] * (RateTemp[1] * RateTemp[1])) +
    BiasCoefRate2[3] * rt_powf_snf(RateTemp[1], 3.0F)) + BiasCoefRate2[4] *
    rt_powf_snf(RateTemp[1], 4.0F)) + BiasCoefRate2[5] * rt_powf_snf(RateTemp[1],
    5.0F))) * (((((ScaleFactorCoefRate2[0] + ScaleFactorCoefRate2[1] * RateTemp
                   [1]) + ScaleFactorCoefRate2[2] * (RateTemp[1] * RateTemp[1]))
                 + ScaleFactorCoefRate2[3] * rt_powf_snf(RateTemp[1], 3.0F)) +
                ScaleFactorCoefRate2[4] * rt_powf_snf(RateTemp[1], 4.0F)) +
               ScaleFactorCoefRate2[5] * rt_powf_snf(RateTemp[1], 5.0F)) -
    RateLookup[1];
  WrapperRateZ = (RateSensor3 - (((((BiasCoefRate3[0] + BiasCoefRate3[1] *
    RateTemp[2]) + BiasCoefRate3[2] * (RateTemp[2] * RateTemp[2])) +
    BiasCoefRate3[3] * rt_powf_snf(RateTemp[2], 3.0F)) + BiasCoefRate3[4] *
    rt_powf_snf(RateTemp[2], 4.0F)) + BiasCoefRate3[5] * rt_powf_snf(RateTemp[2],
    5.0F))) * (((((ScaleFactorCoefRate3[0] + ScaleFactorCoefRate3[1] * RateTemp
                   [2]) + ScaleFactorCoefRate3[2] * (RateTemp[2] * RateTemp[2]))
                 + ScaleFactorCoefRate3[3] * rt_powf_snf(RateTemp[2], 3.0F)) +
                ScaleFactorCoefRate3[4] * rt_powf_snf(RateTemp[2], 4.0F)) +
               ScaleFactorCoefRate3[5] * rt_powf_snf(RateTemp[2], 5.0F)) -
    RateLookup[2];

  /* Output After compensation */
  *CompRateX = (WrapperRateX * fcnOutput[0] + WrapperRateY * fcnOutput[1]) +
    WrapperRateZ * fcnOutput[2];
  *CompRateY = (WrapperRateX * fcnOutput[3] + WrapperRateY * fcnOutput[4]) +
    WrapperRateZ * fcnOutput[5];
  *CompRateZ = (WrapperRateX * fcnOutput[6] + WrapperRateY * fcnOutput[7]) +
    WrapperRateZ * fcnOutput[8];
}

/*
 * File trailer for compensationRate.c
 *
 * [EOF]
 */
