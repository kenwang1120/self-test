/*
 * File: compensationCode_rtwutil.c
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "compensationAccel.h"
#include "compensationRate.h"
#include "compensationCode_rtwutil.h"

/* Function Definitions */

/*
 * Arguments    : float u0
 *                float u1
 * Return Type  : float
 */
float rt_powf_snf(float u0, float u1)
{
   int count = (int)u1;
   float temp = u0, output = u0;
   if(u1 == 0.0f)
     output = 1;
   else
       for(int i = 0; i < count - 1; i++)
           {
               temp = output;
               output = temp * u0; 
           }
   return output;
}

/*
 * File trailer for compensationCode_rtwutil.c
 *
 * [EOF]
 */
