/*
 * File: compensationCode_rtwutil.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

#ifndef __COMPENSATIONCODE_RTWUTIL_H__
#define __COMPENSATIONCODE_RTWUTIL_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "compensationCode_types.h"

/* Function Declarations */
extern float rt_powf_snf(float u0, float u1);

#endif

/*
 * File trailer for compensationCode_rtwutil.h
 *
 * [EOF]
 */
