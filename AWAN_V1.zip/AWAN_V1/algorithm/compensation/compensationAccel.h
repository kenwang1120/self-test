/*
 * File: compensationAccel.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 28-May-2016 19:58:11
 */

#ifndef __COMPENSATIONACCEL_H__
#define __COMPENSATIONACCEL_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "compensationCode_types.h"

/* Function Declarations */
extern void compensationAccel(float AccelSensor1, float AccelSensor2, float
  AccelSensor3, float AccelTemp, const float BiasCoefAccel1[6], const float
  BiasCoefAccel2[6], const float BiasCoefAccel3[6], const float
  ScaleFactorCoefAccel1[6], const float ScaleFactorCoefAccel2[6], const float
  ScaleFactorCoefAccel3[6], const float AligFactorAccel1[3], const float
  AligFactorAccel2[3], const float AligFactorAccel3[3], float *CompAccelX, float
  *CompAccelY, float *CompAccelZ);

#endif

/*
 * File trailer for compensationAccel.h
 *
 * [EOF]
 */
