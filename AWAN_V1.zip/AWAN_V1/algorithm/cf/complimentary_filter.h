

void MahonyInit(float halT);
void pitchRollUpdate(float gx, float gy, float gz, float ax, float ay, float az, float halfT);
void pitchRollYawUpdate(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz, float halfT);
void AHRSupdate(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz, float halfT) ;
void MahonyGetEuler();
