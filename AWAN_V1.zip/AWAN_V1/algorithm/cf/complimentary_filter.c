#include <stdio.h>
#include "complimentary_filter.h"
#include "math.h"

// high value for static or low dynamic scenario
//#define KP_ACC_HIGH 1.0f                        // proportional gain governs rate of convergence to accelerometer/magnetometer
//#define KI_ACC_HIGH 0.5f                          // integral gain governs rate of convergence of gyroscope biases                  // half the sample period�������ڵ�һ��
//// low value for dynamic scenario
//#define KP_ACC_LOW 0.01f
//#define KI_ACC_LOW 0.001f
#define KP_ACC_HIGH 10.0f                        // proportional gain governs rate of convergence to accelerometer/magnetometer
#define KI_ACC_HIGH 0.08f                          // integral gain governs rate of convergence of gyroscope biases                  // half the sample period�������ڵ�һ��
// low value for dynamic scenario
#define KP_ACC_LOW 10.0f
#define KI_ACC_LOW 0.08f
#define INNOVATION_LIMIT 0.1f
#define M_PI_F 3.14159265358979323846f
#define DPH (DEG/3600.0f)

float q0 = 1, q1 = 0, q2 = 0, q3 = 0;    // quaternion elements representing the estimated orientation
float exInt = 0, eyInt = 0, ezInt = 0;    // scaled integral error
float gx_bias, gy_bias, gz_bias;

float pitch = 0, roll = 0, yaw = 0;
float kp_acc = 1, ki_acc = 0.001;

static float C00,C01,C02, C10,C11,C12, C20,C21,C22;

//static float Kp = 10.0f, Ki = 0.08f;//delay 620 delta T
//static float Kp = 50.0f, Ki = 0.08f; //delay 380 delta T
//static float Kp = 200.0f, Ki = 0.08f;  //70 delta_T
//static float Kp = 1000.0f, Ki = 0.08f; //diverged
//static float Kp = 400.0f, Ki = 0.08f; //110Delta_T
//static float Kp = 700.0f, Ki = 0.08f; //10-30 Delta_T
//static float Kp = 700.0f, Ki = 0.8f; //100 Delta_T
//static float Kp = 700.0f, Ki = 0.04f; //50 Delta_T
//static float Kp = 700.0f, Ki = 0.12f; //30 Delta_T
//static float Kp = 800.0f, Ki = 0.08f; //70 Delta_T
//static float Kp = 650.0f, Ki = 0.08f; //40 Delta_T
//static float Kp = 720.0f, Ki = 0.008f; //80 Delta_T
//static float Kp = 720.0f, Ki = 0.1f; //60 Delta_T
//static float Kp = 720.0f, Ki = 0.08f; //50 Delta_T
//static float Kp = 600.0f, Ki = 0.064f; //75 Delta_T
//static float Kp = 700.0f, Ki = 0.07f; //80 Delta_T
//static float Kp = 900.0f, Ki = 0.07f; //diverge
//static float Kp = 800.0f, Ki = 0.07f; //marginal
// static float Kp = 700.0f, Ki = 0.08f; //30-50 delta_T
//static float Kp = 550.0f, Ki = 0.05f; //40-50 delta_T
//static float Kp = 750.0f, Ki = 0.05f; //a little osc
//static float Kp = 750.0f, Ki = 0.02f; //a little osc
//static float Kp = 700.0f, Ki = 0.02f; //a little osc
//static float Kp = 650.0f, Ki = 0.02f; //a little osc on roll
//static float Kp = 620.0f, Ki = 0.02f; //85delay
//static float Kp = 620.0f, Ki = 0.2f; //50-80 delay
//static float Kp = 600.0f, Ki = 0.6f; //40-55 delay
//static float Kp = 560.0f, Ki = 0.8f; //60 delay
//static float Kp = 600.0f, Ki = 0.8f; //50 delay
//static float Kp = 600.0f, Ki = 2.8f; //50 delay (Smoother)
//static float Kp = 10.0f, Ki = 0.08f;
//param on 10.12.2019
//static float Kp = 600.0f, Ki = 0.08f; //50-60 delay 
//static float Kp = 200.0f, Ki = 0.08f; //12-20 delay

// static float Kp = 500.0f, Ki = 0.2f; //more Oscillation 
//static float Kp = 100.0f, Ki = 0.055f; //8-20 delay 
//static float Kp = 100.0f, Ki = 0.055f; //8-20 delay 
//static float Kp = 700.0f, Ki = 0.05f; // 17 delay 
//static float Kp = 700.0f, Ki = 0.085f; // too quick advanced  delay 

//static float Kp = 400.0f, Ki = 0.085f; // more Oscillation 
//static float Kp = 600.0f, Ki = 0.8f; //50 delay

static float Kp = 180.0f, Ki = 1.0f; 

extern float gyro_calibration_value[3];
extern float accel_calibration_value[3];

void pitchRollUpdate(float gx, float gy, float gz, float ax, float ay, float az, float halfT)
{
  //float k = 0.9;
  float k = 0.6;
//  float accNorm,gyroNorm,qNorm,errorNorm;
  float accNorm,gyroNorm,qNorm;
//  float hx, hy, hz, bx, bz;
  float vx, vy, vz;// wx, wy, wz;
  float ex, ey, ez;
 
  // �Ȱ���Щ�õõ���ֵ���
  float q0q0 = q0*q0;
  float q0q1 = q0*q1;
  float q0q2 = q0*q2;
//  float q0q3 = q0*q3;
  float q1q1 = q1*q1;
//  float q1q2 = q1*q2;
  float q1q3 = q1*q3;
  float q2q2 = q2*q2;
  float q2q3 = q2*q3;
  float q3q3 = q3*q3;
 
  const float CONSTANTS_ONE_G = 9.80665f;
  const float D2R = M_PI_F/180;
  
//  gx = (gx - gyro_calibration_value[0]) * D2R; //conver unit from deg to rad
//  gy = (gy - gyro_calibration_value[1]) * D2R;
//  gz= (gz - gyro_calibration_value[2]) * D2R;
//  
//  ax = (ax - accel_calibration_value[0]) * CONSTANTS_ONE_G; // conver unit from g to m/s^2
//  ay = (ay - accel_calibration_value[1]) * CONSTANTS_ONE_G;
////  az = (az - accel_calibration_value[2] - 1) * CONSTANTS_ONE_G;  
//  az = az  * CONSTANTS_ONE_G;
  
    gx = gx  * D2R; //conver unit from deg to rad
    gy = gy  * D2R;
    gz=  gz  * D2R;
  
    ax = ax  * CONSTANTS_ONE_G; // conver unit from g to m/s^2
    ay = ay  * CONSTANTS_ONE_G;
    //  az = (az - accel_calibration_value[2] - 1) * CONSTANTS_ONE_G;  
    az = az  * CONSTANTS_ONE_G;
  
  
  if(ax*ay*az==0)
    return;
  
 
  accNorm = sqrt(ax*ax + ay*ay + az*az);       
  gyroNorm = sqrt(gx*gx + gy*gy + gz*gz); 
  
  // For the high dynamic scenario, the accelerator measurement is actually not 1g, so use lower parameter
  if((fabs(accNorm - 9.8) > 0.2) || (gyroNorm > 0.2) )    
  {
    ki_acc = Ki;
    kp_acc = Kp;   
  }
  else
  {
    ki_acc = Ki;
    kp_acc = Kp;  
  }
   
  //acc���ݹ�һ��
  ax = ax /accNorm;
  ay = ay / accNorm;
  az = az / accNorm;
 
  // estimated direction of gravity and flux (v and w)              �����������������/��Ǩ
  vx = 2*(q1q3 - q0q2);                                             //��Ԫ����xyz�ı�ʾ
  vy = 2*(q0q1 + q2q3);
  vz = q0q0 - q1q1 - q2q2 + q3q3 ;
 
  // error is sum of cross product between reference direction of fields and direction measured by sensors
  ex = (ay*vz - az*vy) ;                                             //�������������õ���־������
  ey = (az*vx - ax*vz) ;
  ez = (ax*vy - ay*vx) ;
 
  // handle the situdation the error norm is too big, this may caused by mearsument error
//  errorNorm = sqrt(ex*ex + ey*ey + ez*ez);
//  if(errorNorm > INNOVATION_LIMIT)
//  {
//    ex = ex / errorNorm * INNOVATION_LIMIT;
//    ey = ey / errorNorm * INNOVATION_LIMIT;
//    ez = ez / errorNorm * INNOVATION_LIMIT;
//  }
  
  //�������л���
//  exInt = exInt + ex * ki_acc * halfT *2;                                
//  eyInt = eyInt + ey * ki_acc * halfT *2;
//  ezInt = ezInt + ez * ki_acc * halfT *2;
  exInt = exInt + ex * ki_acc;                                
  eyInt = eyInt + ey * ki_acc;
  ezInt = ezInt + ez * ki_acc;
  
  // apply a low pass filter for gyro correction
  gx_bias = k*gx_bias + (1-k) * (kp_acc*ex + exInt);
  gy_bias = k*gy_bias + (1-k) * (kp_acc*ey + eyInt);
  gz_bias = k*gz_bias + (1-k) * (kp_acc*ez + ezInt);
    
  // adjusted gyroscope measurements  
  gx = gx + gx_bias;                                              
  gy = gy + gy_bias;
  gz = gz + gz_bias;                                         
 
  // integrate quaternion rate and normalise 
  //��Ԫ�ص�΢�ַ���
  q0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;
  q1 = q1 + (q0*gx + q2*gz - q3*gy)*halfT;
  q2 = q2 + (q0*gy - q1*gz + q3*gx)*halfT;
  q3 = q3 + (q0*gz + q1*gy - q2*gx)*halfT;
 
  // normalise quaternion
  qNorm = sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
  q0 = q0 / qNorm;
  q1 = q1 / qNorm;
  q2 = q2 / qNorm;
  q3 = q3 / qNorm;
 
//  //Q_ANGLE.Yaw = atan2(2 * q1 * q2 + 2 * q0 * q3, -2 * q2*q2 - 2 * q3* q3 + 1)* 57.3; // yaw
//  pitch  = asin(-2 * q1 * q3 + 2 * q0* q2)* 57.296f; // pitch
//  roll = atan2(2 * q2 * q3 + 2 * q0 * q1, -2 * q1 * q1 - 2 * q2* q2 + 1)* 57.296f; // roll
  
  
 //Q_ANGLE.Yaw = atan2(2 * q1 * q2 + 2 * q0 * q3, -2 * q1*q1 - 2 * q3* q3 + 1)* 57.296; // yaw
  pitch  = asin(2 * q2 * q3 - 2 * q0* q1)* 57.296f; // pitch
  roll = atan2(2 * q1 * q3 + 2 * q0 * q2, 2 * q1 * q1 + 2 * q2* q2 -1)* 57.296f; // roll
  
  pitch = -1.0f * pitch;
     
  if(roll<0)
  {
    roll += 360;
  }
    roll= roll-180;
 //printf("%f,%f\r\n",pitch, roll);
}


void AHRSupdate(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz, float halfT) 
{
    float norm;  
    float hx, hy, hz, bx, bz;  
    float vx, vy, vz, wx, wy, wz;   
    float ex, ey, ez;       

    const float CONSTANTS_ONE_G = 9.80665f;
    const float D2R = M_PI_F/180;
  
    gx = gx  * D2R; //conver unit from deg to rad
    gy = gy  * D2R;
    gz=  gz  * D2R;
  
    ax = ax  * CONSTANTS_ONE_G; // conver unit from g to m/s^2
    ay = ay  * CONSTANTS_ONE_G;
    //  az = (az - accel_calibration_value[2] - 1) * CONSTANTS_ONE_G;  
    az = az  * CONSTANTS_ONE_G;
   
    // auxiliary variables to reduce number of repeated operations  
    float q0q0 = q0*q0;  
    float q0q1 = q0*q1;  
    float q0q2 = q0*q2;  
    float q0q3 = q0*q3;  
    float q1q1 = q1*q1;  
    float q1q2 = q1*q2;  
    float q1q3 = q1*q3;  
    float q2q2 = q2*q2;  
    float q2q3 = q2*q3;  
    float q3q3 = q3*q3;  
            
     // normalise the measurements  
    norm = sqrt(ax*ax + ay*ay + az*az);  
    ax = ax / norm;  
    ay = ay / norm;  
    az = az / norm;  
    norm = sqrt(mx*mx + my*my + mz*mz);  
    mx = mx / norm;  
    my = my / norm;  
    mz = mz / norm;  
            
    // compute reference direction of magnetic field  
    hx = 2*mx*(0.5 - q2q2 - q3q3) + 2*my*(q1q2 - q0q3) + 2*mz*(q1q3 + q0q2);  
    hy = 2*mx*(q1q2 + q0q3) + 2*my*(0.5 - q1q1 - q3q3) + 2*mz*(q2q3 - q0q1);  
    hz = 2*mx*(q1q3 - q0q2) + 2*my*(q2q3 + q0q1) + 2*mz*(0.5 - q1q1 -q2q2);          
    bx = sqrt((hx*hx) + (hy*hy));  
    bz = hz;  
            
    // estimated direction of gravity and magnetic field (v and w)  
    vx = 2*(q1q3 - q0q2);  
    vy = 2*(q0q1 + q2q3);  
    vz = q0q0 - q1q1 - q2q2 + q3q3;  
    wx = 2*bx*(0.5 - q2q2 - q3q3) + 2*bz*(q1q3 - q0q2);  
    wy = 2*bx*(q1q2 - q0q3) + 2*bz*(q0q1 + q2q3);  
    wz = 2*bx*(q0q2 + q1q3) + 2*bz*(0.5 - q1q1 - q2q2);   
            
    // error is sum ofcross product between reference direction of fields and directionmeasured by sensors   
    ex = (ay*vz - az*vy) + (my*wz - mz*wy);  
    ey = (az*vx - ax*vz) + (mz*wx - mx*wz);  
    ez = (ax*vy - ay*vx) + (mx*wy - my*wx);  
            
    // integral error scaled integral gain  
    exInt = exInt + ex*Ki* (2 * halfT);  
    eyInt = eyInt + ey*Ki* (2 * halfT); 
    ezInt = ezInt + ez*Ki* (2 * halfT); 
           // adjusted gyroscope measurements  
    gx = gx + Kp*ex + exInt;  
    gy = gy + Kp*ey + eyInt;  
    gz = gz + Kp*ez + ezInt;  
            
    // integrate quaternion rate and normalize  
    q0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;  
    q1 = q1 + (q0*gx + q2*gz - q3*gy)*halfT;  
    q2 = q2 + (q0*gy - q1*gz + q3*gx)*halfT;  
    q3 = q3 + (q0*gz + q1*gy - q2*gx)*halfT; 
           
    //  printf("%f,%f,%f,%f\r\n",q0,q1,q2,q3);
            
    // normalise quaternion  
     norm = sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);  
     q0 = q0 / norm;  
     q1 = q1 / norm;  
     q2 = q2 / norm;  
     q3 = q3 / norm; 
           
     yaw = atan2(2 * q1 * q2 + 2 * q0 * q3, -2 * q2*q2 - 2 * q3* q3 + 1)* 57.296f; // yaw
     pitch  = asin(-2 * q1 * q3 + 2 * q0* q2)* 57.296f; // pitch
     roll = atan2(2 * q2 * q3 + 2 * q0 * q1, -2 * q1 * q1 - 2 * q2* q2 + 1)* 57.296f; // roll  
     
     pitch = -1.0f * pitch;
     if(roll<0)
     {
       roll += 360;
     }
     roll= roll-180;
     yaw =  -1.0f * yaw;
     //printf("pitch:%f,roll:%f,yaw:%f\r\n",pitch, roll, yaw);
} 
      
      

static void qua2cnb(void)
{
 float q00 = q0*q0, q01 = q0*q1, q02 = q0*q2, q03 = q0*q3;
 float q11 = q1*q1, q12 = q1*q2, q13 = q1*q3;
 float q22 = q2*q2, q23 = q2*q3;
 float q33 = q3*q3;
 C00 = q00+q11-q22-q33,  C01 = 2*(q12-q03),     C02 = 2*(q13+q02);  // ��Ԫ��ת��̬��
 C10 = 2*(q12+q03),      C11 = q00-q11+q22-q33, C12 = 2*(q23-q01);
 C20 = 2*(q13-q02),      C21 = 2*(q23+q01),     C22 = q00-q11-q22+q33;
}


void MahonyInit(float halT)
{
 float beta = 2.146f/(halT*2);
 Kp = 2.0f*beta, Ki = beta*beta;
 q0 = 1.0f, q1 = q2 = q3 = 0.0f;
 qua2cnb();
 exInt = eyInt = ezInt = 0.0f;
}      
      
      
void pitchRollYawUpdate(float gx, float gy, float gz, float ax, float ay, float az, float mx, float my, float mz, float halfT)      
{
 float norm;
 float by, bz, wx, wy, wz;
 float ex, ey, ez, KiT;
 float _q0, _q1, _q2, _q3;
 
 const float CONSTANTS_ONE_G = 9.80665f;
 const float D2R = M_PI_F/180;
 
 gx = (gx - gyro_calibration_value[0]) * D2R; //conver unit from deg to rad
 gy = (gy - gyro_calibration_value[1]) * D2R;
 gz= (gz - gyro_calibration_value[2]) * D2R;
 
 ax = (ax - accel_calibration_value[0]) * CONSTANTS_ONE_G; // conver unit from g to m/s^2
 ay = (ay - accel_calibration_value[1]) * CONSTANTS_ONE_G;
 //  az = (az - accel_calibration_value[2] - 1) * CONSTANTS_ONE_G;  
 az = az  * CONSTANTS_ONE_G;
 
 
 KiT = Ki*halfT*2;
 
 norm = (float)sqrt(ax*ax + ay*ay + az*az);       // �Ӽƹ�һ��
 norm = norm>0.1f ? 1.0f/norm : 0.0f;
 ax *= norm,  ay *= norm,  az *= norm;
 
 norm = (float)sqrt(mx*mx + my*my + mz*mz);       // �Ź�һ��
 norm = norm>0.1f ? 1.0f/norm : 0.0f;
 mx *= norm,  my *= norm,  mz *= norm;
 
 bz = C20*mx + C21*my + C22*mz;  // �ų�������ͶӰ����
 by = (float)sqrt(1.0f-bz*bz);   // �ų���ˮƽ���ű���ͶӰ����
// bx = 0.0f;                      // �ų��ĴŶ���ͶӰ����
 
 wx = C10*by + C20*bz;   // �ų�������bϵͶӰ����
 wy = C11*by + C21*bz;
 wz = C12*by + C22*bz;
 
 ex = (ay*C22-az*C21) + (my*wz-mz*wy); // �ӼƲ�ˮƽ���Ųⷽλ���
 ey = (az*C20-ax*C22) + (mz*wx-mx*wz);
 ez = (ax*C21-ay*C20) + (mx*wy-my*wx);
 
 exInt += ex * KiT;
 eyInt += ey * KiT;
 ezInt += ez * KiT;
 
 gx += Kp*ex + exInt;  // ��������
 gy += Kp*ey + eyInt;
 gz += Kp*ez + ezInt;
 
 _q0 = q0 + (-q1*gx - q2*gy - q3*gz)*halfT;  // ����Ԫ��΢�ַ���
 _q1 = q1 + ( q0*gx + q2*gz - q3*gy)*halfT;
 _q2 = q2 + ( q0*gy - q1*gz + q3*gx)*halfT;
 _q3 = q3 + ( q0*gz + q1*gy - q2*gx)*halfT;
 
 norm = 1.0f/(float)sqrt(_q0*_q0 + _q1*_q1 + _q2*_q2 + _q3*_q3); // ��Ԫ����һ��
 q0 = _q0 * norm, q1 = _q1 * norm, q2 = _q2 * norm, q3 = _q3 * norm;
 qua2cnb();
}
 
void MahonyGetEuler()
{
  pitch = (float)asin(C21) * 57.296f;   // deg
  roll  = (float)atan2(-C20, C22) * 57.296f;
  yaw   = (float)atan2(-C01, C11) * 57.296f;  // +-180deg, ��ƫ��Ϊ��
  //printf("pitch:%f,roll:%f,yaw:%f\r\n",pitch, roll, yaw);
}
 

   
