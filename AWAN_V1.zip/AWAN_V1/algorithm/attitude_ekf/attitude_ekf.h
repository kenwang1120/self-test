#pragma once

#ifndef _ATTITUDE_RKF_H_
#define _ATTITUDE_RKF_H_







// attitude_estimatorq status
#ifndef RAW_ATTITUDE
#define RAW_ATTITUDE (1)
#endif // !RAW_ATTITUDE

#ifndef VALID_ATTITUDE
#define VALID_ATTITUDE (2)
#endif // !VALID_ATTITUDE

#ifndef GOOD_ATTITUDE
#define GOOD_ATTITUDE (3)
#endif // !GOOD_ATTITUDE

#ifndef NOUPDATE_ATTITUDE
#define NOUPDATE_ATTITUDE (0)
#endif // !NOUPDATE_ATTITUDE

#ifdef __cplusplus
extern "C" {
#endif

int do_attitude_ekf(float* gyro, float * accel,float * mag, float dt, float* att_out, float* rate_out, float* accel_out);
void set_ekf_params();

#ifdef __cplusplus
}
#endif


#endif
