//******************************************************************************
//! @ProjectName: V-3000-HUANDA
//! @ModuleName:  estimator_interface.cpp
//!
//! @Purpose:
//! Definition of base class for attitude estimators
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//******************************************************************************

#include "estimator_interface.h"

#include <ecl.h>
#include <mathlib/mathlib.h>

const float EstimatorInterface::FILTER_UPDATE_PERIOD_S = FILTER_UPDATE_PERIOD_MS * 0.001f;
EstimatorInterface::EstimatorInterface()
{
    _obs_buffer_length = 0;
	_imu_buffer_length = 0;
	_min_obs_interval_us = 0; // minimum time inter
	_dt_imu_avg = 0.0f;

    memset(&_imu_sample_delayed,0,sizeof(_imu_sample_delayed));
    memset(&_mag_sample_delayed,0,sizeof(_mag_sample_delayed));
    memset(&_baro_sample_delayed,0,sizeof(_baro_sample_delayed));
    memset(&_gps_sample_delayed,0,sizeof(_gps_sample_delayed));
    memset(&_range_sample_delayed,0,sizeof(_range_sample_delayed));
    memset(&_airspeed_sample_delayed,0,sizeof(_airspeed_sample_delayed));
    memset(&_flow_sample_delayed,0,sizeof(_flow_sample_delayed));
    memset(&_ev_sample_delayed,0,sizeof(_ev_sample_delayed));
    memset(&_drag_sample_delayed,0,sizeof(_drag_sample_delayed));
    memset(&_drag_down_sampled,0,sizeof(_drag_sample_delayed));
    memset(&_auxvel_sample_delayed,0,sizeof(_auxvel_sample_delayed));

    _drag_sample_count = 0;
    _drag_sample_time_dt = 0.0f;
    _air_density = CONSTANTS_AIR_DENSITY_SEA_LEVEL_15C;

    _flow_max_rate     = 0.0f;
    _flow_min_distance = 0.0f;
    _flow_max_distance = 0.0f;

    memset(&_output_sample_delayed,0,sizeof(_output_sample_delayed));
    _output_sample_delayed.quat_nominal(0) = 1;
    memset(&_output_new,0,sizeof(_output_new));
    memset(&_output_vert_delayed,0,sizeof(_output_vert_delayed));
    memset(&_output_vert_new,0,sizeof(_output_vert_new));
    memset(&_imu_sample_new,0,sizeof(_imu_sample_new));

    _imu_updated = false;
    _initialised = false;

    _NED_origin_initialised = false;
    _gps_speed_valid = false;
    _gps_origin_eph = 0.0f; // horizontal position
    _gps_origin_epv = 0.0f; // vertical position u
    memset(&_pos_ref     ,0,sizeof(_pos_ref));   //
    memset(&_gps_pos_prev,0,sizeof(_gps_pos_prev));
    _gps_alt_prev = 0.0f;
    _gps_yaw_offset = 0.0f;

    _yaw_test_ratio = 0.0f;  
    memset(_mag_test_ratio,0,sizeof(float)*3);  
    memset(_vel_pos_test_ratio,0,sizeof(float)*6);
    _tas_test_ratio = 0.0f;
    _terr_test_ratio = 0.0f;
    _beta_test_ratio = 0.0f;
    memset(_drag_test_ratio,0,sizeof(float)*2);
    memset(&_innov_check_fail_status,0,sizeof(_innov_check_fail_status));

    _is_dead_reckoning = false;
    _deadreckon_time_exceeded = true;
    _is_wind_dead_reckoning = false;
    memset(_vibe_metrics,0,sizeof(float)*3);
    memset(_gps_drift_metrics,0,sizeof(float)*3);
	_vehicle_at_rest = false;	// true when the vehicle is at rest
	_time_last_move_detect_us = 0;	// timestamp of last movement detection event in microseconds
	_gps_drift_updated = false;

	_gps_buffer_fail      = false;
    _mag_buffer_fail      = false;
    _baro_buffer_fail     = false;
    _range_buffer_fail    = false;
    _airspeed_buffer_fail = false;
    _flow_buffer_fail     = false;
    _ev_buffer_fail       = false;
    _drag_buffer_fail     = false;
    _auxvel_buffer_fail   = false;

    _time_last_imu           = 0;
    _time_last_gps           = 0;
    _time_last_mag           = 0;
    _time_last_baro          = 0;
    _time_last_range         = 0;
    _time_last_airspeed      = 0;
    _time_last_ext_vision    = 0;
    _time_last_optflow       = 0;
    _time_last_gnd_effect_on = 0;
    _time_last_auxvel        = 0;

    _mag_declination_gps = 0.0f;
    _mag_inclination_gps = 0.0f;
    _mag_strength_gps    = 0.0f;
    memset(&_control_status     ,0,sizeof(_control_status));
    memset(&_control_status_prev,0,sizeof(_control_status_prev));
    memset(&_fault_status,       0,sizeof(_fault_status));
}

EstimatorInterface::~EstimatorInterface()
{

}

// Accumulate imu data and store to buffer at desired rate
void EstimatorInterface::setIMUData(const imuSample &imu_sample)
{
	if (!_initialised) {
		init(imu_sample.time_us);
		_initialised = true;
	}

	const float dt = math::constrain((imu_sample.time_us - _time_last_imu) / 1e6f, 1.0e-4f, 0.02f);

	_time_last_imu = imu_sample.time_us;

	if (_time_last_imu > 0) {
		_dt_imu_avg = 0.8f * _dt_imu_avg + 0.2f * dt;
	}

	// detect if the vehicle is not moving when on ground

		_time_last_move_detect_us = imu_sample.time_us;
		_vehicle_at_rest = false;

	// accumulate and down-sample imu data and push to the buffer when new downsampled data becomes available
	if (collect_imu(imu_sample)) {

		// down-sample the drag specific force data by accumulating and calculating the mean when
		// sufficient samples have been collected
		if ((_params.fusion_mode & MASK_USE_DRAG) && !_drag_buffer_fail) {

			// Allocate the required buffer size if not previously done
			// Do not retry if allocation has failed previously
			if (_drag_buffer.get_length() < _obs_buffer_length) {
				_drag_buffer_fail = !_drag_buffer.allocate(_obs_buffer_length);

				if (_drag_buffer_fail) {
					ECL_ERR("EKF drag buffer allocation failed");
					return;
				}
			}

			_drag_sample_count ++;
			// note acceleration is accumulated as a delta velocity
			_drag_down_sampled.accelXY(0) += imu_sample.delta_vel(0);
			_drag_down_sampled.accelXY(1) += imu_sample.delta_vel(1);
			_drag_down_sampled.time_us += imu_sample.time_us;
			_drag_sample_time_dt += imu_sample.delta_vel_dt;

			// calculate the downsample ratio for drag specific force data
			uint8_t min_sample_ratio = (uint8_t) ceilf((float)_imu_buffer_length / _obs_buffer_length);

			if (min_sample_ratio < 5) {
				min_sample_ratio = 5;
			}

			// calculate and store means from accumulated values
			if (_drag_sample_count >= min_sample_ratio) {
				// note conversion from accumulated delta velocity to acceleration
				_drag_down_sampled.accelXY(0) /= _drag_sample_time_dt;
				_drag_down_sampled.accelXY(1) /= _drag_sample_time_dt;
				_drag_down_sampled.time_us /= _drag_sample_count;

				// write to buffer
				_drag_buffer.push(_drag_down_sampled);

				// reset accumulators
				_drag_sample_count = 0;
				_drag_down_sampled.accelXY.zero();
				_drag_down_sampled.time_us = 0;
				_drag_sample_time_dt = 0.0f;
			}
		}
	}
}

void EstimatorInterface::setIMUData(uint64_t time_usec, uint64_t delta_ang_dt, uint64_t delta_vel_dt,
				    float (&delta_ang)[3], float (&delta_vel)[3])
{
	imuSample imu_sample_new;
	imu_sample_new.delta_ang = Vector3f(delta_ang);
	imu_sample_new.delta_vel = Vector3f(delta_vel);

	// convert time from us to secs
	imu_sample_new.delta_ang_dt = delta_ang_dt / 1e6f;
	imu_sample_new.delta_vel_dt = delta_vel_dt / 1e6f;
	imu_sample_new.time_us = time_usec;

	setIMUData(imu_sample_new);
}

void EstimatorInterface::setMagData(uint64_t time_usec, float (&data)[3])
{
	if (!_initialised || _mag_buffer_fail) {
		return;
	}

	// Allocate the required buffer size if not previously done
	// Do not retry if allocation has failed previously
	if (_mag_buffer.get_length() < _obs_buffer_length) {
		_mag_buffer_fail = !_mag_buffer.allocate(_obs_buffer_length);

		if (_mag_buffer_fail) {
			ECL_ERR("EKF mag buffer allocation failed");
			return;
		}
	}

	// limit data rate to prevent data being lost
	if ((time_usec - _time_last_mag) > _min_obs_interval_us) {

		magSample mag_sample_new;
		mag_sample_new.time_us = time_usec - uint64_t(_params.mag_delay_ms * 1000);

		mag_sample_new.time_us -= FILTER_UPDATE_PERIOD_MS * 1000 / 2;
		_time_last_mag = time_usec;

		mag_sample_new.mag = Vector3f(data);

		_mag_buffer.push(mag_sample_new);
	}
}

void EstimatorInterface::setGpsData(uint64_t time_usec, const gps_message &gps)
{
//	if (!_initialised || _gps_buffer_fail) {
//		return;
//	}
//
//	// Allocate the required buffer size if not previously done
//	// Do not retry if allocation has failed previously
//	if (_gps_buffer.get_length() < _obs_buffer_length) {
//		_gps_buffer_fail = !_gps_buffer.allocate(_obs_buffer_length);
//
//		if (_gps_buffer_fail) {
//			ECL_ERR("EKF GPS buffer allocation failed");
//			return;
//		}
//	}
//
//	// limit data rate to prevent data being lost
//	bool need_gps = (_params.fusion_mode & MASK_USE_GPS) || (_params.vdist_sensor_type == VDIST_SENSOR_GPS);
//
//	if (((time_usec - _time_last_gps) > _min_obs_interval_us) && need_gps && gps.fix_type > 2) {
//		gpsSample gps_sample_new;
//		gps_sample_new.time_us = gps.time_usec - uint64_t(_params.gps_delay_ms * 1000);
//
//		gps_sample_new.time_us -= FILTER_UPDATE_PERIOD_MS * 1000 / 2;
//		_time_last_gps = time_usec;
//
//		gps_sample_new.time_us = math::max(gps_sample_new.time_us, _imu_sample_delayed.time_us);
//		gps_sample_new.vel = Vector3f(gps.vel_ned);
//
//		_gps_speed_valid = gps.vel_ned_valid;
//		gps_sample_new.sacc = gps.sacc;
//		gps_sample_new.hacc = gps.eph;
//		gps_sample_new.vacc = gps.epv;
//
//		gps_sample_new.hgt = (float)gps.alt * 1e-3f;
//
//		gps_sample_new.yaw = gps.yaw;
//		if (ISFINITE(gps.yaw_offset)) {
//			_gps_yaw_offset = gps.yaw_offset;
//		} else {
//			_gps_yaw_offset = 0.0f;
//		}
//
//		// Only calculate the relative position if the WGS-84 location of the origin is set
//		if (collect_gps(gps)) {
//			float lpos_x = 0.0f;
//			float lpos_y = 0.0f;
//			map_projection_project(&_pos_ref, (gps.lat / 1.0e7), (gps.lon / 1.0e7), &lpos_x, &lpos_y);
//			gps_sample_new.pos(0) = lpos_x;
//			gps_sample_new.pos(1) = lpos_y;
//
//		} else {
//			gps_sample_new.pos(0) = 0.0f;
//			gps_sample_new.pos(1) = 0.0f;
//		}
//
//		_gps_buffer.push(gps_sample_new);
//	}
}

void EstimatorInterface::setBaroData(uint64_t time_usec, float data)
{
	if (!_initialised || _baro_buffer_fail) {
		return;
	}

	// Allocate the required buffer size if not previously done
	// Do not retry if allocation has failed previously
	if (_baro_buffer.get_length() < _obs_buffer_length) {
		_baro_buffer_fail = !_baro_buffer.allocate(_obs_buffer_length);

		if (_baro_buffer_fail) {
			ECL_ERR("EKF baro buffer allocation failed");
			return;
		}
	}

	// limit data rate to prevent data being lost
	if ((time_usec - _time_last_baro) > _min_obs_interval_us) {

		baroSample baro_sample_new;
		baro_sample_new.hgt = data;
		baro_sample_new.time_us = time_usec - uint64_t(_params.baro_delay_ms * 1000);

		baro_sample_new.time_us -= FILTER_UPDATE_PERIOD_MS * 1000 / 2;
		_time_last_baro = time_usec;

		baro_sample_new.time_us = math::max(baro_sample_new.time_us, _imu_sample_delayed.time_us);

		_baro_buffer.push(baro_sample_new);
	}
}

void EstimatorInterface::setAirspeedData(uint64_t time_usec, float true_airspeed, float eas2tas)
{
	if (!_initialised || _airspeed_buffer_fail) {
		return;
	}

	// Allocate the required buffer size if not previously done
	// Do not retry if allocation has failed previously
	if (_airspeed_buffer.get_length() < _obs_buffer_length) {
		_airspeed_buffer_fail = !_airspeed_buffer.allocate(_obs_buffer_length);

		if (_airspeed_buffer_fail) {
			ECL_ERR("EKF airspeed buffer allocation failed");
			return;
		}
	}

	// limit data rate to prevent data being lost
	if ((time_usec - _time_last_airspeed) > _min_obs_interval_us) {
		airspeedSample airspeed_sample_new;
		airspeed_sample_new.true_airspeed = true_airspeed;
		airspeed_sample_new.eas2tas = eas2tas;
		airspeed_sample_new.time_us = time_usec - uint64_t(_params.airspeed_delay_ms * 1000);
		airspeed_sample_new.time_us -= FILTER_UPDATE_PERIOD_MS * 1000 / 2;
		_time_last_airspeed = time_usec;

		_airspeed_buffer.push(airspeed_sample_new);
	}
}

void EstimatorInterface::setAuxVelData(uint64_t time_usec, float (&data)[2], float (&variance)[2])
{
	if (!_initialised || _auxvel_buffer_fail) {
		return;
	}

	// Allocate the required buffer size if not previously done
	// Do not retry if allocation has failed previously
	if (_auxvel_buffer.get_length() < _obs_buffer_length) {
		_auxvel_buffer_fail = !_auxvel_buffer.allocate(_obs_buffer_length);

		if (_auxvel_buffer_fail) {
			ECL_ERR("EKF aux vel buffer allocation failed");
			return;
		}
	}

	// limit data rate to prevent data being lost
	if ((time_usec - _time_last_auxvel) > _min_obs_interval_us) {

		auxVelSample auxvel_sample_new;
		auxvel_sample_new.time_us = time_usec - uint64_t(_params.auxvel_delay_ms * 1000);

		auxvel_sample_new.time_us -= FILTER_UPDATE_PERIOD_MS * 1000 / 2;
		_time_last_auxvel = time_usec;

		auxvel_sample_new.velNE = Vector2f(data);
		auxvel_sample_new.velVarNE = Vector2f(variance);

		_auxvel_buffer.push(auxvel_sample_new);
	}
}

bool EstimatorInterface::initialise_interface(uint64_t timestamp)
{
	// find the maximum time delay the buffers are required to handle
	uint16_t max_time_delay_ms = (uint16_t)math::max(_params.mag_delay_ms,
					     math::max(_params.gps_delay_ms,
						     math::max(_params.ev_delay_ms,
							 math::max(_params.auxvel_delay_ms,
							     math::max(_params.min_delay_ms,
								 math::max(_params.airspeed_delay_ms, _params.baro_delay_ms))))));

	// calculate the IMU buffer length required to accomodate the maximum delay with some allowance for jitter
	_imu_buffer_length = (max_time_delay_ms / FILTER_UPDATE_PERIOD_MS) + 1;

	// set the observation buffer length to handle the minimum time of arrival between observations in combination
	// with the worst case delay from current time to ekf fusion time
	// allow for worst case 50% extension of the ekf fusion time horizon delay due to timing jitter
	uint16_t ekf_delay_ms = max_time_delay_ms + (int)(ceilf((float)max_time_delay_ms * 0.5f));
	_obs_buffer_length = (ekf_delay_ms / _params.sensor_interval_min_ms) + 1;

	// limit to be no longer than the IMU buffer (we can't process data faster than the EKF prediction rate)
	_obs_buffer_length = math::min(_obs_buffer_length, _imu_buffer_length);

	if (!(_imu_buffer.allocate(_imu_buffer_length) &&
	      _output_buffer.allocate(_imu_buffer_length) &&
	      _output_vert_buffer.allocate(_imu_buffer_length))) {

		ECL_ERR("EKF buffer allocation failed!");
		unallocate_buffers();
		return false;
	}

	_imu_sample_delayed.delta_ang.setZero();
	_imu_sample_delayed.delta_vel.setZero();
	_imu_sample_delayed.delta_ang_dt = 0.0f;
	_imu_sample_delayed.delta_vel_dt = 0.0f;
	_imu_sample_delayed.time_us = timestamp;

	_initialised = false;

	_time_last_imu = 0;
	_time_last_gps = 0;
	_time_last_mag = 0;
	_time_last_baro = 0;
	_time_last_range = 0;
	_time_last_airspeed = 0;
	_time_last_optflow = 0;
	_fault_status.value = 0;
	_time_last_ext_vision = 0;
	return true;
}

void EstimatorInterface::unallocate_buffers()
{
	_imu_buffer.unallocate();
	_gps_buffer.unallocate();
	_mag_buffer.unallocate();
	_baro_buffer.unallocate();
	_airspeed_buffer.unallocate();
	_ext_vision_buffer.unallocate();
	_output_buffer.unallocate();
	_output_vert_buffer.unallocate();
	_drag_buffer.unallocate();
	_auxvel_buffer.unallocate();

}

bool EstimatorInterface::local_position_is_valid()
{
	// return true if we are not doing unconstrained free inertial navigation
	return !_deadreckon_time_exceeded;
}

void EstimatorInterface::print_status()
{
	ECL_INFO("local position valid: %s", local_position_is_valid() ? "yes" : "no");
	ECL_INFO("global position valid: %s", global_position_is_valid() ? "yes" : "no");

	ECL_INFO("imu buffer: %d (%d Bytes)", _imu_buffer.get_length(), _imu_buffer.get_total_size());
	ECL_INFO("gps buffer: %d (%d Bytes)", _gps_buffer.get_length(), _gps_buffer.get_total_size());
	ECL_INFO("mag buffer: %d (%d Bytes)", _mag_buffer.get_length(), _mag_buffer.get_total_size());
	ECL_INFO("baro buffer: %d (%d Bytes)", _baro_buffer.get_length(), _baro_buffer.get_total_size());
	ECL_INFO("airspeed buffer: %d (%d Bytes)", _airspeed_buffer.get_length(), _airspeed_buffer.get_total_size());
	ECL_INFO("ext vision buffer: %d (%d Bytes)", _ext_vision_buffer.get_length(), _ext_vision_buffer.get_total_size());
	ECL_INFO("output buffer: %d (%d Bytes)", _output_buffer.get_length(), _output_buffer.get_total_size());
	ECL_INFO("output vert buffer: %d (%d Bytes)", _output_vert_buffer.get_length(), _output_vert_buffer.get_total_size());
	ECL_INFO("drag buffer: %d (%d Bytes)", _drag_buffer.get_length(), _drag_buffer.get_total_size());
}
