/*
 * EKF_HDG_Gain_Sched_V0.c
 *
 * Code generation for model "EKF_HDG_Gain_Sched_V0".
 *
 * Model version              : 1.8
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Thu Feb 04 13:51:54 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "EKF_HDG_Gain_Sched_V0.h"
#include "EKF_HDG_Gain_Sched_V0_private.h"

/* External inputs (root inport signals with auto storage) */
ExtU_EKF_HDG_Gain_Sched_V0_T EKF_HDG_Gain_Sched_V0_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_EKF_HDG_Gain_Sched_V0_T EKF_HDG_Gain_Sched_V0_Y;

/* Real-time model */
RT_MODEL_EKF_HDG_Gain_Sched_V_T EKF_HDG_Gain_Sched_V0_M_;
RT_MODEL_EKF_HDG_Gain_Sched_V_T *const EKF_HDG_Gain_Sched_V0_M =
  &EKF_HDG_Gain_Sched_V0_M_;

/* Model step function */
void EKF_HDG_Gain_Sched_V0_step(void)
{
  int8_T rtb_DTC1[25];
  real_T rtb_MultiportSwitch;
  real_T rtb_OUT;
  int32_T i;

  /* DataTypeConversion: '<S3>/DTC1' incorporates:
   *  Constant: '<S1>/P_INDEX'
   *  Inport: '<Root>/Yaw_Ang_In'
   *  RelationalOperator: '<S3>/Relational Operator'
   */
  for (i = 0; i < 25; i++) {
    rtb_DTC1[i] = (int8_T)(EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In >=
      EKF_HDG_Gain_Sched_V0_P.HDG_Index[i]);
  }

  /* End of DataTypeConversion: '<S3>/DTC1' */

  /* Sum: '<S3>/Sum' */
  rtb_MultiportSwitch = rtb_DTC1[0];
  for (i = 0; i < 24; i++) {
    rtb_MultiportSwitch += (real_T)rtb_DTC1[i + 1];
  }

  /* End of Sum: '<S3>/Sum' */

  /* Saturate: '<S3>/OUT' */
  if (rtb_MultiportSwitch > EKF_HDG_Gain_Sched_V0_P.OUT_UpperSat) {
    rtb_OUT = EKF_HDG_Gain_Sched_V0_P.OUT_UpperSat;
  } else if (rtb_MultiportSwitch < EKF_HDG_Gain_Sched_V0_P.OUT_LowerSat) {
    rtb_OUT = EKF_HDG_Gain_Sched_V0_P.OUT_LowerSat;
  } else {
    rtb_OUT = rtb_MultiportSwitch;
  }

  /* End of Saturate: '<S3>/OUT' */

  /* Saturate: '<S2>/Saturation' */
  if (rtb_OUT > EKF_HDG_Gain_Sched_V0_P.Saturation_UpperSat) {
    rtb_MultiportSwitch = EKF_HDG_Gain_Sched_V0_P.Saturation_UpperSat;
  } else if (rtb_OUT < EKF_HDG_Gain_Sched_V0_P.Saturation_LowerSat) {
    rtb_MultiportSwitch = EKF_HDG_Gain_Sched_V0_P.Saturation_LowerSat;
  } else {
    rtb_MultiportSwitch = rtb_OUT;
  }

  /* End of Saturate: '<S2>/Saturation' */

  /* Product: '<S1>/Product' incorporates:
   *  Constant: '<S1>/Constant'
   *  Constant: '<S1>/P_INDEX'
   *  Inport: '<Root>/Yaw_Ang_In'
   *  MultiPortSwitch: '<S4>/Multiport Switch'
   *  MultiPortSwitch: '<S5>/Multiport Switch'
   *  Sum: '<S1>/Sum'
   *  Sum: '<S1>/Sum1'
   *  Sum: '<S1>/Sum2'
   */
  rtb_OUT = 1.0 / (EKF_HDG_Gain_Sched_V0_P.HDG_Index[(int32_T)(rtb_OUT +
    EKF_HDG_Gain_Sched_V0_P.Constant_Value_b) - 1] -
                   EKF_HDG_Gain_Sched_V0_P.HDG_Index[(int32_T)rtb_OUT - 1]) *
    (EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In - EKF_HDG_Gain_Sched_V0_P.HDG_Index
     [(int32_T)rtb_OUT - 1]);

  /* Saturate: '<S1>/Saturation1' */
  if (rtb_OUT > EKF_HDG_Gain_Sched_V0_P.Saturation1_UpperSat) {
    rtb_OUT = EKF_HDG_Gain_Sched_V0_P.Saturation1_UpperSat;
  } else {
    if (rtb_OUT < EKF_HDG_Gain_Sched_V0_P.Saturation1_LowerSat) {
      rtb_OUT = EKF_HDG_Gain_Sched_V0_P.Saturation1_LowerSat;
    }
  }

  /* End of Saturate: '<S1>/Saturation1' */

  /* Outport: '<Root>/Cal_Yaw_Ang_Out' incorporates:
   *  Constant: '<S2>/Constant'
   *  Constant: '<S2>/P_INTERP'
   *  MultiPortSwitch: '<S6>/Multiport Switch'
   *  MultiPortSwitch: '<S7>/Multiport Switch'
   *  Product: '<S2>/Product'
   *  Product: '<S2>/Product1'
   *  Sum: '<S2>/Sum'
   *  Sum: '<S2>/Sum1'
   *  Sum: '<S2>/Sum2'
   */
  EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out = EKF_HDG_Gain_Sched_V0_P.HDG_Interp
    [(int32_T)(rtb_MultiportSwitch + EKF_HDG_Gain_Sched_V0_P.Constant_Value) - 1]
    * rtb_OUT + EKF_HDG_Gain_Sched_V0_P.HDG_Interp[(int32_T)rtb_MultiportSwitch
    - 1] * (EKF_HDG_Gain_Sched_V0_P.Constant_Value - rtb_OUT);

  /* Matfile logging */
  //rt_UpdateTXYLogVars(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo,
  //                    (&EKF_HDG_Gain_Sched_V0_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [1.0s, 0.0s] */
    if ((rtmGetTFinal(EKF_HDG_Gain_Sched_V0_M)!=-1) &&
        !((rtmGetTFinal(EKF_HDG_Gain_Sched_V0_M)-
           EKF_HDG_Gain_Sched_V0_M->Timing.taskTime0) >
          EKF_HDG_Gain_Sched_V0_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(EKF_HDG_Gain_Sched_V0_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++EKF_HDG_Gain_Sched_V0_M->Timing.clockTick0)) {
    ++EKF_HDG_Gain_Sched_V0_M->Timing.clockTickH0;
  }

  EKF_HDG_Gain_Sched_V0_M->Timing.taskTime0 =
    EKF_HDG_Gain_Sched_V0_M->Timing.clockTick0 *
    EKF_HDG_Gain_Sched_V0_M->Timing.stepSize0 +
    EKF_HDG_Gain_Sched_V0_M->Timing.clockTickH0 *
    EKF_HDG_Gain_Sched_V0_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void EKF_HDG_Gain_Sched_V0_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)EKF_HDG_Gain_Sched_V0_M, 0,
                sizeof(RT_MODEL_EKF_HDG_Gain_Sched_V_T));
  rtmSetTFinal(EKF_HDG_Gain_Sched_V0_M, 10.0);
  EKF_HDG_Gain_Sched_V0_M->Timing.stepSize0 = 1.0;

  /* Setup for data logging */
  //{
  //  static RTWLogInfo rt_DataLoggingInfo;
  //  rt_DataLoggingInfo.loggingInterval = NULL;
  //  EKF_HDG_Gain_Sched_V0_M->rtwLogInfo = &rt_DataLoggingInfo;
  //}

  /* Setup for data logging */
  /*{
    rtliSetLogXSignalInfo(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, (NULL));
    rtliSetLogT(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, "tout");
    rtliSetLogX(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, "");
    rtliSetLogXFinal(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, 1);
    rtliSetLogY(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, (NULL));
  }*/

  /* external inputs */
  EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In = 0.0;

  /* external outputs */
  EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out = 0.0;

  /* Matfile logging */
  //rt_StartDataLoggingWithStartTime(EKF_HDG_Gain_Sched_V0_M->rtwLogInfo, 0.0,
  //  rtmGetTFinal(EKF_HDG_Gain_Sched_V0_M),
  //  EKF_HDG_Gain_Sched_V0_M->Timing.stepSize0, (&rtmGetErrorStatus
  //  (EKF_HDG_Gain_Sched_V0_M)));
}

/* Model terminate function */
void EKF_HDG_Gain_Sched_V0_terminate(void)
{
  /* (no terminate code required) */
}
