/*
 * AHRS_Yaw_Drift_Tuning.h
 *
 * Code generation for model "AHRS_Yaw_Drift_Tuning".
 *
 * Model version              : 1.7
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Tue Jan 12 10:52:55 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_AHRS_Yaw_Drift_Tuning_h_
#define RTW_HEADER_AHRS_Yaw_Drift_Tuning_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef AHRS_Yaw_Drift_Tuning_COMMON_INCLUDES_
# define AHRS_Yaw_Drift_Tuning_COMMON_INCLUDES_
#include "rtwtypes.h"
//#include "rtw_continuous.h"
//#include "rtw_solver.h"
//#include "rt_logging.h"
#endif                                 /* AHRS_Yaw_Drift_Tuning_COMMON_INCLUDES_ */

#include "AHRS_Yaw_Drift_Tuning_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T Delay_DSTATE;                 /* '<S10>/Delay' */
  real_T Delay1_DSTATE;                /* '<S10>/Delay1' */
  real_T Delay2_DSTATE;                /* '<S10>/Delay2' */
  real_T Delay3_DSTATE;                /* '<S10>/Delay3' */
  real_T Delay4_DSTATE;                /* '<S10>/Delay4' */
  real_T Delay5_DSTATE;                /* '<S10>/Delay5' */
  real_T Delay6_DSTATE;                /* '<S10>/Delay6' */
  real_T Delay7_DSTATE;                /* '<S10>/Delay7' */
  real_T Delay8_DSTATE;                /* '<S10>/Delay8' */
  real_T Delay2_DSTATE_l;              /* '<S6>/Delay2' */
  real_T Delay_DSTATE_h;               /* '<S7>/Delay' */
  real_T Delay1_DSTATE_g;              /* '<S7>/Delay1' */
  real_T Delay2_DSTATE_e;              /* '<S7>/Delay2' */
  real_T Delay3_DSTATE_o;              /* '<S7>/Delay3' */
  real_T Delay4_DSTATE_g;              /* '<S7>/Delay4' */
  real_T Delay5_DSTATE_j;              /* '<S7>/Delay5' */
  real_T Delay6_DSTATE_o;              /* '<S7>/Delay6' */
  real_T Delay7_DSTATE_b;              /* '<S7>/Delay7' */
  real_T Delay8_DSTATE_h;              /* '<S7>/Delay8' */
  real_T M2_PreviousInput;             /* '<S8>/M2' */
  real_T M1_PreviousInput;             /* '<S8>/M1' */
  real_T M2_PreviousInput_j;           /* '<S5>/M2' */
  real_T M1_PreviousInput_i;           /* '<S5>/M1' */
  boolean_T Delay_DSTATE_n;            /* '<S11>/Delay' */
} DW_AHRS_Yaw_Drift_Tuning_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Yaw_Rate_dps_In;              /* '<Root>/Yaw_Rate_dps_In' */
  real_T Yaw_Ang_In;                   /* '<Root>/Yaw_Ang_In' */
} ExtU_AHRS_Yaw_Drift_Tuning_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T Delta_Yaw_Rate_Rps_Out;       /* '<Root>/Delta_Yaw_Rate_Rps_Out' */
} ExtY_AHRS_Yaw_Drift_Tuning_T;

/* Parameters (auto storage) */
struct P_AHRS_Yaw_Drift_Tuning_T_ {
  real_T LAG_Psi_Tau;                  /* Mask Parameter: LAG_Psi_Tau
                                        * Referenced by: '<S5>/P_LAG'
                                        */
  real_T LAG_R_Tau;                    /* Mask Parameter: LAG_R_Tau
                                        * Referenced by: '<S8>/P_LAG'
                                        */
  real_T Logic_False_Gain1_Gain;       /* Expression: 0
                                        * Referenced by: '<Root>/Logic_False_Gain1'
                                        */
  real_T Logic_False_Gain_Gain;        /* Expression: 0
                                        * Referenced by: '<Root>/Logic_False_Gain'
                                        */
  real_T Psi_P_Gain_Gain;              /* Expression: 3.6
                                        * Referenced by: '<Root>/Psi_P_Gain'
                                        */
  real_T R_P_Gain_Gain;                /* Expression: 1
                                        * Referenced by: '<Root>/R_P_Gain'
                                        */
  real_T d2r_Gain;                     /* Expression: 0.0174533
                                        * Referenced by: '<Root>/d2r'
                                        */
  real_T Gain_Gain;                    /* Expression: 1
                                        * Referenced by: '<S5>/Gain'
                                        */
  real_T S1_Threshold;                 /* Expression: 0.5
                                        * Referenced by: '<S5>/S1'
                                        */
  real_T Gain_Gain_b;                  /* Expression: 1
                                        * Referenced by: '<S8>/Gain'
                                        */
  real_T S1_Threshold_k;               /* Expression: 0.5
                                        * Referenced by: '<S8>/S1'
                                        */
  real_T R_C0_Value;                   /* Expression: 0
                                        * Referenced by: '<S2>/R_C0'
                                        */
  real_T M2_X0;                        /* Expression: 0
                                        * Referenced by: '<S8>/M2'
                                        */
  real_T M1_X0;                        /* Expression: 0
                                        * Referenced by: '<S8>/M1'
                                        */
  real_T S2_Threshold;                 /* Expression: 0.5
                                        * Referenced by: '<S8>/S2'
                                        */
  real_T Delay_InitialCondition;       /* Expression: 0
                                        * Referenced by: '<S10>/Delay'
                                        */
  real_T Delay1_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay1'
                                        */
  real_T Delay2_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay2'
                                        */
  real_T Delay3_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay3'
                                        */
  real_T Delay4_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay4'
                                        */
  real_T Delay5_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay5'
                                        */
  real_T Delay6_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay6'
                                        */
  real_T Delay7_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay7'
                                        */
  real_T Delay8_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S10>/Delay8'
                                        */
  real_T Gain_Gain_h;                  /* Expression: 1/10
                                        * Referenced by: '<S10>/Gain'
                                        */
  real_T Ave_Gain_Gain;                /* Expression: 1
                                        * Referenced by: '<S9>/Ave_Gain'
                                        */
  real_T Psi_C0_Value;                 /* Expression: 0
                                        * Referenced by: '<S1>/Psi_C0'
                                        */
  real_T M2_X0_b;                      /* Expression: 0
                                        * Referenced by: '<S5>/M2'
                                        */
  real_T M1_X0_f;                      /* Expression: 0
                                        * Referenced by: '<S5>/M1'
                                        */
  real_T S2_Threshold_l;               /* Expression: 0.5
                                        * Referenced by: '<S5>/S2'
                                        */
  real_T Delay2_InitialCondition_l;    /* Expression: 0
                                        * Referenced by: '<S6>/Delay2'
                                        */
  real_T Delay_InitialCondition_g;     /* Expression: 0
                                        * Referenced by: '<S7>/Delay'
                                        */
  real_T Delay1_InitialCondition_j;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay1'
                                        */
  real_T Delay2_InitialCondition_m;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay2'
                                        */
  real_T Delay3_InitialCondition_a;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay3'
                                        */
  real_T Delay4_InitialCondition_g;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay4'
                                        */
  real_T Delay5_InitialCondition_l;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay5'
                                        */
  real_T Delay6_InitialCondition_o;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay6'
                                        */
  real_T Delay7_InitialCondition_m;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay7'
                                        */
  real_T Delay8_InitialCondition_k;    /* Expression: 0
                                        * Referenced by: '<S7>/Delay8'
                                        */
  real_T Gain_Gain_n;                  /* Expression: 1/10
                                        * Referenced by: '<S7>/Gain'
                                        */
  real_T Ave_Gain_Gain_d;              /* Expression: 1
                                        * Referenced by: '<S6>/Ave_Gain'
                                        */
  real_T Rate_Conv_Gain_Gain;          /* Expression: 600
                                        * Referenced by: '<Root>/Rate_Conv_Gain'
                                        */
  real32_T C_S0_Value;                 /* Computed Parameter: C_S0_Value
                                        * Referenced by: '<S4>/C_S0'
                                        */
  real32_T C_S1_Value;                 /* Computed Parameter: C_S1_Value
                                        * Referenced by: '<S4>/C_S1'
                                        */
  real32_T C_R0_Value;                 /* Computed Parameter: C_R0_Value
                                        * Referenced by: '<S4>/C_R0'
                                        */
  real32_T C0_LL_Value;                /* Computed Parameter: C0_LL_Value
                                        * Referenced by: '<S3>/C0_LL'
                                        */
  uint32_T Delay_DelayLength;          /* Computed Parameter: Delay_DelayLength
                                        * Referenced by: '<S10>/Delay'
                                        */
  uint32_T Delay1_DelayLength;         /* Computed Parameter: Delay1_DelayLength
                                        * Referenced by: '<S10>/Delay1'
                                        */
  uint32_T Delay2_DelayLength;         /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<S10>/Delay2'
                                        */
  uint32_T Delay3_DelayLength;         /* Computed Parameter: Delay3_DelayLength
                                        * Referenced by: '<S10>/Delay3'
                                        */
  uint32_T Delay4_DelayLength;         /* Computed Parameter: Delay4_DelayLength
                                        * Referenced by: '<S10>/Delay4'
                                        */
  uint32_T Delay5_DelayLength;         /* Computed Parameter: Delay5_DelayLength
                                        * Referenced by: '<S10>/Delay5'
                                        */
  uint32_T Delay6_DelayLength;         /* Computed Parameter: Delay6_DelayLength
                                        * Referenced by: '<S10>/Delay6'
                                        */
  uint32_T Delay7_DelayLength;         /* Computed Parameter: Delay7_DelayLength
                                        * Referenced by: '<S10>/Delay7'
                                        */
  uint32_T Delay8_DelayLength;         /* Computed Parameter: Delay8_DelayLength
                                        * Referenced by: '<S10>/Delay8'
                                        */
  uint32_T Delay2_DelayLength_e;       /* Computed Parameter: Delay2_DelayLength_e
                                        * Referenced by: '<S6>/Delay2'
                                        */
  uint32_T Delay_DelayLength_j;        /* Computed Parameter: Delay_DelayLength_j
                                        * Referenced by: '<S7>/Delay'
                                        */
  uint32_T Delay1_DelayLength_h;       /* Computed Parameter: Delay1_DelayLength_h
                                        * Referenced by: '<S7>/Delay1'
                                        */
  uint32_T Delay2_DelayLength_k;       /* Computed Parameter: Delay2_DelayLength_k
                                        * Referenced by: '<S7>/Delay2'
                                        */
  uint32_T Delay3_DelayLength_l;       /* Computed Parameter: Delay3_DelayLength_l
                                        * Referenced by: '<S7>/Delay3'
                                        */
  uint32_T Delay4_DelayLength_m;       /* Computed Parameter: Delay4_DelayLength_m
                                        * Referenced by: '<S7>/Delay4'
                                        */
  uint32_T Delay5_DelayLength_f;       /* Computed Parameter: Delay5_DelayLength_f
                                        * Referenced by: '<S7>/Delay5'
                                        */
  uint32_T Delay6_DelayLength_m;       /* Computed Parameter: Delay6_DelayLength_m
                                        * Referenced by: '<S7>/Delay6'
                                        */
  uint32_T Delay7_DelayLength_k;       /* Computed Parameter: Delay7_DelayLength_k
                                        * Referenced by: '<S7>/Delay7'
                                        */
  uint32_T Delay8_DelayLength_c;       /* Computed Parameter: Delay8_DelayLength_c
                                        * Referenced by: '<S7>/Delay8'
                                        */
  uint32_T Delay_DelayLength_l;        /* Computed Parameter: Delay_DelayLength_l
                                        * Referenced by: '<S11>/Delay'
                                        */
  boolean_T Delay_InitialCondition_l;  /* Computed Parameter: Delay_InitialCondition_l
                                        * Referenced by: '<S11>/Delay'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_AHRS_Yaw_Drift_Tuning_T {
  const char_T *errorStatus;
  //RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (auto storage) */
extern P_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_P;

/* Block states (auto storage) */
extern DW_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_Y;

/* Model entry point functions */
extern void AHRS_Yaw_Drift_Tuning_initialize(void);
extern void AHRS_Yaw_Drift_Tuning_step(void);
extern void AHRS_Yaw_Drift_Tuning_terminate(void);

/* Real-time Model object */
extern RT_MODEL_AHRS_Yaw_Drift_Tunin_T *const AHRS_Yaw_Drift_Tuning_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'AHRS_Yaw_Drift_Tuning'
 * '<S1>'   : 'AHRS_Yaw_Drift_Tuning/HDG_Ave'
 * '<S2>'   : 'AHRS_Yaw_Drift_Tuning/R_Ave'
 * '<S3>'   : 'AHRS_Yaw_Drift_Tuning/Rate_Limit_Logic'
 * '<S4>'   : 'AHRS_Yaw_Drift_Tuning/Yaw_Logic1'
 * '<S5>'   : 'AHRS_Yaw_Drift_Tuning/HDG_Ave/LAG_Psi'
 * '<S6>'   : 'AHRS_Yaw_Drift_Tuning/HDG_Ave/Psi_Ave_By_30'
 * '<S7>'   : 'AHRS_Yaw_Drift_Tuning/HDG_Ave/Psi_Ave_By_30/Ave_By_Ten3'
 * '<S8>'   : 'AHRS_Yaw_Drift_Tuning/R_Ave/LAG_R'
 * '<S9>'   : 'AHRS_Yaw_Drift_Tuning/R_Ave/R_Ave_By_30'
 * '<S10>'  : 'AHRS_Yaw_Drift_Tuning/R_Ave/R_Ave_By_30/Ave_By_Ten3'
 * '<S11>'  : 'AHRS_Yaw_Drift_Tuning/Yaw_Logic1/SRLatch'
 */
#endif                                 /* RTW_HEADER_AHRS_Yaw_Drift_Tuning_h_ */
