/*
 * EKF_HDG_Gain_Sched_V0_types.h
 *
 * Code generation for model "EKF_HDG_Gain_Sched_V0".
 *
 * Model version              : 1.8
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Thu Feb 04 13:51:54 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_EKF_HDG_Gain_Sched_V0_types_h_
#define RTW_HEADER_EKF_HDG_Gain_Sched_V0_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_EKF_HDG_Gain_Sched_V0_T_ P_EKF_HDG_Gain_Sched_V0_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_EKF_HDG_Gain_Sched_V0_T RT_MODEL_EKF_HDG_Gain_Sched_V_T;

#endif                                 /* RTW_HEADER_EKF_HDG_Gain_Sched_V0_types_h_ */
