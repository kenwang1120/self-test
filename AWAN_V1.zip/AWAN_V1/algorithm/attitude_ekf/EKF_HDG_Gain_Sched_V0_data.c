/*
 * EKF_HDG_Gain_Sched_V0_data.c
 *
 * Code generation for model "EKF_HDG_Gain_Sched_V0".
 *
 * Model version              : 1.8
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Thu Feb 04 13:51:54 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "EKF_HDG_Gain_Sched_V0.h"
#include "EKF_HDG_Gain_Sched_V0_private.h"

char arr1[20];
/* Block parameters (auto storage) */
P_EKF_HDG_Gain_Sched_V0_T EKF_HDG_Gain_Sched_V0_P = {
  /*  Variable: HDG_Index
   * Referenced by: '<S1>/P_INDEX'
   */
  //{ -176.5, -164.1, -150.0, -134.8, -119.0, -104.7, -90.2, -74.3, -58.7, -43.0,
  //  -28.7, -14.3, 1.25, 16.7, 32.3, 52.5, 73.25, 89.0, 106.7, 119.8, 132.6,145.4,
  //  157.9, 169.2, 180.0 },//2_2_1
  //{ -175.1, -162.7, -148.1, -131.9, -115.8, -98.7, -82.2, -66.7, -50.5, -34.6,
  //  -19.5, -4.0, 10.2, 25.7, 40.6, 54.7, 71.8, 87.9, 102.8, 115.9, 127.2,138.6,
  //  152.2, 169.0, 183.0 },//OK 9_2_1
  //  { -180.0, -166.3, -152.5, -137.8, -123.7, -109.9, -95.7, -82.1, -68.1, -54.2,
  //  -40.0, -25.1, -9.8, 4.1, 19.9, 35.5, 51.0, 67.6, 82.8, 98.6, 114.5,129.4,
  //  145.5, 161.0, 180.0 },//9_2_7 huan-da
  { -179.5, -165.0, -150.0, -135.0, -120.0, -105.0, -90.0, -75.0, -60.0, -45.0,
    -30.0, -15.0, 0.0, 15.0, 30.0, 45.0, 60.0, 75.0, 90.0, 105.0, 120.0, 135.0,
    150.0, 165.0, 179.5 },//desired
   //{ -179.5,-163,-146.3,-130.5,-115,-101.2,-88.5,-74.9,-60.8,-44.2,-26.4,-9.1,8.6,26.3,41.5,56.4,69.3,80.9,91.2,103.9,121.3,130.4,146.1,162.1,180 },//9-2-7
    //{-179.5,-163.1,-147.6,-132.3,-118.5,-105.2,-92.3,-79.9,-66.8,-53.1,-36.9,-21.3,-4.3,13.4,30.1,46.5,60.9,75.5,90.0,103.9,118.2,134.0,149.6,165.1,180.0},
    //{-179.5,-163.5,-148.2,-133.7,-119.6,-105.5,-91.7,-77.9,-63.2,-47.0,-29.2,-12.1,5.3,21.2,36.2,47.8,63.7,75.6,89.3,102.7,116.6,131.8,146.8,163.2,179.5}, 
  /*  Variable: HDG_Interp
   * Referenced by: '<S2>/P_INTERP'
   */
  { -179.5, -165.0, -150.0, -135.0, -120.0, -105.0, -90.0, -75.0, -60.0, -45.0,
    -30.0, -15.0, 0.0, 15.0, 30.0, 45.0, 60.0, 75.0, 90.0, 105.0, 120.0, 135.0,
    150.0, 165.0, 180.0 },
  24.0,                                /* Expression: 24
                                        * Referenced by: '<S3>/OUT'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S3>/OUT'
                                        */
  24.0,                                /* Expression: N - 1
                                        * Referenced by: '<S2>/Saturation'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/Saturation'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/Constant'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Constant'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/Saturation1'
                                        */
  0.0                                  /* Expression: 0
                                        * Referenced by: '<S1>/Saturation1'
                                        */
};
void  setData(float* hdgParam)
{
  int i=0;
  for(i=0;i<25;i++)
  {
    EKF_HDG_Gain_Sched_V0_P.HDG_Index[i] = hdgParam[i];
  }
  //for(i = 0; i < 25; i++)
  //{
  //  sprintf(arr1, "EKF_HDG_Gain_Sched_V0_P.HDG_Index[%d]=%f\r\n",i,EKF_HDG_Gain_Sched_V0_P.HDG_Index[i]);
  //  LPUART1_Send((__UINT8_T_TYPE__ const*)arr1, strlen(arr1));
  //}
}
