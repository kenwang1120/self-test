/*
 * Axyz_Estimation_to_VBxyz.h
 *
 * Code generation for model "Axyz_Estimation_to_VBxyz".
 *
 * Model version              : 1.157
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Sat May 07 14:20:14 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Axyz_Estimation_to_VBxyz_h_
#define RTW_HEADER_Axyz_Estimation_to_VBxyz_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef Axyz_Estimation_to_VBxyz_COMMON_INCLUDES_
# define Axyz_Estimation_to_VBxyz_COMMON_INCLUDES_
#include "rtwtypes.h"
//#include "rtw_continuous.h"
//#include "rtw_solver.h"
//#include "rt_logging.h"
#endif                                 /* Axyz_Estimation_to_VBxyz_COMMON_INCLUDES_ */

#include "Axyz_Estimation_to_VBxyz_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T Delay4_DSTATE;                /* '<S20>/Delay4' */
  real_T Delay3_DSTATE;                /* '<S20>/Delay3' */
  real_T Delay2_DSTATE;                /* '<S20>/Delay2' */
  real_T Delay1_DSTATE;                /* '<S20>/Delay1' */
  real_T Delay4_DSTATE_f;              /* '<S16>/Delay4' */
  real_T Delay3_DSTATE_n;              /* '<S16>/Delay3' */
  real_T Delay2_DSTATE_n;              /* '<S16>/Delay2' */
  real_T Delay1_DSTATE_m;              /* '<S16>/Delay1' */
  real_T Delay4_DSTATE_i;              /* '<S18>/Delay4' */
  real_T Delay3_DSTATE_m;              /* '<S18>/Delay3' */
  real_T Delay2_DSTATE_c;              /* '<S18>/Delay2' */
  real_T Delay1_DSTATE_l;              /* '<S18>/Delay1' */
  real_T Delay4_DSTATE_e;              /* '<S27>/Delay4' */
  real_T Delay3_DSTATE_d;              /* '<S27>/Delay3' */
  real_T Delay2_DSTATE_o;              /* '<S27>/Delay2' */
  real_T Delay1_DSTATE_o;              /* '<S27>/Delay1' */
  real_T Delay4_DSTATE_p;              /* '<S29>/Delay4' */
  real_T Delay3_DSTATE_mi;             /* '<S29>/Delay3' */
  real_T Delay2_DSTATE_cc;             /* '<S29>/Delay2' */
  real_T Delay1_DSTATE_b;              /* '<S29>/Delay1' */
  real_T Delay4_DSTATE_d;              /* '<S31>/Delay4' */
  real_T Delay3_DSTATE_nh;             /* '<S31>/Delay3' */
  real_T Delay2_DSTATE_g;              /* '<S31>/Delay2' */
  real_T Delay1_DSTATE_a;              /* '<S31>/Delay1' */
  real_T Delay4_DSTATE_j;              /* '<S37>/Delay4' */
  real_T Delay3_DSTATE_k;              /* '<S37>/Delay3' */
  real_T Delay2_DSTATE_a;              /* '<S37>/Delay2' */
  real_T Delay1_DSTATE_d;              /* '<S37>/Delay1' */
  real_T Delay4_DSTATE_fc;             /* '<S39>/Delay4' */
  real_T Delay3_DSTATE_j;              /* '<S39>/Delay3' */
  real_T Delay2_DSTATE_ae;             /* '<S39>/Delay2' */
  real_T Delay1_DSTATE_f;              /* '<S39>/Delay1' */
  real_T Memory4_PreviousInput;        /* '<S14>/Memory4' */
  real_T Memory3_PreviousInput;        /* '<S14>/Memory3' */
  real_T Memory4_PreviousInput_f;      /* '<S10>/Memory4' */
  real_T Memory2_PreviousInput;        /* '<S10>/Memory2' */
  real_T Memory2_PreviousInput_o;      /* '<S15>/Memory2' */
  real_T Memory1_PreviousInput;        /* '<S15>/Memory1' */
  real_T Memory4_PreviousInput_g;      /* '<S24>/Memory4' */
  real_T Memory3_PreviousInput_l;      /* '<S24>/Memory3' */
  real_T Memory4_PreviousInput_j;      /* '<S8>/Memory4' */
  real_T Memory2_PreviousInput_f;      /* '<S8>/Memory2' */
  real_T Memory2_PreviousInput_p;      /* '<S25>/Memory2' */
  real_T Memory1_PreviousInput_d;      /* '<S25>/Memory1' */
  real_T Memory2_PreviousInput_ft;     /* '<S35>/Memory2' */
  real_T Memory1_PreviousInput_o;      /* '<S35>/Memory1' */
  real_T Memory4_PreviousInput_l;      /* '<S9>/Memory4' */
  real_T Memory2_PreviousInput_j;      /* '<S9>/Memory2' */
  real_T Memory2_PreviousInput_g;      /* '<S36>/Memory2' */
  real_T Memory1_PreviousInput_da;     /* '<S36>/Memory1' */
  boolean_T Memory1_PreviousInput_l;   /* '<S21>/Memory1' */
  boolean_T Memory1_PreviousInput_p;   /* '<S17>/Memory1' */
  boolean_T Memory1_PreviousInput_b;   /* '<S19>/Memory1' */
  boolean_T Memory1_PreviousInput_ph;  /* '<S28>/Memory1' */
  boolean_T Memory1_PreviousInput_a;   /* '<S30>/Memory1' */
  boolean_T Memory1_PreviousInput_n;   /* '<S32>/Memory1' */
  boolean_T Memory1_PreviousInput_do;  /* '<S38>/Memory1' */
  boolean_T Memory1_PreviousInput_ak;  /* '<S40>/Memory1' */
} DW_Axyz_Estimation_to_VBxyz_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Ax_mps2;                      /* '<Root>/Ax_mps2' */
  real_T Ay_mps2;                      /* '<Root>/Ay_mps2' */
  real_T Az_mps2;                      /* '<Root>/Az_mps2' */
  real_T Phi_Deg;                      /* '<Root>/Phi_Deg' */
  real_T Theta_Deg;                    /* '<Root>/Theta_Deg' */
} ExtU_Axyz_Estimation_to_VBxyz_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T VB_x;                         /* '<Root>/VB_x' */
  real_T XB;                           /* '<Root>/XB' */
  real_T VB_y;                         /* '<Root>/VB_y' */
  real_T YB;                           /* '<Root>/YB' */
  real_T VB_z;                         /* '<Root>/VB_z' */
  real_T ZB;                           /* '<Root>/ZB' */
  boolean_T Road_Hole_Hit;             /* '<Root>/Road_Hole_Hit' */
} ExtY_Axyz_Estimation_to_VBxyz_T;

/* Parameters (auto storage) */
struct P_Axyz_Estimation_to_VBxyz_T_ {
  real_T DT;                           /* Variable: DT
                                        * Referenced by:
                                        *   '<S8>/Delta_T'
                                        *   '<S9>/Delta_T'
                                        *   '<S10>/Delta_T'
                                        *   '<S14>/Constant1'
                                        *   '<S15>/Constant5'
                                        *   '<S24>/Constant1'
                                        *   '<S25>/Constant5'
                                        *   '<S35>/Constant5'
                                        *   '<S36>/Constant5'
                                        */
  real_T Zero1_Value;                  /* Expression: 0
                                        * Referenced by: '<S11>/Zero1'
                                        */
  real_T Zero1_Value_j;                /* Expression: 0
                                        * Referenced by: '<S12>/Zero1'
                                        */
  real_T Ax_Zero1_Value;               /* Expression: 0.0
                                        * Referenced by: '<S13>/Ax_Zero1'
                                        */
  real_T Ax_NH_LL_Value;               /* Expression: -1.5
                                        * Referenced by: '<S5>/Ax_NH_LL'
                                        */
  real_T P_INTEG_LL_Value;             /* Expression: -inf
                                        * Referenced by: '<S15>/P_INTEG_LL'
                                        */
  real_T X_P_INTEG_Value;              /* Expression: 2.5
                                        * Referenced by: '<S15>/X_P_INTEG'
                                        */
  real_T X_Gain1_Gain;                 /* Expression: 0.5
                                        * Referenced by: '<S15>/X_Gain1'
                                        */
  real_T Ay_Zero1_Value;               /* Expression: 0.0
                                        * Referenced by: '<S22>/Ay_Zero1'
                                        */
  real_T Zero1_Value_m;                /* Expression: 0
                                        * Referenced by: '<S23>/Zero1'
                                        */
  real_T Ay_NH_LL_Value;               /* Expression: -1.5
                                        * Referenced by: '<S6>/Ay_NH_LL'
                                        */
  real_T P_INTEG_LL_Value_f;           /* Expression: -inf
                                        * Referenced by: '<S25>/P_INTEG_LL'
                                        */
  real_T P_INTEG_Value;                /* Expression: 2.5
                                        * Referenced by: '<S25>/P_INTEG'
                                        */
  real_T Gain1_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<S25>/Gain1'
                                        */
  real_T Zero1_Value_mb;               /* Expression: 0
                                        * Referenced by: '<S26>/Zero1'
                                        */
  real_T Az_Zero_Value;                /* Expression: 0.0
                                        * Referenced by: '<S33>/Az_Zero'
                                        */
  real_T Zero1_Value_l;                /* Expression: 0.0
                                        * Referenced by: '<S34>/Zero1'
                                        */
  real_T P_INTEG_LL_Value_g;           /* Expression: -inf
                                        * Referenced by: '<S35>/P_INTEG_LL'
                                        */
  real_T P_INTEG_Value_g;              /* Expression: 2.5
                                        * Referenced by: '<S35>/P_INTEG'
                                        */
  real_T Gain1_Gain_o;                 /* Expression: 0.5
                                        * Referenced by: '<S35>/Gain1'
                                        */
  real_T P_INTEG_LL_Value_h;           /* Expression: -inf
                                        * Referenced by: '<S36>/P_INTEG_LL'
                                        */
  real_T Ax_NH_UL_Value;               /* Expression: 1.5
                                        * Referenced by: '<S5>/Ax_NH_UL'
                                        */
  real_T Memory4_X0;                   /* Expression: 0
                                        * Referenced by: '<S14>/Memory4'
                                        */
  real_T Memory3_X0;                   /* Expression: 0
                                        * Referenced by: '<S14>/Memory3'
                                        */
  real_T Delay4_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S20>/Delay4'
                                        */
  real_T Delay3_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S20>/Delay3'
                                        */
  real_T Delay2_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S20>/Delay2'
                                        */
  real_T Delay1_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S20>/Delay1'
                                        */
  real_T P_LAG1_Value;                 /* Expression: 1
                                        * Referenced by: '<S10>/P_LAG1'
                                        */
  real_T Memory4_X0_c;                 /* Expression: 0
                                        * Referenced by: '<S10>/Memory4'
                                        */
  real_T Inv_G_Gain_Gain;              /* Expression: 0.1020
                                        * Referenced by: '<S1>/Inv_G_Gain'
                                        */
  real_T D2R_Gain_Gain;                /* Expression: 0.0174533
                                        * Referenced by: '<S1>/D2R_Gain'
                                        */
  real_T D2R_Gain1_Gain;               /* Expression: 0.0174533
                                        * Referenced by: '<S1>/D2R_Gain1'
                                        */
  real_T Phi_Amp_Gain_Gain;            /* Expression: 0.5
                                        * Referenced by: '<S2>/Phi_Amp_Gain'
                                        */
  real_T D_Ax_Tuning_Gain;             /* Expression: 1
                                        * Referenced by: '<S1>/D_Ax_Tuning'
                                        */
  real_T G_Gain1_Gain;                 /* Expression: 9.8
                                        * Referenced by: '<S1>/G_Gain1'
                                        */
  real_T Memory2_X0;                   /* Expression: 0
                                        * Referenced by: '<S10>/Memory2'
                                        */
  real_T Gain4_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<S10>/Gain4'
                                        */
  real_T Gain_Gain;                    /* Expression: 0.2
                                        * Referenced by: '<S20>/Gain'
                                        */
  real_T Ax_LL_Value;                  /* Expression: 0.1
                                        * Referenced by: '<S13>/Ax_LL'
                                        */
  real_T Ax_UL_Value;                  /* Expression: 0.05
                                        * Referenced by: '<S13>/Ax_UL'
                                        */
  real_T Ax_Amp_Gain_Gain;             /* Expression: 1.1
                                        * Referenced by: '<S5>/Ax_Amp_Gain'
                                        */
  real_T Delay4_InitialCondition_m;    /* Expression: 0
                                        * Referenced by: '<S16>/Delay4'
                                        */
  real_T Delay3_InitialCondition_b;    /* Expression: 0
                                        * Referenced by: '<S16>/Delay3'
                                        */
  real_T Delay2_InitialCondition_m;    /* Expression: 0
                                        * Referenced by: '<S16>/Delay2'
                                        */
  real_T Delay1_InitialCondition_m;    /* Expression: 0
                                        * Referenced by: '<S16>/Delay1'
                                        */
  real_T Gain_Gain_i;                  /* Expression: 0.2
                                        * Referenced by: '<S16>/Gain'
                                        */
  real_T LL_Value;                     /* Expression: 0.03
                                        * Referenced by: '<S11>/LL'
                                        */
  real_T UL_Value;                     /* Expression: 0.04
                                        * Referenced by: '<S11>/UL'
                                        */
  real_T Ax_Gain_Gain;                 /* Expression: 0.5
                                        * Referenced by: '<S14>/Ax_Gain'
                                        */
  real_T P_INTEG1_Value;               /* Expression: 2.5
                                        * Referenced by: '<S14>/P_INTEG1'
                                        */
  real_T VX_Amp_Tuning1_Gain;          /* Expression: 1
                                        * Referenced by: '<S5>/VX_Amp_Tuning1'
                                        */
  real_T Delay4_InitialCondition_n;    /* Expression: 0
                                        * Referenced by: '<S18>/Delay4'
                                        */
  real_T Delay3_InitialCondition_o;    /* Expression: 0
                                        * Referenced by: '<S18>/Delay3'
                                        */
  real_T Delay2_InitialCondition_j;    /* Expression: 0
                                        * Referenced by: '<S18>/Delay2'
                                        */
  real_T Delay1_InitialCondition_g;    /* Expression: 0
                                        * Referenced by: '<S18>/Delay1'
                                        */
  real_T Gain_Gain_h;                  /* Expression: 0.2
                                        * Referenced by: '<S18>/Gain'
                                        */
  real_T LL2_Value;                    /* Expression: 0.35
                                        * Referenced by: '<S12>/LL2'
                                        */
  real_T UL2_Value;                    /* Expression: 0.5
                                        * Referenced by: '<S12>/UL2'
                                        */
  real_T X_Amp_Tuning_Gain;            /* Expression: 1.0
                                        * Referenced by: '<S5>/X_Amp_Tuning'
                                        */
  real_T P_INTEG_UL_Value;             /* Expression: inf
                                        * Referenced by: '<S15>/P_INTEG_UL'
                                        */
  real_T Memory2_X0_m;                 /* Expression: 0
                                        * Referenced by: '<S15>/Memory2'
                                        */
  real_T No_Hold1_Value;               /* Expression: 0
                                        * Referenced by: '<S5>/No_Hold1'
                                        */
  real_T Memory1_X0;                   /* Expression: 0
                                        * Referenced by: '<S15>/Memory1'
                                        */
  real_T Switch3_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S15>/Switch3'
                                        */
  real_T Ay_NH_UL_Value;               /* Expression: 1.5
                                        * Referenced by: '<S6>/Ay_NH_UL'
                                        */
  real_T Memory4_X0_o;                 /* Expression: 0
                                        * Referenced by: '<S24>/Memory4'
                                        */
  real_T Memory3_X0_a;                 /* Expression: 0
                                        * Referenced by: '<S24>/Memory3'
                                        */
  real_T Delay4_InitialCondition_ml;   /* Expression: 0
                                        * Referenced by: '<S27>/Delay4'
                                        */
  real_T Delay3_InitialCondition_n;    /* Expression: 0
                                        * Referenced by: '<S27>/Delay3'
                                        */
  real_T Delay2_InitialCondition_e;    /* Expression: 0
                                        * Referenced by: '<S27>/Delay2'
                                        */
  real_T Delay1_InitialCondition_mc;   /* Expression: 0
                                        * Referenced by: '<S27>/Delay1'
                                        */
  real_T P_LAG1_Value_p;               /* Expression: 1
                                        * Referenced by: '<S8>/P_LAG1'
                                        */
  real_T Memory4_X0_k;                 /* Expression: 0
                                        * Referenced by: '<S8>/Memory4'
                                        */
  real_T Inv_G_Gain1_Gain;             /* Expression: 0.1020
                                        * Referenced by: '<S1>/Inv_G_Gain1'
                                        */
  real_T Theta_Amp_Gain_Gain;          /* Expression: 0.5
                                        * Referenced by: '<S2>/Theta_Amp_Gain'
                                        */
  real_T D_Ay_Tuning_Gain;             /* Expression: 1.0
                                        * Referenced by: '<S1>/D_Ay_Tuning'
                                        */
  real_T G_Gain_Gain;                  /* Expression: 9.8
                                        * Referenced by: '<S1>/G_Gain'
                                        */
  real_T Memory2_X0_l;                 /* Expression: 0
                                        * Referenced by: '<S8>/Memory2'
                                        */
  real_T Gain4_Gain_g;                 /* Expression: 0.5
                                        * Referenced by: '<S8>/Gain4'
                                        */
  real_T Gain_Gain_hz;                 /* Expression: 0.2
                                        * Referenced by: '<S27>/Gain'
                                        */
  real_T Ay_LL_Value;                  /* Expression: 0.5
                                        * Referenced by: '<S22>/Ay_LL'
                                        */
  real_T Ay_UL_Value;                  /* Expression: 0.6
                                        * Referenced by: '<S22>/Ay_UL'
                                        */
  real_T Gain9_Gain;                   /* Expression: 1.1
                                        * Referenced by: '<S6>/Gain9'
                                        */
  real_T Delay4_InitialCondition_k;    /* Expression: 0
                                        * Referenced by: '<S29>/Delay4'
                                        */
  real_T Delay3_InitialCondition_no;   /* Expression: 0
                                        * Referenced by: '<S29>/Delay3'
                                        */
  real_T Delay2_InitialCondition_k;    /* Expression: 0
                                        * Referenced by: '<S29>/Delay2'
                                        */
  real_T Delay1_InitialCondition_k;    /* Expression: 0
                                        * Referenced by: '<S29>/Delay1'
                                        */
  real_T Gain_Gain_k;                  /* Expression: 0.2
                                        * Referenced by: '<S29>/Gain'
                                        */
  real_T LL_Value_e;                   /* Expression: 0.03
                                        * Referenced by: '<S23>/LL'
                                        */
  real_T UL_Value_i;                   /* Expression: 0.05
                                        * Referenced by: '<S23>/UL'
                                        */
  real_T Ay_Gain_Gain;                 /* Expression: 0.6
                                        * Referenced by: '<S6>/Ay_Gain'
                                        */
  real_T Gain_Gain_h4;                 /* Expression: 0.5
                                        * Referenced by: '<S24>/Gain'
                                        */
  real_T P_INTEG1_Value_e;             /* Expression: 2.5
                                        * Referenced by: '<S24>/P_INTEG1'
                                        */
  real_T Vy_Gain1_Gain;                /* Expression: 1.0
                                        * Referenced by: '<S6>/Vy_Gain1'
                                        */
  real_T Delay4_InitialCondition_b;    /* Expression: 0
                                        * Referenced by: '<S31>/Delay4'
                                        */
  real_T Delay3_InitialCondition_ni;   /* Expression: 0
                                        * Referenced by: '<S31>/Delay3'
                                        */
  real_T Delay2_InitialCondition_l;    /* Expression: 0
                                        * Referenced by: '<S31>/Delay2'
                                        */
  real_T Delay1_InitialCondition_h;    /* Expression: 0
                                        * Referenced by: '<S31>/Delay1'
                                        */
  real_T Gain_Gain_kd;                 /* Expression: 0.2
                                        * Referenced by: '<S31>/Gain'
                                        */
  real_T LL_Value_eu;                  /* Expression: 0.35
                                        * Referenced by: '<S26>/LL'
                                        */
  real_T UL_Value_l;                   /* Expression: 0.4
                                        * Referenced by: '<S26>/UL'
                                        */
  real_T Y_Amp_Tuning_Gain;            /* Expression: 1.0
                                        * Referenced by: '<S6>/Y_Amp_Tuning'
                                        */
  real_T P_INTEG_UL_Value_j;           /* Expression: inf
                                        * Referenced by: '<S25>/P_INTEG_UL'
                                        */
  real_T Memory2_X0_n;                 /* Expression: 0
                                        * Referenced by: '<S25>/Memory2'
                                        */
  real_T Y_No_Hold1_Value;             /* Expression: 0
                                        * Referenced by: '<S6>/Y_No_Hold1'
                                        */
  real_T Memory1_X0_h;                 /* Expression: 0
                                        * Referenced by: '<S25>/Memory1'
                                        */
  real_T Switch3_Threshold_f;          /* Expression: 0.5
                                        * Referenced by: '<S25>/Switch3'
                                        */
  real_T P_INTEG_UL_Value_m;           /* Expression: inf
                                        * Referenced by: '<S35>/P_INTEG_UL'
                                        */
  real_T Memory2_X0_nb;                /* Expression: 0
                                        * Referenced by: '<S35>/Memory2'
                                        */
  real_T Az_No_Hold_Value;             /* Expression: 0.0
                                        * Referenced by: '<S7>/Az_No_Hold'
                                        */
  real_T Memory1_X0_j;                 /* Expression: 0
                                        * Referenced by: '<S35>/Memory1'
                                        */
  real_T Delay4_InitialCondition_e;    /* Expression: 0
                                        * Referenced by: '<S37>/Delay4'
                                        */
  real_T Delay3_InitialCondition_d;    /* Expression: 0
                                        * Referenced by: '<S37>/Delay3'
                                        */
  real_T Delay2_InitialCondition_f;    /* Expression: 0
                                        * Referenced by: '<S37>/Delay2'
                                        */
  real_T Delay1_InitialCondition_gz;   /* Expression: 0
                                        * Referenced by: '<S37>/Delay1'
                                        */
  real_T P_LAG1_Value_j;               /* Expression: 1
                                        * Referenced by: '<S9>/P_LAG1'
                                        */
  real_T Memory4_X0_m;                 /* Expression: 0
                                        * Referenced by: '<S9>/Memory4'
                                        */
  real_T Gain_Gain_ha;                 /* Expression: -1
                                        * Referenced by: '<S3>/Gain'
                                        */
  real_T Memory2_X0_j;                 /* Expression: 0
                                        * Referenced by: '<S9>/Memory2'
                                        */
  real_T Gain4_Gain_m;                 /* Expression: 0.5
                                        * Referenced by: '<S9>/Gain4'
                                        */
  real_T Inv_G_Gain1_Gain_e;           /* Expression: 0.1020
                                        * Referenced by: '<S3>/Inv_G_Gain1'
                                        */
  real_T Gain1_Gain_k;                 /* Expression: 9.8
                                        * Referenced by: '<S7>/Gain1'
                                        */
  real_T Az_Neg_Gain_Gain;             /* Expression: -1.0
                                        * Referenced by: '<S7>/Az_Neg_Gain'
                                        */
  real_T Gain_Gain_e;                  /* Expression: 0.2
                                        * Referenced by: '<S37>/Gain'
                                        */
  real_T Az_LL_Value;                  /* Expression: 0.4
                                        * Referenced by: '<S33>/Az_LL'
                                        */
  real_T Az_UL_Value;                  /* Expression: 0.5
                                        * Referenced by: '<S33>/Az_UL'
                                        */
  real_T Az_Amp_Gain_Gain;             /* Expression: 1.0
                                        * Referenced by: '<S7>/Az_Amp_Gain'
                                        */
  real_T Switch3_Threshold_j;          /* Expression: 0.5
                                        * Referenced by: '<S35>/Switch3'
                                        */
  real_T Vz_Amp_Tuning1_Gain;          /* Expression: 1.0
                                        * Referenced by: '<S7>/Vz_Amp_Tuning1'
                                        */
  real_T Delay4_InitialCondition_ec;   /* Expression: 0
                                        * Referenced by: '<S39>/Delay4'
                                        */
  real_T Delay3_InitialCondition_l;    /* Expression: 0
                                        * Referenced by: '<S39>/Delay3'
                                        */
  real_T Delay2_InitialCondition_f4;   /* Expression: 0
                                        * Referenced by: '<S39>/Delay2'
                                        */
  real_T Delay1_InitialCondition_b;    /* Expression: 0
                                        * Referenced by: '<S39>/Delay1'
                                        */
  real_T Gain_Gain_f;                  /* Expression: 0.2
                                        * Referenced by: '<S39>/Gain'
                                        */
  real_T UL_Value_b;                   /* Expression: 0.25
                                        * Referenced by: '<S34>/UL'
                                        */
  real_T LL_Value_j;                   /* Expression: 0.2
                                        * Referenced by: '<S34>/LL'
                                        */
  real_T Z_Amp_Tuning_Gain;            /* Expression: 1.0
                                        * Referenced by: '<S7>/Z_Amp_Tuning'
                                        */
  real_T P_INTEG_UL_Value_jt;          /* Expression: inf
                                        * Referenced by: '<S36>/P_INTEG_UL'
                                        */
  real_T Memory2_X0_mz;                /* Expression: 0
                                        * Referenced by: '<S36>/Memory2'
                                        */
  real_T Memory1_X0_hi;                /* Expression: 0
                                        * Referenced by: '<S36>/Memory1'
                                        */
  real_T Gain1_Gain_km;                /* Expression: 0.5
                                        * Referenced by: '<S36>/Gain1'
                                        */
  real_T P_INTEG_Value_g5;             /* Expression: 2.5
                                        * Referenced by: '<S36>/P_INTEG'
                                        */
  real_T Hole_Tune_C0_Value;           /* Expression: 1.5
                                        * Referenced by: '<S2>/Hole_Tune_C0'
                                        */
  uint32_T Delay4_DelayLength;         /* Computed Parameter: Delay4_DelayLength
                                        * Referenced by: '<S20>/Delay4'
                                        */
  uint32_T Delay3_DelayLength;         /* Computed Parameter: Delay3_DelayLength
                                        * Referenced by: '<S20>/Delay3'
                                        */
  uint32_T Delay2_DelayLength;         /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<S20>/Delay2'
                                        */
  uint32_T Delay1_DelayLength;         /* Computed Parameter: Delay1_DelayLength
                                        * Referenced by: '<S20>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_a;       /* Computed Parameter: Delay4_DelayLength_a
                                        * Referenced by: '<S16>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_k;       /* Computed Parameter: Delay3_DelayLength_k
                                        * Referenced by: '<S16>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_d;       /* Computed Parameter: Delay2_DelayLength_d
                                        * Referenced by: '<S16>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_c;       /* Computed Parameter: Delay1_DelayLength_c
                                        * Referenced by: '<S16>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_m;       /* Computed Parameter: Delay4_DelayLength_m
                                        * Referenced by: '<S18>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_e;       /* Computed Parameter: Delay3_DelayLength_e
                                        * Referenced by: '<S18>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_p;       /* Computed Parameter: Delay2_DelayLength_p
                                        * Referenced by: '<S18>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_n;       /* Computed Parameter: Delay1_DelayLength_n
                                        * Referenced by: '<S18>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_e;       /* Computed Parameter: Delay4_DelayLength_e
                                        * Referenced by: '<S27>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_o;       /* Computed Parameter: Delay3_DelayLength_o
                                        * Referenced by: '<S27>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_a;       /* Computed Parameter: Delay2_DelayLength_a
                                        * Referenced by: '<S27>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_e;       /* Computed Parameter: Delay1_DelayLength_e
                                        * Referenced by: '<S27>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_b;       /* Computed Parameter: Delay4_DelayLength_b
                                        * Referenced by: '<S29>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_m;       /* Computed Parameter: Delay3_DelayLength_m
                                        * Referenced by: '<S29>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_f;       /* Computed Parameter: Delay2_DelayLength_f
                                        * Referenced by: '<S29>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_f;       /* Computed Parameter: Delay1_DelayLength_f
                                        * Referenced by: '<S29>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_g;       /* Computed Parameter: Delay4_DelayLength_g
                                        * Referenced by: '<S31>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_ek;      /* Computed Parameter: Delay3_DelayLength_ek
                                        * Referenced by: '<S31>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_p0;      /* Computed Parameter: Delay2_DelayLength_p0
                                        * Referenced by: '<S31>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_a;       /* Computed Parameter: Delay1_DelayLength_a
                                        * Referenced by: '<S31>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_l;       /* Computed Parameter: Delay4_DelayLength_l
                                        * Referenced by: '<S37>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_m3;      /* Computed Parameter: Delay3_DelayLength_m3
                                        * Referenced by: '<S37>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_pc;      /* Computed Parameter: Delay2_DelayLength_pc
                                        * Referenced by: '<S37>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_m;       /* Computed Parameter: Delay1_DelayLength_m
                                        * Referenced by: '<S37>/Delay1'
                                        */
  uint32_T Delay4_DelayLength_j;       /* Computed Parameter: Delay4_DelayLength_j
                                        * Referenced by: '<S39>/Delay4'
                                        */
  uint32_T Delay3_DelayLength_p;       /* Computed Parameter: Delay3_DelayLength_p
                                        * Referenced by: '<S39>/Delay3'
                                        */
  uint32_T Delay2_DelayLength_e;       /* Computed Parameter: Delay2_DelayLength_e
                                        * Referenced by: '<S39>/Delay2'
                                        */
  uint32_T Delay1_DelayLength_j;       /* Computed Parameter: Delay1_DelayLength_j
                                        * Referenced by: '<S39>/Delay1'
                                        */
  boolean_T Memory1_X0_k;              /* Computed Parameter: Memory1_X0_k
                                        * Referenced by: '<S21>/Memory1'
                                        */
  boolean_T Memory1_X0_m;              /* Computed Parameter: Memory1_X0_m
                                        * Referenced by: '<S17>/Memory1'
                                        */
  boolean_T Memory1_X0_me;             /* Computed Parameter: Memory1_X0_me
                                        * Referenced by: '<S19>/Memory1'
                                        */
  boolean_T Memory1_X0_g;              /* Computed Parameter: Memory1_X0_g
                                        * Referenced by: '<S28>/Memory1'
                                        */
  boolean_T Memory1_X0_ml;             /* Computed Parameter: Memory1_X0_ml
                                        * Referenced by: '<S30>/Memory1'
                                        */
  boolean_T Memory1_X0_c;              /* Computed Parameter: Memory1_X0_c
                                        * Referenced by: '<S32>/Memory1'
                                        */
  boolean_T Memory1_X0_n;              /* Computed Parameter: Memory1_X0_n
                                        * Referenced by: '<S38>/Memory1'
                                        */
  boolean_T Memory1_X0_kd;             /* Computed Parameter: Memory1_X0_kd
                                        * Referenced by: '<S40>/Memory1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_Axyz_Estimation_to_VB_T {
  const char_T *errorStatus;
//  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (auto storage) */
extern P_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_P;

/* Block states (auto storage) */
extern DW_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_Y;

/* Model entry point functions */
extern void Axyz_Estimation_to_VBxyz_initialize(void);
extern void Axyz_Estimation_to_VBxyz_step(void);
extern void Axyz_Estimation_to_VBxyz_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Axyz_Estimation_to_V_T *const Axyz_Estimation_to_VBxyz_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Axyz_Estimation_to_VBxyz'
 * '<S1>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem'
 * '<S2>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Gravity_Effect_Cancelation'
 * '<S3>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Total_Acc1'
 * '<S4>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub'
 * '<S5>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2'
 * '<S6>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2'
 * '<S7>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub'
 * '<S8>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Hz_50_Ang_Fil1'
 * '<S9>'   : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Hz_50_Ang_Fil2'
 * '<S10>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Hz_50_Ang_Fil6'
 * '<S11>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set1'
 * '<S12>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set2'
 * '<S13>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set3'
 * '<S14>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Integ_Sub1'
 * '<S15>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Integ_Sub3'
 * '<S16>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set1/Ave'
 * '<S17>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set1/Latch'
 * '<S18>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set2/Ave'
 * '<S19>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set2/Latch'
 * '<S20>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set3/Ave'
 * '<S21>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ax_X_Sub2/Ax_Dead_Zone_Set3/Ax_Latch'
 * '<S22>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Ay_Dead_Zone_Set0'
 * '<S23>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Ay_Dead_Zone_Set3'
 * '<S24>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Integ_Sub1'
 * '<S25>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Integ_Sub3'
 * '<S26>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Vy_Dead_Zone_Set2'
 * '<S27>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Ay_Dead_Zone_Set0/Ay_Ave_Cal'
 * '<S28>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Ay_Dead_Zone_Set0/Latch'
 * '<S29>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Ay_Dead_Zone_Set3/Ave'
 * '<S30>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Ay_Dead_Zone_Set3/Latch'
 * '<S31>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Vy_Dead_Zone_Set2/Ave'
 * '<S32>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Ay_Y_Sub2/Vy_Dead_Zone_Set2/Latch'
 * '<S33>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Az_Dead_Zone_Set1'
 * '<S34>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Vz_Dead_Zone_Set2'
 * '<S35>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Vz_Integ_Sub'
 * '<S36>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Z_Integ_Sub1'
 * '<S37>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Az_Dead_Zone_Set1/AzAve'
 * '<S38>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Az_Dead_Zone_Set1/Az_Latch'
 * '<S39>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Vz_Dead_Zone_Set2/Ave'
 * '<S40>'  : 'Axyz_Estimation_to_VBxyz/A_xyz_to_VB_xyz_Subsystem/Val_Pos_Estimate_Sub/Az_Z_Sub/Vz_Dead_Zone_Set2/Latch'
 */
#endif                                 /* RTW_HEADER_Axyz_Estimation_to_VBxyz_h_ */
