/*
 * AHRS_Angle_PI_Gain_Tuning.c
 *
 * Code generation for model "AHRS_Angle_PI_Gain_Tuning".
 *
 * Model version              : 1.3
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Wed Jan 06 15:50:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "AHRS_Angle_PI_Gain_Tuning.h"
#include "AHRS_Angle_PI_Gain_Tuning_private.h"

/* Block states (auto storage) */
DW_AHRS_Angle_PI_Gain_Tuning_T AHRS_Angle_PI_Gain_Tuning_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_AHRS_Angle_PI_Gain_Tunin_T AHRS_Angle_PI_Gain_Tuning_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_AHRS_Angle_PI_Gain_Tunin_T AHRS_Angle_PI_Gain_Tuning_Y;

/* Real-time model */
RT_MODEL_AHRS_Angle_PI_Gain_T_T AHRS_Angle_PI_Gain_Tuning_M_;
RT_MODEL_AHRS_Angle_PI_Gain_T_T *const AHRS_Angle_PI_Gain_Tuning_M =
  &AHRS_Angle_PI_Gain_Tuning_M_;

/* Model step function */
void AHRS_Angle_PI_Gain_Tuning_step(void)
{
  real_T rtb_I_Gain;
  real_T rtb_K1;
  real_T rtb_K2;
  real_T rtb_Switch3;
  real_T rtb_Gain_g;
  real_T rtb_Gain_p;
  real_T rtb_Xn;

  /* Gain: '<Root>/I_Gain' incorporates:
   *  Inport: '<Root>/Ang_In'
   */
  rtb_I_Gain = AHRS_Angle_PI_Gain_Tuning_P.I_Gain_Gain *
    AHRS_Angle_PI_Gain_Tuning_U.Ang_In;

  /* Switch: '<S4>/Switch6' incorporates:
   *  Constant: '<S1>/C0'
   *  Constant: '<S4>/Constant5'
   *  Constant: '<S4>/P_INTEG'
   *  Gain: '<S4>/Gain'
   *  Memory: '<S4>/Memory1'
   *  Memory: '<S4>/Memory2'
   *  Product: '<S4>/ '
   *  Product: '<S4>/K ''
   *  Sum: '<S4>/Sum1'
   *  Sum: '<S4>/Sum2'
   *  Switch: '<S4>/Switch3'
   */
  if (AHRS_Angle_PI_Gain_Tuning_P.C0_Value >=
      AHRS_Angle_PI_Gain_Tuning_P.Switch6_Threshold) {
    rtb_Switch3 = AHRS_Angle_PI_Gain_Tuning_P.C0_Value;
  } else if (AHRS_Angle_PI_Gain_Tuning_P.C0_Value >=
             AHRS_Angle_PI_Gain_Tuning_P.Switch3_Threshold) {
    /* Switch: '<S4>/Switch3' incorporates:
     *  Memory: '<S4>/Memory2'
     */
    rtb_Switch3 = AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput;
  } else {
    rtb_Switch3 = (AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput +
                   rtb_I_Gain) * AHRS_Angle_PI_Gain_Tuning_P.Gain_Gain *
      (AHRS_Angle_PI_Gain_Tuning_P.P_INTEG_Value *
       AHRS_Angle_PI_Gain_Tuning_P.SIMTIME_DT) +
      AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput;
  }

  /* End of Switch: '<S4>/Switch6' */

  /* Switch: '<S4>/Switch7' incorporates:
   *  Constant: '<S4>/P_INTEG_LL'
   *  Constant: '<S4>/P_INTEG_UL'
   *  RelationalOperator: '<S4>/Relational Operator1'
   *  RelationalOperator: '<S4>/Relational Operator2'
   *  Switch: '<S4>/Switch8'
   */
  if (rtb_Switch3 > AHRS_Angle_PI_Gain_Tuning_P.P_INTEG_UL_Value) {
    rtb_Switch3 = AHRS_Angle_PI_Gain_Tuning_P.P_INTEG_UL_Value;
  } else {
    if (rtb_Switch3 < AHRS_Angle_PI_Gain_Tuning_P.P_INTEG_LL_Value) {
      /* Switch: '<S4>/Switch8' incorporates:
       *  Constant: '<S4>/P_INTEG_LL'
       */
      rtb_Switch3 = AHRS_Angle_PI_Gain_Tuning_P.P_INTEG_LL_Value;
    }
  }

  /* End of Switch: '<S4>/Switch7' */

  /* Outport: '<Root>/Ang_Out' incorporates:
   *  Gain: '<Root>/Amp_Gain'
   *  Gain: '<Root>/Deri_Gain'
   *  Gain: '<Root>/P_Gain'
   *  Inport: '<Root>/Ang_In'
   *  Sum: '<Root>/Sum1'
   *  UnitDelay: '<Root>/Unit Delay1'
   */
  AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out = (AHRS_Angle_PI_Gain_Tuning_P.P_Gain_Gain
    * AHRS_Angle_PI_Gain_Tuning_U.Ang_In + rtb_Switch3) +
    AHRS_Angle_PI_Gain_Tuning_P.Amp_Gain_Gain *
    AHRS_Angle_PI_Gain_Tuning_DW.UnitDelay1_DSTATE *
    AHRS_Angle_PI_Gain_Tuning_P.Deri_Gain_Gain;

  /* Switch: '<S3>/Switch1' incorporates:
   *  Constant: '<Root>/C0'
   *  Constant: '<S3>/C_300Hz'
   *  Constant: '<S3>/P_LAG'
   *  Inport: '<Root>/Ang_In'
   *  Math: '<S3>/Math Function'
   *  Memory: '<S3>/Memory1'
   *  Product: '<S3>/Product'
   *  Product: '<S3>/Product1'
   *  Sum: '<S3>/Sum2'
   *  Sum: '<S3>/Sum3'
   *  Switch: '<S3>/Switch'
   *
   * About '<S3>/Math Function':
   *  Operator: exp
   */
  if (AHRS_Angle_PI_Gain_Tuning_P.C0_Value_m >=
      AHRS_Angle_PI_Gain_Tuning_P.Switch1_Threshold) {
    rtb_Gain_g = AHRS_Angle_PI_Gain_Tuning_U.Ang_In;
  } else {
    if (AHRS_Angle_PI_Gain_Tuning_P.C0_Value_m >=
        AHRS_Angle_PI_Gain_Tuning_P.Switch_Threshold_j) {
      /* Switch: '<S3>/Switch' incorporates:
       *  Inport: '<Root>/Ang_In'
       */
      rtb_Gain_p = AHRS_Angle_PI_Gain_Tuning_U.Ang_In;
    } else {
      /* Switch: '<S3>/Switch' incorporates:
       *  Memory: '<S3>/Memory'
       */
      rtb_Gain_p = AHRS_Angle_PI_Gain_Tuning_DW.Memory_PreviousInput;
    }

    /* Gain: '<S3>/Gain' incorporates:
     *  Inport: '<Root>/Ang_In'
     *  Sum: '<S3>/Sum'
     */
    rtb_Gain_g = (AHRS_Angle_PI_Gain_Tuning_U.Ang_In - rtb_Gain_p) *
      AHRS_Angle_PI_Gain_Tuning_P.Gain_Gain_c;
    rtb_Gain_g += (AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput_b +
                   rtb_Gain_g) * exp(-AHRS_Angle_PI_Gain_Tuning_P.SIMTIME_DT *
      AHRS_Angle_PI_Gain_Tuning_P.C_300Hz_Value);
  }

  /* End of Switch: '<S3>/Switch1' */

  /* Gain: '<S2>/K1' */
  rtb_K1 = AHRS_Angle_PI_Gain_Tuning_P.K1_Gain * rtb_Gain_g;

  /* Switch: '<S5>/Switch6' incorporates:
   *  Constant: '<S2>/C1'
   *  Constant: '<S2>/C3'
   *  Switch: '<S5>/Switch7'
   */
  if (AHRS_Angle_PI_Gain_Tuning_P.C1_Value >=
      AHRS_Angle_PI_Gain_Tuning_P.Switch6_Threshold_l) {
    rtb_Xn = rtb_K1;
  } else if (AHRS_Angle_PI_Gain_Tuning_P.C3_Value >=
             AHRS_Angle_PI_Gain_Tuning_P.Switch7_Threshold) {
    /* Switch: '<S5>/Switch7' incorporates:
     *  Memory: '<S5>/Memory4'
     */
    rtb_Xn = AHRS_Angle_PI_Gain_Tuning_DW.Memory4_PreviousInput;
  } else {
    /* Gain: '<S5>/Gain1' incorporates:
     *  Memory: '<S5>/Memory2'
     *  Sum: '<S5>/Sum3'
     *  Switch: '<S5>/Switch7'
     */
    rtb_Xn = (rtb_K1 + AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput_c) *
      AHRS_Angle_PI_Gain_Tuning_P.Gain1_Gain;

    /* Switch: '<S5>/Switch7' incorporates:
     *  Constant: '<S2>/C_30Hz'
     *  Constant: '<S5>/P_LAG'
     *  Math: '<S5>/Math Function'
     *  Memory: '<S5>/Memory4'
     *  Product: '<S5>/Product1'
     *  Product: '<S5>/Product2'
     *  Sum: '<S5>/Sum5'
     *  Sum: '<S5>/Sum6'
     *
     * About '<S5>/Math Function':
     *  Operator: exp
     */
    rtb_Xn += exp(-AHRS_Angle_PI_Gain_Tuning_P.SIMTIME_DT *
                  AHRS_Angle_PI_Gain_Tuning_P.C_30Hz_Value) *
      (AHRS_Angle_PI_Gain_Tuning_DW.Memory4_PreviousInput - rtb_Xn);
  }

  /* End of Switch: '<S5>/Switch6' */

  /* Gain: '<S2>/K2' */
  rtb_K2 = AHRS_Angle_PI_Gain_Tuning_P.K2_Gain * rtb_Gain_g;

  /* Switch: '<S6>/Switch1' incorporates:
   *  Constant: '<S2>/C1'
   *  Constant: '<S2>/C_30Hz'
   *  Constant: '<S6>/P_LAG'
   *  Math: '<S6>/Math Function'
   *  Memory: '<S6>/Memory1'
   *  Product: '<S6>/Product'
   *  Product: '<S6>/Product1'
   *  Sum: '<S6>/Sum2'
   *  Sum: '<S6>/Sum3'
   *  Switch: '<S6>/Switch'
   *
   * About '<S6>/Math Function':
   *  Operator: exp
   */
  if (AHRS_Angle_PI_Gain_Tuning_P.C1_Value >=
      AHRS_Angle_PI_Gain_Tuning_P.Switch1_Threshold_b) {
    rtb_Gain_p = rtb_K2;
  } else {
    if (AHRS_Angle_PI_Gain_Tuning_P.C1_Value >=
        AHRS_Angle_PI_Gain_Tuning_P.Switch_Threshold) {
      /* Switch: '<S6>/Switch' */
      rtb_Gain_p = rtb_K2;
    } else {
      /* Switch: '<S6>/Switch' incorporates:
       *  Memory: '<S6>/Memory'
       */
      rtb_Gain_p = AHRS_Angle_PI_Gain_Tuning_DW.Memory_PreviousInput_c;
    }

    /* Gain: '<S6>/Gain' incorporates:
     *  Sum: '<S6>/Sum'
     */
    rtb_Gain_p = (rtb_K2 - rtb_Gain_p) * AHRS_Angle_PI_Gain_Tuning_P.Gain_Gain_m;
    rtb_Gain_p += (AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput_f +
                   rtb_Gain_p) * exp(-AHRS_Angle_PI_Gain_Tuning_P.SIMTIME_DT *
      AHRS_Angle_PI_Gain_Tuning_P.C_30Hz_Value);
  }

  /* End of Switch: '<S6>/Switch1' */

  /* Update for Memory: '<S4>/Memory2' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput = rtb_Switch3;

  /* Update for Memory: '<S4>/Memory1' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput = rtb_I_Gain;

  /* Update for UnitDelay: '<Root>/Unit Delay1' incorporates:
   *  Gain: '<S2>/K3'
   *  Sum: '<S2>/Sum2'
   */
  AHRS_Angle_PI_Gain_Tuning_DW.UnitDelay1_DSTATE = (rtb_Xn + rtb_Gain_p) *
    AHRS_Angle_PI_Gain_Tuning_P.K3_Gain;

  /* Update for Memory: '<S3>/Memory1' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput_b = rtb_Gain_g;

  /* Update for Memory: '<S3>/Memory' incorporates:
   *  Update for Inport: '<Root>/Ang_In'
   */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory_PreviousInput =
    AHRS_Angle_PI_Gain_Tuning_U.Ang_In;

  /* Update for Memory: '<S5>/Memory2' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput_c = rtb_K1;

  /* Update for Memory: '<S5>/Memory4' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory4_PreviousInput = rtb_Xn;

  /* Update for Memory: '<S6>/Memory' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory_PreviousInput_c = rtb_K2;

  /* Update for Memory: '<S6>/Memory1' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput_f = rtb_Gain_p;

  /* Matfile logging */
  //rt_UpdateTXYLogVars(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo,
  //                    (&AHRS_Angle_PI_Gain_Tuning_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0016666666666666668s, 0.0s] */
    if ((rtmGetTFinal(AHRS_Angle_PI_Gain_Tuning_M)!=-1) &&
        !((rtmGetTFinal(AHRS_Angle_PI_Gain_Tuning_M)-
           AHRS_Angle_PI_Gain_Tuning_M->Timing.taskTime0) >
          AHRS_Angle_PI_Gain_Tuning_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(AHRS_Angle_PI_Gain_Tuning_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++AHRS_Angle_PI_Gain_Tuning_M->Timing.clockTick0)) {
    ++AHRS_Angle_PI_Gain_Tuning_M->Timing.clockTickH0;
  }

  AHRS_Angle_PI_Gain_Tuning_M->Timing.taskTime0 =
    AHRS_Angle_PI_Gain_Tuning_M->Timing.clockTick0 *
    AHRS_Angle_PI_Gain_Tuning_M->Timing.stepSize0 +
    AHRS_Angle_PI_Gain_Tuning_M->Timing.clockTickH0 *
    AHRS_Angle_PI_Gain_Tuning_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void AHRS_Angle_PI_Gain_Tuning_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)AHRS_Angle_PI_Gain_Tuning_M, 0,
                sizeof(RT_MODEL_AHRS_Angle_PI_Gain_T_T));
  rtmSetTFinal(AHRS_Angle_PI_Gain_Tuning_M, 10.0);
  AHRS_Angle_PI_Gain_Tuning_M->Timing.stepSize0 = 0.0016666666666666668;

  /* Setup for data logging */
  {
//    static RTWLogInfo rt_DataLoggingInfo;
 //   rt_DataLoggingInfo.loggingInterval = NULL;
 //   AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
 //   rtliSetLogXSignalInfo(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, (NULL));
 //   rtliSetLogXSignalPtrs(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, (NULL));
 //   rtliSetLogT(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, "tout");
 //   rtliSetLogX(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, "");
//    rtliSetLogXFinal(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, "");
 //   rtliSetLogVarNameModifier(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, "rt_");
//    rtliSetLogFormat(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, 4);
 //   rtliSetLogMaxRows(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, 1000);
 //   rtliSetLogDecimation(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, 1);
  //  rtliSetLogY(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, "");
  //  rtliSetLogYSignalInfo(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, (NULL));
  //  rtliSetLogYSignalPtrs(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, (NULL));
  }

  /* states (dwork) */
  (void) memset((void *)&AHRS_Angle_PI_Gain_Tuning_DW, 0,
                sizeof(DW_AHRS_Angle_PI_Gain_Tuning_T));

  /* external inputs */
  AHRS_Angle_PI_Gain_Tuning_U.Ang_In = 0.0;

  /* external outputs */
  AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out = 0.0;

  /* Matfile logging */
//  rt_StartDataLoggingWithStartTime(AHRS_Angle_PI_Gain_Tuning_M->rtwLogInfo, 0.0,
//    rtmGetTFinal(AHRS_Angle_PI_Gain_Tuning_M),
//    AHRS_Angle_PI_Gain_Tuning_M->Timing.stepSize0, (&rtmGetErrorStatus
//    (AHRS_Angle_PI_Gain_Tuning_M)));

  /* InitializeConditions for Memory: '<S4>/Memory2' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput =
    AHRS_Angle_PI_Gain_Tuning_P.Memory2_X0;

  /* InitializeConditions for Memory: '<S4>/Memory1' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput =
    AHRS_Angle_PI_Gain_Tuning_P.Memory1_X0;

  /* InitializeConditions for UnitDelay: '<Root>/Unit Delay1' */
  AHRS_Angle_PI_Gain_Tuning_DW.UnitDelay1_DSTATE =
    AHRS_Angle_PI_Gain_Tuning_P.UnitDelay1_InitialCondition;

  /* InitializeConditions for Memory: '<S3>/Memory1' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput_b =
    AHRS_Angle_PI_Gain_Tuning_P.Memory1_X0_h;

  /* InitializeConditions for Memory: '<S3>/Memory' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory_PreviousInput =
    AHRS_Angle_PI_Gain_Tuning_P.Memory_X0;

  /* InitializeConditions for Memory: '<S5>/Memory2' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory2_PreviousInput_c =
    AHRS_Angle_PI_Gain_Tuning_P.Memory2_X0_g;

  /* InitializeConditions for Memory: '<S5>/Memory4' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory4_PreviousInput =
    AHRS_Angle_PI_Gain_Tuning_P.Memory4_X0;

  /* InitializeConditions for Memory: '<S6>/Memory' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory_PreviousInput_c =
    AHRS_Angle_PI_Gain_Tuning_P.Memory_X0_p;

  /* InitializeConditions for Memory: '<S6>/Memory1' */
  AHRS_Angle_PI_Gain_Tuning_DW.Memory1_PreviousInput_f =
    AHRS_Angle_PI_Gain_Tuning_P.Memory1_X0_b;
}

/* Model terminate function */
void AHRS_Angle_PI_Gain_Tuning_terminate(void)
{
  /* (no terminate code required) */
}
