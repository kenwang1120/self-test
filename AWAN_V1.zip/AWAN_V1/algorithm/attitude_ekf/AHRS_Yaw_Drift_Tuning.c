/*
 * AHRS_Yaw_Drift_Tuning.c
 *
 * Code generation for model "AHRS_Yaw_Drift_Tuning".
 *
 * Model version              : 1.7
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Tue Jan 12 10:52:55 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "AHRS_Yaw_Drift_Tuning.h"
#include "AHRS_Yaw_Drift_Tuning_private.h"

/* Block states (auto storage) */
DW_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_Y;

/* Real-time model */
RT_MODEL_AHRS_Yaw_Drift_Tunin_T AHRS_Yaw_Drift_Tuning_M_;
RT_MODEL_AHRS_Yaw_Drift_Tunin_T *const AHRS_Yaw_Drift_Tuning_M =
  &AHRS_Yaw_Drift_Tuning_M_;

/* Model step function */
void AHRS_Yaw_Drift_Tuning_step(void)
{
  real_T rtb_Delay;
  real_T rtb_Delay1;
  real_T rtb_Delay2;
  real_T rtb_Delay3;
  real_T rtb_Delay4;
  real_T rtb_Delay5;
  real_T rtb_Delay6;
  real_T rtb_Delay7;
  real_T rtb_Ave_Gain;
  real_T rtb_Add1;
  real_T rtb_Delay_ae;
  real_T rtb_Delay1_c;
  real_T rtb_Delay2_f;
  real_T rtb_Delay3_f;
  real_T rtb_Delay4_b;
  real_T rtb_Delay5_k;
  real_T rtb_Delay6_p;
  real_T rtb_Delay7_e;
  real_T rtb_Rate_Conv_Gain;
  real_T rtb_Abs1;
  boolean_T rtb_OUT_og;
  real_T rtb_Xn;
  real_T rtb_Xn_f;

  /* Switch: '<S8>/S2' incorporates:
   *  Constant: '<S2>/R_C0'
   *  Inport: '<Root>/Yaw_Rate_dps_In'
   *  Switch: '<S8>/S1'
   */
  if (AHRS_Yaw_Drift_Tuning_P.R_C0_Value > AHRS_Yaw_Drift_Tuning_P.S2_Threshold)
  {
    rtb_Xn = AHRS_Yaw_Drift_Tuning_U.Yaw_Rate_dps_In;
  } else if (AHRS_Yaw_Drift_Tuning_P.R_C0_Value >
             AHRS_Yaw_Drift_Tuning_P.S1_Threshold_k) {
    /* Switch: '<S8>/S1' incorporates:
     *  Memory: '<S8>/M2'
     */
    rtb_Xn = AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput;
  } else {
    /* Gain: '<S8>/Gain' incorporates:
     *  Inport: '<Root>/Yaw_Rate_dps_In'
     *  Memory: '<S8>/M1'
     *  Sum: '<S8>/Sum3'
     *  Switch: '<S8>/S1'
     */
    rtb_Xn = (AHRS_Yaw_Drift_Tuning_U.Yaw_Rate_dps_In +
              AHRS_Yaw_Drift_Tuning_DW.M1_PreviousInput) *
      AHRS_Yaw_Drift_Tuning_P.Gain_Gain_b;

    /* Switch: '<S8>/S1' incorporates:
     *  Constant: '<S8>/P_LAG'
     *  Fcn: '<S8>/Fcn'
     *  Memory: '<S8>/M2'
     *  Product: '<S8>/Product2'
     *  Sum: '<S8>/Sum5'
     *  Sum: '<S8>/Sum6'
     */
    rtb_Xn += exp(-0.0016666666666666668 / AHRS_Yaw_Drift_Tuning_P.LAG_R_Tau) *
      (AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput - rtb_Xn);
  }

  /* End of Switch: '<S8>/S2' */

  /* Delay: '<S10>/Delay' */
  rtb_Delay = AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE;

  /* Delay: '<S10>/Delay1' */
  rtb_Delay1 = AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE;

  /* Delay: '<S10>/Delay2' */
  rtb_Delay2 = AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE;

  /* Delay: '<S10>/Delay3' */
  rtb_Delay3 = AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE;

  /* Delay: '<S10>/Delay4' */
  rtb_Delay4 = AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE;

  /* Delay: '<S10>/Delay5' */
  rtb_Delay5 = AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE;

  /* Delay: '<S10>/Delay6' */
  rtb_Delay6 = AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE;

  /* Delay: '<S10>/Delay7' */
  rtb_Delay7 = AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE;

  /* Gain: '<S9>/Ave_Gain' incorporates:
   *  Delay: '<S10>/Delay'
   *  Delay: '<S10>/Delay1'
   *  Delay: '<S10>/Delay2'
   *  Delay: '<S10>/Delay3'
   *  Delay: '<S10>/Delay4'
   *  Delay: '<S10>/Delay5'
   *  Delay: '<S10>/Delay6'
   *  Delay: '<S10>/Delay7'
   *  Delay: '<S10>/Delay8'
   *  Gain: '<S10>/Gain'
   *  Sum: '<S10>/Add'
   */
  rtb_Ave_Gain = (((((((((rtb_Xn + AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE) +
    AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE) +
                        AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE) +
                       AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE) +
                      AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE) +
                     AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE) +
                    AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE) +
                   AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE) +
                  AHRS_Yaw_Drift_Tuning_DW.Delay8_DSTATE) *
    AHRS_Yaw_Drift_Tuning_P.Gain_Gain_h * AHRS_Yaw_Drift_Tuning_P.Ave_Gain_Gain;

  /* Switch: '<S5>/S2' incorporates:
   *  Constant: '<S1>/Psi_C0'
   *  Inport: '<Root>/Yaw_Ang_In'
   *  Switch: '<S5>/S1'
   */
  if (AHRS_Yaw_Drift_Tuning_P.Psi_C0_Value >
      AHRS_Yaw_Drift_Tuning_P.S2_Threshold_l) {
    rtb_Xn_f = AHRS_Yaw_Drift_Tuning_U.Yaw_Ang_In;
  } else if (AHRS_Yaw_Drift_Tuning_P.Psi_C0_Value >
             AHRS_Yaw_Drift_Tuning_P.S1_Threshold) {
    /* Switch: '<S5>/S1' incorporates:
     *  Memory: '<S5>/M2'
     */
    rtb_Xn_f = AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput_j;
  } else {
    /* Gain: '<S5>/Gain' incorporates:
     *  Inport: '<Root>/Yaw_Ang_In'
     *  Memory: '<S5>/M1'
     *  Sum: '<S5>/Sum3'
     *  Switch: '<S5>/S1'
     */
    rtb_Xn_f = (AHRS_Yaw_Drift_Tuning_U.Yaw_Ang_In +
                AHRS_Yaw_Drift_Tuning_DW.M1_PreviousInput_i) *
      AHRS_Yaw_Drift_Tuning_P.Gain_Gain;

    /* Switch: '<S5>/S1' incorporates:
     *  Constant: '<S5>/P_LAG'
     *  Fcn: '<S5>/Fcn'
     *  Memory: '<S5>/M2'
     *  Product: '<S5>/Product2'
     *  Sum: '<S5>/Sum5'
     *  Sum: '<S5>/Sum6'
     */
    rtb_Xn_f += exp(-0.0016666666666666668 / AHRS_Yaw_Drift_Tuning_P.LAG_Psi_Tau)
      * (AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput_j - rtb_Xn_f);
  }

  /* End of Switch: '<S5>/S2' */

  /* Sum: '<S6>/Add1' incorporates:
   *  Delay: '<S6>/Delay2'
   */
  rtb_Add1 = rtb_Xn_f - AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_l;

  /* Delay: '<S7>/Delay' */
  rtb_Delay_ae = AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_h;

  /* Delay: '<S7>/Delay1' */
  rtb_Delay1_c = AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE_g;

  /* Delay: '<S7>/Delay2' */
  rtb_Delay2_f = AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_e;

  /* Delay: '<S7>/Delay3' */
  rtb_Delay3_f = AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE_o;

  /* Delay: '<S7>/Delay4' */
  rtb_Delay4_b = AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE_g;

  /* Delay: '<S7>/Delay5' */
  rtb_Delay5_k = AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE_j;

  /* Delay: '<S7>/Delay6' */
  rtb_Delay6_p = AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE_o;

  /* Delay: '<S7>/Delay7' */
  rtb_Delay7_e = AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE_b;

  /* Gain: '<Root>/Rate_Conv_Gain' incorporates:
   *  Delay: '<S7>/Delay'
   *  Delay: '<S7>/Delay1'
   *  Delay: '<S7>/Delay2'
   *  Delay: '<S7>/Delay3'
   *  Delay: '<S7>/Delay4'
   *  Delay: '<S7>/Delay5'
   *  Delay: '<S7>/Delay6'
   *  Delay: '<S7>/Delay7'
   *  Delay: '<S7>/Delay8'
   *  Gain: '<S6>/Ave_Gain'
   *  Gain: '<S7>/Gain'
   *  Sum: '<S7>/Add'
   */
  rtb_Rate_Conv_Gain = (((((((((rtb_Add1 +
    AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_h) +
    AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE_g) +
    AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_e) +
    AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE_o) +
    AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE_g) +
    AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE_j) +
    AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE_o) +
    AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE_b) +
                        AHRS_Yaw_Drift_Tuning_DW.Delay8_DSTATE_h) *
    AHRS_Yaw_Drift_Tuning_P.Gain_Gain_n *
    AHRS_Yaw_Drift_Tuning_P.Ave_Gain_Gain_d *
    AHRS_Yaw_Drift_Tuning_P.Rate_Conv_Gain_Gain;

  /* Abs: '<S4>/Abs1' */
  rtb_Abs1 = fabs(rtb_Ave_Gain);

  /* Logic: '<S11>/AND1' incorporates:
   *  Abs: '<S4>/Abs2'
   *  Constant: '<S4>/C_R0'
   *  Constant: '<S4>/C_S0'
   *  Constant: '<S4>/C_S1'
   *  Delay: '<S11>/Delay'
   *  Logic: '<S11>/NOT1'
   *  Logic: '<S11>/OR2'
   *  Logic: '<S4>/OR2'
   *  RelationalOperator: '<S4>/GE1'
   *  RelationalOperator: '<S4>/GE2'
   *  RelationalOperator: '<S4>/LE1'
   */
  rtb_OUT_og = ((AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_n || (rtb_Abs1 >=
    AHRS_Yaw_Drift_Tuning_P.C_S0_Value)) && (!((fabs(rtb_Rate_Conv_Gain) >=
    AHRS_Yaw_Drift_Tuning_P.C_S1_Value) || (rtb_Abs1 <=
    AHRS_Yaw_Drift_Tuning_P.C_R0_Value))));

  /* Switch: '<Root>/Sw_Yaw' incorporates:
   *  Gain: '<Root>/Logic_False_Gain'
   *  Gain: '<Root>/Psi_P_Gain'
   *  Gain: '<Root>/R_P_Gain'
   *  Gain: '<Root>/d2r'
   *  Sum: '<Root>/Add'
   */
  if (rtb_OUT_og) {
    rtb_Ave_Gain = (AHRS_Yaw_Drift_Tuning_P.R_P_Gain_Gain * rtb_Ave_Gain +
                    AHRS_Yaw_Drift_Tuning_P.Psi_P_Gain_Gain * rtb_Rate_Conv_Gain)
      * AHRS_Yaw_Drift_Tuning_P.d2r_Gain;
  } else {
    rtb_Ave_Gain = AHRS_Yaw_Drift_Tuning_P.Logic_False_Gain_Gain *
      rtb_Rate_Conv_Gain;
  }

  /* End of Switch: '<Root>/Sw_Yaw' */

  /* Switch: '<Root>/Sw_Yaw1' incorporates:
   *  Abs: '<S3>/Abs1'
   *  Constant: '<S3>/C0_LL'
   *  RelationalOperator: '<S3>/GE1'
   */
  if (fabs(rtb_Rate_Conv_Gain) <= AHRS_Yaw_Drift_Tuning_P.C0_LL_Value) {
    /* Outport: '<Root>/Delta_Yaw_Rate_Rps_Out' */
    AHRS_Yaw_Drift_Tuning_Y.Delta_Yaw_Rate_Rps_Out = rtb_Ave_Gain;
  } else {
    /* Outport: '<Root>/Delta_Yaw_Rate_Rps_Out' incorporates:
     *  Gain: '<Root>/Logic_False_Gain1'
     */
    AHRS_Yaw_Drift_Tuning_Y.Delta_Yaw_Rate_Rps_Out =
      AHRS_Yaw_Drift_Tuning_P.Logic_False_Gain1_Gain * rtb_Ave_Gain;
  }

  /* End of Switch: '<Root>/Sw_Yaw1' */

  /* Update for Memory: '<S8>/M2' */
  AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput = rtb_Xn;

  /* Update for Memory: '<S8>/M1' incorporates:
   *  Update for Inport: '<Root>/Yaw_Rate_dps_In'
   */
  AHRS_Yaw_Drift_Tuning_DW.M1_PreviousInput =
    AHRS_Yaw_Drift_Tuning_U.Yaw_Rate_dps_In;

  /* Update for Delay: '<S10>/Delay' */
  AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE = rtb_Xn;

  /* Update for Delay: '<S10>/Delay1' */
  AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE = rtb_Delay;

  /* Update for Delay: '<S10>/Delay2' */
  AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE = rtb_Delay1;

  /* Update for Delay: '<S10>/Delay3' */
  AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE = rtb_Delay2;

  /* Update for Delay: '<S10>/Delay4' */
  AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE = rtb_Delay3;

  /* Update for Delay: '<S10>/Delay5' */
  AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE = rtb_Delay4;

  /* Update for Delay: '<S10>/Delay6' */
  AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE = rtb_Delay5;

  /* Update for Delay: '<S10>/Delay7' */
  AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE = rtb_Delay6;

  /* Update for Delay: '<S10>/Delay8' */
  AHRS_Yaw_Drift_Tuning_DW.Delay8_DSTATE = rtb_Delay7;

  /* Update for Memory: '<S5>/M2' */
  AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput_j = rtb_Xn_f;

  /* Update for Memory: '<S5>/M1' incorporates:
   *  Update for Inport: '<Root>/Yaw_Ang_In'
   */
  AHRS_Yaw_Drift_Tuning_DW.M1_PreviousInput_i =
    AHRS_Yaw_Drift_Tuning_U.Yaw_Ang_In;

  /* Update for Delay: '<S6>/Delay2' */
  AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_l = rtb_Xn_f;

  /* Update for Delay: '<S7>/Delay' */
  AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_h = rtb_Add1;

  /* Update for Delay: '<S7>/Delay1' */
  AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE_g = rtb_Delay_ae;

  /* Update for Delay: '<S7>/Delay2' */
  AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_e = rtb_Delay1_c;

  /* Update for Delay: '<S7>/Delay3' */
  AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE_o = rtb_Delay2_f;

  /* Update for Delay: '<S7>/Delay4' */
  AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE_g = rtb_Delay3_f;

  /* Update for Delay: '<S7>/Delay5' */
  AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE_j = rtb_Delay4_b;

  /* Update for Delay: '<S7>/Delay6' */
  AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE_o = rtb_Delay5_k;

  /* Update for Delay: '<S7>/Delay7' */
  AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE_b = rtb_Delay6_p;

  /* Update for Delay: '<S7>/Delay8' */
  AHRS_Yaw_Drift_Tuning_DW.Delay8_DSTATE_h = rtb_Delay7_e;

  /* Update for Delay: '<S11>/Delay' */
  AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_n = rtb_OUT_og;

  /* Matfile logging */
  //rt_UpdateTXYLogVars(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo,
  //                    (&AHRS_Yaw_Drift_Tuning_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0016666666666666668s, 0.0s] */
    if ((rtmGetTFinal(AHRS_Yaw_Drift_Tuning_M)!=-1) &&
        !((rtmGetTFinal(AHRS_Yaw_Drift_Tuning_M)-
           AHRS_Yaw_Drift_Tuning_M->Timing.taskTime0) >
          AHRS_Yaw_Drift_Tuning_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(AHRS_Yaw_Drift_Tuning_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++AHRS_Yaw_Drift_Tuning_M->Timing.clockTick0)) {
    ++AHRS_Yaw_Drift_Tuning_M->Timing.clockTickH0;
  }

  AHRS_Yaw_Drift_Tuning_M->Timing.taskTime0 =
    AHRS_Yaw_Drift_Tuning_M->Timing.clockTick0 *
    AHRS_Yaw_Drift_Tuning_M->Timing.stepSize0 +
    AHRS_Yaw_Drift_Tuning_M->Timing.clockTickH0 *
    AHRS_Yaw_Drift_Tuning_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void AHRS_Yaw_Drift_Tuning_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)AHRS_Yaw_Drift_Tuning_M, 0,
                sizeof(RT_MODEL_AHRS_Yaw_Drift_Tunin_T));
  rtmSetTFinal(AHRS_Yaw_Drift_Tuning_M, 10.0);
  AHRS_Yaw_Drift_Tuning_M->Timing.stepSize0 = 0.0016666666666666668;

  /* Setup for data logging */
  {
    //static RTWLogInfo rt_DataLoggingInfo;
    //rt_DataLoggingInfo.loggingInterval = NULL;
    //AHRS_Yaw_Drift_Tuning_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    /*rtliSetLogXSignalInfo(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, (NULL));
    rtliSetLogT(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, "tout");
    rtliSetLogX(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, "");
    rtliSetLogXFinal(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, 1);
    rtliSetLogY(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, (NULL));*/
  }

  /* states (dwork) */
  (void) memset((void *)&AHRS_Yaw_Drift_Tuning_DW, 0,
                sizeof(DW_AHRS_Yaw_Drift_Tuning_T));

  /* external inputs */
  (void) memset((void *)&AHRS_Yaw_Drift_Tuning_U, 0,
                sizeof(ExtU_AHRS_Yaw_Drift_Tuning_T));

  /* external outputs */
  AHRS_Yaw_Drift_Tuning_Y.Delta_Yaw_Rate_Rps_Out = 0.0;

  /* Matfile logging */
  //rt_StartDataLoggingWithStartTime(AHRS_Yaw_Drift_Tuning_M->rtwLogInfo, 0.0,
  //  rtmGetTFinal(AHRS_Yaw_Drift_Tuning_M),
  //  AHRS_Yaw_Drift_Tuning_M->Timing.stepSize0, (&rtmGetErrorStatus
  //  (AHRS_Yaw_Drift_Tuning_M)));

  /* InitializeConditions for Memory: '<S8>/M2' */
  AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput = AHRS_Yaw_Drift_Tuning_P.M2_X0;

  /* InitializeConditions for Memory: '<S8>/M1' */
  AHRS_Yaw_Drift_Tuning_DW.M1_PreviousInput = AHRS_Yaw_Drift_Tuning_P.M1_X0;

  /* InitializeConditions for Delay: '<S10>/Delay' */
  AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay1' */
  AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay1_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay2' */
  AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay2_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay3' */
  AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay3_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay4' */
  AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay4_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay5' */
  AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay5_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay6' */
  AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay6_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay7' */
  AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay7_InitialCondition;

  /* InitializeConditions for Delay: '<S10>/Delay8' */
  AHRS_Yaw_Drift_Tuning_DW.Delay8_DSTATE =
    AHRS_Yaw_Drift_Tuning_P.Delay8_InitialCondition;

  /* InitializeConditions for Memory: '<S5>/M2' */
  AHRS_Yaw_Drift_Tuning_DW.M2_PreviousInput_j = AHRS_Yaw_Drift_Tuning_P.M2_X0_b;

  /* InitializeConditions for Memory: '<S5>/M1' */
  AHRS_Yaw_Drift_Tuning_DW.M1_PreviousInput_i = AHRS_Yaw_Drift_Tuning_P.M1_X0_f;

  /* InitializeConditions for Delay: '<S6>/Delay2' */
  AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_l =
    AHRS_Yaw_Drift_Tuning_P.Delay2_InitialCondition_l;

  /* InitializeConditions for Delay: '<S7>/Delay' */
  AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_h =
    AHRS_Yaw_Drift_Tuning_P.Delay_InitialCondition_g;

  /* InitializeConditions for Delay: '<S7>/Delay1' */
  AHRS_Yaw_Drift_Tuning_DW.Delay1_DSTATE_g =
    AHRS_Yaw_Drift_Tuning_P.Delay1_InitialCondition_j;

  /* InitializeConditions for Delay: '<S7>/Delay2' */
  AHRS_Yaw_Drift_Tuning_DW.Delay2_DSTATE_e =
    AHRS_Yaw_Drift_Tuning_P.Delay2_InitialCondition_m;

  /* InitializeConditions for Delay: '<S7>/Delay3' */
  AHRS_Yaw_Drift_Tuning_DW.Delay3_DSTATE_o =
    AHRS_Yaw_Drift_Tuning_P.Delay3_InitialCondition_a;

  /* InitializeConditions for Delay: '<S7>/Delay4' */
  AHRS_Yaw_Drift_Tuning_DW.Delay4_DSTATE_g =
    AHRS_Yaw_Drift_Tuning_P.Delay4_InitialCondition_g;

  /* InitializeConditions for Delay: '<S7>/Delay5' */
  AHRS_Yaw_Drift_Tuning_DW.Delay5_DSTATE_j =
    AHRS_Yaw_Drift_Tuning_P.Delay5_InitialCondition_l;

  /* InitializeConditions for Delay: '<S7>/Delay6' */
  AHRS_Yaw_Drift_Tuning_DW.Delay6_DSTATE_o =
    AHRS_Yaw_Drift_Tuning_P.Delay6_InitialCondition_o;

  /* InitializeConditions for Delay: '<S7>/Delay7' */
  AHRS_Yaw_Drift_Tuning_DW.Delay7_DSTATE_b =
    AHRS_Yaw_Drift_Tuning_P.Delay7_InitialCondition_m;

  /* InitializeConditions for Delay: '<S7>/Delay8' */
  AHRS_Yaw_Drift_Tuning_DW.Delay8_DSTATE_h =
    AHRS_Yaw_Drift_Tuning_P.Delay8_InitialCondition_k;

  /* InitializeConditions for Delay: '<S11>/Delay' */
  AHRS_Yaw_Drift_Tuning_DW.Delay_DSTATE_n =
    AHRS_Yaw_Drift_Tuning_P.Delay_InitialCondition_l;
}

/* Model terminate function */
void AHRS_Yaw_Drift_Tuning_terminate(void)
{
  /* (no terminate code required) */
}
