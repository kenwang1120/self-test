//******************************************************************************
//! @ProjectName: AWAN_V1
//! @ModuleName:  attitude_estimator_q_main.cpp
//!
//! @Purpose:
//! Functions for attitude estimator.
//!
//! AWAN Proprietary
//!
//! @AWAN All rights reserved.
//******************************************************************************

#include <float.h>
#include <cmath>
#include "geo.h"
#include "geo_mag_declination.h"
#include "mathlib/mathlib.h"
#include "matrix/math.hpp"
#include "matrix/Euler.hpp"
#include "helper_functions.hpp"
#include "attitude_estimator_q.h"
#include "usart.h"
extern "C" {
#include "AHRS_Angle_PI_Gain_Tuning.h"
#include "AHRS_Yaw_Drift_Tuning.h"
#include "AHRS_Yaw_Drift_Tuning.h"
#include "Axyz_Estimation_to_VBxyz.h"
#include "gps1.h"
}
//#include "scheduler.h"
using matrix::Dcmf;
using matrix::Eulerf;
using matrix::Quatf;
using matrix::Vector3f;
using matrix::wrap_pi;

using math::constrain;

const float _dt_min = 0.00001f;
const float _dt_max = 0.02f;
const float MIN_GPS_EPH = 3.0f;//5.0f;

//extern float debugger_a[3];
extern float Q[4];
extern float kMagX,kMagY;

extern bool initEST;

float errRoll=0;
float errPitch=0;
float gyPitch=0;
float gyPitchBias=0;
float yaw_0=0,yaw_1=0,yaw_2=0,yaw_3=0,yaw_4=0,_spinRate=0,yaw_5=0;
float mag_earth_x=0,mag_earth_y=0,magAtan=0;
float VB_x;                         /* '<Root>/VB_x' */
float XB;                           /* '<Root>/XB' */
float VB_y;                         /* '<Root>/VB_y' */
float YB;                           /* '<Root>/YB' */
float VB_z;                         /* '<Root>/VB_z' */
float ZB;                           /* '<Root>/ZB' */
boolean_T Road_Hole_Hit;             /* '<Root>/Road_Hole_Hit' */
enum EXT_HEADING_MODE
{
    NO_AID = 0,
    EXT_VISION,
    EXT_MOCAP,
    EXT_GPS,
};

class AttitudeEstimatorQ
{
public:
	AttitudeEstimatorQ();
    static AttitudeEstimatorQ& instance();

    ~AttitudeEstimatorQ();

    int task_main(float gx, float gy, float gz,
        float ax, float ay, float az,
        float mx, float my, float mz, float dt);

    void euler(float*x, float*y, float*z) const;
    void set_w_accel(float val)    {_w_accel = val;}
    void set_w_mag(float val)      {_w_mag = val;}
    void set_w_ext_heading(float val)   {_w_ext_hdg = val;}
    void set_w_gyro_bias(float val){_w_gyro_bias = val;}
    void set_mag_decl(float val)   {_mag_decl = val;}
    void set_bias_max(float val)   {_bias_max = val;}
    void get_rates(float* rate) const{rate[0]=_rates(0);rate[1]=_rates(1);rate[2]=_rates(2);}
    void set_heading(Quatf val) {_q=val;}
    struct GPS gpos;
private:
    Quatf		_q;
	float		_w_accel;
	float		_w_mag;
	float		_w_ext_hdg;
	float		_w_gyro_bias;
	float		_mag_decl;
	bool		_mag_decl_auto;
	bool		_acc_comp;
	float		_bias_max;
	int32_t		_ext_hdg_mode;
        float           psi_rad_in;//timchen 20210108 for yaw drift cancellation
        float           phi_rad_in;
        float           theta_rad_in;

	Vector3f	_gyro;
	Vector3f	_accel;
	Vector3f	_mag;

	Vector3f	_vision_hdg;
	Vector3f	_mocap_hdg;

	Vector3f	_rates;
	Vector3f	_gyro_bias;

	Vector3f	_vel_prev;
	long	_vel_prev_t;

	Vector3f	_pos_acc;

	bool		_inited ;
	bool		_ext_hdg_good;

	bool init();
	bool update(float dt);
	// Update magnetic declination (in rads) immediately changing yaw rotation
	void update_mag_declination(float new_declination);
};

AttitudeEstimatorQ& AttitudeEstimatorQ::instance() {
    static AttitudeEstimatorQ ins;
    return ins;
}


AttitudeEstimatorQ::AttitudeEstimatorQ()
{
  
  
      _inited = false;
    _ext_hdg_good = false;
    _vel_prev_t = 0;

    _w_accel = 3.6f;
   //_w_accel = 0.2f;     // rich mark
    _w_mag = 0.10f;
  //  _w_ext_hdg = 0.1f;
 
    _w_ext_hdg = 0.1f;

    _w_gyro_bias = 0.1f;
    _mag_decl = 0.0f;
    _mag_decl_auto = false;
    _acc_comp = true;
    _bias_max = 0.05f;
    _ext_hdg_mode = NO_AID;
    gpos.eph = 999.9f;
    gpos.heading_valid = false;
  

    gps.eph = 999.0f;
    gps.heading_valid = false;



	_vel_prev.zero();
	_pos_acc.zero();

	_gyro.zero();
	_accel.zero();
	_mag.zero();

	_vision_hdg.zero();
	_mocap_hdg.zero();

	_q.zero();
	_rates.zero();
	_gyro_bias.zero();

}

/**
 * Destructor, also kills task.
 */
AttitudeEstimatorQ::~AttitudeEstimatorQ()
{
}

int AttitudeEstimatorQ::task_main(float gx,float gy,float gz,
    float ax, float ay, float az, 
    float mx, float my, float mz, float dt)
{
	//gpos=gps;

    _gyro(0) = gx;
    _gyro(1) = gy;
    _gyro(2) = gz;
    yaw_0 = _gyro(2);

    _accel(0) = ax;
    _accel(1) = ay;
    _accel(2) = az;
    if (_accel.length() < 0.01f) {
        return INVALID_ACCELERATION;
    }
    


    _mag(0) = mx;
    _mag(1) = my;
    _mag(2) = mz;



//   if (_mag.length() < 0.01f) {
//       return INVALID_MAG;
//   }
//
//	if (_mag_decl_auto && gpos.eph < 20.0f) {
//		/* set magnetic declination automatically */
//		update_mag_declination(math::radians(get_mag_declination(gpos.lat, gpos.lon)));
//	}

	if (_acc_comp && gpos.timestamp != 0 && gpos.eph < MIN_GPS_EPH && _inited) {
        if (gpos.heading_valid == VALID_GPS_HEADING)
        {

            _ext_hdg_mode = EXT_GPS;
            _ext_hdg_good = true;//false = no yaw fusion，a = false,b=true;
        }
        else{
        	_ext_hdg_good=false;
        }
	}
	else{

		_ext_hdg_good=false;
	}
		/* position data is actual */
		Vector3f vel(gpos.vel_n, gpos.vel_e, gpos.vel_d);

		/* velocity updated */
		if (_vel_prev_t != 0 && gpos.timestamp != _vel_prev_t) {
			float vel_dt = (gpos.timestamp - _vel_prev_t) / 1e6f;
			/* calculate acceleration in body frame */
			_pos_acc = _q.conjugate_inversed((vel - _vel_prev) / vel_dt);

			_vel_prev_t = gpos.timestamp;
			_vel_prev = vel;
		}

//		_vel_prev_t = gpos.timestamp;
//		_vel_prev = vel;
		else {//} else {
		/* position data is outdated, reset acceleration */
		_pos_acc.zero();
		_vel_prev.zero();
		_vel_prev_t = 0;
	}

	/* time from previous iteration */
	dt = constrain(dt, _dt_min, _dt_max);
    
  
    return update(dt);
}

bool AttitudeEstimatorQ::init()
{
  
  
 //extern float debugger_a[3];
	// Rotation matrix can be easily constructed from acceleration and mag field vectors
	// 'k' is Earth Z axis (Down) unit vector in body frame
  
//_accel(0)=0.0f;//fake ini data
//_accel(1)=0.0f;
//_accel(2)=-9.8f;
  
	Vector3f k = -_accel;
	k.normalize();

    _mag(0) = 30;//kMagX;//30.0f;//fake ini data
    _mag(1) = 0;//kMagY;//0.0f;
    _mag(2) = 0.0f;
        
        
        
	// 'i' is Earth X axis (North) unit vector in body frame, orthogonal with 'k'
	Vector3f i = (_mag - k * (_mag * k));
	i.normalize();

	// 'j' is Earth Y axis (East) unit vector in body frame, orthogonal with 'k' and 'i'
	Vector3f j = k % i;

	// Fill rotation matrix
	Dcmf R;
	R.setRow(0, i);
	R.setRow(1, j);
	R.setRow(2, k);

	// Convert to quaternion
	_q = R;

	// Compensate for magnetic declination
	//Quatf decl_rotation = Eulerf(0.0f, 0.0f, _mag_decl);
       // Quatf decl_rotation = Eulerf(0.0f, 0.0f, 0.0f);
	//_q = _q * decl_rotation;

	_q.normalize();

	if (ECF_ISFINITE(_q(0)) && ECF_ISFINITE(_q(1)) &&
	    ECF_ISFINITE(_q(2)) && ECF_ISFINITE(_q(3)) &&
	    _q.length() > 0.95f && _q.length() < 1.05f) {
		_inited = true;

	} else {
		_inited = false;
	}
       // debugger_a[2] = 1.0f;
	return _inited;
}

bool AttitudeEstimatorQ::update(float dt)
{       
      //  debugger_a[0] = 5.0f;
	if (!_inited) {
          
         // debugger_a[0] = 0.0f;
          
		return init();
	}

	Quatf q_last = _q;

	// Angular rate of correction
	Vector3f corr;
	float spinRate = _gyro.length();
	_spinRate = spinRate;

	if (_ext_hdg_mode > 0 && _ext_hdg_good) {
//		if (_ext_hdg_mode == EXT_VISION) {
//			// Vision heading correction
//			// Project heading to global frame and extract XY component
//			Vector3f vision_hdg_earth = _q.conjugate(_vision_hdg);
//			float vision_hdg_err = wrap_pi(atan2f(vision_hdg_earth(1), vision_hdg_earth(0)));
//			// Project correction to body frame
//			corr += _q.conjugate_inversed(Vector3f(0.0f, 0.0f, -vision_hdg_err)) * _w_ext_hdg;
//		}

//		if (_ext_hdg_mode == EXT_MOCAP) {
//			// Mocap heading correction
//			// Project heading to global frame and extract XY component
//			Vector3f mocap_hdg_earth = _q.conjugate(_mocap_hdg);
//			float mocap_hdg_err = wrap_pi(atan2f(mocap_hdg_earth(1), mocap_hdg_earth(0)));
//			// Project correction to body frame
//			corr += _q.conjugate_inversed(Vector3f(0.0f, 0.0f, -mocap_hdg_err)) * _w_ext_hdg;
//		}

        if (_ext_hdg_mode == EXT_GPS) {
        	gps.state=2;
            float x,y, z;
            euler(&x, &y, &z);
            float gps_heading_err = wrap_pi(z-gpos.heading);
            phi_rad_in = x;
            theta_rad_in = y;
            psi_rad_in = z;
//            corr += _q.conjugate_inversed(Vector3f(0.0f, 0.0f, -gps_heading_err)) * _w_ext_hdg;
            corr += _q.conjugate_inversed(Vector3f(0.0f, 0.0f, -gps_heading_err)) * _w_ext_hdg*2;
        }
	}
	else{
		corr(2);//=0;
//		_gyro_bias(2)=0;
	}
	yaw_1 = corr(2)*57.2957;


        //Yucheng
	//if (_ext_hdg_mode == 0 || !_ext_hdg_good) {
        if(0){
		// Magnetometer correction
		// Project mag field vector to global frame and extract XY component
		Vector3f mag_earth = _q.conjugate(_mag);
//		mag_earth_x = mag_earth(0);
//		mag_earth_y = mag_earth(1);
//		magAtan = atan2f(mag_earth(1), mag_earth(0));
		float mag_err = wrap_pi(atan2f(mag_earth(1), mag_earth(0)) - _mag_decl);
		float gainMult = 1.0f;
		const float fifty_dps = 0.873f;

		if (spinRate > fifty_dps) {
			gainMult = math::min(spinRate / fifty_dps, 10.0f);
		}

		// Project magnetometer correction to body frame
		corr += _q.conjugate_inversed(Vector3f(0.0f, 0.0f, -mag_err)) * _w_mag * gainMult;
				mag_earth_x = corr(0);
				mag_earth_y = corr(1);
				magAtan = corr(2);
	}

	_q.normalize();


	// Accelerometer correction
	// Project 'k' unit vector of earth frame to body frame
	// Vector3f k = _q.conjugate_inversed(Vector3f(0.0f, 0.0f, 1.0f));
	// Optimized version with dropped zeros
	Vector3f k(
		2.0f * (_q(1) * _q(3) - _q(0) * _q(2)),
		2.0f * (_q(2) * _q(3) + _q(0) * _q(1)),
		(_q(0) * _q(0) - _q(1) * _q(1) - _q(2) * _q(2) + _q(3) * _q(3))
	);

	// If we are not using acceleration compensation based on GPS velocity,
	// fuse accel data only if its norm is close to 1 g (reduces drift).
	const float accel_norm_sq = _accel.norm_squared();
	const float upper_accel_limit = CONSTANTS_ONE_G * 1.1f;
	const float lower_accel_limit = CONSTANTS_ONE_G * 0.9f;

	if (_acc_comp || (accel_norm_sq > lower_accel_limit * lower_accel_limit &&
			  accel_norm_sq < upper_accel_limit * upper_accel_limit  )) {

//		corr = (k % (_accel - _pos_acc).normalized()) * _w_accel;    // 20220504 Macial

//                float qz = corr(2);
////                float delta_qz=0;
//                AHRS_Angle_PI_Gain_Tuning_U.Ang_In = qz;
//                AHRS_Angle_PI_Gain_Tuning_step();
//                qz = AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out;
//                //yaw angle cancellation start from here
//                float yaw_rate_dps_in = qz * R2D;
//                float psi_deg_in = psi_rad_in * R2D;
//
//                float delta_qz1;
//                AHRS_Yaw_Drift_Tuning_U.Yaw_Rate_dps_In = yaw_rate_dps_in;
//                AHRS_Yaw_Drift_Tuning_U.Yaw_Ang_In = psi_deg_in;
//                AHRS_Yaw_Drift_Tuning_step();
//                delta_qz1 = AHRS_Yaw_Drift_Tuning_Y.Delta_Yaw_Rate_Rps_Out;
//
//                float x,y, z;
//                euler(&x, &y, &z);
//
//                Axyz_Estimation_to_VBxyz_U.Phi_Deg = x*57.296;// * R2D;
//			   Axyz_Estimation_to_VBxyz_U.Theta_Deg = y*57.296;// * R2D;
//			   double  acc_rls_x=_accel(0);
//			   double  acc_rls_y=_accel(1);
//			   double  acc_rls_z=_accel(2);
//			   acc_rls_x=acc_rls_x-sin(y)*9.81;
//			   acc_rls_y=acc_rls_y+cos(y)*sin(x)*9.81;
//			   acc_rls_z=acc_rls_z+cos(y)*cos(x)*9.81;
//			   Axyz_Estimation_to_VBxyz_U.Ax_mps2 = acc_rls_x;
//			   Axyz_Estimation_to_VBxyz_U.Ay_mps2 = acc_rls_y;
//			   Axyz_Estimation_to_VBxyz_U.Az_mps2 = acc_rls_z;
//			   Axyz_Estimation_to_VBxyz_U.Ax_mps2 = _accel(0);
//			   Axyz_Estimation_to_VBxyz_U.Ay_mps2 = _accel(1);
//			   Axyz_Estimation_to_VBxyz_U.Az_mps2 = _accel(2);
//			   Axyz_Estimation_to_VBxyz_step();
//			   VB_x = Axyz_Estimation_to_VBxyz_Y.VB_x;                         /* '<Root>/VB_x' */
//			   XB = Axyz_Estimation_to_VBxyz_Y.XB;                           /* '<Root>/XB' */
//			   VB_y = Axyz_Estimation_to_VBxyz_Y.VB_y;                         /* '<Root>/VB_y' */
//			   YB = Axyz_Estimation_to_VBxyz_Y.YB;                           /* '<Root>/YB' */
//			   VB_z = Axyz_Estimation_to_VBxyz_Y.VB_z;                         /* '<Root>/VB_z' */
//			   ZB = Axyz_Estimation_to_VBxyz_Y.ZB;                           /* '<Root>/ZB' */
//			   Road_Hole_Hit = Axyz_Estimation_to_VBxyz_Y.Road_Hole_Hit;

                /*float qx = corr(0);
                float delta_qx=0;
                AHRS_Angle_PI_Gain_Tuning_U.Ang_In = qx;
                AHRS_Angle_PI_Gain_Tuning_step();
                qx = AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out;
                //yaw angle cancellation start from here
                float roll_rate_dps_in = qx * R2D;
                float phi_deg_in = phi_rad_in * R2D;
                
                //float delta_qx1;
                AHRS_Yaw_Drift_Tuning_U.Yaw_Rate_dps_In = roll_rate_dps_in;
                AHRS_Yaw_Drift_Tuning_U.Yaw_Ang_In = phi_deg_in;
                AHRS_Yaw_Drift_Tuning_step();
                delta_qx1 = AHRS_Yaw_Drift_Tuning_Y.Delta_Yaw_Rate_Rps_Out;
                
                float qy = corr(1);
                float delta_qy=0;
                AHRS_Angle_PI_Gain_Tuning_U.Ang_In = qy;
                AHRS_Angle_PI_Gain_Tuning_step();
                qy = AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out;
                //yaw angle cancellation start from here
                float pitch_rate_dps_in = qy * R2D;
                float theta_deg_in = theta_rad_in * R2D;
                
                float delta_qy1;
                AHRS_Yaw_Drift_Tuning_U.Yaw_Rate_dps_In = pitch_rate_dps_in;
                AHRS_Yaw_Drift_Tuning_U.Yaw_Ang_In = theta_deg_in;
                AHRS_Yaw_Drift_Tuning_step();
                delta_qy1 = AHRS_Yaw_Drift_Tuning_Y.Delta_Yaw_Rate_Rps_Out;*/
                
                //yaw angle cancellation stop here timchen 20210108
                //corr(0) = corr(0) + delta_qx1;
                //corr(1) = corr(1) + delta_qy1;
                //corr(2) = corr(2) + delta_qz1;
                float CORR2 = corr(2) ;//+ delta_qz1;
                //delta_qz = 0;//qz*(0.025f);
              //  vel[2]=corr(2);
		corr += (k % (_accel - _pos_acc).normalized()) * _w_accel;
//                corr = (k % (_accel - _pos_acc).normalized()) * _w_accel;
                Vector3f a(corr(0)*5.0f,corr(1)*5.0f,0);
                //Vector3f a(corr(0),corr(1), 0);
                corr += a;
                errRoll = corr(0);
                errPitch = corr(1);
//                corr(2) = CORR2;
                yaw_2 = corr(2)*57.2957;
                //gps.pdop=corr(2);
                //int qq = AHRS_Angle_PI_Gain_Tuning_step( corr.z);
                //qqv = v3f( 0,0,qq);
                //corr += qqv;
	}
        float x = corr(0);
        //AHRS_Angle_PI_Gain_Tuning_U.Ang_In = x;
        //AHRS_Angle_PI_Gain_Tuning_step();
        //x = AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out;
        
        float y = corr(1);
        //AHRS_Angle_PI_Gain_Tuning_U.Ang_In = y;
        //AHRS_Angle_PI_Gain_Tuning_step();
        //y = AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out;

        float z = corr(2);
        
        //AHRS_Angle_PI_Gain_Tuning_U.Ang_In = z;
        //AHRS_Angle_PI_Gain_Tuning_step();
        //z = AHRS_Angle_PI_Gain_Tuning_Y.Ang_Out;
        
        //Vector3f q(x,y,z);
        //corr += q;

        yaw_5 = 0;
	// Gyro bias estimation // jack said here need an i-gain.
	if (spinRate < 0.175f) {
		_gyro_bias += corr * (_w_gyro_bias * dt);
		yaw_5 =_gyro_bias(2)*57.2957;

		for (int i = 0; i < 3; i++) {
			_gyro_bias(i) = math::constrain(_gyro_bias(i), -_bias_max, _bias_max);
		}

	}

	gyPitchBias =_gyro_bias(2)*57.2957;
	gyPitch = _gyro(2)*57.2957;
	_rates = _gyro + _gyro_bias;

	// Feed forward gyro
	corr += _rates;
	yaw_3 = corr(2)*57.2957;

	// Apply correction to state
    //_q += _q.derivative1(corr) * dt;
    _q += _q.derivative1(corr) * dt;

	// Normalize quaternion
	_q.normalize();

//	char _arr[100];
//	sprintf(_arr, "%7.4f,%7.4f,%7.4f,%7.4f,%7.4f,%7.4f,%7.4f,%7.4f\r\n",yaw_1,yaw_2,yaw_3,yaw_4,gyPitchBias,gyPitch,spinRate,yaw_5);
//	LPUART3_Send((uint8_t*)_arr, strlen(_arr));
//	char _arr[100];
//	sprintf(_arr, "{\"q0\":%.6f,\"q1\":%.6f,\"q2\":%.6f,\"q3\":%.6f}\r\n", _q(0), _q(1),_q(2),_q(3));
//	LPUART3_Send((uint8_t*)_arr, strlen(_arr));

	if (!(ECF_ISFINITE(_q(0)) && ECF_ISFINITE(_q(1)) &&
	      ECF_ISFINITE(_q(2)) && ECF_ISFINITE(_q(3)))) {
		// Reset quaternion to last good state
		_q = q_last;
		_rates.zero();
		yaw_4 = _rates(2)*57.2957;
		_gyro_bias.zero();
//char _arr[100];
////sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f\r\n",yaw_0,yaw_1,yaw_2,yaw_3,yaw_4,gyPitchBias,gyPitch,spinRate);
//		sprintf(_arr, "{\"q0\":%.6f,\"q1\":%.6f,\"q2\":%.6f,\"q3\":%.6f}\r\n", _q(0), _q(1),_q(2),_q(3));
//LPUART3_Send((uint8_t*)_arr, strlen(_arr));
		return NOUPDATE_ATTITUDE;
	}

	return VALID_ATTITUDE;
}

void AttitudeEstimatorQ::update_mag_declination(float new_declination)
{
	// Apply initial declination or trivial rotations without changing estimation
	if (!_inited || fabsf(new_declination - _mag_decl) < 0.0001f) {
		_mag_decl = new_declination;

	} else {
		// Immediately rotate current estimation to avoid gyro bias growth
		Quatf decl_rotation = Eulerf(0.0f, 0.0f, new_declination - _mag_decl);
		_q = _q * decl_rotation;
		_mag_decl = new_declination;
	}
}

void AttitudeEstimatorQ::euler(float*x, float*y, float*z) const
{
    // Eulerf att(AttitudeEstimatorQ::instance()._q);
    Eulerf att(_q);
    
    for(int i=0;i<4;i++){
      
        Q[i]=_q(i);
        
        }
   
    
    *x = att(0);
    *y = att(1);
    *z = att(2);
}

void set_gps(struct GPS * gps)
{
    AttitudeEstimatorQ::instance().gpos = *gps;
}

void set_w_accel(float val)
{
    AttitudeEstimatorQ::instance().set_w_accel(val);
}
void set_w_mag(float val)
{
    AttitudeEstimatorQ::instance().set_w_mag(val);
}
void set_w_ext_heading(float val)
{
    AttitudeEstimatorQ::instance().set_w_ext_heading(val);
}
void set_w_gyro_bias(float val)
{
    AttitudeEstimatorQ::instance().set_w_gyro_bias(val);
}
void set_mag_decl(float val)
{
    AttitudeEstimatorQ::instance().set_mag_decl(val);
}
void set_bias_max(float val)
{
    AttitudeEstimatorQ::instance().set_bias_max(val);
}
void set_heading(float val)
{
	Quatf init_heading=Eulerf(0.0,0.0,val);
    AttitudeEstimatorQ::instance().set_heading(init_heading);
}


int do_attitude_estimator(float gx, float gy, float gz,
    float ax, float ay, float az,
    float mx, float my, float mz, float dt, 
    float*x,float*y,float*z, float *rate_out)
{

	set_gps(&gps);

    int status = AttitudeEstimatorQ::instance().task_main( gx,  gy,  gz,
         ax,  ay,  az,
         mx,  my,  mz,  dt);

    if (status>=NOUPDATE_ATTITUDE)
    {
        AttitudeEstimatorQ::instance().euler(x, y, z);
        AttitudeEstimatorQ::instance().get_rates(rate_out);
    }

    return status;
}
