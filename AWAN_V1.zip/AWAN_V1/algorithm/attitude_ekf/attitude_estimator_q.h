#pragma once

// attitude_estimatorq status
#ifndef VALID_ATTITUDE
#define VALID_ATTITUDE (1)
#endif
#define NOUPDATE_ATTITUDE (0)

#define INVALID_ACCELERATION (-1)
#define INVALID_MAG (-2)

#define VALID_GPS_HEADING (1)
#define INVALID_GPS_HEADING (0)
#include<stdbool.h>
struct GPS
{
	uint16_t id;
	bool valid;
	int state;
    uint64_t timestamp;     // time since system start (microseconds)
    uint16_t time_sec;
    uint16_t time_min;
    uint16_t time_hour;
    uint16_t time_day;
	uint16_t time_month;
	uint16_t time_year;

    float pdop;
	float eph;          // Standard deviation of horizontal position error, (metres)
	float epv;          // Standard deviation of vertical position error, (metres)

    uint32_t lat;          // Latitude, (degrees*10^7)
    uint32_t lon;          // Longitude, (degrees*10^7)
    float vel;			// earth speed (metres / sec)
    float vel_n;        // North velocity in NED earth - fixed frame, (metres / sec)
    float vel_e;        // East velocity in NED earth - fixed frame, (metres / sec)
    float vel_d;        // Down velocity in NED earth - fixed frame, (metres / sec)


    float heading;      // heading (radian)
    float rGPSHeading;
    uint8_t rGPSCnt;
    int heading_valid;  // VALID_GPS_HEADING or INVALID_GPS_HEADING

    float distance;
    uint8_t gps_timeValid;
    uint8_t antFlag;
    uint8_t gps_headingAlign;
    uint8_t gps_lost;
    uint8_t gps_psuedoLost;
    uint8_t test;
};

#ifdef __cplusplus
extern "C" {
#endif

int do_attitude_estimator(float gx, float gy, float gz,
    float ax, float ay, float az,
    float mx, float my, float mz, float dt, 
    float*x,float*y,float*z, float *rate_out);

void set_gps(struct GPS * gps);
void set_w_accel(float val);
void set_w_mag(float val);
void set_w_ext_heading(float val);
void set_w_gyro_bias(float val);
void set_mag_decl(float val);
void set_bias_max(float val);
void set_heading(float val);

#ifdef __cplusplus
}
#endif
