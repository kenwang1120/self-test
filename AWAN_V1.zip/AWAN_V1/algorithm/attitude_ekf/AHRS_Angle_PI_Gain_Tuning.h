/*
 * AHRS_Angle_PI_Gain_Tuning.h
 *
 * Code generation for model "AHRS_Angle_PI_Gain_Tuning".
 *
 * Model version              : 1.3
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Wed Jan 06 15:50:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_AHRS_Angle_PI_Gain_Tuning_h_
#define RTW_HEADER_AHRS_Angle_PI_Gain_Tuning_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef AHRS_Angle_PI_Gain_Tuning_COMMON_INCLUDES_
# define AHRS_Angle_PI_Gain_Tuning_COMMON_INCLUDES_
#include "rtwtypes.h"
//#include "rtw_continuous.h"
//#include "rtw_solver.h"
//#include "rt_logging.h"
#endif                                 /* AHRS_Angle_PI_Gain_Tuning_COMMON_INCLUDES_ */

#include "AHRS_Angle_PI_Gain_Tuning_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay1_DSTATE;            /* '<Root>/Unit Delay1' */
  real_T Memory2_PreviousInput;        /* '<S4>/Memory2' */
  real_T Memory1_PreviousInput;        /* '<S4>/Memory1' */
  real_T Memory1_PreviousInput_b;      /* '<S3>/Memory1' */
  real_T Memory_PreviousInput;         /* '<S3>/Memory' */
  real_T Memory2_PreviousInput_c;      /* '<S5>/Memory2' */
  real_T Memory4_PreviousInput;        /* '<S5>/Memory4' */
  real_T Memory_PreviousInput_c;       /* '<S6>/Memory' */
  real_T Memory1_PreviousInput_f;      /* '<S6>/Memory1' */
} DW_AHRS_Angle_PI_Gain_Tuning_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Ang_In;                       /* '<Root>/Ang_In' */
} ExtU_AHRS_Angle_PI_Gain_Tunin_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T Ang_Out;                      /* '<Root>/Ang_Out' */
} ExtY_AHRS_Angle_PI_Gain_Tunin_T;

/* Parameters (auto storage) */
struct P_AHRS_Angle_PI_Gain_Tuning_T_ {
  real_T SIMTIME_DT;                   /* Variable: SIMTIME_DT
                                        * Referenced by:
                                        *   '<S3>/P_LAG'
                                        *   '<S4>/Constant5'
                                        *   '<S5>/P_LAG'
                                        *   '<S6>/P_LAG'
                                        */
  real_T P_INTEG_LL_Value;             /* Expression: -1
                                        * Referenced by: '<S4>/P_INTEG_LL'
                                        */
  real_T P_INTEG_Value;                /* Expression: 1
                                        * Referenced by: '<S4>/P_INTEG'
                                        */
  real_T Gain_Gain;                    /* Expression: 0.5
                                        * Referenced by: '<S4>/Gain'
                                        */
  real_T Switch3_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S4>/Switch3'
                                        */
  real_T Gain1_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<S5>/Gain1'
                                        */
  real_T C3_Value;                     /* Expression: 0
                                        * Referenced by: '<S2>/C3'
                                        */
  real_T Switch7_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S5>/Switch7'
                                        */
  real_T Switch_Threshold;             /* Expression: 0.5
                                        * Referenced by: '<S6>/Switch'
                                        */
  real_T Gain_Gain_m;                  /* Expression: 0.5
                                        * Referenced by: '<S6>/Gain'
                                        */
  real_T C_300Hz_Value;                /* Expression: 300
                                        * Referenced by: '<S3>/C_300Hz'
                                        */
  real_T Switch_Threshold_j;           /* Expression: 0.5
                                        * Referenced by: '<S3>/Switch'
                                        */
  real_T Gain_Gain_c;                  /* Expression: 0.5
                                        * Referenced by: '<S3>/Gain'
                                        */
  real_T P_Gain_Gain;                  /* Expression: 1
                                        * Referenced by: '<Root>/P_Gain'
                                        */
  real_T P_INTEG_UL_Value;             /* Expression: 1
                                        * Referenced by: '<S4>/P_INTEG_UL'
                                        */
  real_T C0_Value;                     /* Expression: 0
                                        * Referenced by: '<S1>/C0'
                                        */
  real_T Memory2_X0;                   /* Expression: 0
                                        * Referenced by: '<S4>/Memory2'
                                        */
  real_T Memory1_X0;                   /* Expression: 0
                                        * Referenced by: '<S4>/Memory1'
                                        */
  real_T I_Gain_Gain;                  /* Expression: 0.1
                                        * Referenced by: '<Root>/I_Gain'
                                        */
  real_T Switch6_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S4>/Switch6'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<Root>/Unit Delay1'
                                        */
  real_T Amp_Gain_Gain;                /* Expression: 10
                                        * Referenced by: '<Root>/Amp_Gain'
                                        */
  real_T Deri_Gain_Gain;               /* Expression: 0.5
                                        * Referenced by: '<Root>/Deri_Gain'
                                        */
  real_T C0_Value_m;                   /* Expression: 0
                                        * Referenced by: '<Root>/C0'
                                        */
  real_T C1_Value;                     /* Expression: 0
                                        * Referenced by: '<S2>/C1'
                                        */
  real_T C_30Hz_Value;                 /* Expression: 30
                                        * Referenced by: '<S2>/C_30Hz'
                                        */
  real_T Memory1_X0_h;                 /* Expression: 0
                                        * Referenced by: '<S3>/Memory1'
                                        */
  real_T Memory_X0;                    /* Expression: 0
                                        * Referenced by: '<S3>/Memory'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S3>/Switch1'
                                        */
  real_T K1_Gain;                      /* Expression: 1
                                        * Referenced by: '<S2>/K1'
                                        */
  real_T Memory2_X0_g;                 /* Expression: 0
                                        * Referenced by: '<S5>/Memory2'
                                        */
  real_T Memory4_X0;                   /* Expression: 0
                                        * Referenced by: '<S5>/Memory4'
                                        */
  real_T Switch6_Threshold_l;          /* Expression: 0.5
                                        * Referenced by: '<S5>/Switch6'
                                        */
  real_T K2_Gain;                      /* Expression: 1/1
                                        * Referenced by: '<S2>/K2'
                                        */
  real_T Memory_X0_p;                  /* Expression: 0
                                        * Referenced by: '<S6>/Memory'
                                        */
  real_T Memory1_X0_b;                 /* Expression: 0
                                        * Referenced by: '<S6>/Memory1'
                                        */
  real_T Switch1_Threshold_b;          /* Expression: 0.5
                                        * Referenced by: '<S6>/Switch1'
                                        */
  real_T K3_Gain;                      /* Expression: 1
                                        * Referenced by: '<S2>/K3'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_AHRS_Angle_PI_Gain_Tu_T {
  const char_T *errorStatus;
//  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (auto storage) */
extern P_AHRS_Angle_PI_Gain_Tuning_T AHRS_Angle_PI_Gain_Tuning_P;

/* Block states (auto storage) */
extern DW_AHRS_Angle_PI_Gain_Tuning_T AHRS_Angle_PI_Gain_Tuning_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_AHRS_Angle_PI_Gain_Tunin_T AHRS_Angle_PI_Gain_Tuning_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_AHRS_Angle_PI_Gain_Tunin_T AHRS_Angle_PI_Gain_Tuning_Y;

/* Model entry point functions */
extern void AHRS_Angle_PI_Gain_Tuning_initialize(void);
extern void AHRS_Angle_PI_Gain_Tuning_step(void);
extern void AHRS_Angle_PI_Gain_Tuning_terminate(void);

/* Real-time Model object */
extern RT_MODEL_AHRS_Angle_PI_Gain_T_T *const AHRS_Angle_PI_Gain_Tuning_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'AHRS_Angle_PI_Gain_Tuning'
 * '<S1>'   : 'AHRS_Angle_PI_Gain_Tuning/Integ'
 * '<S2>'   : 'AHRS_Angle_PI_Gain_Tuning/Lead_Lag_30Hz'
 * '<S3>'   : 'AHRS_Angle_PI_Gain_Tuning/Washout_300Hz'
 * '<S4>'   : 'AHRS_Angle_PI_Gain_Tuning/Integ/Integrator'
 * '<S5>'   : 'AHRS_Angle_PI_Gain_Tuning/Lead_Lag_30Hz/Deri_Lag_Filter'
 * '<S6>'   : 'AHRS_Angle_PI_Gain_Tuning/Lead_Lag_30Hz/Deri_W_out'
 */
#endif                                 /* RTW_HEADER_AHRS_Angle_PI_Gain_Tuning_h_ */
