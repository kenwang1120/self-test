/*
 * AHRS_Yaw_Drift_Tuning_data.c
 *
 * Code generation for model "AHRS_Yaw_Drift_Tuning".
 *
 * Model version              : 1.7
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Tue Jan 12 10:52:55 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "AHRS_Yaw_Drift_Tuning.h"
#include "AHRS_Yaw_Drift_Tuning_private.h"

/* Block parameters (auto storage) */
P_AHRS_Yaw_Drift_Tuning_T AHRS_Yaw_Drift_Tuning_P = {
  10.0,                                /* Mask Parameter: LAG_Psi_Tau
                                        * Referenced by: '<S5>/P_LAG'
                                        */
  10.0,                                /* Mask Parameter: LAG_R_Tau
                                        * Referenced by: '<S8>/P_LAG'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Logic_False_Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Logic_False_Gain'
                                        */
  0.360,                                 /* Expression: 3.6
                                        * Referenced by: '<Root>/Psi_P_Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/R_P_Gain'
                                        */
  0.0174533,                           /* Expression: 0.0174533
                                        * Referenced by: '<Root>/d2r'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S5>/S1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S8>/Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S8>/S1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/R_C0'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/M2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/M1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S8>/S2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay5'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay6'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay7'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Delay8'
                                        */
  0.1,                                 /* Expression: 1/10
                                        * Referenced by: '<S10>/Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S9>/Ave_Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Psi_C0'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/M2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/M1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S5>/S2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S6>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay5'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay6'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay7'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S7>/Delay8'
                                        */
  0.1,                                 /* Expression: 1/10
                                        * Referenced by: '<S7>/Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S6>/Ave_Gain'
                                        */
  600.0,                               /* Expression: 600
                                        * Referenced by: '<Root>/Rate_Conv_Gain'
                                        */
  0.0001F,                             /* Computed Parameter: C_S0_Value
                                        * Referenced by: '<S4>/C_S0'
                                        */
  3.0F,                                /* Computed Parameter: C_S1_Value
                                        * Referenced by: '<S4>/C_S1'
                                        */
  2.5E-5F,                             /* Computed Parameter: C_R0_Value
                                        * Referenced by: '<S4>/C_R0'
                                        */
  0.05F,                                /* Computed Parameter: C0_LL_Value
                                        * Referenced by: '<S3>/C0_LL'
                                        */
  1U,                                  /* Computed Parameter: Delay_DelayLength
                                        * Referenced by: '<S10>/Delay'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength
                                        * Referenced by: '<S10>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<S10>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength
                                        * Referenced by: '<S10>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength
                                        * Referenced by: '<S10>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay5_DelayLength
                                        * Referenced by: '<S10>/Delay5'
                                        */
  1U,                                  /* Computed Parameter: Delay6_DelayLength
                                        * Referenced by: '<S10>/Delay6'
                                        */
  1U,                                  /* Computed Parameter: Delay7_DelayLength
                                        * Referenced by: '<S10>/Delay7'
                                        */
  1U,                                  /* Computed Parameter: Delay8_DelayLength
                                        * Referenced by: '<S10>/Delay8'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_e
                                        * Referenced by: '<S6>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay_DelayLength_j
                                        * Referenced by: '<S7>/Delay'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_h
                                        * Referenced by: '<S7>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_k
                                        * Referenced by: '<S7>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_l
                                        * Referenced by: '<S7>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_m
                                        * Referenced by: '<S7>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay5_DelayLength_f
                                        * Referenced by: '<S7>/Delay5'
                                        */
  1U,                                  /* Computed Parameter: Delay6_DelayLength_m
                                        * Referenced by: '<S7>/Delay6'
                                        */
  1U,                                  /* Computed Parameter: Delay7_DelayLength_k
                                        * Referenced by: '<S7>/Delay7'
                                        */
  1U,                                  /* Computed Parameter: Delay8_DelayLength_c
                                        * Referenced by: '<S7>/Delay8'
                                        */
  1U,                                  /* Computed Parameter: Delay_DelayLength_l
                                        * Referenced by: '<S11>/Delay'
                                        */
  0                                    /* Computed Parameter: Delay_InitialCondition_l
                                        * Referenced by: '<S11>/Delay'
                                        */
};
