/*
 * AHRS_Angle_PI_Gain_Tuning_data.c
 *
 * Code generation for model "AHRS_Angle_PI_Gain_Tuning".
 *
 * Model version              : 1.3
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Wed Jan 06 15:50:13 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "AHRS_Angle_PI_Gain_Tuning.h"
#include "AHRS_Angle_PI_Gain_Tuning_private.h"

/* Block parameters (auto storage) */
P_AHRS_Angle_PI_Gain_Tuning_T AHRS_Angle_PI_Gain_Tuning_P = {
  0.0016666666666666668,               /* Variable: SIMTIME_DT
                                        * Referenced by:
                                        *   '<S3>/P_LAG'
                                        *   '<S4>/Constant5'
                                        *   '<S5>/P_LAG'
                                        *   '<S6>/P_LAG'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S4>/P_INTEG_LL'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/P_INTEG'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S4>/Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S4>/Switch3'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S5>/Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/C3'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S5>/Switch7'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S6>/Switch'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S6>/Gain'
                                        */
  300.0,                               /* Expression: 300
                                        * Referenced by: '<S3>/C_300Hz'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S3>/Switch'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S3>/Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/P_Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/P_INTEG_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/C0'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Memory1'
                                        */
  0.0,                                 /* Expression: 0.1
                                        * Referenced by: '<Root>/I_Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S4>/Switch6'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Unit Delay1'
                                        */
  0.0,                                /* Expression: 10
                                        * Referenced by: '<Root>/Amp_Gain'
                                        */
  0.0,                              /* Expression: 0.5
                                        * Referenced by: '<Root>/Deri_Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/C0'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/C1'
                                        */
  30.0,                                /* Expression: 30
                                        * Referenced by: '<S2>/C_30Hz'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S3>/Memory'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S3>/Switch1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/K1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/Memory4'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S5>/Switch6'
                                        */
  1.0,                                 /* Expression: 1/1
                                        * Referenced by: '<S2>/K2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S6>/Memory'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S6>/Memory1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S6>/Switch1'
                                        */
  1.0                                  /* Expression: 1
                                        * Referenced by: '<S2>/K3'
                                        */
};
