//******************************************************************************
//! @ProjectName: V-3000-HUANDA
//! @ModuleName:  attitude_ekf.cpp
//!
//! @Purpose:
//! Functions for attitude ekf.
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//******************************************************************************

#include "attitude_ekf.h"
#include "ekf.h"

Ekf _ekf_engine;
static uint64_t _fake_system_time = 0;

void accumulate_mag(uint64_t timestamp, float* magnetometer_ga);
void accumulate_baro(uint64_t timestamp, float baro_alt_meter);
imuSample _imu_sample;

int do_attitude_ekf(float* gyro, float * accel,float * mag, 
   float dt, float* att_out, float* rate_out, float* accel_out)
{  
    _fake_system_time += uint64_t(dt*1.e6);
    uint64_t time_usec = _fake_system_time;
    
    _imu_sample.delta_ang(0) = gyro[0] * dt;
    _imu_sample.delta_ang(1) = gyro[1] * dt;
    _imu_sample.delta_ang(2) = gyro[2] * dt;
    _imu_sample.delta_vel(0) = accel[0] * dt;
    _imu_sample.delta_vel(1) = accel[1] * dt;
    _imu_sample.delta_vel(2) = accel[2] * dt;
    _imu_sample.delta_ang_dt = dt;   ///< delta angle integration period (sec)
    _imu_sample.delta_vel_dt = dt;   ///< delta velocity integration period (sec)
    _imu_sample.time_us = time_usec;
    _ekf_engine.set_in_air_status(true);

    _ekf_engine.setIMUData(_imu_sample);
    //Yucheng
//    mag[0] =mag[0]/50.0f;
//    mag[1] =mag[1]/50.0f;
//    mag[2] =mag[2]/50.0f;
    accumulate_mag(time_usec, mag);
    //gps_message gps;
    //gps.time_usec= time_usec;
    //gps.lat=0;		///< Latitude in 1E-7 degrees
    //gps.lon=0;		///< Longitude in 1E-7 degrees
    //gps.alt=0;		///< Altitude in 1E-3 meters (millimeters) above MSL
    //gps.yaw = 0;		///< yaw angle. NaN if not set (used for dual antenna GPS), (rad, [-PI, PI])
    //gps.yaw_offset;	///< Heading/Yaw offset for dual antenna GPS - refer to description for GPS_YAW_OFFSET
    //gps.fix_type = 3;	///< 0-1: no fix, 2: 2D fix, 3: 3D fix, 4: RTCM code differential, 5: Real-Time Kinematic
    //gps.eph = 0.001;		///< GPS horizontal position accuracy in m
    //gps.epv = 0.001;		///< GPS vertical position accuracy in m
    //gps.sacc = 0.001;		///< GPS speed accuracy in m/s
    //gps.vel_m_s = 0;		///< GPS ground speed (m/sec)
    //gps.vel_ned[0]= gps.vel_ned[1] = gps.vel_ned[2] = 0;	///< GPS ground speed NED
    //gps.vel_ned_valid = 1;	///< GPS ground speed is valid
    //gps.nsats = 16;		///< number of satellites used
    //gps.gdop = 0.04;		///< geometric dilution of precision
    //_ekf_engine.setGpsData (time_usec, gps);
    accumulate_baro(time_usec, 0);

    if (_ekf_engine.update()) 
    {
        if (_ekf_engine.attitude_valid())
        {
            Eulerf att(_ekf_engine.calculate_quaternion());
            att_out[0] = att(0);att_out[1] = att(1);att_out[2] = att(2);

            float gbias[3] = { 0 };
            _ekf_engine.get_gyro_bias(gbias);
            rate_out[0] = gyro[0] - gbias[0];
            rate_out[1] = gyro[1] - gbias[1];
            rate_out[2] = gyro[2] - gbias[2];

            float abias[3] = { 0 };
            _ekf_engine.get_accel_bias(abias);
            accel_out[0] = accel[0] - abias[0];
            accel_out[1] = accel[1] - abias[1];
            accel_out[2] = accel[2] - abias[2];

            float speed[6] = { 0 };
            _ekf_engine.get_vel_pos_innov(speed);

            if (_ekf_engine.attitude_good()) { return GOOD_ATTITUDE;}
            else { return VALID_ATTITUDE; }
        }
        else {return NOUPDATE_ATTITUDE;}
    }
    //else { att_out[0] = NAN; att_out[1] = NAN; att_out[2] = NAN; }
    else { att_out[0] = 0; att_out[1] = 0; att_out[2] = 0; }
    return NOUPDATE_ATTITUDE;
}

void accumulate_mag(uint64_t timestamp, float* magnetometer_ga)
{
    // If the time last used by the EKF is less than specified, then accumulate the
                // data and push the average when the specified interval is reached.
    static uint64_t _mag_time_sum_ms = 0;
    static uint8_t _mag_sample_count=0;
    static float _mag_data_sum[3] = { 0.0f,0.0f,0.0f };
    static uint64_t _mag_time_ms_last_used = 0;

    _mag_time_sum_ms += timestamp / 1000;
    _mag_sample_count++;
    _mag_data_sum[0] += magnetometer_ga[0];
    _mag_data_sum[1] += magnetometer_ga[1];
    _mag_data_sum[2] += magnetometer_ga[2];
    uint64_t mag_time_ms = _mag_time_sum_ms / _mag_sample_count;
    
    if ((mag_time_ms - _mag_time_ms_last_used) > (uint64_t)_ekf_engine.getParamHandle()->sensor_interval_min_ms)
    {
        const float mag_sample_count_inv = 1.0f / _mag_sample_count;
        // calculate mean of measurements and correct for learned bias offsets
        float mag_data_avg_ga[3] = { _mag_data_sum[0] * mag_sample_count_inv,
                        _mag_data_sum[1] * mag_sample_count_inv,
                        _mag_data_sum[2] * mag_sample_count_inv
        };

        _ekf_engine.setMagData(1000 * (uint64_t)mag_time_ms, mag_data_avg_ga);

        _mag_time_ms_last_used = mag_time_ms;
        _mag_time_sum_ms = 0;
        _mag_sample_count = 0;
        _mag_data_sum[0] = 0.0f;
        _mag_data_sum[1] = 0.0f;
        _mag_data_sum[2] = 0.0f;
    }
}

void accumulate_baro(uint64_t timestamp, float baro_alt_meter)
{
    static uint64_t _balt_time_sum_ms = 0;
    _balt_time_sum_ms  += timestamp / 1000;
    static uint8_t _balt_sample_count = 0;
    _balt_sample_count++;
    static float _balt_data_sum = 0.0f;
    static uint64_t _balt_time_ms_last_used = 0;
    _balt_data_sum += baro_alt_meter;
    uint64_t balt_time_ms = _balt_time_sum_ms / _balt_sample_count;
    if (balt_time_ms - _balt_time_ms_last_used > (uint32_t)(_ekf_engine.getParamHandle()->sensor_interval_min_ms)) {
        // take mean across sample period
        float balt_data_avg = _balt_data_sum / (float)_balt_sample_count;
        //balt_data_avg = 10*sin(M_PI / 2 * timestamp*1.0e-6);
        _ekf_engine.setBaroData(1000 * (uint64_t)balt_time_ms, balt_data_avg);

        _balt_time_ms_last_used = balt_time_ms;
        _balt_time_sum_ms = 0;
        _balt_sample_count = 0;
        _balt_data_sum = 0.0f;
    }
}

void set_ekf_params()
{
    static short params_initlised = 0;
    if (params_initlised == 0)
    {
       parameters * param_handle = _ekf_engine.getParamHandle();
       param_handle->mag_noise = 0.9e0f;// 0.9e-3f;
       param_handle->mage_p_noise = 1.0e-0f;//Earth mag noise
       param_handle->magb_p_noise = 1.0e-0f;//Body mag noise

       //param_handle->gyro_noise = 1.5e-2f; jack Test, 0218-2021 yaw quickness
       param_handle->gyro_noise = 1.5e-0f;
       param_handle->accel_noise = 0.5e0f;
       // param_handle->gyro_bias_p_noise = 1.0e-3f;jack Test, 0218-2021 yaw quickness
       param_handle->gyro_bias_p_noise = 1.0e-0f;
       param_handle->accel_bias_p_noise = 3.60e-0f;

 //      param_handle->mag_delay_ms = 10.0f;
 //      param_handle->baro_delay_ms = 5.0f;
 //      param_handle->gps_delay_ms = 10.0f;
 //      param_handle->sensor_interval_min_ms = 10;
 //      param_handle->mag_declination_deg = 0.0f;
       // The following are Jack Test to remove time delay for EST yaw angle test, Jack Shue 0218-2021
       param_handle->mag_delay_ms = 10.0f;
       param_handle->baro_delay_ms = 10.0f;
       param_handle->gps_delay_ms = 10.0f;
       param_handle->sensor_interval_min_ms = 1.0;
       param_handle->mag_declination_deg = -0.2f;
       params_initlised = 1;
    }
}



