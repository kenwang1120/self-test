/*
 * Axyz_Estimation_to_VBxyz.c
 *
 * Code generation for model "Axyz_Estimation_to_VBxyz".
 *
 * Model version              : 1.157
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Sat May 07 14:20:14 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Axyz_Estimation_to_VBxyz.h"
#include "Axyz_Estimation_to_VBxyz_private.h"

/* Block states (auto storage) */
DW_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_Y;

/* Real-time model */
RT_MODEL_Axyz_Estimation_to_V_T Axyz_Estimation_to_VBxyz_M_;
RT_MODEL_Axyz_Estimation_to_V_T *const Axyz_Estimation_to_VBxyz_M =
  &Axyz_Estimation_to_VBxyz_M_;

/* Model step function */
void Axyz_Estimation_to_VBxyz_step(void)
{
  real_T rtb_Product1_dj;
  real_T rtb_Sqrt1;
  real_T rtb_Product2_j;
  real_T rtb_Sw1_j;
  real_T rtb_Abs2;
  real_T rtb_G_Gain1;
  real_T rtb_Yn;
  boolean_T rtb_OUT_h;
  real_T rtb_Ax_Amp_Gain;
  boolean_T rtb_OUT_c;
  real_T rtb_Sw1;
  real_T rtb_Sum3_p;
  real_T rtb_VX_Amp_Tuning1;
  boolean_T rtb_OUT_k3;
  real_T rtb_X_Amp_Tuning;
  real_T rtb_Memory2;
  real_T rtb_G_Gain;
  real_T rtb_Yn_a;
  boolean_T rtb_OUT_ha;
  real_T rtb_Gain9;
  boolean_T rtb_OUT_o;
  real_T rtb_Sum3_f;
  real_T rtb_Vy_Gain1;
  boolean_T rtb_OUT_m;
  real_T rtb_Y_Amp_Tuning;
  real_T rtb_Memory2_o;
  boolean_T rtb_OUT_jt;
  real_T rtb_Az_Amp_Gain;
  real_T rtb_OUT_d;
  real_T rtb_Vz_Amp_Tuning1;
  boolean_T rtb_OUT_j;
  real_T rtb_Sum1;

  /* Product: '<S3>/Product3' incorporates:
   *  Inport: '<Root>/Ax_mps2'
   */
  rtb_Sqrt1 = Axyz_Estimation_to_VBxyz_U.Ax_mps2 *
    Axyz_Estimation_to_VBxyz_U.Ax_mps2;

  /* Product: '<S3>/Product2' incorporates:
   *  Inport: '<Root>/Az_mps2'
   */
  rtb_Product2_j = Axyz_Estimation_to_VBxyz_U.Az_mps2 *
    Axyz_Estimation_to_VBxyz_U.Az_mps2;

  /* Gain: '<S1>/D2R_Gain1' incorporates:
   *  Inport: '<Root>/Theta_Deg'
   */
  rtb_Sw1_j = Axyz_Estimation_to_VBxyz_P.D2R_Gain1_Gain *
    Axyz_Estimation_to_VBxyz_U.Theta_Deg;

  /* Gain: '<S1>/G_Gain1' incorporates:
   *  DotProduct: '<S2>/Cth*Sphi'
   *  Gain: '<S1>/D2R_Gain'
   *  Gain: '<S1>/D_Ax_Tuning'
   *  Gain: '<S1>/Inv_G_Gain'
   *  Gain: '<S2>/Phi_Amp_Gain'
   *  Inport: '<Root>/Ax_mps2'
   *  Inport: '<Root>/Ay_mps2'
   *  Inport: '<Root>/Phi_Deg'
   *  Product: '<S3>/Divide2'
   *  Sqrt: '<S3>/Sqrt2'
   *  Sum: '<S1>/Add5'
   *  Sum: '<S2>/Add2'
   *  Sum: '<S3>/Add3'
   *  Trigonometry: '<S2>/Cthe'
   *  Trigonometry: '<S2>/Sphi'
   *  Trigonometry: '<S3>/Atan1'
   */
  rtb_G_Gain1 = (Axyz_Estimation_to_VBxyz_P.Inv_G_Gain_Gain *
                 Axyz_Estimation_to_VBxyz_U.Ax_mps2 - sin((0.0 - atan
    (Axyz_Estimation_to_VBxyz_U.Ay_mps2 / sqrt(rtb_Sqrt1 + rtb_Product2_j))) -
    Axyz_Estimation_to_VBxyz_P.D2R_Gain_Gain *
    Axyz_Estimation_to_VBxyz_U.Phi_Deg) * cos(rtb_Sw1_j) *
                 Axyz_Estimation_to_VBxyz_P.Phi_Amp_Gain_Gain) *
    Axyz_Estimation_to_VBxyz_P.D_Ax_Tuning_Gain *
    Axyz_Estimation_to_VBxyz_P.G_Gain1_Gain;
//  rtb_G_Gain1=Axyz_Estimation_to_VBxyz_U.Ax_mps2-9.8*sin(Axyz_Estimation_to_VBxyz_P.D2R_Gain_Gain *
	//	    Axyz_Estimation_to_VBxyz_U.Theta_Deg);
  /* Gain: '<S10>/Gain4' incorporates:
   *  Memory: '<S10>/Memory2'
   *  Sum: '<S10>/Sum3'
   */
  rtb_Abs2 = (rtb_G_Gain1 + Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput) *
    Axyz_Estimation_to_VBxyz_P.Gain4_Gain;

  /* Sum: '<S10>/Sum6' incorporates:
   *  Constant: '<S10>/Delta_T'
   *  Constant: '<S10>/P_LAG1'
   *  Math: '<S10>/Exp'
   *  Memory: '<S10>/Memory4'
   *  Product: '<S10>/Product1'
   *  Product: '<S10>/Product2'
   *  Sum: '<S10>/Sum5'
   *
   * About '<S10>/Exp':
   *  Operator: exp
   */
  rtb_Yn = exp(-Axyz_Estimation_to_VBxyz_P.DT *
               Axyz_Estimation_to_VBxyz_P.P_LAG1_Value) *
    (Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_f - rtb_Abs2) + rtb_Abs2;

  /* Abs: '<S13>/Ax_Abs' incorporates:
   *  Delay: '<S20>/Delay1'
   *  Delay: '<S20>/Delay2'
   *  Delay: '<S20>/Delay3'
   *  Delay: '<S20>/Delay4'
   *  Gain: '<S20>/Gain'
   *  Sum: '<S20>/Add3'
   */
  rtb_Abs2 = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE +
                      Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE) +
                     Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE) +
                    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE) + rtb_Yn) *
                  Axyz_Estimation_to_VBxyz_P.Gain_Gain);

  /* Logic: '<S21>/Logical Operator' incorporates:
   *  Constant: '<S13>/Ax_LL'
   *  Constant: '<S13>/Ax_UL'
   *  Logic: '<S21>/Logical Operator1'
   *  Logic: '<S21>/Logical Operator2'
   *  Memory: '<S21>/Memory1'
   *  RelationalOperator: '<S13>/Ax_GE'
   *  RelationalOperator: '<S13>/Ax_LE'
   */
  rtb_OUT_h = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_l || (rtb_Abs2
    <= Axyz_Estimation_to_VBxyz_P.Ax_LL_Value)) && (!(rtb_Abs2 >=
    Axyz_Estimation_to_VBxyz_P.Ax_UL_Value)));

  /* Switch: '<S13>/Ax_Sw1' incorporates:
   *  Constant: '<S13>/Ax_Zero1'
   */
  if (rtb_OUT_h) {
    rtb_Ax_Amp_Gain = Axyz_Estimation_to_VBxyz_P.Ax_Zero1_Value;
  } else {
    rtb_Ax_Amp_Gain = rtb_Yn;
  }

  /* End of Switch: '<S13>/Ax_Sw1' */

  /* Gain: '<S5>/Ax_Amp_Gain' */
  rtb_Ax_Amp_Gain *= Axyz_Estimation_to_VBxyz_P.Ax_Amp_Gain_Gain;

  /* Abs: '<S11>/Abs' incorporates:
   *  Delay: '<S16>/Delay1'
   *  Delay: '<S16>/Delay2'
   *  Delay: '<S16>/Delay3'
   *  Delay: '<S16>/Delay4'
   *  Gain: '<S16>/Gain'
   *  Sum: '<S16>/Add3'
   */
  rtb_Abs2 = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_f +
                      Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_n) +
                     Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_n) +
                    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_m) +
                   rtb_Ax_Amp_Gain) * Axyz_Estimation_to_VBxyz_P.Gain_Gain_i);

  /* Logic: '<S17>/Logical Operator' incorporates:
   *  Constant: '<S11>/LL'
   *  Constant: '<S11>/UL'
   *  Logic: '<S17>/Logical Operator1'
   *  Logic: '<S17>/Logical Operator2'
   *  Memory: '<S17>/Memory1'
   *  RelationalOperator: '<S11>/GEE1'
   *  RelationalOperator: '<S11>/LE'
   */
  rtb_OUT_c = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_p || (rtb_Abs2
    >= Axyz_Estimation_to_VBxyz_P.LL_Value)) && (!(rtb_Abs2 <=
    Axyz_Estimation_to_VBxyz_P.UL_Value)));

  /* Switch: '<S11>/Sw1' incorporates:
   *  Constant: '<S11>/Zero1'
   */
  if (rtb_OUT_c) {
    rtb_Sw1 = rtb_Ax_Amp_Gain;
  } else {
    rtb_Sw1 = Axyz_Estimation_to_VBxyz_P.Zero1_Value;
  }

  /* End of Switch: '<S11>/Sw1' */

  /* Sum: '<S14>/Sum3' incorporates:
   *  Constant: '<S14>/Constant1'
   *  Constant: '<S14>/P_INTEG1'
   *  Gain: '<S14>/Ax_Gain'
   *  Memory: '<S14>/Memory3'
   *  Memory: '<S14>/Memory4'
   *  Product: '<S14>/ times1'
   *  Product: '<S14>/Ktimes'
   *  Sum: '<S14>/Sum4'
   */
  rtb_Sum3_p = (Axyz_Estimation_to_VBxyz_DW.Memory3_PreviousInput + rtb_Sw1) *
    Axyz_Estimation_to_VBxyz_P.Ax_Gain_Gain *
    (Axyz_Estimation_to_VBxyz_P.P_INTEG1_Value * Axyz_Estimation_to_VBxyz_P.DT)
    + Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput;

  /* Switch: '<S14>/Switch4' incorporates:
   *  Constant: '<S5>/Ax_NH_LL'
   *  Constant: '<S5>/Ax_NH_UL'
   *  RelationalOperator: '<S14>/Relational Operator3'
   *  RelationalOperator: '<S14>/Relational Operator4'
   *  Switch: '<S14>/Switch5'
   */
  if (rtb_Sum3_p > Axyz_Estimation_to_VBxyz_P.Ax_NH_UL_Value) {
    rtb_Sum3_p = Axyz_Estimation_to_VBxyz_P.Ax_NH_UL_Value;
  } else {
    if (rtb_Sum3_p < Axyz_Estimation_to_VBxyz_P.Ax_NH_LL_Value) {
      /* Switch: '<S14>/Switch5' incorporates:
       *  Constant: '<S5>/Ax_NH_LL'
       */
      rtb_Sum3_p = Axyz_Estimation_to_VBxyz_P.Ax_NH_LL_Value;
    }
  }

  /* End of Switch: '<S14>/Switch4' */

  /* Gain: '<S5>/VX_Amp_Tuning1' */
  rtb_VX_Amp_Tuning1 = Axyz_Estimation_to_VBxyz_P.VX_Amp_Tuning1_Gain *
    rtb_Sum3_p;

  /* Abs: '<S12>/Abs' incorporates:
   *  Delay: '<S18>/Delay1'
   *  Delay: '<S18>/Delay2'
   *  Delay: '<S18>/Delay3'
   *  Delay: '<S18>/Delay4'
   *  Gain: '<S18>/Gain'
   *  Sum: '<S18>/Add3'
   */
  rtb_Abs2 = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_i +
                      Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_m) +
                     Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_c) +
                    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_l) +
                   rtb_VX_Amp_Tuning1) * Axyz_Estimation_to_VBxyz_P.Gain_Gain_h);

  /* Logic: '<S19>/Logical Operator' incorporates:
   *  Constant: '<S12>/LL2'
   *  Constant: '<S12>/UL2'
   *  Logic: '<S19>/Logical Operator1'
   *  Logic: '<S19>/Logical Operator2'
   *  Memory: '<S19>/Memory1'
   *  RelationalOperator: '<S12>/GEE1'
   *  RelationalOperator: '<S12>/LE'
   */
  rtb_OUT_k3 = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_b ||
                 (rtb_Abs2 >= Axyz_Estimation_to_VBxyz_P.LL2_Value)) &&
                (!(rtb_Abs2 <= Axyz_Estimation_to_VBxyz_P.UL2_Value)));

  /* Switch: '<S12>/Sw1' incorporates:
   *  Constant: '<S12>/Zero1'
   */
  if (rtb_OUT_k3) {
    rtb_X_Amp_Tuning = rtb_VX_Amp_Tuning1;
  } else {
    rtb_X_Amp_Tuning = Axyz_Estimation_to_VBxyz_P.Zero1_Value_j;
  }

  /* End of Switch: '<S12>/Sw1' */

  /* Gain: '<S5>/X_Amp_Tuning' */
  rtb_X_Amp_Tuning *= Axyz_Estimation_to_VBxyz_P.X_Amp_Tuning_Gain;

  /* Outport: '<Root>/VB_x' */
  Axyz_Estimation_to_VBxyz_Y.VB_x = rtb_X_Amp_Tuning;

  /* Memory: '<S15>/Memory2' */
  rtb_Memory2 = Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_o;

  /* Switch: '<S15>/Switch3' incorporates:
   *  Constant: '<S15>/Constant5'
   *  Constant: '<S15>/X_P_INTEG'
   *  Constant: '<S5>/No_Hold1'
   *  Gain: '<S15>/X_Gain1'
   *  Memory: '<S15>/Memory1'
   *  Product: '<S15>/ '
   *  Product: '<S15>/K ''
   *  Sum: '<S15>/Sum1'
   *  Sum: '<S15>/Sum2'
   */
  if (!(Axyz_Estimation_to_VBxyz_P.No_Hold1_Value >=
        Axyz_Estimation_to_VBxyz_P.Switch3_Threshold)) {
    rtb_Memory2 += (Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput +
                    rtb_X_Amp_Tuning) * Axyz_Estimation_to_VBxyz_P.X_Gain1_Gain *
      (Axyz_Estimation_to_VBxyz_P.X_P_INTEG_Value *
       Axyz_Estimation_to_VBxyz_P.DT);
  }

  /* End of Switch: '<S15>/Switch3' */

  /* Switch: '<S15>/Switch7' incorporates:
   *  Constant: '<S15>/P_INTEG_LL'
   *  Constant: '<S15>/P_INTEG_UL'
   *  RelationalOperator: '<S15>/Relational Operator1'
   *  RelationalOperator: '<S15>/Relational Operator2'
   *  Switch: '<S15>/Switch8'
   */
  if (rtb_Memory2 > Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value) {
    rtb_Memory2 = Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value;
  } else {
    if (rtb_Memory2 < Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value) {
      /* Switch: '<S15>/Switch8' incorporates:
       *  Constant: '<S15>/P_INTEG_LL'
       */
      rtb_Memory2 = Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value;
    }
  }

  /* End of Switch: '<S15>/Switch7' */

  /* Outport: '<Root>/XB' */
  Axyz_Estimation_to_VBxyz_Y.XB = rtb_Memory2;

  /* Product: '<S3>/Product1' incorporates:
   *  Inport: '<Root>/Ay_mps2'
   */
  rtb_Product1_dj = Axyz_Estimation_to_VBxyz_U.Ay_mps2 *
    Axyz_Estimation_to_VBxyz_U.Ay_mps2;

  /* Gain: '<S1>/G_Gain' incorporates:
   *  Gain: '<S1>/D_Ay_Tuning'
   *  Gain: '<S1>/Inv_G_Gain1'
   *  Gain: '<S2>/Theta_Amp_Gain'
   *  Inport: '<Root>/Ax_mps2'
   *  Inport: '<Root>/Ay_mps2'
   *  Product: '<S3>/Divide3'
   *  Sqrt: '<S3>/Sqrt3'
   *  Sum: '<S1>/Add1'
   *  Sum: '<S2>/Add3'
   *  Sum: '<S3>/Add4'
   *  Trigonometry: '<S2>/Sin_the'
   *  Trigonometry: '<S3>/Atan2'
   */
  rtb_G_Gain = (Axyz_Estimation_to_VBxyz_P.Inv_G_Gain1_Gain *
                Axyz_Estimation_to_VBxyz_U.Ay_mps2 - sin(atan
    (Axyz_Estimation_to_VBxyz_U.Ax_mps2 / sqrt(rtb_Product1_dj + rtb_Product2_j))
    + rtb_Sw1_j) * Axyz_Estimation_to_VBxyz_P.Theta_Amp_Gain_Gain) *
    Axyz_Estimation_to_VBxyz_P.D_Ay_Tuning_Gain *
    Axyz_Estimation_to_VBxyz_P.G_Gain_Gain;

  /* Gain: '<S8>/Gain4' incorporates:
   *  Memory: '<S8>/Memory2'
   *  Sum: '<S8>/Sum3'
   */
  rtb_Sw1_j = (rtb_G_Gain + Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_f)
    * Axyz_Estimation_to_VBxyz_P.Gain4_Gain_g;

  /* Sum: '<S8>/Sum6' incorporates:
   *  Constant: '<S8>/Delta_T'
   *  Constant: '<S8>/P_LAG1'
   *  Math: '<S8>/Exp'
   *  Memory: '<S8>/Memory4'
   *  Product: '<S8>/Product1'
   *  Product: '<S8>/Product2'
   *  Sum: '<S8>/Sum5'
   *
   * About '<S8>/Exp':
   *  Operator: exp
   */
  rtb_Yn_a = exp(-Axyz_Estimation_to_VBxyz_P.DT *
                 Axyz_Estimation_to_VBxyz_P.P_LAG1_Value_p) *
    (Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_j - rtb_Sw1_j) +
    rtb_Sw1_j;

  /* Abs: '<S22>/Ay_Abs' incorporates:
   *  Delay: '<S27>/Delay1'
   *  Delay: '<S27>/Delay2'
   *  Delay: '<S27>/Delay3'
   *  Delay: '<S27>/Delay4'
   *  Gain: '<S27>/Gain'
   *  Sum: '<S27>/Add3'
   */
  rtb_Sw1_j = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_e +
                       Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_d) +
                      Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_o) +
                     Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_o) + rtb_Yn_a) *
                   Axyz_Estimation_to_VBxyz_P.Gain_Gain_hz);

  /* Logic: '<S28>/Logical Operator' incorporates:
   *  Constant: '<S22>/Ay_LL'
   *  Constant: '<S22>/Ay_UL'
   *  Logic: '<S28>/Logical Operator1'
   *  Logic: '<S28>/Logical Operator2'
   *  Memory: '<S28>/Memory1'
   *  RelationalOperator: '<S22>/Ay_GE1'
   *  RelationalOperator: '<S22>/Ay_LE'
   */
  rtb_OUT_ha = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_ph ||
                 (rtb_Sw1_j <= Axyz_Estimation_to_VBxyz_P.Ay_LL_Value)) &&
                (!(rtb_Sw1_j >= Axyz_Estimation_to_VBxyz_P.Ay_UL_Value)));

  /* Switch: '<S22>/Ay_Sw1' incorporates:
   *  Constant: '<S22>/Ay_Zero1'
   */
  if (rtb_OUT_ha) {
    rtb_Sw1_j = Axyz_Estimation_to_VBxyz_P.Ay_Zero1_Value;
  } else {
    rtb_Sw1_j = rtb_Yn_a;
  }

  /* End of Switch: '<S22>/Ay_Sw1' */

  /* Gain: '<S6>/Gain9' */
  rtb_Gain9 = Axyz_Estimation_to_VBxyz_P.Gain9_Gain * rtb_Sw1_j;

  /* Abs: '<S23>/Abs' incorporates:
   *  Delay: '<S29>/Delay1'
   *  Delay: '<S29>/Delay2'
   *  Delay: '<S29>/Delay3'
   *  Delay: '<S29>/Delay4'
   *  Gain: '<S29>/Gain'
   *  Sum: '<S29>/Add3'
   */
  rtb_Sw1_j = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_p +
                       Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_mi) +
                      Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_cc) +
                     Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_b) + rtb_Gain9) *
                   Axyz_Estimation_to_VBxyz_P.Gain_Gain_k);

  /* Logic: '<S30>/Logical Operator' incorporates:
   *  Constant: '<S23>/LL'
   *  Constant: '<S23>/UL'
   *  Logic: '<S30>/Logical Operator1'
   *  Logic: '<S30>/Logical Operator2'
   *  Memory: '<S30>/Memory1'
   *  RelationalOperator: '<S23>/GEE1'
   *  RelationalOperator: '<S23>/LE'
   */
  rtb_OUT_o = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_a ||
                (rtb_Sw1_j >= Axyz_Estimation_to_VBxyz_P.LL_Value_e)) &&
               (!(rtb_Sw1_j <= Axyz_Estimation_to_VBxyz_P.UL_Value_i)));

  /* Switch: '<S23>/Sw1' incorporates:
   *  Constant: '<S23>/Zero1'
   */
  if (rtb_OUT_o) {
    rtb_Sw1_j = rtb_Gain9;
  } else {
    rtb_Sw1_j = Axyz_Estimation_to_VBxyz_P.Zero1_Value_m;
  }

  /* End of Switch: '<S23>/Sw1' */

  /* Gain: '<S6>/Ay_Gain' */
  rtb_Sw1_j *= Axyz_Estimation_to_VBxyz_P.Ay_Gain_Gain;

  /* Sum: '<S24>/Sum3' incorporates:
   *  Constant: '<S24>/Constant1'
   *  Constant: '<S24>/P_INTEG1'
   *  Gain: '<S24>/Gain'
   *  Memory: '<S24>/Memory3'
   *  Memory: '<S24>/Memory4'
   *  Product: '<S24>/ times1'
   *  Product: '<S24>/Ktimes'
   *  Sum: '<S24>/Sum4'
   */
  rtb_Sum3_f = (Axyz_Estimation_to_VBxyz_DW.Memory3_PreviousInput_l + rtb_Sw1_j)
    * Axyz_Estimation_to_VBxyz_P.Gain_Gain_h4 *
    (Axyz_Estimation_to_VBxyz_P.P_INTEG1_Value_e * Axyz_Estimation_to_VBxyz_P.DT)
    + Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_g;

  /* Switch: '<S24>/Switch4' incorporates:
   *  Constant: '<S6>/Ay_NH_LL'
   *  Constant: '<S6>/Ay_NH_UL'
   *  RelationalOperator: '<S24>/Relational Operator3'
   *  RelationalOperator: '<S24>/Relational Operator4'
   *  Switch: '<S24>/Switch5'
   */
  if (rtb_Sum3_f > Axyz_Estimation_to_VBxyz_P.Ay_NH_UL_Value) {
    rtb_Sum3_f = Axyz_Estimation_to_VBxyz_P.Ay_NH_UL_Value;
  } else {
    if (rtb_Sum3_f < Axyz_Estimation_to_VBxyz_P.Ay_NH_LL_Value) {
      /* Switch: '<S24>/Switch5' incorporates:
       *  Constant: '<S6>/Ay_NH_LL'
       */
      rtb_Sum3_f = Axyz_Estimation_to_VBxyz_P.Ay_NH_LL_Value;
    }
  }

  /* End of Switch: '<S24>/Switch4' */

  /* Gain: '<S6>/Vy_Gain1' */
  rtb_Vy_Gain1 = Axyz_Estimation_to_VBxyz_P.Vy_Gain1_Gain * rtb_Sum3_f;

  /* Abs: '<S26>/Abs' incorporates:
   *  Delay: '<S31>/Delay1'
   *  Delay: '<S31>/Delay2'
   *  Delay: '<S31>/Delay3'
   *  Delay: '<S31>/Delay4'
   *  Gain: '<S31>/Gain'
   *  Sum: '<S31>/Add3'
   */
  rtb_Abs2 = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_d +
                      Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_nh) +
                     Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_g) +
                    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_a) + rtb_Vy_Gain1)
                  * Axyz_Estimation_to_VBxyz_P.Gain_Gain_kd);

  /* Logic: '<S32>/Logical Operator' incorporates:
   *  Constant: '<S26>/LL'
   *  Constant: '<S26>/UL'
   *  Logic: '<S32>/Logical Operator1'
   *  Logic: '<S32>/Logical Operator2'
   *  Memory: '<S32>/Memory1'
   *  RelationalOperator: '<S26>/GEE1'
   *  RelationalOperator: '<S26>/LE'
   */
  rtb_OUT_m = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_n || (rtb_Abs2
    >= Axyz_Estimation_to_VBxyz_P.LL_Value_eu)) && (!(rtb_Abs2 <=
    Axyz_Estimation_to_VBxyz_P.UL_Value_l)));

  /* Switch: '<S26>/Sw1' incorporates:
   *  Constant: '<S26>/Zero1'
   */
  if (rtb_OUT_m) {
    rtb_Y_Amp_Tuning = rtb_Vy_Gain1;
  } else {
    rtb_Y_Amp_Tuning = Axyz_Estimation_to_VBxyz_P.Zero1_Value_mb;
  }

  /* End of Switch: '<S26>/Sw1' */

  /* Gain: '<S6>/Y_Amp_Tuning' */
  rtb_Y_Amp_Tuning *= Axyz_Estimation_to_VBxyz_P.Y_Amp_Tuning_Gain;

  /* Outport: '<Root>/VB_y' */
  Axyz_Estimation_to_VBxyz_Y.VB_y = rtb_Y_Amp_Tuning;

  /* Memory: '<S25>/Memory2' */
  rtb_Memory2_o = Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_p;

  /* Switch: '<S25>/Switch3' incorporates:
   *  Constant: '<S25>/Constant5'
   *  Constant: '<S25>/P_INTEG'
   *  Constant: '<S6>/Y_No_Hold1'
   *  Gain: '<S25>/Gain1'
   *  Memory: '<S25>/Memory1'
   *  Product: '<S25>/ '
   *  Product: '<S25>/K ''
   *  Sum: '<S25>/Sum1'
   *  Sum: '<S25>/Sum2'
   */
  if (!(Axyz_Estimation_to_VBxyz_P.Y_No_Hold1_Value >=
        Axyz_Estimation_to_VBxyz_P.Switch3_Threshold_f)) {
    rtb_Memory2_o += (Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_d +
                      rtb_Y_Amp_Tuning) * Axyz_Estimation_to_VBxyz_P.Gain1_Gain *
      (Axyz_Estimation_to_VBxyz_P.P_INTEG_Value * Axyz_Estimation_to_VBxyz_P.DT);
  }

  /* End of Switch: '<S25>/Switch3' */

  /* Switch: '<S25>/Switch7' incorporates:
   *  Constant: '<S25>/P_INTEG_LL'
   *  Constant: '<S25>/P_INTEG_UL'
   *  RelationalOperator: '<S25>/Relational Operator1'
   *  RelationalOperator: '<S25>/Relational Operator2'
   *  Switch: '<S25>/Switch8'
   */
  if (rtb_Memory2_o > Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_j) {
    rtb_Memory2_o = Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_j;
  } else {
    if (rtb_Memory2_o < Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_f) {
      /* Switch: '<S25>/Switch8' incorporates:
       *  Constant: '<S25>/P_INTEG_LL'
       */
      rtb_Memory2_o = Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_f;
    }
  }

  /* End of Switch: '<S25>/Switch7' */

  /* Outport: '<Root>/YB' */
  Axyz_Estimation_to_VBxyz_Y.YB = rtb_Memory2_o;

  /* Sum: '<S3>/Add1' */
  rtb_Sqrt1 = (rtb_Sqrt1 + rtb_Product1_dj) + rtb_Product2_j;

  /* Sqrt: '<S3>/Sqrt1' */
  rtb_Sqrt1 = sqrt(rtb_Sqrt1);

  /* Gain: '<S3>/Gain' */
  rtb_Product2_j = Axyz_Estimation_to_VBxyz_P.Gain_Gain_ha * rtb_Sqrt1;

  /* Gain: '<S9>/Gain4' incorporates:
   *  Memory: '<S9>/Memory2'
   *  Sum: '<S9>/Sum3'
   */
  rtb_Product1_dj = (rtb_Product2_j +
                     Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_j) *
    Axyz_Estimation_to_VBxyz_P.Gain4_Gain_m;

  /* Sum: '<S9>/Sum6' incorporates:
   *  Constant: '<S9>/Delta_T'
   *  Constant: '<S9>/P_LAG1'
   *  Math: '<S9>/Exp'
   *  Memory: '<S9>/Memory4'
   *  Product: '<S9>/Product1'
   *  Product: '<S9>/Product2'
   *  Sum: '<S9>/Sum5'
   *
   * About '<S9>/Exp':
   *  Operator: exp
   */
  rtb_Product1_dj += exp(-Axyz_Estimation_to_VBxyz_P.DT *
    Axyz_Estimation_to_VBxyz_P.P_LAG1_Value_j) *
    (Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_l - rtb_Product1_dj);

  /* Gain: '<S7>/Az_Neg_Gain' incorporates:
   *  Gain: '<S3>/Inv_G_Gain1'
   *  Gain: '<S7>/Gain1'
   *  Sum: '<S7>/Add3'
   */
  rtb_Sqrt1 = (Axyz_Estimation_to_VBxyz_P.Inv_G_Gain1_Gain_e * rtb_Sqrt1 *
               Axyz_Estimation_to_VBxyz_P.Gain1_Gain_k + rtb_Product1_dj) *
    Axyz_Estimation_to_VBxyz_P.Az_Neg_Gain_Gain;

  /* Abs: '<S33>/Az_Abs' incorporates:
   *  Delay: '<S37>/Delay1'
   *  Delay: '<S37>/Delay2'
   *  Delay: '<S37>/Delay3'
   *  Delay: '<S37>/Delay4'
   *  Gain: '<S37>/Gain'
   *  Sum: '<S37>/Add3'
   */
  rtb_Abs2 = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_j +
                      Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_k) +
                     Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_a) +
                    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_d) + rtb_Sqrt1) *
                  Axyz_Estimation_to_VBxyz_P.Gain_Gain_e);

  /* Logic: '<S38>/Logical Operator' incorporates:
   *  Constant: '<S33>/Az_LL'
   *  Constant: '<S33>/Az_UL'
   *  Logic: '<S38>/Logical Operator1'
   *  Logic: '<S38>/Logical Operator2'
   *  Memory: '<S38>/Memory1'
   *  RelationalOperator: '<S33>/Az_GE'
   *  RelationalOperator: '<S33>/Az_LE'
   */
  rtb_OUT_jt = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_do ||
                 (rtb_Abs2 < Axyz_Estimation_to_VBxyz_P.Az_LL_Value)) &&
                (!(rtb_Abs2 >= Axyz_Estimation_to_VBxyz_P.Az_UL_Value)));

  /* Switch: '<S33>/Az_Sw1' incorporates:
   *  Constant: '<S33>/Az_Zero'
   */
  if (rtb_OUT_jt) {
    rtb_Az_Amp_Gain = Axyz_Estimation_to_VBxyz_P.Az_Zero_Value;
  } else {
    rtb_Az_Amp_Gain = rtb_Sqrt1;
  }

  /* End of Switch: '<S33>/Az_Sw1' */

  /* Gain: '<S7>/Az_Amp_Gain' */
  rtb_Az_Amp_Gain *= Axyz_Estimation_to_VBxyz_P.Az_Amp_Gain_Gain;

  /* Switch: '<S35>/Switch3' incorporates:
   *  Constant: '<S35>/Constant5'
   *  Constant: '<S35>/P_INTEG'
   *  Constant: '<S7>/Az_No_Hold'
   *  Gain: '<S35>/Gain1'
   *  Memory: '<S35>/Memory1'
   *  Memory: '<S35>/Memory2'
   *  Product: '<S35>/ '
   *  Product: '<S35>/K ''
   *  Sum: '<S35>/Sum1'
   *  Sum: '<S35>/Sum2'
   */
  if (Axyz_Estimation_to_VBxyz_P.Az_No_Hold_Value >=
      Axyz_Estimation_to_VBxyz_P.Switch3_Threshold_j) {
    rtb_Abs2 = Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_ft;
  } else {
    rtb_Abs2 = (Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_o +
                rtb_Az_Amp_Gain) * Axyz_Estimation_to_VBxyz_P.Gain1_Gain_o *
      (Axyz_Estimation_to_VBxyz_P.P_INTEG_Value_g *
       Axyz_Estimation_to_VBxyz_P.DT) +
      Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_ft;
  }

  /* End of Switch: '<S35>/Switch3' */

  /* Switch: '<S35>/Switch7' incorporates:
   *  Constant: '<S35>/P_INTEG_LL'
   *  Constant: '<S35>/P_INTEG_UL'
   *  RelationalOperator: '<S35>/Relational Operator1'
   *  RelationalOperator: '<S35>/Relational Operator2'
   *  Switch: '<S35>/Switch8'
   */
  if (rtb_Abs2 > Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_m) {
    rtb_OUT_d = Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_m;
  } else if (rtb_Abs2 < Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_g) {
    /* Switch: '<S35>/Switch8' incorporates:
     *  Constant: '<S35>/P_INTEG_LL'
     */
    rtb_OUT_d = Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_g;
  } else {
    rtb_OUT_d = rtb_Abs2;
  }

  /* End of Switch: '<S35>/Switch7' */

  /* Gain: '<S7>/Vz_Amp_Tuning1' */
  rtb_Vz_Amp_Tuning1 = Axyz_Estimation_to_VBxyz_P.Vz_Amp_Tuning1_Gain *
    rtb_OUT_d;

  /* Abs: '<S34>/Abs' incorporates:
   *  Delay: '<S39>/Delay1'
   *  Delay: '<S39>/Delay2'
   *  Delay: '<S39>/Delay3'
   *  Delay: '<S39>/Delay4'
   *  Gain: '<S39>/Gain'
   *  Sum: '<S39>/Add3'
   */
  rtb_Abs2 = fabs(((((Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_fc +
                      Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_j) +
                     Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_ae) +
                    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_f) +
                   rtb_Vz_Amp_Tuning1) * Axyz_Estimation_to_VBxyz_P.Gain_Gain_f);

  /* Logic: '<S40>/Logical Operator' incorporates:
   *  Constant: '<S34>/LL'
   *  Constant: '<S34>/UL'
   *  Logic: '<S40>/Logical Operator1'
   *  Logic: '<S40>/Logical Operator2'
   *  Memory: '<S40>/Memory1'
   *  RelationalOperator: '<S34>/GEE1'
   *  RelationalOperator: '<S34>/LE'
   */
  rtb_OUT_j = ((Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_ak ||
                (rtb_Abs2 >= Axyz_Estimation_to_VBxyz_P.UL_Value_b)) &&
               (!(rtb_Abs2 <= Axyz_Estimation_to_VBxyz_P.LL_Value_j)));

  /* Switch: '<S34>/Sw1' incorporates:
   *  Constant: '<S34>/Zero1'
   */
  if (rtb_OUT_j) {
    rtb_Abs2 = rtb_Vz_Amp_Tuning1;
  } else {
    rtb_Abs2 = Axyz_Estimation_to_VBxyz_P.Zero1_Value_l;
  }

  /* End of Switch: '<S34>/Sw1' */

  /* Gain: '<S7>/Z_Amp_Tuning' */
  rtb_Abs2 *= Axyz_Estimation_to_VBxyz_P.Z_Amp_Tuning_Gain;

  /* Outport: '<Root>/VB_z' */
  Axyz_Estimation_to_VBxyz_Y.VB_z = rtb_Abs2;

  /* Sum: '<S36>/Sum1' incorporates:
   *  Constant: '<S36>/Constant5'
   *  Constant: '<S36>/P_INTEG'
   *  Gain: '<S36>/Gain1'
   *  Memory: '<S36>/Memory1'
   *  Memory: '<S36>/Memory2'
   *  Product: '<S36>/ '
   *  Product: '<S36>/K ''
   *  Sum: '<S36>/Sum2'
   */
  rtb_Sum1 = (Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_da + rtb_Abs2) *
    Axyz_Estimation_to_VBxyz_P.Gain1_Gain_km *
    (Axyz_Estimation_to_VBxyz_P.P_INTEG_Value_g5 * Axyz_Estimation_to_VBxyz_P.DT)
    + Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_g;

  /* Switch: '<S36>/Switch7' incorporates:
   *  Constant: '<S36>/P_INTEG_LL'
   *  Constant: '<S36>/P_INTEG_UL'
   *  RelationalOperator: '<S36>/Relational Operator1'
   *  RelationalOperator: '<S36>/Relational Operator2'
   *  Switch: '<S36>/Switch8'
   */
  if (rtb_Sum1 > Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_jt) {
    rtb_Sum1 = Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_jt;
  } else {
    if (rtb_Sum1 < Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_h) {
      /* Switch: '<S36>/Switch8' incorporates:
       *  Constant: '<S36>/P_INTEG_LL'
       */
      rtb_Sum1 = Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_h;
    }
  }

  /* End of Switch: '<S36>/Switch7' */

  /* Outport: '<Root>/ZB' */
  Axyz_Estimation_to_VBxyz_Y.ZB = rtb_Sum1;

  /* Outport: '<Root>/Road_Hole_Hit' incorporates:
   *  Abs: '<S2>/Abs2'
   *  Constant: '<S2>/Hole_Tune_C0'
   *  Inport: '<Root>/Ax_mps2'
   *  Inport: '<Root>/Ay_mps2'
   *  Logic: '<S2>/And2'
   *  RelationalOperator: '<S2>/GE2'
   *  RelationalOperator: '<S2>/GE3'
   */
  Axyz_Estimation_to_VBxyz_Y.Road_Hole_Hit = ((fabs
    (Axyz_Estimation_to_VBxyz_U.Ay_mps2) >=
    Axyz_Estimation_to_VBxyz_P.Hole_Tune_C0_Value) &&
    (Axyz_Estimation_to_VBxyz_U.Ax_mps2 >=
     Axyz_Estimation_to_VBxyz_P.Hole_Tune_C0_Value));

  /* Update for Memory: '<S14>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput = rtb_Sum3_p;

  /* Update for Memory: '<S14>/Memory3' */
  Axyz_Estimation_to_VBxyz_DW.Memory3_PreviousInput = rtb_Sw1;

  /* Update for Memory: '<S21>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_l = rtb_OUT_h;

  /* Update for Delay: '<S20>/Delay4' incorporates:
   *  Delay: '<S20>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE;

  /* Update for Delay: '<S20>/Delay3' incorporates:
   *  Delay: '<S20>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE;

  /* Update for Delay: '<S20>/Delay2' incorporates:
   *  Delay: '<S20>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE;

  /* Update for Delay: '<S20>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE = rtb_Yn;

  /* Update for Memory: '<S10>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_f = rtb_Yn;

  /* Update for Memory: '<S10>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput = rtb_G_Gain1;

  /* Update for Memory: '<S17>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_p = rtb_OUT_c;

  /* Update for Delay: '<S16>/Delay4' incorporates:
   *  Delay: '<S16>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_f =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_n;

  /* Update for Delay: '<S16>/Delay3' incorporates:
   *  Delay: '<S16>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_n =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_n;

  /* Update for Delay: '<S16>/Delay2' incorporates:
   *  Delay: '<S16>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_n =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_m;

  /* Update for Delay: '<S16>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_m = rtb_Ax_Amp_Gain;

  /* Update for Memory: '<S19>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_b = rtb_OUT_k3;

  /* Update for Delay: '<S18>/Delay4' incorporates:
   *  Delay: '<S18>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_i =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_m;

  /* Update for Delay: '<S18>/Delay3' incorporates:
   *  Delay: '<S18>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_m =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_c;

  /* Update for Delay: '<S18>/Delay2' incorporates:
   *  Delay: '<S18>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_c =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_l;

  /* Update for Delay: '<S18>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_l = rtb_VX_Amp_Tuning1;

  /* Update for Memory: '<S15>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_o = rtb_Memory2;

  /* Update for Memory: '<S15>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput = rtb_X_Amp_Tuning;

  /* Update for Memory: '<S24>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_g = rtb_Sum3_f;

  /* Update for Memory: '<S24>/Memory3' */
  Axyz_Estimation_to_VBxyz_DW.Memory3_PreviousInput_l = rtb_Sw1_j;

  /* Update for Memory: '<S28>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_ph = rtb_OUT_ha;

  /* Update for Delay: '<S27>/Delay4' incorporates:
   *  Delay: '<S27>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_e =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_d;

  /* Update for Delay: '<S27>/Delay3' incorporates:
   *  Delay: '<S27>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_d =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_o;

  /* Update for Delay: '<S27>/Delay2' incorporates:
   *  Delay: '<S27>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_o =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_o;

  /* Update for Delay: '<S27>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_o = rtb_Yn_a;

  /* Update for Memory: '<S8>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_j = rtb_Yn_a;

  /* Update for Memory: '<S8>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_f = rtb_G_Gain;

  /* Update for Memory: '<S30>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_a = rtb_OUT_o;

  /* Update for Delay: '<S29>/Delay4' incorporates:
   *  Delay: '<S29>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_p =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_mi;

  /* Update for Delay: '<S29>/Delay3' incorporates:
   *  Delay: '<S29>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_mi =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_cc;

  /* Update for Delay: '<S29>/Delay2' incorporates:
   *  Delay: '<S29>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_cc =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_b;

  /* Update for Delay: '<S29>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_b = rtb_Gain9;

  /* Update for Memory: '<S32>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_n = rtb_OUT_m;

  /* Update for Delay: '<S31>/Delay4' incorporates:
   *  Delay: '<S31>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_d =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_nh;

  /* Update for Delay: '<S31>/Delay3' incorporates:
   *  Delay: '<S31>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_nh =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_g;

  /* Update for Delay: '<S31>/Delay2' incorporates:
   *  Delay: '<S31>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_g =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_a;

  /* Update for Delay: '<S31>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_a = rtb_Vy_Gain1;

  /* Update for Memory: '<S25>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_p = rtb_Memory2_o;

  /* Update for Memory: '<S25>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_d = rtb_Y_Amp_Tuning;

  /* Update for Memory: '<S35>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_ft = rtb_OUT_d;

  /* Update for Memory: '<S35>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_o = rtb_Az_Amp_Gain;

  /* Update for Memory: '<S38>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_do = rtb_OUT_jt;

  /* Update for Delay: '<S37>/Delay4' incorporates:
   *  Delay: '<S37>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_j =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_k;

  /* Update for Delay: '<S37>/Delay3' incorporates:
   *  Delay: '<S37>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_k =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_a;

  /* Update for Delay: '<S37>/Delay2' incorporates:
   *  Delay: '<S37>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_a =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_d;

  /* Update for Delay: '<S37>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_d = rtb_Sqrt1;

  /* Update for Memory: '<S9>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_l = rtb_Product1_dj;

  /* Update for Memory: '<S9>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_j = rtb_Product2_j;

  /* Update for Memory: '<S40>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_ak = rtb_OUT_j;

  /* Update for Delay: '<S39>/Delay4' incorporates:
   *  Delay: '<S39>/Delay3'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_fc =
    Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_j;

  /* Update for Delay: '<S39>/Delay3' incorporates:
   *  Delay: '<S39>/Delay2'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_j =
    Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_ae;

  /* Update for Delay: '<S39>/Delay2' incorporates:
   *  Delay: '<S39>/Delay1'
   */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_ae =
    Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_f;

  /* Update for Delay: '<S39>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_f = rtb_Vz_Amp_Tuning1;

  /* Update for Memory: '<S36>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_g = rtb_Sum1;

  /* Update for Memory: '<S36>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_da = rtb_Abs2;

  /* Matfile logging */
  //rt_UpdateTXYLogVars(Axyz_Estimation_to_VBxyz_M->rtwLogInfo,
  //                    (&Axyz_Estimation_to_VBxyz_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.005s, 0.0s] */
    if ((rtmGetTFinal(Axyz_Estimation_to_VBxyz_M)!=-1) &&
        !((rtmGetTFinal(Axyz_Estimation_to_VBxyz_M)-
           Axyz_Estimation_to_VBxyz_M->Timing.taskTime0) >
          Axyz_Estimation_to_VBxyz_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(Axyz_Estimation_to_VBxyz_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Axyz_Estimation_to_VBxyz_M->Timing.clockTick0)) {
    ++Axyz_Estimation_to_VBxyz_M->Timing.clockTickH0;
  }

  Axyz_Estimation_to_VBxyz_M->Timing.taskTime0 =
    Axyz_Estimation_to_VBxyz_M->Timing.clockTick0 *
    Axyz_Estimation_to_VBxyz_M->Timing.stepSize0 +
    Axyz_Estimation_to_VBxyz_M->Timing.clockTickH0 *
    Axyz_Estimation_to_VBxyz_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void Axyz_Estimation_to_VBxyz_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value = rtMinusInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_f = rtMinusInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_g = rtMinusInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_LL_Value_h = rtMinusInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value = rtInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_j = rtInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_m = rtInf;
  Axyz_Estimation_to_VBxyz_P.P_INTEG_UL_Value_jt = rtInf;

  /* initialize real-time model */
  (void) memset((void *)Axyz_Estimation_to_VBxyz_M, 0,
                sizeof(RT_MODEL_Axyz_Estimation_to_V_T));
  rtmSetTFinal(Axyz_Estimation_to_VBxyz_M, 150.0);
  Axyz_Estimation_to_VBxyz_M->Timing.stepSize0 = 0.005;

  /* Setup for data logging */
  {
 //   static RTWLogInfo rt_DataLoggingInfo;
 //   rt_DataLoggingInfo.loggingInterval = NULL;
 //   Axyz_Estimation_to_VBxyz_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
 //   rtliSetLogXSignalInfo(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, (NULL));
//    rtliSetLogXSignalPtrs(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, (NULL));
 //   rtliSetLogT(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, "tout");
 //   rtliSetLogX(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, "");
 //   rtliSetLogXFinal(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, "");
 //   rtliSetLogVarNameModifier(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, "rt_");
 //   rtliSetLogFormat(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, 4);
///    rtliSetLogMaxRows(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, 1000);
//    rtliSetLogDecimation(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, 1);
//    rtliSetLogY(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, "");
 //   rtliSetLogYSignalInfo(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, (NULL));
 //   rtliSetLogYSignalPtrs(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, (NULL));
  }

  /* states (dwork) */
  (void) memset((void *)&Axyz_Estimation_to_VBxyz_DW, 0,
                sizeof(DW_Axyz_Estimation_to_VBxyz_T));

  /* external inputs */
  (void) memset((void *)&Axyz_Estimation_to_VBxyz_U, 0,
                sizeof(ExtU_Axyz_Estimation_to_VBxyz_T));

  /* external outputs */
  (void) memset((void *)&Axyz_Estimation_to_VBxyz_Y, 0,
                sizeof(ExtY_Axyz_Estimation_to_VBxyz_T));

  /* Matfile logging */
//  rt_StartDataLoggingWithStartTime(Axyz_Estimation_to_VBxyz_M->rtwLogInfo, 0.0,
 //   rtmGetTFinal(Axyz_Estimation_to_VBxyz_M),
 //   Axyz_Estimation_to_VBxyz_M->Timing.stepSize0, (&rtmGetErrorStatus
 //   (Axyz_Estimation_to_VBxyz_M)));

  /* InitializeConditions for Memory: '<S14>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput =
    Axyz_Estimation_to_VBxyz_P.Memory4_X0;

  /* InitializeConditions for Memory: '<S14>/Memory3' */
  Axyz_Estimation_to_VBxyz_DW.Memory3_PreviousInput =
    Axyz_Estimation_to_VBxyz_P.Memory3_X0;

  /* InitializeConditions for Memory: '<S21>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_l =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_k;

  /* InitializeConditions for Delay: '<S20>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition;

  /* InitializeConditions for Delay: '<S20>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition;

  /* InitializeConditions for Delay: '<S20>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition;

  /* InitializeConditions for Delay: '<S20>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition;

  /* InitializeConditions for Memory: '<S10>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_f =
    Axyz_Estimation_to_VBxyz_P.Memory4_X0_c;

  /* InitializeConditions for Memory: '<S10>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0;

  /* InitializeConditions for Memory: '<S17>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_p =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_m;

  /* InitializeConditions for Delay: '<S16>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_f =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_m;

  /* InitializeConditions for Delay: '<S16>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_n =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_b;

  /* InitializeConditions for Delay: '<S16>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_n =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_m;

  /* InitializeConditions for Delay: '<S16>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_m =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_m;

  /* InitializeConditions for Memory: '<S19>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_b =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_me;

  /* InitializeConditions for Delay: '<S18>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_i =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_n;

  /* InitializeConditions for Delay: '<S18>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_m =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_o;

  /* InitializeConditions for Delay: '<S18>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_c =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_j;

  /* InitializeConditions for Delay: '<S18>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_l =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_g;

  /* InitializeConditions for Memory: '<S15>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_o =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0_m;

  /* InitializeConditions for Memory: '<S15>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0;

  /* InitializeConditions for Memory: '<S24>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_g =
    Axyz_Estimation_to_VBxyz_P.Memory4_X0_o;

  /* InitializeConditions for Memory: '<S24>/Memory3' */
  Axyz_Estimation_to_VBxyz_DW.Memory3_PreviousInput_l =
    Axyz_Estimation_to_VBxyz_P.Memory3_X0_a;

  /* InitializeConditions for Memory: '<S28>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_ph =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_g;

  /* InitializeConditions for Delay: '<S27>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_e =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_ml;

  /* InitializeConditions for Delay: '<S27>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_d =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_n;

  /* InitializeConditions for Delay: '<S27>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_o =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_e;

  /* InitializeConditions for Delay: '<S27>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_o =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_mc;

  /* InitializeConditions for Memory: '<S8>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_j =
    Axyz_Estimation_to_VBxyz_P.Memory4_X0_k;

  /* InitializeConditions for Memory: '<S8>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_f =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0_l;

  /* InitializeConditions for Memory: '<S30>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_a =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_ml;

  /* InitializeConditions for Delay: '<S29>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_p =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_k;

  /* InitializeConditions for Delay: '<S29>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_mi =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_no;

  /* InitializeConditions for Delay: '<S29>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_cc =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_k;

  /* InitializeConditions for Delay: '<S29>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_b =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_k;

  /* InitializeConditions for Memory: '<S32>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_n =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_c;

  /* InitializeConditions for Delay: '<S31>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_d =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_b;

  /* InitializeConditions for Delay: '<S31>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_nh =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_ni;

  /* InitializeConditions for Delay: '<S31>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_g =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_l;

  /* InitializeConditions for Delay: '<S31>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_a =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_h;

  /* InitializeConditions for Memory: '<S25>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_p =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0_n;

  /* InitializeConditions for Memory: '<S25>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_d =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_h;

  /* InitializeConditions for Memory: '<S35>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_ft =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0_nb;

  /* InitializeConditions for Memory: '<S35>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_o =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_j;

  /* InitializeConditions for Memory: '<S38>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_do =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_n;

  /* InitializeConditions for Delay: '<S37>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_j =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_e;

  /* InitializeConditions for Delay: '<S37>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_k =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_d;

  /* InitializeConditions for Delay: '<S37>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_a =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_f;

  /* InitializeConditions for Delay: '<S37>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_d =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_gz;

  /* InitializeConditions for Memory: '<S9>/Memory4' */
  Axyz_Estimation_to_VBxyz_DW.Memory4_PreviousInput_l =
    Axyz_Estimation_to_VBxyz_P.Memory4_X0_m;

  /* InitializeConditions for Memory: '<S9>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_j =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0_j;

  /* InitializeConditions for Memory: '<S40>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_ak =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_kd;

  /* InitializeConditions for Delay: '<S39>/Delay4' */
  Axyz_Estimation_to_VBxyz_DW.Delay4_DSTATE_fc =
    Axyz_Estimation_to_VBxyz_P.Delay4_InitialCondition_ec;

  /* InitializeConditions for Delay: '<S39>/Delay3' */
  Axyz_Estimation_to_VBxyz_DW.Delay3_DSTATE_j =
    Axyz_Estimation_to_VBxyz_P.Delay3_InitialCondition_l;

  /* InitializeConditions for Delay: '<S39>/Delay2' */
  Axyz_Estimation_to_VBxyz_DW.Delay2_DSTATE_ae =
    Axyz_Estimation_to_VBxyz_P.Delay2_InitialCondition_f4;

  /* InitializeConditions for Delay: '<S39>/Delay1' */
  Axyz_Estimation_to_VBxyz_DW.Delay1_DSTATE_f =
    Axyz_Estimation_to_VBxyz_P.Delay1_InitialCondition_b;

  /* InitializeConditions for Memory: '<S36>/Memory2' */
  Axyz_Estimation_to_VBxyz_DW.Memory2_PreviousInput_g =
    Axyz_Estimation_to_VBxyz_P.Memory2_X0_mz;

  /* InitializeConditions for Memory: '<S36>/Memory1' */
  Axyz_Estimation_to_VBxyz_DW.Memory1_PreviousInput_da =
    Axyz_Estimation_to_VBxyz_P.Memory1_X0_hi;
}

/* Model terminate function */
void Axyz_Estimation_to_VBxyz_terminate(void)
{
  /* (no terminate code required) */
}
