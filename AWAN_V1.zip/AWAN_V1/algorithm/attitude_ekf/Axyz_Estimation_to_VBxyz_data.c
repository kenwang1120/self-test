/*
 * Axyz_Estimation_to_VBxyz_data.c
 *
 * Code generation for model "Axyz_Estimation_to_VBxyz".
 *
 * Model version              : 1.157
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Sat May 07 14:20:14 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Axyz_Estimation_to_VBxyz.h"
#include "Axyz_Estimation_to_VBxyz_private.h"

/* Block parameters (auto storage) */
P_Axyz_Estimation_to_VBxyz_T Axyz_Estimation_to_VBxyz_P = {
  0.05,                                /* Variable: DT
                                        * Referenced by:
                                        *   '<S8>/Delta_T'
                                        *   '<S9>/Delta_T'
                                        *   '<S10>/Delta_T'
                                        *   '<S14>/Constant1'
                                        *   '<S15>/Constant5'
                                        *   '<S24>/Constant1'
                                        *   '<S25>/Constant5'
                                        *   '<S35>/Constant5'
                                        *   '<S36>/Constant5'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S11>/Zero1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S12>/Zero1'
                                        */
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S13>/Ax_Zero1'
                                        */
  -1.5,                                /* Expression: -1.5
                                        * Referenced by: '<S5>/Ax_NH_LL'
                                        */
  0.0,                                 /* Expression: -inf
                                        * Referenced by: '<S15>/P_INTEG_LL'
                                        */
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S15>/X_P_INTEG'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S15>/X_Gain1'
                                        */
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S22>/Ay_Zero1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S23>/Zero1'
                                        */
  -1.5,                                /* Expression: -1.5
                                        * Referenced by: '<S6>/Ay_NH_LL'
                                        */
  0.0,                                 /* Expression: -inf
                                        * Referenced by: '<S25>/P_INTEG_LL'
                                        */
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S25>/P_INTEG'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S25>/Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S26>/Zero1'
                                        */
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S33>/Az_Zero'
                                        */
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S34>/Zero1'
                                        */
  0.0,                                 /* Expression: -inf
                                        * Referenced by: '<S35>/P_INTEG_LL'
                                        */
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S35>/P_INTEG'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S35>/Gain1'
                                        */
  0.0,                                 /* Expression: -inf
                                        * Referenced by: '<S36>/P_INTEG_LL'
                                        */
  1.5,                                 /* Expression: 1.5
                                        * Referenced by: '<S5>/Ax_NH_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S14>/Memory4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S14>/Memory3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S20>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S20>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S20>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S20>/Delay1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S10>/P_LAG1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Memory4'
                                        */
  0.102,                               /* Expression: 0.1020
                                        * Referenced by: '<S1>/Inv_G_Gain'
                                        */
  0.0174533,                           /* Expression: 0.0174533
                                        * Referenced by: '<S1>/D2R_Gain'
                                        */
  0.0174533,                           /* Expression: 0.0174533
                                        * Referenced by: '<S1>/D2R_Gain1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S2>/Phi_Amp_Gain'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S1>/D_Ax_Tuning'
                                        */
  9.8,                                 /* Expression: 9.8
                                        * Referenced by: '<S1>/G_Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S10>/Memory2'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S10>/Gain4'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S20>/Gain'
                                        */
  0.1,                                 /* Expression: 0.1
                                        * Referenced by: '<S13>/Ax_LL'
                                        */
  0.05,                                /* Expression: 0.05
                                        * Referenced by: '<S13>/Ax_UL'
                                        */
  1.1,                                 /* Expression: 1.1
                                        * Referenced by: '<S5>/Ax_Amp_Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S16>/Delay1'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S16>/Gain'
                                        */
  0.03,                                /* Expression: 0.03
                                        * Referenced by: '<S11>/LL'
                                        */
  0.04,                                /* Expression: 0.04
                                        * Referenced by: '<S11>/UL'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S14>/Ax_Gain'
                                        */
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S14>/P_INTEG1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S5>/VX_Amp_Tuning1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S18>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S18>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S18>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S18>/Delay1'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S18>/Gain'
                                        */
  0.35,                                /* Expression: 0.35
                                        * Referenced by: '<S12>/LL2'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S12>/UL2'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S5>/X_Amp_Tuning'
                                        */
  0.0,                                 /* Expression: inf
                                        * Referenced by: '<S15>/P_INTEG_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S15>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/No_Hold1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S15>/Memory1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S15>/Switch3'
                                        */
  1.5,                                 /* Expression: 1.5
                                        * Referenced by: '<S6>/Ay_NH_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S24>/Memory4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S24>/Memory3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S27>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S27>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S27>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S27>/Delay1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S8>/P_LAG1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Memory4'
                                        */
  0.102,                               /* Expression: 0.1020
                                        * Referenced by: '<S1>/Inv_G_Gain1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S2>/Theta_Amp_Gain'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S1>/D_Ay_Tuning'
                                        */
  9.8,                                 /* Expression: 9.8
                                        * Referenced by: '<S1>/G_Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S8>/Memory2'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S8>/Gain4'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S27>/Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S22>/Ay_LL'
                                        */
  0.6,                                 /* Expression: 0.6
                                        * Referenced by: '<S22>/Ay_UL'
                                        */
  1.1,                                 /* Expression: 1.1
                                        * Referenced by: '<S6>/Gain9'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S29>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S29>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S29>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S29>/Delay1'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S29>/Gain'
                                        */
  0.03,                                /* Expression: 0.03
                                        * Referenced by: '<S23>/LL'
                                        */
  0.05,                                /* Expression: 0.05
                                        * Referenced by: '<S23>/UL'
                                        */
  0.6,                                 /* Expression: 0.6
                                        * Referenced by: '<S6>/Ay_Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S24>/Gain'
                                        */
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S24>/P_INTEG1'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S6>/Vy_Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S31>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S31>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S31>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S31>/Delay1'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S31>/Gain'
                                        */
  0.35,                                /* Expression: 0.35
                                        * Referenced by: '<S26>/LL'
                                        */
  0.4,                                 /* Expression: 0.4
                                        * Referenced by: '<S26>/UL'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S6>/Y_Amp_Tuning'
                                        */
  0.0,                                 /* Expression: inf
                                        * Referenced by: '<S25>/P_INTEG_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S25>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S6>/Y_No_Hold1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S25>/Memory1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S25>/Switch3'
                                        */
  0.0,                                 /* Expression: inf
                                        * Referenced by: '<S35>/P_INTEG_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S35>/Memory2'
                                        */
  0.0,                                 /* Expression: 0.0
                                        * Referenced by: '<S7>/Az_No_Hold'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S35>/Memory1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S37>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S37>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S37>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S37>/Delay1'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S9>/P_LAG1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S9>/Memory4'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S3>/Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S9>/Memory2'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S9>/Gain4'
                                        */
  0.102,                               /* Expression: 0.1020
                                        * Referenced by: '<S3>/Inv_G_Gain1'
                                        */
  9.8,                                 /* Expression: 9.8
                                        * Referenced by: '<S7>/Gain1'
                                        */
  -1.0,                                /* Expression: -1.0
                                        * Referenced by: '<S7>/Az_Neg_Gain'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S37>/Gain'
                                        */
  0.4,                                 /* Expression: 0.4
                                        * Referenced by: '<S33>/Az_LL'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S33>/Az_UL'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S7>/Az_Amp_Gain'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S35>/Switch3'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S7>/Vz_Amp_Tuning1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S39>/Delay4'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S39>/Delay3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S39>/Delay2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S39>/Delay1'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S39>/Gain'
                                        */
  0.25,                                /* Expression: 0.25
                                        * Referenced by: '<S34>/UL'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S34>/LL'
                                        */
  1.0,                                 /* Expression: 1.0
                                        * Referenced by: '<S7>/Z_Amp_Tuning'
                                        */
  0.0,                                 /* Expression: inf
                                        * Referenced by: '<S36>/P_INTEG_UL'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S36>/Memory2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S36>/Memory1'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S36>/Gain1'
                                        */
  2.5,                                 /* Expression: 2.5
                                        * Referenced by: '<S36>/P_INTEG'
                                        */
  1.5,                                 /* Expression: 1.5
                                        * Referenced by: '<S2>/Hole_Tune_C0'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength
                                        * Referenced by: '<S20>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength
                                        * Referenced by: '<S20>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength
                                        * Referenced by: '<S20>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength
                                        * Referenced by: '<S20>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_a
                                        * Referenced by: '<S16>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_k
                                        * Referenced by: '<S16>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_d
                                        * Referenced by: '<S16>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_c
                                        * Referenced by: '<S16>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_m
                                        * Referenced by: '<S18>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_e
                                        * Referenced by: '<S18>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_p
                                        * Referenced by: '<S18>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_n
                                        * Referenced by: '<S18>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_e
                                        * Referenced by: '<S27>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_o
                                        * Referenced by: '<S27>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_a
                                        * Referenced by: '<S27>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_e
                                        * Referenced by: '<S27>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_b
                                        * Referenced by: '<S29>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_m
                                        * Referenced by: '<S29>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_f
                                        * Referenced by: '<S29>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_f
                                        * Referenced by: '<S29>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_g
                                        * Referenced by: '<S31>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_ek
                                        * Referenced by: '<S31>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_p0
                                        * Referenced by: '<S31>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_a
                                        * Referenced by: '<S31>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_l
                                        * Referenced by: '<S37>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_m3
                                        * Referenced by: '<S37>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_pc
                                        * Referenced by: '<S37>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_m
                                        * Referenced by: '<S37>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: Delay4_DelayLength_j
                                        * Referenced by: '<S39>/Delay4'
                                        */
  1U,                                  /* Computed Parameter: Delay3_DelayLength_p
                                        * Referenced by: '<S39>/Delay3'
                                        */
  1U,                                  /* Computed Parameter: Delay2_DelayLength_e
                                        * Referenced by: '<S39>/Delay2'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength_j
                                        * Referenced by: '<S39>/Delay1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_k
                                        * Referenced by: '<S21>/Memory1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_m
                                        * Referenced by: '<S17>/Memory1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_me
                                        * Referenced by: '<S19>/Memory1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_g
                                        * Referenced by: '<S28>/Memory1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_ml
                                        * Referenced by: '<S30>/Memory1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_c
                                        * Referenced by: '<S32>/Memory1'
                                        */
  0,                                   /* Computed Parameter: Memory1_X0_n
                                        * Referenced by: '<S38>/Memory1'
                                        */
  0                                    /* Computed Parameter: Memory1_X0_kd
                                        * Referenced by: '<S40>/Memory1'
                                        */
};
