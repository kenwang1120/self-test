/*
 * Axyz_Estimation_to_VBxyz_types.h
 *
 * Code generation for model "Axyz_Estimation_to_VBxyz".
 *
 * Model version              : 1.157
 * Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
 * C source code generated on : Sat May 07 14:20:14 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Axyz_Estimation_to_VBxyz_types_h_
#define RTW_HEADER_Axyz_Estimation_to_VBxyz_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_Axyz_Estimation_to_VBxyz_T_ P_Axyz_Estimation_to_VBxyz_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Axyz_Estimation_to_VB_T RT_MODEL_Axyz_Estimation_to_V_T;

#endif                                 /* RTW_HEADER_Axyz_Estimation_to_VBxyz_types_h_ */
