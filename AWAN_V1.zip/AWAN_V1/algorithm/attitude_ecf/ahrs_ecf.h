#ifndef __AHRS_ECF_H_XQC_
#define __AHRS_ECF_H_XQC_
#ifndef  REAL
#define REAL float
#endif // ! REAL

#ifdef __cplusplus
/* fahrs_ecf -------------------------------------------------
* fahrs_ecf
* args   : mxi       I   # Magnetic field in NED body frame, in Gauss
*          myi       I   # Magnetic field in NED body frame, in Gauss
*          myi       I   # Magnetic field in NED body frame, in Gauss
*          axi       I   # accel in NED body frame, in m/s^2
*          ayi       I   # accel in NED body frame, in m/s^2
*          ayi       I   # accel in NED body frame, in m/s^2
*          gxi       I   # angle rate in the NED body frame in rad/s
*          gyi       I   # angle rate in the NED body frame in rad/s
*          gyi       I   # angle rate in the NED body frame in rad/s
*		   q0_o      O   # Quaternion (NED)
*		   q1_o      O   # Quaternion (NED)
*		   q2_o      O   # Quaternion (NED)
*		   q3_o      O   # Quaternion (NED)
*		   rate0     O   # Angular velocity about body north axis (x) in rad/s
*		   rate1     O   # Angular velocity about body east axis (y) in rad/s
*		   rate2     O   # Angular velocity about body down axis (z) in rad/s
* return : void
* notes  : 
*-----------------------------------------------------------------------------*/
extern "C" {
#endif
    struct COMPASS
    {
        REAL x;
        REAL y;
        REAL z;
    };
    struct ACCEL
    {
        REAL x;
        REAL y;
        REAL z;
    };
    struct GYRO
    {
        REAL x;
        REAL y;
        REAL z;
    };

    struct RATE
    {
        REAL x;
        REAL y;
        REAL z;
    };
void fahrs_ecf(const struct COMPASS *mag, const struct ACCEL *acc, const struct GYRO *gy,
	           REAL dt, REAL *phi, REAL *theta, REAL *psi,struct RATE * rate);
#ifdef __cplusplus
}
#endif

#endif 