#include <math.h>
#include "ahrs_ecf.h"
//#include "scheduler.h"
#ifndef M_PI
#define M_PI (3.14159265358979323846f)
#endif
static int _ahrs_initlised = 0;
static REAL q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;	
static REAL dq0 = 0.0f, dq1 = 0.0f, dq2 = 0.0f, dq3 = 0.0f;	
static REAL gyro_bias[3] = { 0.0f, 0.0f, 0.0f };
static REAL q0q0, q0q1, q0q2, q0q3;
static REAL q1q1, q1q2, q1q3;
static REAL q2q2, q2q3;
static REAL q3q3;
static REAL _rates[3];
#define INV_SQRT_MAGIC32 0x5f375a86
#define INV_SQRT_MAGIC64 0x5fe6eb50c7aa19f9
extern float Q[4];
static REAL inv_sqrt(REAL number)
{
    return 1.0f/sqrtf(number);
}

static void ahrs_init(REAL ax, REAL ay, REAL az, REAL mx, REAL my, REAL mz)
{
    REAL initialRoll, initialPitch;
    REAL cosRoll, sinRoll, cosPitch, sinPitch;
    REAL magX, magY;
    REAL initialHdg, cosHeading, sinHeading;

    initialRoll = atan2f(-ay, -az);
    initialPitch = atan2f(ax, -az);

    cosRoll = cosf(initialRoll);
    sinRoll = sinf(initialRoll);
    cosPitch = cosf(initialPitch);
    sinPitch = sinf(initialPitch);

    magX = mx * cosPitch + my * sinRoll * sinPitch + mz * cosRoll * sinPitch;

    magY = my * cosRoll - mz * sinRoll;

    initialHdg = atan2f(-magY, magX);

    cosRoll = cosf(initialRoll * 0.5f);
    sinRoll = sinf(initialRoll * 0.5f);

    cosPitch = cosf(initialPitch * 0.5f);
    sinPitch = sinf(initialPitch * 0.5f);

    cosHeading = cosf(initialHdg * 0.5f);
    sinHeading = sinf(initialHdg * 0.5f);

    q0 = cosRoll * cosPitch * cosHeading + sinRoll * sinPitch * sinHeading;
    q1 = sinRoll * cosPitch * cosHeading - cosRoll * sinPitch * sinHeading;
    q2 = cosRoll * sinPitch * cosHeading + sinRoll * cosPitch * sinHeading;
    q3 = cosRoll * cosPitch * sinHeading - sinRoll * sinPitch * cosHeading;

    q0q0 = q0 * q0;
    q0q1 = q0 * q1;
    q0q2 = q0 * q2;
    q0q3 = q0 * q3;
    q1q1 = q1 * q1;
    q1q2 = q1 * q2;
    q1q3 = q1 * q3;
    q2q2 = q2 * q2;
    q2q3 = q2 * q3;
    q3q3 = q3 * q3;
}

static void ahrs_update(REAL gx, REAL gy, REAL gz, REAL ax, REAL ay, REAL az, REAL mx, REAL my, REAL mz, REAL twoKp, REAL twoKi, REAL dt)
{
    REAL recipNorm;
    REAL halfex = 0.0f, halfey = 0.0f, halfez = 0.0f;

    if (_ahrs_initlised == 0) {
        ahrs_init(ax, ay, az, mx, my, mz);
        _ahrs_initlised = 1;
    }

    if (!((mx == 0.0f) && (my == 0.0f) && (mz == 0.0f))) {
        REAL hx, hy, hz, bx, bz;
        REAL halfwx, halfwy, halfwz;

        recipNorm = inv_sqrt(mx * mx + my * my + mz * mz);
        mx *= recipNorm;
        my *= recipNorm;
        mz *= recipNorm;

        hx = 2.0f * (mx * (0.5f - q2q2 - q3q3) + my * (q1q2 - q0q3) + mz * (q1q3 + q0q2));
        hy = 2.0f * (mx * (q1q2 + q0q3) + my * (0.5f - q1q1 - q3q3) + mz * (q2q3 - q0q1));
        hz = 2.0f * mx * (q1q3 - q0q2) + 2.0f * my * (q2q3 + q0q1) + 2.0f * mz * (0.5f - q1q1 - q2q2);
        bx = sqrtf(hx * hx + hy * hy);
        bz = hz;

        halfwx = bx * (0.5f - q2q2 - q3q3) + bz * (q1q3 - q0q2);
        halfwy = bx * (q1q2 - q0q3) + bz * (q0q1 + q2q3);
        halfwz = bx * (q0q2 + q1q3) + bz * (0.5f - q1q1 - q2q2);

        halfex += (my * halfwz - mz * halfwy);
        halfey += (mz * halfwx - mx * halfwz);
        halfez += (mx * halfwy - my * halfwx);
    }

    if (!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f))) {
        REAL halfvx, halfvy, halfvz;

        recipNorm = inv_sqrt(ax * ax + ay * ay + az * az);
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;

        halfvx = q1q3 - q0q2;
        halfvy = q0q1 + q2q3;
        halfvz = q0q0 - 0.5f + q3q3;

        halfex += ay * halfvz - az * halfvy;
        halfey += az * halfvx - ax * halfvz;
        halfez += ax * halfvy - ay * halfvx;
    }

    if (halfex != 0.0f && halfey != 0.0f && halfez != 0.0f) {
        if (twoKi > 0.0f) {
            gyro_bias[0] += twoKi * halfex * dt;
            gyro_bias[1] += twoKi * halfey * dt;
            gyro_bias[2] += twoKi * halfez * dt;

            gx += gyro_bias[0];
            gy += gyro_bias[1];
            gz += gyro_bias[2];
        }
        else {
            gyro_bias[0] = 0.0f;
            gyro_bias[1] = 0.0f;
            gyro_bias[2] = 0.0f;
        }

        gx += twoKp * halfex;
        gy += twoKp * halfey;
        gz += twoKp * halfez;
    }

    _rates[0] = gx;
    _rates[1] = gy;
    _rates[2] = gz;

    dq0 = 0.5f*(-q1 * gx - q2 * gy - q3 * gz);
    dq1 = 0.5f*(q0 * gx + q2 * gz - q3 * gy);
    dq2 = 0.5f*(q0 * gy - q1 * gz + q3 * gx);
    dq3 = 0.5f*(q0 * gz + q1 * gy - q2 * gx);

    q0 += dt*dq0;
    q1 += dt*dq1;
    q2 += dt*dq2;
    q3 += dt*dq3;

    recipNorm = inv_sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);
    q0 *= recipNorm;
    q1 *= recipNorm;
    q2 *= recipNorm;
    q3 *= recipNorm;

    q0q0 = q0 * q0;
    q0q1 = q0 * q1;
    q0q2 = q0 * q2;
    q0q3 = q0 * q3;
    q1q1 = q1 * q1;
    q1q2 = q1 * q2;
    q1q3 = q1 * q3;
    q2q2 = q2 * q2;
    q2q3 = q2 * q3;
    q3q3 = q3 * q3;
}

static void q2euler(REAL q_q0, REAL q_q1, REAL q_q2, REAL q_q3, REAL *phi, REAL *theta, REAL *psi)
{
    REAL a = q_q0;
    REAL b = q_q1;
    REAL c = q_q2;
    REAL d = q_q3;
    REAL aa = a * a;
    REAL ab = a * b;
    REAL ac = a * c;
    REAL ad = a * d;
    REAL bb = b * b;
    REAL bc = b * c;
    REAL bd = b * d;
    REAL cc = c * c;
    REAL cd = c * d;
    REAL dd = d * d;
    REAL dcm00 = aa + bb - cc - dd;
    // REAL dcm01 = 2 * (bc - ad);
    REAL dcm02 = 2 * (ac + bd);
    REAL dcm10 = 2 * (bc + ad);
    // REAL dcm11 = aa - bb + cc - dd;
    REAL dcm12 = 2 * (cd - ab);
    REAL dcm20 = 2 * (bd - ac);
    REAL dcm21 = 2 * (ab + cd);
    REAL dcm22 = aa - bb - cc + dd;

    REAL phi_val = (atan2f(dcm21, dcm22));
    REAL theta_val = (asinf(-dcm20));
    REAL psi_val = (atan2f(dcm10, dcm00));
    REAL pi = (M_PI);

    if ((fabs(theta_val - pi / (2))) < (1.0e-3)) {
        phi_val = (0.0);
        psi_val = (atan2f(dcm12, dcm02));
    }
    else if ((fabs(theta_val + pi / (2))) < (1.0e-3)) {
        phi_val = (0.0);
        psi_val = (atan2f(-dcm12, -dcm02));
    }
    *phi = phi_val;
    *theta = theta_val;
    *psi = psi_val;
}


void fahrs_ecf(const struct COMPASS *mag, const struct ACCEL *acc, const struct GYRO *gy,
    REAL dt, REAL *phi, REAL *theta, REAL *psi,
    struct RATE * rate)
{
    ahrs_update(gy->x, gy->y, gy->z,
        -acc->x, -acc->y, -acc->z, 
        mag->x, mag->y, mag->z, 
        1.0f, 0.05f, dt);


        Q[0]=q0;
        Q[1]=q1;
        Q[2]=q2;
        Q[3]=q3;


    q2euler(q0, q1,q2,q3, phi, theta, psi);
    rate->x = _rates[0];
    rate->y = _rates[1];
    rate->z = _rates[2];
}
