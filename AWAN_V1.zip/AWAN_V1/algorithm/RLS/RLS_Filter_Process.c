/*
 * File: RLS_Filter_Process.c
 *
 * Code generated for Simulink model 'RLS_Fliter_Alg_Function'.
 *
 * Model version                  : 1.87
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Mon May 27 08:58:46 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "RLS_Filter_Process.h"


/* Initial conditions for atomic system: '<Root>/RLS_Filter_Process' */
void RLS_Fli_RLS_Filter_Process_Init(DW_RLS_Filter_Process_RLS_Fli_T *localDW)
{
	localDW->Count = 0U;
	localDW->RLS_Initialize = false;
	for(int index = 0; index < 5; index++)
	{
		localDW->Wx[index] = 0.2f;
		localDW->Wy[index] = 0.2f;
		localDW->Wz[index] = 0.2f;
	}
	// Lyapunov Matrix Parameter
//	localDW->rtu_Lxy[0] = 1600.0f;
//	localDW->rtu_Lxy[1] = 160.0f;
//	localDW->rtu_Lxy[2] = 160.0f;
//	localDW->rtu_Dxy[0] = 100.0f;
//	localDW->rtu_Dxy[1] = 20.0f;
//	localDW->rtu_Dxy[2] = 6.0f;
//
//	localDW->rtu_Lz[0] = 1600.0f;
//	localDW->rtu_Lz[1] = 160.0f;
//	localDW->rtu_Lz[2] = 160.0f;
//	localDW->rtu_Dz[0] = 100.0f;
//	localDW->rtu_Dz[1] = 20.0f;
//	localDW->rtu_Dz[2] = 6.0f;

	/* P_diagonal P is Lyapunov Matrix */
	localDW->Px[0] = 1.0f / localDW->rtu_Dxy[0];
	localDW->Px[1] = 1.0f / localDW->rtu_Dxy[1];
	localDW->Px[2] = 1.0f / localDW->rtu_Dxy[1];
	localDW->Px[3] = 1.0f / localDW->rtu_Dxy[2];
	localDW->Px[4] = 1.0f / localDW->rtu_Dxy[2];

	localDW->Py[0] = 1.0f / localDW->rtu_Dxy[0];
	localDW->Py[1] = 1.0f / localDW->rtu_Dxy[1];
	localDW->Py[2] = 1.0f / localDW->rtu_Dxy[1];
	localDW->Py[3] = 1.0f / localDW->rtu_Dxy[2];
	localDW->Py[4] = 1.0f / localDW->rtu_Dxy[2];

	localDW->Pz[0] = 1.0f / localDW->rtu_Dz[0];
	localDW->Pz[1] = 1.0f / localDW->rtu_Dz[0];
	localDW->Pz[2] = 1.0f / localDW->rtu_Dz[1];
	localDW->Pz[3] = 1.0f / localDW->rtu_Dz[1];
	localDW->Pz[4] = 1.0f / localDW->rtu_Dz[2];
}

/* Output and update for atomic system: '<Root>/RLS_Filter_Process' */
void RLS_Fliter_A_RLS_Filter_Process(real_T rtu_Xin, real_T rtu_Yin, real_T rtu_Zin,
		                             B_RLS_Filter_Process_RLS_Flit_T *localB,
									 DW_RLS_Filter_Process_RLS_Fli_T *localDW )
{
	/*  Initialize the delay unit */
	if (!localDW->RLS_Initialize) {
		for(int index = 0; index < 5; index++)
		{
			localDW->X[index] = rtu_Xin;
			localDW->Y[index] = rtu_Yin;
			localDW->Z[index] = rtu_Zin;
		}
		localDW->RLS_Initialize = true;
	}

	/* Step 1: Calculation the gain G */
	localDW->Kx[0] = (localDW->Px[0]*localDW->X[4]) / (localDW->Px[0]*localDW->X[4]*localDW->X[4] + localDW->rtu_Lxy[0]);
	localDW->Kx[1] = (localDW->Px[1]*localDW->X[3]) / (localDW->Px[1]*localDW->X[3]*localDW->X[3] + localDW->rtu_Lxy[0]);
	localDW->Kx[2] = (localDW->Px[2]*localDW->X[2]) / (localDW->Px[2]*localDW->X[2]*localDW->X[2] + localDW->rtu_Lxy[1]);
	localDW->Kx[3] = (localDW->Px[3]*localDW->X[1]) / (localDW->Px[3]*localDW->X[1]*localDW->X[1] + localDW->rtu_Lxy[1]);
	localDW->Kx[4] = (localDW->Px[4]*localDW->X[0]) / (localDW->Px[4]*localDW->X[0]*localDW->X[0] + localDW->rtu_Lxy[2]);

	localDW->Ky[0] = (localDW->Px[0]*localDW->Y[4]) / (localDW->Px[0]*localDW->Y[4]*localDW->Y[4] + localDW->rtu_Lxy[0]);
	localDW->Ky[1] = (localDW->Px[1]*localDW->Y[3]) / (localDW->Px[1]*localDW->Y[3]*localDW->Y[3] + localDW->rtu_Lxy[0]);
	localDW->Ky[2] = (localDW->Px[2]*localDW->Y[2]) / (localDW->Px[2]*localDW->Y[2]*localDW->Y[2] + localDW->rtu_Lxy[1]);
	localDW->Ky[3] = (localDW->Px[3]*localDW->Y[1]) / (localDW->Px[3]*localDW->Y[1]*localDW->Y[1] + localDW->rtu_Lxy[1]);
	localDW->Ky[4] = (localDW->Px[4]*localDW->Y[0]) / (localDW->Px[4]*localDW->Y[0]*localDW->Y[0] + localDW->rtu_Lxy[2]);

	localDW->Kz[0] = (localDW->Px[0]*localDW->Z[4]) / (localDW->Px[0]*localDW->Z[4]*localDW->Z[4] + localDW->rtu_Lz[0]);
	localDW->Kz[1] = (localDW->Px[1]*localDW->Z[3]) / (localDW->Px[1]*localDW->Z[3]*localDW->Z[3] + localDW->rtu_Lz[0]);
	localDW->Kz[2] = (localDW->Px[2]*localDW->Z[2]) / (localDW->Px[2]*localDW->Z[2]*localDW->Z[2] + localDW->rtu_Lz[1]);
	localDW->Kz[3] = (localDW->Px[3]*localDW->Z[1]) / (localDW->Px[3]*localDW->Z[1]*localDW->Z[1] + localDW->rtu_Lz[1]);
	localDW->Kz[4] = (localDW->Px[4]*localDW->Z[0]) / (localDW->Px[4]*localDW->Z[0]*localDW->Z[0] + localDW->rtu_Lz[2]);

	/* Step 2: Filtering */
	/* output estimate for the rls */
	if(localDW->Count >= 7U)
	{
		localDW->Xout = localDW->Wx[0]*localDW->X[4] +
				        localDW->Wx[1]*localDW->X[3] +
				        localDW->Wx[2]*localDW->X[2] +
						localDW->Wx[3]*localDW->X[1] +
				        localDW->Wx[4]*localDW->X[0];

		localDW->Yout = localDW->Wy[0]*localDW->Y[4] +
						localDW->Wy[1]*localDW->Y[3] +
						localDW->Wy[2]*localDW->Y[2] +
						localDW->Wy[3]*localDW->Y[1] +
						localDW->Wy[4]*localDW->Y[0];

		localDW->Zout = localDW->Wz[0]*localDW->Z[4] +
						localDW->Wz[1]*localDW->Z[3] +
						localDW->Wz[2]*localDW->Z[2] +
						localDW->Wz[3]*localDW->Z[1] +
						localDW->Wz[4]*localDW->Z[0];
	}else{
		localDW->Xout = rtu_Xin;
		localDW->Yout = rtu_Yin;
		localDW->Zout = rtu_Zin;
	}

	localDW->Ex = rtu_Xin - localDW->Xout;
	localDW->Ey = rtu_Yin - localDW->Yout;
	localDW->Ez = rtu_Zin - localDW->Zout;

	/* Step 4: Tap-weight vector adaptation */
	for(int index = 0; index < 5; index++)
	{
		localDW->Wx[index] += localDW->Kx[index] * localDW->Ex;
		localDW->Wy[index] += localDW->Ky[index] * localDW->Ey;
		localDW->Wz[index] += localDW->Kz[index] * localDW->Ez;
	}

	/* Step 5: Correlation Update */
	/* calculating the P of the rls algorithm */
	localDW->Px[0] *= (1.0f - localDW->Kx[0]*localDW->X[4]) / localDW->rtu_Lxy[0];
	localDW->Px[1] *= (1.0f - localDW->Kx[1]*localDW->X[3]) / localDW->rtu_Lxy[0];
	localDW->Px[2] *= (1.0f - localDW->Kx[2]*localDW->X[2]) / localDW->rtu_Lxy[1];
	localDW->Px[3] *= (1.0f - localDW->Kx[3]*localDW->X[1]) / localDW->rtu_Lxy[1];
	localDW->Px[4] *= (1.0f - localDW->Kx[4]*localDW->X[0]) / localDW->rtu_Lxy[2];

	localDW->Py[0] *= (1.0f - localDW->Ky[0]*localDW->Y[4]) / localDW->rtu_Lxy[0];
	localDW->Py[1] *= (1.0f - localDW->Ky[1]*localDW->Y[3]) / localDW->rtu_Lxy[0];
	localDW->Py[2] *= (1.0f - localDW->Ky[2]*localDW->Y[2]) / localDW->rtu_Lxy[1];
	localDW->Py[3] *= (1.0f - localDW->Ky[3]*localDW->Y[1]) / localDW->rtu_Lxy[1];
	localDW->Py[4] *= (1.0f - localDW->Ky[4]*localDW->Y[0]) / localDW->rtu_Lxy[2];

	localDW->Pz[0] *= (1.0f - localDW->Kz[0]*localDW->Z[4]) / localDW->rtu_Lz[0];
	localDW->Pz[1] *= (1.0f - localDW->Kz[1]*localDW->Z[3]) / localDW->rtu_Lz[0];
	localDW->Pz[2] *= (1.0f - localDW->Kz[2]*localDW->Z[2]) / localDW->rtu_Lz[1];
	localDW->Pz[3] *= (1.0f - localDW->Kz[3]*localDW->Z[1]) / localDW->rtu_Lz[1];
	localDW->Pz[4] *= (1.0f - localDW->Kz[4]*localDW->Z[0]) / localDW->rtu_Lz[2];

	/* one delay */
	for(int index = 4; index > 0; index--)
	{
		localDW->X[index] = localDW->X[index - 1];
		localDW->Y[index] = localDW->Y[index - 1];
		localDW->Z[index] = localDW->Z[index - 1];
	}
	localDW->X[0] = rtu_Xin;
	localDW->Y[0] = rtu_Yin;
	localDW->Z[0] = rtu_Zin;

	/* '<S1>:1:334' */
	localDW->Count++;
	localB->Xout = localDW->Xout;
	localB->Yout = localDW->Yout;
	localB->Zout = localDW->Zout;
//	rtu_Out[0] = localDW->Xout;
//	rtu_Out[1] = localDW->Yout;
//	rtu_Out[2] = localDW->Zout;
}


/*
 * File trailer for generated code.
 *
 * [EOF]
 */

//
///* Initial conditions for atomic system: '<Root>/RLS_Filter_Process' */
//void RLS_Fli_RLS_Filter_Process_Init(DW_RLS_Filter_Process_RLS_Fli_T *localDW)
//{
//  localDW->X1_not_empty = false;
//  localDW->X2_not_empty = false;
//  localDW->X3_not_empty = false;
//  localDW->X4_not_empty = false;
//  localDW->X5_not_empty = false;
//  localDW->X6_not_empty = false;
//  localDW->Y1_not_empty = false;
//  localDW->Y2_not_empty = false;
//  localDW->Y3_not_empty = false;
//  localDW->Y4_not_empty = false;
//  localDW->Y5_not_empty = false;
//  localDW->Y6_not_empty = false;
//  localDW->Z1_not_empty = false;
//  localDW->Z2_not_empty = false;
//  localDW->Z3_not_empty = false;
//  localDW->Z4_not_empty = false;
//  localDW->Z5_not_empty = false;
//  localDW->Z6_not_empty = false;
//  localDW->Px11_not_empty = false;
//  localDW->Px22_not_empty = false;
//  localDW->Px33_not_empty = false;
//  localDW->Px44_not_empty = false;
//  localDW->Px55_not_empty = false;
//  localDW->Py11_not_empty = false;
//  localDW->Py22_not_empty = false;
//  localDW->Py33_not_empty = false;
//  localDW->Py44_not_empty = false;
//  localDW->Py55_not_empty = false;
//  localDW->Pz11_not_empty = false;
//  localDW->Pz22_not_empty = false;
//  localDW->Pz33_not_empty = false;
//  localDW->Pz44_not_empty = false;
//  localDW->Pz55_not_empty = false;
//  localDW->Count = 0.0f;
//  localDW->Wx1 = 0.2f;
//  localDW->Wx2 = 0.2f;
//  localDW->Wx3 = 0.2f;
//  localDW->Wx4 = 0.2f;
//  localDW->Wx5 = 0.2f;
//  localDW->Wy1 = 0.2f;
//  localDW->Wy2 = 0.2f;
//  localDW->Wy3 = 0.2f;
//  localDW->Wy4 = 0.2f;
//  localDW->Wy5 = 0.2f;
//  localDW->Wz1 = 0.2f;
//  localDW->Wz2 = 0.2f;
//  localDW->Wz3 = 0.2f;
//  localDW->Wz4 = 0.2f;
//  localDW->Wz5 = 0.2f;
//}
//
//
///* Output and update for atomic system: '<Root>/RLS_Filter_Process' */
//void RLS_Fliter_A_RLS_Filter_Process(real_T rtu_Lxy1, real_T rtu_Lxy2, real_T
//  rtu_Lxy3, real_T rtu_Dxy1, real_T rtu_Dxy2, real_T rtu_Dxy3, real_T rtu_Lz1,
//  real_T rtu_Lz2, real_T rtu_Lz3, real_T rtu_Dz1, real_T rtu_Dz2, real_T rtu_Dz3,
//  real_T rtu_Xin, real_T rtu_Yin, real_T rtu_Zin,
//  B_RLS_Filter_Process_RLS_Flit_T *localB, DW_RLS_Filter_Process_RLS_Fli_T
//  *localDW)
//{
//  real_T Xout;
//  real_T Yout;
//  real_T Zout;
//  real_T Kx1;
//  real_T Kx2;
//  real_T Kx3;
//  real_T Kx4;
//  real_T Kx5;
//  real_T Ky1;
//  real_T Ky2;
//  real_T Ky3;
//  real_T Ky4;
//  real_T Ky5;
//  real_T Kz1;
//  real_T Kz2;
//  real_T Kz3;
//  real_T Kz4;
//  real_T Kz5;
//  real_T Ex;
//  real_T Ey;
//  real_T Ez;
//
//  /* MATLAB Function 'RLS_Filter_Process': '<S1>:1' */
//  /*  Initialize the delay unit */
//  if (!localDW->X1_not_empty) {
//    /* '<S1>:1:34' */
//    /* '<S1>:1:35' */
//    localDW->X1 = rtu_Xin;
//    localDW->X1_not_empty = true;
//  }
//
//  if (!localDW->X2_not_empty) {
//    /* '<S1>:1:38' */
//    /* '<S1>:1:39' */
//    localDW->X2 = rtu_Xin;
//    localDW->X2_not_empty = true;
//  }
//
//  if (!localDW->X3_not_empty) {
//    /* '<S1>:1:42' */
//    /* '<S1>:1:43' */
//    localDW->X3 = rtu_Xin;
//    localDW->X3_not_empty = true;
//  }
//
//  if (!localDW->X4_not_empty) {
//    /* '<S1>:1:46' */
//    /* '<S1>:1:47' */
//    localDW->X4 = rtu_Xin;
//    localDW->X4_not_empty = true;
//  }
//
//  if (!localDW->X5_not_empty) {
//    /* '<S1>:1:50' */
//    /* '<S1>:1:51' */
//    localDW->X5 = rtu_Xin;
//    localDW->X5_not_empty = true;
//  }
//
//  if (!localDW->X6_not_empty) {
//    /* '<S1>:1:54' */
//    /* '<S1>:1:55' */
//    localDW->X6 = rtu_Xin;
//    localDW->X6_not_empty = true;
//  }
//
//  if (!localDW->Y1_not_empty) {
//    /* '<S1>:1:60' */
//    /* '<S1>:1:61' */
//    localDW->Y1 = rtu_Yin;
//    localDW->Y1_not_empty = true;
//  }
//
//  if (!localDW->Y2_not_empty) {
//    /* '<S1>:1:64' */
//    /* '<S1>:1:65' */
//    localDW->Y2 = rtu_Yin;
//    localDW->Y2_not_empty = true;
//  }
//
//  if (!localDW->Y3_not_empty) {
//    /* '<S1>:1:68' */
//    /* '<S1>:1:69' */
//    localDW->Y3 = rtu_Yin;
//    localDW->Y3_not_empty = true;
//  }
//
//  if (!localDW->Y4_not_empty) {
//    /* '<S1>:1:72' */
//    /* '<S1>:1:73' */
//    localDW->Y4 = rtu_Yin;
//    localDW->Y4_not_empty = true;
//  }
//
//  if (!localDW->Y5_not_empty) {
//    /* '<S1>:1:76' */
//    /* '<S1>:1:77' */
//    localDW->Y5 = rtu_Yin;
//    localDW->Y5_not_empty = true;
//  }
//
//  if (!localDW->Y6_not_empty) {
//    /* '<S1>:1:80' */
//    /* '<S1>:1:81' */
//    localDW->Y6 = rtu_Yin;
//    localDW->Y6_not_empty = true;
//  }
//
//  if (!localDW->Z1_not_empty) {
//    /* '<S1>:1:84' */
//    /* '<S1>:1:85' */
//    localDW->Z1 = rtu_Zin;
//    localDW->Z1_not_empty = true;
//  }
//
//  if (!localDW->Z2_not_empty) {
//    /* '<S1>:1:88' */
//    /* '<S1>:1:89' */
//    localDW->Z2 = rtu_Zin;
//    localDW->Z2_not_empty = true;
//  }
//
//  if (!localDW->Z3_not_empty) {
//    /* '<S1>:1:92' */
//    /* '<S1>:1:93' */
//    localDW->Z3 = rtu_Zin;
//    localDW->Z3_not_empty = true;
//  }
//
//  if (!localDW->Z4_not_empty) {
//    /* '<S1>:1:96' */
//    /* '<S1>:1:97' */
//    localDW->Z4 = rtu_Zin;
//    localDW->Z4_not_empty = true;
//  }
//
//  if (!localDW->Z5_not_empty) {
//    /* '<S1>:1:100' */
//    /* '<S1>:1:101' */
//    localDW->Z5 = rtu_Zin;
//    localDW->Z5_not_empty = true;
//  }
//
//  if (!localDW->Z6_not_empty) {
//    /* '<S1>:1:104' */
//    /* '<S1>:1:105' */
//    localDW->Z6 = rtu_Zin;
//    localDW->Z6_not_empty = true;
//  }
//
//  /* X axis tap-weight and input vector */
//  /* P_diagonal P is Lyapunov Matrix */
//  if (!localDW->Px11_not_empty) {
//    /* '<S1>:1:132' */
//    /* '<S1>:1:133' */
//    localDW->Px11 = 1.0f / rtu_Dxy1;
//    localDW->Px11_not_empty = true;
//  }
//
//  if (!localDW->Px22_not_empty) {
//    /* '<S1>:1:136' */
//    /* '<S1>:1:137' */
//    localDW->Px22 = 1.0f / rtu_Dxy2;
//    localDW->Px22_not_empty = true;
//  }
//
//  if (!localDW->Px33_not_empty) {
//    /* '<S1>:1:140' */
//    /* '<S1>:1:141' */
//    localDW->Px33 = 1.0f / rtu_Dxy2;
//    localDW->Px33_not_empty = true;
//  }
//
//  if (!localDW->Px44_not_empty) {
//    /* '<S1>:1:144' */
//    /* '<S1>:1:145' */
//    localDW->Px44 = 1.0f / rtu_Dxy3;
//    localDW->Px44_not_empty = true;
//  }
//
//  if (!localDW->Px55_not_empty) {
//    /* '<S1>:1:148' */
//    /* '<S1>:1:149' */
//    localDW->Px55 = 1.0f / rtu_Dxy3;
//    localDW->Px55_not_empty = true;
//  }
//
//  /* Y axis tap-weight and input vector */
//  /* P_diagonal P is Lyapunov Matrix */
//  if (!localDW->Py11_not_empty) {
//    /* '<S1>:1:176' */
//    /* '<S1>:1:177' */
//    localDW->Py11 = 1.0f / rtu_Dxy1;
//    localDW->Py11_not_empty = true;
//  }
//
//  if (!localDW->Py22_not_empty) {
//    /* '<S1>:1:180' */
//    /* '<S1>:1:181' */
//    localDW->Py22 = 1.0f / rtu_Dxy2;
//    localDW->Py22_not_empty = true;
//  }
//
//  if (!localDW->Py33_not_empty) {
//    /* '<S1>:1:184' */
//    /* '<S1>:1:185' */
//    localDW->Py33 = 1.0f / rtu_Dxy2;
//    localDW->Py33_not_empty = true;
//  }
//
//  if (!localDW->Py44_not_empty) {
//    /* '<S1>:1:188' */
//    /* '<S1>:1:189' */
//    localDW->Py44 = 1.0f / rtu_Dxy3;
//    localDW->Py44_not_empty = true;
//  }
//
//  if (!localDW->Py55_not_empty) {
//    /* '<S1>:1:192' */
//    /* '<S1>:1:193' */
//    localDW->Py55 = 1.0f / rtu_Dxy3;
//    localDW->Py55_not_empty = true;
//  }
//
//  /* Z axis tap-weight and input vector */
//  /* P_diagonal P is Lyapunov Matrix */
//  if (!localDW->Pz11_not_empty) {
//    /* '<S1>:1:220' */
//    /* '<S1>:1:221' */
//    localDW->Pz11 = 1.0f / rtu_Dz1;
//    localDW->Pz11_not_empty = true;
//  }
//
//  if (!localDW->Pz22_not_empty) {
//    /* '<S1>:1:224' */
//    /* '<S1>:1:225' */
//    localDW->Pz22 = 1.0f / rtu_Dz1;
//    localDW->Pz22_not_empty = true;
//  }
//
//  if (!localDW->Pz33_not_empty) {
//    /* '<S1>:1:228' */
//    /* '<S1>:1:229' */
//    localDW->Pz33 = 1.0f / rtu_Dz2;
//    localDW->Pz33_not_empty = true;
//  }
//
//  if (!localDW->Pz44_not_empty) {
//    /* '<S1>:1:232' */
//    /* '<S1>:1:233' */
//    localDW->Pz44 = 1.0f / rtu_Dz2;
//    localDW->Pz44_not_empty = true;
//  }
//
//  if (!localDW->Pz55_not_empty) {
//    /* '<S1>:1:236' */
//    /* '<S1>:1:237' */
//    localDW->Pz55 = 1.0f / rtu_Dz3;
//    localDW->Pz55_not_empty = true;
//  }
//
//  /* Step 1: Calculation the gain G */
//  /* '<S1>:1:241' */
//  Kx1 = 1.0f / rtu_Lxy1 * localDW->Px11 * localDW->X6 / (1.0f / rtu_Lxy1 *
//    localDW->X6 * localDW->Px11 * localDW->X6 + 1.0f);
//
//  /* '<S1>:1:242' */
//  Kx2 = 1.0f / rtu_Lxy1 * localDW->Px22 * localDW->X5 / (1.0f / rtu_Lxy1 *
//    localDW->X5 * localDW->Px22 * localDW->X5 + 1.0f);
//
//  /* '<S1>:1:243' */
//  Kx3 = 1.0f / rtu_Lxy2 * localDW->Px33 * localDW->X4 / (1.0f / rtu_Lxy2 *
//    localDW->X4 * localDW->Px33 * localDW->X4 + 1.0f);
//
//  /* '<S1>:1:244' */
//  Kx4 = 1.0f / rtu_Lxy2 * localDW->Px44 * localDW->X3 / (1.0f / rtu_Lxy2 *
//    localDW->X3 * localDW->Px44 * localDW->X3 + 1.0f);
//
//  /* '<S1>:1:245' */
//  Kx5 = 1.0f / rtu_Lxy3 * localDW->Px55 * localDW->X2 / (1.0f / rtu_Lxy3 *
//    localDW->X2 * localDW->Px55 * localDW->X2 + 1.0f);
//
//  /* '<S1>:1:247' */
//  Ky1 = 1.0f / rtu_Lxy1 * localDW->Py11 * localDW->Y6 / (1.0f / rtu_Lxy1 *
//    localDW->Y6 * localDW->Py11 * localDW->Y6 + 1.0f);
//
//  /* '<S1>:1:248' */
//  Ky2 = 1.0f / rtu_Lxy1 * localDW->Py22 * localDW->Y5 / (1.0f / rtu_Lxy1 *
//    localDW->Y5 * localDW->Py22 * localDW->Y5 + 1.0f);
//
//  /* '<S1>:1:249' */
//  Ky3 = 1.0f / rtu_Lxy2 * localDW->Py33 * localDW->Y4 / (1.0f / rtu_Lxy2 *
//    localDW->Y4 * localDW->Py33 * localDW->Y4 + 1.0f);
//
//  /* '<S1>:1:250' */
//  Ky4 = 1.0f / rtu_Lxy2 * localDW->Py44 * localDW->Y3 / (1.0f / rtu_Lxy2 *
//    localDW->Y3 * localDW->Py44 * localDW->Y3 + 1.0f);
//
//  /* '<S1>:1:251' */
//  Ky5 = 1.0f / rtu_Lxy3 * localDW->Py55 * localDW->Y2 / (1.0f / rtu_Lxy3 *
//    localDW->Y2 * localDW->Py55 * localDW->Y2 + 1.0f);
//
//  /* '<S1>:1:253' */
//  Kz1 = 1.0f / rtu_Lz1 * localDW->Pz11 * localDW->Z6 / (1.0f / rtu_Lz1 *
//    localDW->Z6 * localDW->Pz11 * localDW->Z6 + 1.0f);
//
//  /* '<S1>:1:254' */
//  Kz2 = 1.0f / rtu_Lz1 * localDW->Pz22 * localDW->Z5 / (1.0f / rtu_Lz1 *
//    localDW->Z5 * localDW->Pz22 * localDW->Z5 + 1.0f);
//
//  /* '<S1>:1:255' */
//  Kz3 = 1.0f / rtu_Lz2 * localDW->Pz33 * localDW->Z4 / (1.0f / rtu_Lz2 *
//    localDW->Z4 * localDW->Pz33 * localDW->Z4 + 1.0f);
//
//  /* '<S1>:1:256' */
//  Kz4 = 1.0f / rtu_Lz2 * localDW->Pz44 * localDW->Z3 / (1.0f / rtu_Lz2 *
//    localDW->Z3 * localDW->Pz44 * localDW->Z3 + 1.0f);
//
//  /* '<S1>:1:257' */
//  Kz5 = 1.0f / rtu_Lz3 * localDW->Pz55 * localDW->Z2 / (1.0f / rtu_Lz3 *
//    localDW->Z2 * localDW->Pz55 * localDW->Z2 + 1.0f);
//
//  /* Step 2: Filtering */
//  /* output estimate for the rls */
//  if (localDW->Count >= 7.0f) {
//    /* '<S1>:1:261' */
//    /* '<S1>:1:262' */
//    Xout = (((localDW->Wx1 * localDW->X6 + localDW->Wx2 * localDW->X5) +
//             localDW->Wx3 * localDW->X4) + localDW->Wx4 * localDW->X3) +
//      localDW->Wx5 * localDW->X2;
//
//    /* '<S1>:1:263' */
//    Yout = (((localDW->Wy1 * localDW->Y6 + localDW->Wy2 * localDW->Y5) +
//             localDW->Wy3 * localDW->Y4) + localDW->Wy4 * localDW->Y3) +
//      localDW->Wy5 * localDW->Y2;
//
//    /* '<S1>:1:264' */
//    Zout = (((localDW->Wz1 * localDW->Z6 + localDW->Wz2 * localDW->Z5) +
//             localDW->Wz3 * localDW->Z4) + localDW->Wz4 * localDW->Z3) +
//      localDW->Wz5 * localDW->Z2;
//  } else {
//    /* '<S1>:1:266' */
//    Xout = rtu_Xin;
//
//    /* '<S1>:1:267' */
//    Yout = rtu_Yin;
//
//    /* '<S1>:1:268' */
//    Zout = rtu_Zin;
//  }
//
//  /* '<S1>:1:270' */
//  Ex = rtu_Xin - Xout;
//
//  /* '<S1>:1:271' */
//  Ey = rtu_Yin - Yout;
//
//  /* '<S1>:1:272' */
//  Ez = rtu_Zin - Zout;
//
//  /* Step 4: Tap-weight vector adaptation */
//  /* '<S1>:1:274' */
//  localDW->Wx1 += Kx1 * Ex;
//
//  /* '<S1>:1:275' */
//  localDW->Wx2 += Kx2 * Ex;
//
//  /* '<S1>:1:276' */
//  localDW->Wx3 += Kx3 * Ex;
//
//  /* '<S1>:1:277' */
//  localDW->Wx4 += Kx4 * Ex;
//
//  /* '<S1>:1:278' */
//  localDW->Wx5 += Kx5 * Ex;
//
//  /* '<S1>:1:280' */
//  localDW->Wy1 += Ky1 * Ey;
//
//  /* '<S1>:1:281' */
//  localDW->Wy2 += Ky2 * Ey;
//
//  /* '<S1>:1:282' */
//  localDW->Wy3 += Ky3 * Ey;
//
//  /* '<S1>:1:283' */
//  localDW->Wy4 += Ky4 * Ey;
//
//  /* '<S1>:1:284' */
//  localDW->Wy5 += Ky5 * Ey;
//
//  /* '<S1>:1:286' */
//  localDW->Wz1 += Kz1 * Ez;
//
//  /* '<S1>:1:287' */
//  localDW->Wz2 += Kz2 * Ez;
//
//  /* '<S1>:1:288' */
//  localDW->Wz3 += Kz3 * Ez;
//
//  /* '<S1>:1:289' */
//  localDW->Wz4 += Kz4 * Ez;
//
//  /* '<S1>:1:290' */
//  localDW->Wz5 += Kz5 * Ez;
//
//  /* Step 5: Correlation Update */
//  /* calculating the P of the rls algorithm */
//  /* '<S1>:1:294' */
//  localDW->Px11 = 1.0f / rtu_Lxy1 * localDW->Px11 - 1.0f / rtu_Lxy1 * Kx1 *
//    localDW->X6 * localDW->Px11;
//
//  /* '<S1>:1:295' */
//  localDW->Px22 = 1.0f / rtu_Lxy1 * localDW->Px22 - 1.0f / rtu_Lxy1 * Kx2 *
//    localDW->X5 * localDW->Px22;
//
//  /* '<S1>:1:296' */
//  localDW->Px33 = 1.0f / rtu_Lxy2 * localDW->Px33 - 1.0f / rtu_Lxy2 * Kx3 *
//    localDW->X4 * localDW->Px33;
//
//  /* '<S1>:1:297' */
//  localDW->Px44 = 1.0f / rtu_Lxy2 * localDW->Px44 - 1.0f / rtu_Lxy2 * Kx4 *
//    localDW->X3 * localDW->Px44;
//
//  /* '<S1>:1:298' */
//  localDW->Px55 = 1.0f / rtu_Lxy3 * localDW->Px55 - 1.0f / rtu_Lxy3 * Kx5 *
//    localDW->X2 * localDW->Px55;
//
//  /* '<S1>:1:300' */
//  localDW->Py11 = 1.0f / rtu_Lxy1 * localDW->Py11 - 1.0f / rtu_Lxy1 * Ky1 *
//    localDW->Y6 * localDW->Py11;
//
//  /* '<S1>:1:301' */
//  localDW->Py22 = 1.0f / rtu_Lxy1 * localDW->Py22 - 1.0f / rtu_Lxy1 * Ky2 *
//    localDW->Y5 * localDW->Py22;
//
//  /* '<S1>:1:302' */
//  localDW->Py33 = 1.0f / rtu_Lxy2 * localDW->Py33 - 1.0f / rtu_Lxy2 * Ky3 *
//    localDW->Y4 * localDW->Py33;
//
//  /* '<S1>:1:303' */
//  localDW->Py44 = 1.0f / rtu_Lxy2 * localDW->Py44 - 1.0f / rtu_Lxy2 * Ky4 *
//    localDW->Y3 * localDW->Py44;
//
//  /* '<S1>:1:304' */
//  localDW->Py55 = 1.0f / rtu_Lxy3 * localDW->Py55 - 1.0f / rtu_Lxy3 * Ky5 *
//    localDW->Y2 * localDW->Py55;
//
//  /* '<S1>:1:306' */
//  localDW->Pz11 = 1.0f / rtu_Lz1 * localDW->Pz11 - 1.0f / rtu_Lz1 * Kz1 *
//    localDW->Z6 * localDW->Pz11;
//
//  /* '<S1>:1:307' */
//  localDW->Pz22 = 1.0f / rtu_Lz1 * localDW->Pz22 - 1.0f / rtu_Lz1 * Kz2 *
//    localDW->Z5 * localDW->Pz22;
//
//  /* '<S1>:1:308' */
//  localDW->Pz33 = 1.0f / rtu_Lz2 * localDW->Pz33 - 1.0f / rtu_Lz2 * Kz3 *
//    localDW->Z4 * localDW->Pz33;
//
//  /* '<S1>:1:309' */
//  localDW->Pz44 = 1.0f / rtu_Lz2 * localDW->Pz44 - 1.0f / rtu_Lz2 * Kz4 *
//    localDW->Z3 * localDW->Pz44;
//
//  /* '<S1>:1:310' */
//  localDW->Pz55 = 1.0f / rtu_Lz3 * localDW->Pz55 - 1.0f / rtu_Lz3 * Kz5 *
//    localDW->Z2 * localDW->Pz55;
//
//  /* one delay */
//  /* '<S1>:1:314' */
//  localDW->X6 = localDW->X5;
//
//  /* '<S1>:1:315' */
//  localDW->X5 = localDW->X4;
//
//  /* '<S1>:1:316' */
//  localDW->X4 = localDW->X3;
//
//  /* '<S1>:1:317' */
//  localDW->X3 = localDW->X2;
//
//  /* '<S1>:1:318' */
//  localDW->X2 = localDW->X1;
//
//  /* '<S1>:1:319' */
//  localDW->X1 = rtu_Xin;
//
//  /* '<S1>:1:321' */
//  localDW->Y6 = localDW->Y5;
//
//  /* '<S1>:1:322' */
//  localDW->Y5 = localDW->Y4;
//
//  /* '<S1>:1:323' */
//  localDW->Y4 = localDW->Y3;
//
//  /* '<S1>:1:324' */
//  localDW->Y3 = localDW->Y2;
//
//  /* '<S1>:1:325' */
//  localDW->Y2 = localDW->Y1;
//
//  /* '<S1>:1:326' */
//  localDW->Y1 = rtu_Yin;
//
//  /* '<S1>:1:328' */
//  localDW->Z6 = localDW->Z5;
//
//  /* '<S1>:1:329' */
//  localDW->Z5 = localDW->Z4;
//
//  /* '<S1>:1:330' */
//  localDW->Z4 = localDW->Z3;
//
//  /* '<S1>:1:331' */
//  localDW->Z3 = localDW->Z2;
//
//  /* '<S1>:1:332' */
//  localDW->Z2 = localDW->Z1;
//
//  /* '<S1>:1:333' */
//  localDW->Z1 = rtu_Zin;
//
//  /* '<S1>:1:334' */
//  localDW->Count++;
//  localB->Xout = Xout;
//  localB->Yout = Yout;
//  localB->Zout = Zout;
//}





