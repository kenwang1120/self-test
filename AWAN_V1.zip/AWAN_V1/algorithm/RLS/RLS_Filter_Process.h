/*
 * File: RLS_Filter_Process.h
 *
 * Code generated for Simulink model 'RLS_Fliter_Alg_Function'.
 *
 * Model version                  : 1.87
 * Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
 * C/C++ source code generated on : Mon May 27 08:58:46 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_RLS_Filter_Process_h_
#define RTW_HEADER_RLS_Filter_Process_h_

#include "rtwtypes.h"
                               



/* Block signals for system '<Root>/RLS_Filter_Process' */
typedef struct {
  real_T Xout;                         /* '<Root>/RLS_Filter_Process' */
  real_T Yout;                         /* '<Root>/RLS_Filter_Process' */
  real_T Zout;                         /* '<Root>/RLS_Filter_Process' */
} B_RLS_Filter_Process_RLS_Flit_T;

/* Block states (auto storage) for system '<Root>/RLS_Filter_Process' */
typedef struct {
	uint_T Count;
	boolean_T RLS_Initialize;

	real_T Xout;
	real_T Yout;
	real_T Zout;

	real_T Ex;
	real_T Ey;
	real_T Ez;


	// X-term
	real_T X[5];                           /* '<Root>/RLS_Filter_Process' */
	real_T Wx[5];                          /* '<Root>/RLS_Filter_Process' */
	real_T Kx[5];
	real_T Px[5];                         /* '<Root>/RLS_Filter_Process' */

	// Y-term
	real_T Y[5];                           /* '<Root>/RLS_Filter_Process' */
	real_T Wy[5];                          /* '<Root>/RLS_Filter_Process' */
	real_T Ky[5];
	real_T Py[5];                         /* '<Root>/RLS_Filter_Process' */

	// Z-term
	real_T Z[5];                           /* '<Root>/RLS_Filter_Process' */
	real_T Wz[5];                          /* '<Root>/RLS_Filter_Process' */
	real_T Kz[5];
	real_T Pz[5];                         /* '<Root>/RLS_Filter_Process' */

	// Lyapunov Matrix parameter, x,y-axis / z-axis
	real_T rtu_Lxy[3];
	real_T rtu_Dxy[3];
	real_T rtu_Lz[3];
	real_T rtu_Dz[3];

} DW_RLS_Filter_Process_RLS_Fli_T;

extern void RLS_Fli_RLS_Filter_Process_Init(DW_RLS_Filter_Process_RLS_Fli_T *localDW);
extern void RLS_Fliter_A_RLS_Filter_Process(real_T rtu_Xin, real_T rtu_Yin, real_T rtu_Zin,
		                                    B_RLS_Filter_Process_RLS_Flit_T *localB,
											DW_RLS_Filter_Process_RLS_Fli_T *localDW);


/*
 * File trailer for generated code.
 *
 * [EOF]
 */

//typedef struct {
//  int_T Count;                        /* '<Root>/RLS_Filter_Process' */
//  real_T X1;                           /* '<Root>/RLS_Filter_Process' */
//  real_T X2;                           /* '<Root>/RLS_Filter_Process' */
//  real_T X3;                           /* '<Root>/RLS_Filter_Process' */
//  real_T X4;                           /* '<Root>/RLS_Filter_Process' */
//  real_T X5;                           /* '<Root>/RLS_Filter_Process' */
//  real_T X6;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Y1;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Y2;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Y3;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Y4;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Y5;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Y6;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Z1;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Z2;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Z3;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Z4;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Z5;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Z6;                           /* '<Root>/RLS_Filter_Process' */
//  real_T Wx1;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wx2;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wx3;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wx4;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wx5;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Px11;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Px22;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Px33;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Px44;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Px55;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Wy1;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wy2;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wy3;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wy4;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wy5;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Py11;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Py22;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Py33;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Py44;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Py55;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Wz1;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wz2;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wz3;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wz4;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Wz5;                          /* '<Root>/RLS_Filter_Process' */
//  real_T Pz11;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Pz22;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Pz33;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Pz44;                         /* '<Root>/RLS_Filter_Process' */
//  real_T Pz55;                         /* '<Root>/RLS_Filter_Process' */
//  boolean_T X1_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T X2_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T X3_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T X4_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T X5_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T X6_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Y1_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Y2_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Y3_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Y4_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Y5_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Y6_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Z1_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Z2_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Z3_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Z4_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Z5_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Z6_not_empty;              /* '<Root>/RLS_Filter_Process' */
//  boolean_T Px11_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Px22_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Px33_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Px44_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Px55_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Py11_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Py22_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Py33_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Py44_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Py55_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Pz11_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Pz22_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Pz33_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Pz44_not_empty;            /* '<Root>/RLS_Filter_Process' */
//  boolean_T Pz55_not_empty;            /* '<Root>/RLS_Filter_Process' */
//} DW_RLS_Filter_Process_RLS_Fli_T;
//
//extern void RLS_Fli_RLS_Filter_Process_Init(DW_RLS_Filter_Process_RLS_Fli_T *localDW);
//
//extern void RLS_Fliter_A_RLS_Filter_Process(real_T rtu_Lxy1, real_T rtu_Lxy2,
//  real_T rtu_Lxy3, real_T rtu_Dxy1, real_T rtu_Dxy2, real_T rtu_Dxy3, real_T
//  rtu_Lz1, real_T rtu_Lz2, real_T rtu_Lz3, real_T rtu_Dz1, real_T rtu_Dz2,
//  real_T rtu_Dz3, real_T rtu_Xin, real_T rtu_Yin, real_T rtu_Zin,
//  B_RLS_Filter_Process_RLS_Flit_T *localB, DW_RLS_Filter_Process_RLS_Fli_T
//  *localDW);


#endif                                 /* RTW_HEADER_RLS_Filter_Process_h_ */

