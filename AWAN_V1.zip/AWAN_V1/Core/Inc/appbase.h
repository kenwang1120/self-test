//******************************************************************************
//! @ProjectName: V-3000
//! @ModuleName:  appbase
//!
//! @Purpose: header file
//! 
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//******************************************************************************

#ifndef _APPBASE_H_
#define _APPBASE_H_
#include "stdint.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"


void SystemClock_Config(void);
void Error_Handler(void);
//******************************************************************************
// Included Files
//******************************************************************************
#define SPI1_CS_Pin GPIO_PIN_4
#define SPI1_CS_GPIO_Port GPIOA
#define WDOG_Pin GPIO_PIN_8
#define WDOG_GPIO_Port GPIOC
#define UART1_RTS_Pin GPIO_PIN_12
#define UART1_RTS_GPIO_Port GPIOA


//void Error_Handler(void);

  /////////////////////////////////////////////////////////

#ifdef __cplusplus
}
#endif















//******************************************************************************
// Exported Function Prototypes
//******************************************************************************
void appBaseTimerSupFast(void);
void appBaseTimerFast(void);
void appBaseTimerNormal(void);
int main(void);
  
#endif //_APPBASE_H_
