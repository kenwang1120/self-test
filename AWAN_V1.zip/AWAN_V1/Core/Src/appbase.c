//******************************************************************************
//! @ProjectName: AWAN_V1
//! @ModuleName:  appbase
//!
//! @Purpose:
//! Functions for appbase.
//!
//! AWAN Proprietary
//!
//! @AWAN All rights reserved.
//******************************************************************************
/*==========================
 *  Include Files
 *=========================*/
#include "stm32f4xx_hal.h"

#include "appbase.h"
#include "scheduler.h"

#include "can.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "stm_flash.h"
#include "calibration.h"

#include "iis2mdc.h"
#include "asm330lhh.h"
#include "pct2075.h"
#include "gps1.h"

#include "dataprocess.h"
#include "dataout.h"

#include "facModeInit.h"
#include "ringBuff.h"

#include "attitude_ekf.h"
#include "attitude_estimator_q.h"
#include "AHRS_Angle_PI_Gain_Tuning.h"
#include "EKF_HDG_Gain_Sched_V0.h"
//#define LPI2C_IIS2MDC_ADDRESS 0x1EU//IIS2MDC address
#include "LiLinEncoder.h"

#include "timestamp.h"
//#include "calibration.h"


/*==========================
 *  Declare Variables
 *=========================*/
/*Different sensors should be different here*/
//#define RES_ACCEL ASM330LHH_FS16G_G
//#define RES_GYRO  ASM330LHH_FS500DPS_DPS
#define RES_ACCEL 0.0001f
#define RES_GYRO  0.0001f
//Original resolution is not for mag
//#define RES_MAG   LSM9DS1_FS8GAUSS2MG
#define RES_MAG   0.0001f
//******************************************************************************
// Local Data
//******************************************************************************
static uint8_t param[24][7];
//Mag offset params
static uint8_t paramMag[3][9];
//config param
static uint8_t paramConfig;

static uint32_t paramInt[28];
uint32_t lilinParamInt[32];
float calResult[27];
//ConfigData for configuration from outside
int configData = 0;
//******************************************************************************
// External Data
//******************************************************************************
static uint8_t enterFacMode = 0;
//static uint8_t paramSetFlag = 0;
//static uint8_t paramSetSel = 0;
//config bytes received are over 255, so uint8_t will not be useful
static int msgCounter = 0;
static uint8_t allParamGet = 0;
/* Default value of imuOrAhrs is 0, which choose ahrs output */
/* 1 stands of imu output */
//uint8_t imuOrAhrs = 0;
uint8_t freqOutputRatio = 1;
extern int redundancyState;
float freqFactor=1.0f;
int step = 0;
int data_len = 0;
int c1 = 0; 
int c2 = 0;
//static uint8_t temp[10];
int data_cali[28];

int flag = 1;//���t��
int data_count = 0;//�p��ƾڤj�p
int comma_position = 0;//�p��p���I��m
int resolution = 0;//�p��ѪR��

int data_int;//���
int data_dec;//�p��

int data_type;//�s��block��

volatile int16_t counter = 10;  // 3000
uint8_t data_received;


//uint32_t baud_rate = BAUD_RATE;
//
//uint32_t data_rate = DATA_RATE;
// unsigned char totalDataBuffer[250];
// char startRcvData = 0;

//extern ringBuffer_t uart1_rxbuf;
//extern ringBuffer_t uart3_rxbuf;
//extern ringBuffer_t uart6_rxbuf;



//extern asm330lhh_data_t asm330lhh_rls_data;
//extern asm330lhh_data_t asm330llh_autotrim_data;
//extern iis2mdc_data_t iis2mdc_raw_data;
//extern asm330lhh_data_t asm330lhh_raw_data;
extern volatile uint32_t timestamp[10];   // test

/*==========================
 *  Main Function *=========================*/
//******************************************************************************
//! int main (void)
//!
//! @description  The main function. Performs initialization tasks and enteres 
//!               infinite loop with time triggered execution of scheduller 
//!               (800Hz basic rate).If a schedling frame is overshot,the abort
//!               function is called and soon after the watchdog restarts the unit.
//! @param        None
//! @return       None
//! @req 
//******************************************************************************
//unsigned int ekf_runtime = 0;
//unsigned int ekf_epoch_runtime = 0;
int main(void)
{

	HAL_Init();
	SystemClock_Config();

	bool running = true;
  //int schedule_period = 1000000 / data_rate; // add by rich 2021-12-17
  
  /* Init board hardware. */
//  BOARD_InitPins();                            // Peripheral pinout setting
//  BOARD_BootClockRUN();
//  BOARD_InitDebugConsole();

//  NVIC_SetPriorityGrouping(0);
//  NVIC_SetPriority(LPIT0_Ch0_IRQn, 0);
//  Peripheral_Init();                           // Peripheral initialize, Macial 22.0217

	GPIO_Init();
	LPUART1_Init(921600);
	LPUART3_Init(921600);
	LPUART6_Init(115200);
	LPSPI1_Init();
	LPSPI2_Init();
	LPI2C1_Init();
	LPI2C3_Init();
	CAN2_Init();
//	 Axyz_Estimation_to_VBxyz_initialize();
	//MX_TIM8_Init();
	freqFactor = (5000/SCHEDULER_PERIOD);        // mark by rich 2021-12-17

	if(freqFactor<=1.0f)
	{
		freqFactor=1.0f;
	}
  
//  LPIT0_Init(kCLOCK_IpSrcSircAsync, SCHEDULER_PERIOD);  // mark by rich 2021-12-17
	LPIT0_Init(SCHEDULER_PERIOD);
  
  /*Fctory Mode starts here*/
  /*Wait for the signal to facMode*/
	char arr[100];



	UART_Text_Print(UART3_Print, "Wait for 5 seconds \r\n");



//	uint8_t _flag = 0;
//	uint8_t outcount = 0;
//	while(1)
//	{
//		if(!RingBuf_Read_8bit(&uart1_rxbuf, &data_received))
//		{
//			LPUART1_Send(&data_received, 1);
////			if(outcount++ > 13)
////			{
////				_flag = 1;
////			}
//		}else{
////			if(_flag == 1)
////			{
////				UART_Text_Print(UART1_Print, "\r\n");
////				_flag = 0;
////				outcount = 0;
////			}
//		}
//	}






  while(counter >= 0 && enterFacMode == 0)
  {
	  HAL_Delay(1);
	  printf("counter = %d \r\n", counter);
    counter--;
    if(0 == RingBuf_Read_8bit(&uart3_rxbuf, &data_received))
    {
//      printf("Recved data!!\r\n");
      if(data_received == 'v')
      {
        enterFacMode = 1;
        break;
      }
    }
    /*Make sure feeding dog in while loop*/
    if(counter %1000 == 0) wdiFeedWdog();
    
  }
  
  
  if(enterFacMode == 1)
  {
//    delaysTcnt(500);
    UART_Text_Print(UART3_Print, " Enter Factory Mode \r\n");


    delaysTcnt(100);
    UART_Text_Print(UART3_Print, " Enter Factory Mode \r\n");
    delaysTcnt(1000);
    unsigned char totalDataBuffer[300];
    char startRcvData = 0;
    uint8_t i;
    uint8_t j;
    uint16_t facModeCounter = 0;
    
    while(1) 
    {
      if(facModeCounter%1000 == 0) wdiFeedWdog();
      if(facModeCounter >= 10000) facModeCounter = 0;
      if(0 == RingBuf_Read_8bit(&uart1_rxbuf, &data_received))
      {
        if(startRcvData == 1)
        {
          totalDataBuffer[msgCounter] = data_received;
          msgCounter++;
        }
        
        /*Received Data format: a+xxx.xxxx,-xxx.xxxx,...*/
        /*Total Data Byte: 8*15 + 8 * 9 + 10 * 3 + 1 = 223*/
        if(msgCounter == 223)
        {
          startRcvData = 0;
          msgCounter = 0;
          
          for(j = 0;j < 24; j++)
          {
              //+xxx.xxxx, total bytes are 9
              for(i = 0;i < 7; i++) 
              {
                param[j][i] = totalDataBuffer[i + 8 * j];
              }
          }
          
          for(j = 0;j < 3; j++)
          {
            //+xxx.xxxx, total bytes are 9
            for(i = 0;i < 9; i++)
            {
                paramMag[j][i] = totalDataBuffer[i + 10 * j + 192];
            }
          }
          paramConfig = totalDataBuffer[222];
          
          allParamGet = 1;

        }
        //
        if(data_received == 'a')
        {
          startRcvData = 1;
          msgCounter = 0;
        }
        
        
        
        if(data_received == 's')
        {
          LPUART1_RTS_CTS_CTRL(1);
          delaysTcnt(500);
          readFromFlashNVM(calResult,&configData, RES_ACCEL, RES_GYRO, RES_MAG);

          for(int i = 0;i < 27; i++)
          {
        	  sprintf(arr, "calResult[%d]=%.4f \r\n",i,calResult[i]);
        	  LPUART1_Send((uint8_t *)arr, strlen(arr));
          }

          delaysTcnt(1000);
          LPUART1_RTS_CTS_CTRL(0);
          
        } /* if(data_received == 's') */

      } /* if(0 == RingBuf_Read_8bit(&data_received)) */
      
      /*If get new params, auto write to system*/
      if(allParamGet == 1){
        /*paramInt[0]-paramInt[8]: accel correlated matrix*/
        paramInt[0] = serialChar2Int(param[0], RES_ACCEL);
        paramInt[1] = serialChar2Int(param[1], RES_ACCEL);
        paramInt[2] = serialChar2Int(param[2], RES_ACCEL);
        paramInt[3] = serialChar2Int(param[3], RES_ACCEL);
        paramInt[4] = serialChar2Int(param[4], RES_ACCEL);
        paramInt[5] = serialChar2Int(param[5], RES_ACCEL);
        paramInt[6] = serialChar2Int(param[6], RES_ACCEL);
        paramInt[7] = serialChar2Int(param[7], RES_ACCEL);
        paramInt[8] = serialChar2Int(param[8], RES_ACCEL);
        /*paramInt[9]-paramInt[11]: accel offset*/
        paramInt[9] = serialChar2Int(param[9], RES_ACCEL);
        paramInt[10] = serialChar2Int(param[10], RES_ACCEL);
        paramInt[11] = serialChar2Int(param[11], RES_ACCEL);
        /*paramInt[12]-paramInt[14]: gyro offset*/
        paramInt[12] = serialChar2Int(param[12], RES_GYRO);
        paramInt[13] = serialChar2Int(param[13], RES_GYRO);
        paramInt[14] = serialChar2Int(param[14], RES_GYRO);
        /*paramInt[16]-paramInt[23]: Mag correlated matrix*/
        paramInt[15] = serialChar2Int(param[15], RES_MAG);
        paramInt[16] = serialChar2Int(param[16], RES_MAG);
        paramInt[17] = serialChar2Int(param[17], RES_MAG);
        paramInt[18] = serialChar2Int(param[18], RES_MAG);
        paramInt[19] = serialChar2Int(param[19], RES_MAG);
        paramInt[20] = serialChar2Int(param[20], RES_MAG);
        paramInt[21] = serialChar2Int(param[21], RES_MAG);
        paramInt[22] = serialChar2Int(param[22], RES_MAG);
        paramInt[23] = serialChar2Int(param[23], RES_MAG);
        /*paramInt[24]-paramInt[26]: Mag OFFSET*/
        paramInt[24] = serialChar2IntMag(paramMag[0], RES_MAG);
        paramInt[25] = serialChar2IntMag(paramMag[1], RES_MAG);
        paramInt[26] = serialChar2IntMag(paramMag[2], RES_MAG);
        /*paramInt[27]: Config parameters*/
        paramInt[27] = serialChar2IntConfig(&paramConfig);
        /*Write parameters to NVMFlash*/
        initFlashNVM(paramInt, 28);
        /*Reset Flag when parameters saved*/
        allParamGet = 0;
        LPUART1_RTS_CTS_CTRL(1);
        delaysTcnt(500);
        
        strcpy(arr, " Got all parameters \r\n");
        LPUART1_Send((uint8_t*)arr, strlen(arr));
        
        readFromFlashNVM(calResult,&configData, RES_ACCEL, RES_GYRO, RES_MAG);
        for(int i = 0; i < 27; i++)
        {
          sprintf(arr, "calResult[%d]=%f\r\n",i,calResult[i]);
          LPUART1_Send((uint8_t*)arr, strlen(arr));
        }
//        imuOrAhrs = configData;
//        sprintf(arr, "imuOrAhrs=%d\r\n",imuOrAhrs);
//        LPUART1_Send((uint8_t*)arr, strlen(arr));
        
        delaysTcnt(1000);
        LPUART1_RTS_CTS_CTRL(0);
      }
      facModeCounter ++;
      
    }
    
  }
  LPUART1_RTS_CTS_CTRL(1);
  delaysTcnt(1000);
  /* If no 'c' was input, Enter normal mode*/
  
  strcpy(arr, " Enter Normal mode \r\n");
  LPUART1_Send((uint8_t*)arr, strlen(arr));
  
delaysTcnt(100);
//  LPUART0_Send((uint8_t*)arr, strlen(arr));

  /*Read parameters from NVMFlash*/
  readFromFlashNVM(calResult, &configData, RES_ACCEL, RES_GYRO, RES_MAG);
  for(int i = 0; i < 27; i++)
  {
    sprintf(arr, "calResult[%d]=%f\r\n", i, calResult[i]);
    LPUART3_Send((uint8_t*)arr, strlen(arr));
  }

  readFromFlashNVM_2(lilinParamInt,&configData);
  for(int i = 0; i < 32; i++)
	{
	  sprintf(arr, "lilinParamInt[%d]=%ld\r\n", i, lilinParamInt[i]);
	  LPUART3_Send((uint8_t*)arr, strlen(arr));
//	  lilinParamInt[i] = lilinParamInt[i] +1;
	}
//  printf("configData: %d \r\n",configData);
//  imuOrAhrs = (uint8_t)(configData &0xff);
//  sprintf(arr, "imuOrAhrs=%d\r\n",imuOrAhrs);
//  LPUART1_Send((uint8_t*)arr, strlen(arr));
delaysTcnt(100);
//  LPUART0_Send((uint8_t const*)arr, strlen(arr));
  
  // sensor initialization  
  iis2mdc_initialize();
  asm330lhh_initialize();
  PCT2075_PowerOn();
  
  // algorithm initialization
  RLS_dataProcess_Init();
  dataProcessAutoTrimInit();
  
  // AHRS initialization param
  set_ekf_params();
  set_w_accel(0.12f);
  //set_w_accel(0.12f);   // rich mark 2021-01-05
  set_w_mag(0.2f);
  set_w_gyro_bias(0.1f);
  


  float delta_t;
  AHRS_Angle_PI_Gain_Tuning_initialize();
  AHRS_Angle_PI_Gain_Tuning_step();

  LPIT0_START();
  uint32_t last_frame = getSys2Tick();
//  gps.id = 6;
//  unsigned int last_frame = 0;
//  uint8_t test = 'a';

//  uint8_t print_flag = 0;
//  uint8_t prve_state = 0;
//  int _counter = 0;
//  int ret = 0;


  while(running)
  {
    if(redundancyState == 0)
    {//200Hz
      //Make sure delta_t is not equal to 0 or make sure the running freq is less than seted one
      if(getSys2Tick() == last_frame)
      {
        continue;
      }
    counter++;
    if(counter %1000 == 0) wdiFeedWdog();

      delta_t = (getSys2Tick()-last_frame)*SCHEDULER_PERIOD*freqFactor* 1.0e-6f; // mark by rich

      last_frame = getSys2Tick();
      scheduler(delta_t);
      /* Systick increase as PIT interrupt */
      if (last_frame > getSys2Tick()) // outof time
      {
        //        LPUART1_Send("\n out of time.\n", strlen("\n out of time.\n"));
    	  UART_Text_Print(UART1_Print, " out of time. \r\n");
    	  asm("BKPT #0");
    	  Error_Handler();
        //        static uint8_t canTxData[8] = {0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa};
        //        CAN0_Send(STANDARD_ID, 0xAA, 8, canTxData);
      }
      if(redundancyState == 1)
      {
        last_frame = getSysTick();
      }
    }
    else
    {             
      //delaysTcnt(2000);
      //LPUART1_RTS_CTS_CTRL(0);
      //delaysTcnt(500);
      //Make sure delta_t is not equal to 0 or make sure the running freq is less than seted one
      if(getSysTick() == last_frame)
      {

#if defined PRINTOUT_LILIN_DATA
    	  if(print_flag)
    	  {

//    		  sprintf(arr, "----%d---\r\n", _counter);
    		  sprintf(arr, "Status:%d ,Encoder:%.2f ,Cmd:%d\r\n", lilin_data.status, lilin_data.angle, lilin_data.cmd);
			  LPUART1_Send((uint8_t*)arr, strlen(arr));
			  print_flag = 0;
//			  _counter++;
    	  }
#endif




        continue;
      }
      //LPUART1_RTS_CTS_CTRL(1);
      //delaysTcnt(100);
    counter++;
    if(counter %1000 == 0) wdiFeedWdog();
/*
//    if(0 == RingBuf_Read(&data_received))
//    {
//      if(data_received == 'm')
//      {
//        //strcpy(arr, " Enter Calibration Mode \r\n");
//        //LPUART1_Send((uint8_t const*)arr, strlen(arr));
//      }
//    }
 */
      delta_t = (getSysTick()-last_frame)*SCHEDULER_PERIOD* 1.0e-6f;     // mark by rich 2021-12-17
      
      last_frame = getSysTick();
//      sprintf(arr, "=%d\r\n",last_frame);
//      LPUART1_Send((uint8_t*)arr, sstrlen(arr));

#if defined LILIN_MODULE
//      LiLin_Data_Get(&lilin_data);
      int ret = 0,ret1=0;

		ret = (int)LiLin_Data_Get(&lilin_data);
		ret1 = (int)Vast_Data_Get(&vast_data);
//#if defined USE_EXT_MAG_SENSOR
//	ret = (int)LiLin_MagData_Get(&lilin_data);
//#endif
#if defined PRINTOUT_LILIN_DATA
		if(ret == LiLin_Operate_OK)
		{
			print_flag = 1;
//			prve_state = LiLin_Operate_OK;
//			_counter = 0;
		}
#endif
//      else
//      {
//    	  switch(ret)
//    	  {
//    	  case LiLin_Operate_TimeOut:
//			  sprintf(arr, "LiLin TimeOut!\r\n");
//			  break;
//    	  case LiLin_Operate_DataLess:
//			  sprintf(arr, "LiLin DataLess!\r\n");
//			  break;
//    	  case LiLin_Operate_Empty:
//			  sprintf(arr, "LiLin Buffer Empty!\r\n");
//			  break;
//    	  case LiLin_Operate_DecodeError:
//			  sprintf(arr, "LiLin DecodeError!\r\n");
//			  break;
//    	  }
//
//    	  if(prve_state != ret)
//    	  {
//    		  LPUART1_Send((uint8_t*)arr, strlen(arr));
//    		  prve_state = ret;
//    	  }
//      }

#endif

      scheduler(delta_t);

      //  Axyz_Estimation_to_VBxyz_step();
     // read_gps(delta_t);
//      sprintf(arr, "%d,%d\r\n",getSysTick(),getSys2Tick());
//      LPUART1_Send((uint8_t*)arr, strlen(arr));



      //wdiFeedWdog();
      //Systick increase as PIT interrupt
      if (last_frame  > getSys2Tick()) // outof time
      {
        //        LPUART1_Send("\n out of time.\n", strlen("\n out of time.\n"));
    	  UART_Text_Print(UART1_Print, " out of time. \r\n");
    	  asm("BKPT #0");
    	  Error_Handler();
        //        static uint8_t canTxData[8] = {0x55,0xaa,0x55,0xaa,0x55,0xaa,0x55,0xaa};
        //        CAN0_Send(STANDARD_ID, 0xAA, 8, canTxData);
      }

//timestamp[9] = get_timestamp();
//uint8_t _test = 0;

    }
  }
}














/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	char *error_msg = "Error handle! \r\n";
	LPUART1_Send((uint8_t*)error_msg, 16);
    __DSB();
  __disable_irq();
  while (1)
  {

  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */


