//*******************************************************************************
//! @Projectname:   V-3000
//! @ModuleName:    iis2mdc_board.h
//!
//! @Purpose:
//! This file contains all the functions prototypes for the iis2mdc-driver using
//! in certain platform.
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//*******************************************************************************

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef IIS2MDC_H
#define IIS2MDC_H
#include "iis2mdc_reg.h"
#include "Sensor_Interface.h"

#ifdef __cplusplus
  extern "C" {
#endif


typedef struct {
  float magnetic_mG[3];        // magnetic field data [mgauss]
  float temperature_degC;      // remperature [degC]
  uint8_t mag_valid;               // magnetic field status: 1-valid 0-not valid
} iis2mdc_data_t;

void platform_init_iis(void);
int iis2mdc_initialize();
int read_iis_data(iis2mdc_data_t * data);


#ifdef __cplusplus
}
#endif

#endif /* IIS2MDC_BOARD_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
