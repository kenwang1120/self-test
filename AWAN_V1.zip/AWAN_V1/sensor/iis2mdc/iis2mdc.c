//*******************************************************************************
//! @Projectname:   V-3000
//! @ModuleName:    iis2mdc_simple.c
//!
//! @Purpose:  This file contains all the functions prototypes for the iis2mdc-driver using
//!            in certain platform.
//! VAST Proprietary
//! @VAST All rights reserved.
//*******************************************************************************
/*==========================
 *  Include Files
 *=========================*/
#include "iis2mdc.h"
#include "string.h"
#include "i2c.h"
#include "gpio.h"


/*==========================
 *  Declare Variables
 *=========================*/
#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET   1

#define LPI2C_IIS2MDC_ADDRESS   0x1E//IIS2MDC address


static iis2mdc_ctx_t dev_ctx;
static int32_t platform_write(void *handle, uint8_t reg, uint8_t *bufp, uint16_t len);
static int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp, uint16_t len);

//*******************************************************************************
//! @fn   int32_t platform_write_iis(void *handle, uint8_t reg, uint8_t *bufp, 
//!                              uint16_t len)
//!
//! @description
//! Write generic device register (platform dependent).
//!
//! @param  handle    customizable argument. In this examples is used in
//!                   order to select the correct sensor I2C address.
//! @param  reg       register to write
//! @param  bufp      pointer to data to write in register reg
//! @param  len       number of consecutive register to write
//! @return resvered
//*******************************************************************************
static int32_t platform_write(void *handle, uint8_t reg, uint8_t *bufp,
                              uint16_t len)
{
  //i2c
	uint8_t _dev = (uint8_t)((LPI2C_IIS2MDC_ADDRESS << 1) & 0xFEU);
	LPI2C1_Write(_dev, reg, bufp, 1);

  //spi
//  reg = reg & 0x7F;// Indicate write into device
//  GPIO_PinWrite(GPIOE, 0, GPIO_PIN_RESET);
//  LPSPI0_Write(&reg, 1);
//  LPSPI0_Write(bufp, len);  
//  GPIO_PinWrite(GPIOE, 0, GPIO_PIN_SET);
  
	return 0;
}

//*******************************************************************************
//! @fn   int32_t platform_read_iis(void *handle, uint8_t reg, uint8_t *bufp, 
//!                              uint16_t len)
//!
//! @description
//! Read generic device register (platform dependent)
//!
//! @param  handle    customizable argument. In this examples is used in
//!                   order to select the correct sensor I2C address.
//! @param  reg       register to read
//! @param  bufp      pointer to data to stroe the data read
//! @param  len       number of consecutive register to read
//! @return resvered
//*******************************************************************************
static int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp,
                             uint16_t len)
{
  //I2C
	uint8_t _dev = (uint8_t)((LPI2C_IIS2MDC_ADDRESS << 1) | 0x01U);
	LPI2C1_Read(_dev, reg, bufp, len);
  
  //spi
//  reg |= 0x80;// Indicate read from register
//  GPIO_PinWrite(GPIOE, 0, GPIO_PIN_RESET);              
//  LPSPI0_Write(&reg, 1);
//  LPSPI0_Read(bufp, len);  
//  GPIO_PinWrite(GPIOE, 0, GPIO_PIN_SET);
  
  return 0;
}

//*******************************************************************************
//! @fn   int iis2mdc_initialize(void)
//!
//! @description
//! platform specific initialization (platform dependent)
//!
//! @return 0-success
//!
//! @req {iis2mdc_initialize condition list below as req}
//*******************************************************************************
int iis2mdc_initialize()
{
	uint8_t whoamI;
	uint8_t rst;
//	int retry_times = 3;

    // Initialize mems driver interface
  dev_ctx.write_reg = platform_write;
  dev_ctx.read_reg = platform_read; 
  
  iis2mdc_int_crtl_reg_t iis2mdc_int_crtl;
  iis2mdc_int_crtl.iea =0;

  // Check device ID

//	while(retry_times--)
//	{
//		/* Check device ID */
//		iis2mdc_device_id_get(&dev_ctx, &whoamI);
//
//		if (whoamI == IIS2MDC_ID)
//		{
//			break;
//		}
//
//		if((whoamI != IIS2MDC_ID) && (retry_times == 0))
//		{
//			return 1;
//		}
//
//		HAL_Delay(5);
//	}
  iis2mdc_device_id_get(&dev_ctx, &whoamI);
  //printf("ISS2MDC_ID:%0x\r\n",whoamI);

  if ( whoamI != IIS2MDC_ID )
  {
    return 1; /*manage here device not found */
  }
  
  // Restore default configuration

  iis2mdc_reset_set(&dev_ctx, PROPERTY_ENABLE);
  do {
    iis2mdc_reset_get(&dev_ctx, &rst);
  } while (rst);
  

  // Enable Block Data Update
  iis2mdc_block_data_update_set(&dev_ctx, PROPERTY_ENABLE);
  
  // Set Output Data Rate
  //iis2mdc_data_rate_set(&dev_ctx, IIS2MDC_ODR_10Hz);
  iis2mdc_data_rate_set(&dev_ctx, IIS2MDC_ODR_100Hz);
  
  // Set / Reset sensor mode
  iis2mdc_set_rst_mode_set(&dev_ctx, IIS2MDC_SENS_OFF_CANC_EVERY_ODR);
  
  // Enable temperature compensation
  iis2mdc_offset_temp_comp_set(&dev_ctx, PROPERTY_ENABLE);
  
  // Set device in continuos mode
  iis2mdc_operating_mode_set(&dev_ctx, IIS2MDC_CONTINUOUS_MODE);
  
  //Set Data-ready signal on INT_DRDY pin
  iis2mdc_drdy_on_pin_set(&dev_ctx, 1);
  //set Interrupt signal on INT_DRDY pin
  iis2mdc_int_on_pin_set(&dev_ctx, 0);
 
  iis2mdc_int_gen_conf_set(&dev_ctx, &iis2mdc_int_crtl);
  
  return 0;
}
//*******************************************************************************
//! @fn   void platform_init_iis(void)
//!
//! @description
//! platform specific initialization (platform dependent)
//!
//! @return None
//*******************************************************************************
void platform_init_iis(void)
{
  
}

//*******************************************************************************
//! @fn   int read_iis_data(iis2mdc_data_t * data)
//!
//! @description
//! Read data
//!
//! @param  data  pointer to data to stroe the data read
//!
//! @return 1-valid 0-not valid
//*******************************************************************************
axis3bit16_u data_raw_magnetic;
axis1bit16_u data_raw_temperature;
// Read output only if new value is available
iis2mdc_reg_u reg;
int read_iis_data(iis2mdc_data_t * data)
{
    reg.status_reg.zyxda = 0;
    iis2mdc_status_get(&dev_ctx, &reg.status_reg);

    data->mag_valid = 0;
    if (reg.status_reg.zyxda)
    {
      //index2++;
      /* Read magnetic field data */
      // memset(data_raw_magnetic.u8bit, 0x00, 3*sizeof(int16_t));
      iis2mdc_magnetic_raw_get(&dev_ctx, data_raw_magnetic.u8bit);
      /*========================================
       * Corresponding to the axial direction
       *----------------------------------------
       * IMU +X  --> MAG -Y
       * IMU +Y  --> MAG +X
       * IMU +Z  --> MAG -Z
       * */
      
      data->magnetic_mG[0] = IIS2MDC_FROM_LSB_TO_mG( data_raw_magnetic.i16bit[1])*(-1.0f);
      data->magnetic_mG[1] = IIS2MDC_FROM_LSB_TO_mG( data_raw_magnetic.i16bit[0]);
      data->magnetic_mG[2] = IIS2MDC_FROM_LSB_TO_mG( data_raw_magnetic.i16bit[2])*(-1.0f);
      
      /* Read temperature data */
      // memset(data_raw_temperature.u8bit, 0x00, sizeof(int16_t));
      iis2mdc_temperature_raw_get(&dev_ctx, data_raw_temperature.u8bit);
      data->temperature_degC = IIS2MDC_FROM_LSB_TO_degC( data_raw_temperature.i16bit );
      
      data->mag_valid = 1;
      return 1;
    }
    else
    {
      return 0;
    }
}
