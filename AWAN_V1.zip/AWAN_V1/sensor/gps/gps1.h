#ifndef __GPS_H
#define __GPS_H
#include "stdbool.h"
#include <stdint.h>
#include <math.h>
#include "attitude_estimator_q.h"
#include "lon_lat.h"

/*struct gps_msg {
	uint64_t time_usec;
	uint64_t time_sec;
	uint64_t time_min;
	uint64_t time_hour;
	int32_t lat;		///< Latitude in 1E-7 degrees
	int32_t lon;		///< Longitude in 1E-7 degrees
	int32_t alt;		///< Altitude in 1E-3 meters (millimeters) above MSL
	float yaw;		///< yaw angle. NaN if not set (used for dual antenna GPS), (rad, [-PI, PI])
	float yaw_offset;	///< Heading/Yaw offset for dual antenna GPS - refer to description for GPS_YAW_OFFSET
	uint8_t fix_type;	///< 0-1: no fix, 2: 2D fix, 3: 3D fix, 4: RTCM code differential, 5: Real-Time Kinematic
	float eph1;		///< GPS horizontal position accuracy in m
	float epv1;		///< GPS vertical position accuracy in m
	float sacc;		///< GPS speed accuracy in m/s
	float vel_m_s;		///< GPS ground speed (m/sec)
	float vel_ned[3];	///< GPS ground speed NED
	bool vel_ned_valid;	///< GPS ground speed is valid
	uint8_t nsats;		///< number of satellites used
	float pdop1;		///< geometric dilution of precision
};*/
extern struct GPS gps;
extern struct lon_lat gps_lon_lat;;
int hexchar2int(char c);
int hex2int(char* c);
int checksum_valid(char* string);
void parse_comma_delimited_str(char* string, char** fields, int max_fields);
int str2int(char* str);
float str2float(char* str);
uint64_t hhmmss_usec(char* str);
uint64_t get_sec(char* str);
uint64_t get_min(char* str);
uint64_t get_hour(char* str);
float ddmm_mmmm_to_dd_dddd(char* str);
int process_gga(char *buffer , struct GPS *gps);
int process_gsa(char* buffer, struct GPS* gps);
int process_gsv(char* buffer, struct GPS* gps);
int process_rmc(char* buffer, struct GPS* gps);
int process_gll(char* buffer, struct GPS* gps);
int process_vtg(char* buffer, struct GPS* gps);
int process_txt(char* buffer, struct GPS* gps);
int gps_process(char *str);
int read_gps( );
#endif

