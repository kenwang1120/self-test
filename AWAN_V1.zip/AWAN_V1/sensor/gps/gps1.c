#include "stdint.h"

//#include "led.h"
//#include "delay.h"
//#include "usart3.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include "math.h"

//#include "common.h"
//#include "attitude_ekf.h"
#include "gps1.h"

#include "ringBuff.h"
#include "usart.h"
#include "timestamp.h"
#include "lon_lat.h"
#include "scheduler.h"

char gps_buffer[100];
double acc_variance;
#define acc_count 100

struct GPS gps;
double yaw_acc;
double yaw_angle;
float deltat;
struct lon_lat gps_lon_lat;
int gps_idx = 0;
int acc_n_times=acc_count;
int acc_e_times=acc_count;
uint16_t cntGPSDelay=0;
uint8_t antFlag = 1;//0 = open
float preGpsVel=0;
float preGpsHeading=0;
//struct gps_msg gps;
char _arr1[100];
char _arr2[100];


int hexchar2int(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;
	if (c >= 'a' && c <= 'f')
		return c - 'a' + 10;
	return -1;
}

int hex2int(char* c)
{
	int value;

	value = hexchar2int(c[0]);
	value = value << 4;
	value += hexchar2int(c[1]);

	return value;
}


int checksum_valid(char* string)
{
	char* checksum_str;
	int checksum;
	unsigned char calculated_checksum = 0;

	// Checksum is postcede by *
	checksum_str = strchr(string, '*');
	if (checksum_str != NULL) {
		// Remove checksum from string
		*checksum_str = '\0';
		// Calculate checksum, starting after $ (i = 1)
		for (int i = 1; i < strlen(string); i++) {
			calculated_checksum = calculated_checksum ^ string[i];
		}
		checksum = hex2int((char*)checksum_str + 1);
		//printf("Checksum Str [%s], Checksum %02X, Calculated Checksum %02X\r\n",(char *)checksum_str+1, checksum, calculated_checksum);
		if (checksum == calculated_checksum) {
			//printf("Checksum OK");
			return 1;
		}
	}
	else {
		//printf("Error: Checksum missing or NULL NMEA message\r\n");
		return 0;
	}
	return 0;
}


//int parse_comma_delimited_str(char* string, char** fields, int max_fields)
void parse_comma_delimited_str(char* string, char** fields, int max_fields)
{
	int i = 0;
	fields[i++] = string;

	while ((i < max_fields) && NULL != (string = strchr(string, ','))) {
		*string = '\0';
		fields[i++] = ++string;
	}

	//return --i;
}

int str2int(char* str)
{
	const char* c;
	int val = 0;

	for (c = str; *c != '\0' && *c >= '0' && *c <= '9'; ++c) {
		val = (*c - '0') + val * 10;
	}
	return val;
}

float str2float(char* str)
{
	const char* c;
	int integer = 0;
	int decimal = 0;
	int d = 1;
	float f = 0;
	int sign = 0;
	c = str;
	if (*c == '-')
	{
		c++;
		sign = 1;
	}
	for (; *c != '.' && *c >= '0' && *c <= '9'; ++c) {
		integer = (*c - '0') + integer * 10;
	}
	c++;
	for (; *c != '\0' && *c >= '0' && *c <= '9'; ++c) {
		decimal = (*c - '0') + decimal * 10;
		d = d * 10;
	}
	f = (float)(integer * d + decimal) / d;
	if (sign == 1)
		f = -f;

	return f;
}


uint64_t hhmmss_usec(char* str)
{
	char s[3];
	uint64_t l = 0;
	int hh, mm, ss;
	s[0] = str[0];
	s[1] = str[1];
	s[2] = 0;
	hh = str2int(s);
	s[0] = str[2];
	s[1] = str[3];
	s[2] = 0;
	mm = str2int(s);
	s[0] = str[4];
	s[1] = str[5];
	s[2] = 0;
	ss = str2int(s);
	l = hh * 3600 + mm * 60 + ss;

	l = l * 1000;
	return l;
}

uint64_t get_sec(char* str)
{
	char s[3];
	int  ss;
	s[0] = str[4];
	s[1] = str[5];
	s[2] = 0;
	ss = str2int(s);

	return ss;
}
uint64_t get_min(char* str)
{
	char s[3];
	int  mm;
	s[0] = str[2];
	s[1] = str[3];
	s[2] = 0;
	mm = str2int(s);

	return mm;
}
uint64_t get_hour(char* str)
{
	char s[3];
	int hh;
	s[0] = str[0];
	s[1] = str[1];
	s[2] = 0;
	hh = str2int(s);
	return hh;
}
uint64_t get_day(char* str)
{
	char s[3];
	int  dd;
	s[0] = str[0];
	s[1] = str[1];
	s[2] = 0;
	dd = str2int(s);

	return dd;
}
uint64_t get_month(char* str)
{
	char s[3];
	int  mm;
	s[0] = str[2];
	s[1] = str[3];
	s[2] = 0;
	mm = str2int(s);

	return mm;
}
uint64_t get_year(char* str)
{
	char s[3];
	int yy;
	s[0] = str[4];
	s[1] = str[5];
	s[2] = 0;
	yy = str2int(s);
	return yy;
}

float ddmm_mmmm_to_dd_dddd(char* str)
{
	int v1 = 0;
	float  v2 = 0;
	char* cursor;
	if (NULL == (cursor = strchr(str, '.'))) {
		return -1;
	}
	/* minutes starts 2 digits before dot */
	cursor -= 2;
	v2 = str2float(cursor);
	*cursor = '\0';

	/* integer degrees */
	cursor = str;
	v1 = str2int(cursor);

	return v1 + v2/60;

}


/// <summary>
/// $GNGGA（GPS 定位信息，Global Positioning System Fix Data）
/// $GNGGA,(1),(2),(3),(4),(5),(6),(7),(8),(9),M,(10),M,(11),(12)*hh(CR)(LF)
/// $GNGGA,064357.00,2459.08555,N,12132.39179,E,1,12,1.02,-32.7,M,17.1,M,,*5C
/// $GNGGA,,,,,,0,00,99.99,,,,,,*56
/*
*   0.$GNGGA
	1.UTC 时间，格式为 hhmmss.ss；
	2.纬度，格式为 ddmm.mmmmm（度分格式）；
	3.纬度半球，N 或 S（北纬或南纬）；
	4.经度，格式为 dddmm.mmmmm（度分格式）；
	5.经度半球，E 或 W（东经或西经）；
	6.GPS 状态，0=未定位，1=非差分定位，2=差分定位；
	7.正在使用的用于定位的卫星数量（00~12）
	8.HDOP 水平精确度因子（0.5~99.9）
	9.海拔高度（-9999.9 到 9999.9 米）
	10.大地水准面高度（-9999.9 到 9999.9 米）
	11.差分时间（从最近一次接收到差分信号开始的秒数，非差分定位，此项为空）
	12.差分参考基站标号（0000 到 1023，首位 0 也将传送，非差分定位，此项为空)
*/
	/// </summary>
	/// <returns></returns>
int process_gga(char *buffer , struct GPS *gps)
{

	char* field[20];
	float f;
	parse_comma_delimited_str(buffer, field, 20);

	//if (*field[2] == NULL)
	//	return 0;

	gps->timestamp = (uint64_t)hhmmss_usec(field[1]);
	f = ddmm_mmmm_to_dd_dddd(field[2]);
	gps->lat = (int)f;
	gps->lat = gps->lat * 10000000;

	f = ddmm_mmmm_to_dd_dddd(field[4]);
	f = f * 10000000;
        gps->lon = (int)f;

	f = str2float(field[8]);
	f = f * 1000;
//	gps->alt = (int)f;

	return 1;
}

/// <summary>
/// $GNGSA（?前?星信息）
/// $GNGSA,(1),(2),(3),(4),(5),(6)*hh(CR)(LF)
///$GNGSA, A, 3, 10, 25, 32, 23, , , , , , , , , 5.85, 2.68, 5.20 * 19
///$GNGSA, A, 3, 76, , , , , , , , , , , , 5.85, 2.68, 5.20 * 1E
///0.$GNGSA
/*
	1.模式，M =  手动，A =  自动。
	2.定位类型，1=未定位，2=2D 定位，3=3D 定位。
	3.正在用于定位的卫星号（01~32）
	4.PDOP 综合位置精度因子（0.5-99.9）
	5.HDOP 水平精度因子 1（0.5-99.9）
	6.VDOP 垂直精度因子（0.5-99.9）
*/
int process_gsa(char* buffer, struct GPS* gps)
{
	char* field[20];
	parse_comma_delimited_str(buffer, field, 20);
 	if (*field[2] == '1') //1 = 未定位
		return 0;
	gps->pdop = str2float(field[15]);
	gps->eph = str2float(field[16]);
	gps->epv = str2float(field[17]);
	//	SetTime(field[9], field[1]);
	return 1;
}

/// <summary>
/// $GPGSV（可??星?，GPS Satellites in View）
/// $GPGSV,  (1),(2),(3),...,(4),(5),(6),(7)*hh(CR)(LF)
/// $GPGSV,3,1,12,10,47,189,22,12,14,039,,16,00,211,,22,49,339,10*76
/*
	1.GSV 语句总数。
	2.本句 GSV 的编号。
	3.可见卫星的总数（00~12，前面的 0 也将被传输）。
	4.卫星编号（01~32，前面的 0 也将被传输）。
	5.卫星仰角（00~90 度，前面的 0 也将被传输）。
	6.卫星方位角（000~359 度，前面的 0 也将被传输）
	7.信噪比（00~99dB，没有跟踪到卫星时为空）。
	注：每条 GSV 语句最多包括四颗卫星的信息，其他卫星的信息将在下一条$GPGSV 语句中输出
*/
int process_gsv(char* buffer, struct GPS* gps)
{
	char* field[20];
	parse_comma_delimited_str(buffer, field, 20);
//	gps->nsats = (uint8_t)str2int(field[2]);
	return 0;
}


/// <summary>
/// $GNRMC（推荐定位信息，Recommended Minimum Specific GPS/Transit Data）
///	$GNRMC, (1), (2), (3), (4), (5), (6), (7), (8), (9), (10), (11), (12)* hh(CR)(LF)
/// $GNRMC,023436.00,A,2459.20415,N,12132.29610,E,2.496,94.64,250122,,,A*47
/// 0.$GNRMC

	/*
	1.UTC 时间，hhmmss（时分秒）
	2.定位状态，A=有效定位，V=无效定位
	3.纬度 ddmm.mmmmm（度分）
	4.纬度半球 N（北半球）或 S（南半球）
	5.经度 dddmm.mmmmm（度分）
	6.经度半球 E（东经）或 W（西经）
	7.地面速率（000.0~999.9 节）
	8.地面航向（000.0~359.9 度，以真北方为参考基准）
	9.UTC 日期，ddmmyy（日月年）
	10.磁偏角（000.0~180.0 度，前导位数不足则补 0）
	11.磁偏角方向，E（东）或 W（西）
	12.模式指示（A=自主定位，D=差分，E=估算，N=数据无效）
	*/

int process_rmc(char* buffer, struct GPS* gps)
{
	char* field[20];
	double f = 0;//float f = 0;
	parse_comma_delimited_str(buffer, field, 20);

	if(*field[2] == 'A')
	{
		gps->gps_timeValid=1;
	}
	else if(*field[2] == 'V')
	{
		gps->gps_timeValid=3;
		gps->rGPSCnt = 0;
	}

	if (*field[2] != 'A' || gps->gps_timeValid==2){
		gps->valid=0;
		gps->state=0;
		gps->heading_valid=INVALID_GPS_HEADING;
		cntGPSDelay=0;
//		gps->gps_headingAlign = 5;
		gps->gps_lost = 1;
		gps->rGPSCnt = 0;

		return 0;
	}  // V = ?效定位

	cntGPSDelay ++;
	if(cntGPSDelay<2)
		return 0;
	else
		cntGPSDelay = 2;

	//gps->gps_timeValid = 1;
	gps->gps_lost = 0;


	gps->timestamp = hhmmss_usec(field[1]);

	gps->time_sec=get_sec(field[1]);
	gps->time_min=get_min(field[1]);
	gps->time_hour=get_hour(field[1]);




	f = ddmm_mmmm_to_dd_dddd(field[3]);
	gps_lon_lat.lat=f;

    f =  f * 10000000;
	gps->lat = (int)f;
//	if(*field[4]=='S'){
//		gps->lat= -gps->lat;
//	}


	f = ddmm_mmmm_to_dd_dddd(field[5]);
	gps_lon_lat.lon=f;
	f = f * 10000000;
    gps->lon = (int)f;
//    if(*field[6]=='W'){
//		gps->lon= -gps->lon;
//	}


	float vel_m_s = str2float(field[7]);
	vel_m_s = vel_m_s * 1.852*1000/3600;
	if(fabs(vel_m_s) > 5.5)
	{
		gps->rGPSCnt ++;//20KM/H
	}
	else if(fabs(vel_m_s) < 4.5)
	{
		gps->rGPSCnt = 0;
	}
	if(gps->rGPSCnt >= 3)
	{
		gps->rGPSCnt = 3;
	}

//	vel_m_s = (vel_m_s - preGpsVel)*0.1 + vel_m_s;//lead
//	vel_m_s = (preGpsVel*0.5 + vel_m_s*0.5);//lag
	preGpsVel = vel_m_s;//avg
	gps->vel=vel_m_s;

		if( field[8] != NULL)//if( field[8] != NULL && gps->rGPSCnt > 2) // yaw
        {
          float yaw = str2float(field[8]);
          if(yaw > 180)
        	  yaw -= 360;
          else if(yaw < -180)
        	  yaw += 360;

          gps->rGPSHeading = yaw;

          gps->heading = yaw * 0.0174532925f; //str2float(field[8]);
          if(yaw > 1 || yaw < -1)//if(gps->heading!=0)//if(yaw > 0.1 || yaw < -0.1)
          {
        	  gps->valid=1;
        	  gps->test=1;
        	  gps->heading = yaw * 0.0174532925f; //str2float(field[8]);
        	  gps->heading_valid = VALID_GPS_HEADING;
        	  if(gps->gps_headingAlign == 1)
        		  gps->gps_headingAlign = 2;
          }
          else
          {//must modify
        	  gps->valid=0;
        	  gps->test=2;
        	  gps->heading_valid = INVALID_GPS_HEADING;
              gps->heading = 0; //str2float(field[8]);
          }


//            if(fabs(gps->heading - preGpsHeading) > 10)
//            	gps->heading = (gps->heading - preGpsHeading)*0.2 + gps->heading;//phase lead
//            gps->heading = (preGpsHeading*0.5 + gps->heading*0.5);//lag
            preGpsHeading = gps->heading;

//            gps->vel_ned_valid = true;
            gps->vel_n = vel_m_s  * cos(yaw* 0.0174532925f);//use rad
            gps->vel_e = vel_m_s  * sin(yaw* 0.0174532925f);
            gps->vel_d = 0;


        }
        else
        {
          gps->valid=0;
          gps->heading_valid = INVALID_GPS_HEADING;
          gps->heading = 0;
          gps->test=0;
          gps->rGPSHeading = 0;
        }
    gps->time_day=get_day(field[9]);
    gps->time_month=get_month(field[9]);
    gps->time_year=get_year(field[9]);

    set_timestamp(0,gps->time_sec,gps->time_min,gps->time_hour,gps->time_day,gps->time_month,gps->time_year);

    if(gps->state==0){
    	gps->state=1;
    }

	return 1;
}

/// <summary>
/// $GNGLL（定位地理信息，Geographic Position）
/// $GNGLL,(1),(2),(3),(4),(5),(6),(7)*hh(CR)(LF)
/// $GNGLL,2459.20415,N,12132.29610,E,023436.00,A,A*70
/// $GNGLL,2459.38910,N,12131.62915,E,002806.00,A,A*7B
/// 0.$GNGLL
	/*
	1.纬度 ddmm.mmmmm（度分）
	2.纬度半球 N（北半球）或 S（南半球）
	3.经度 dddmm.mmmmm（度分）
	4.经度半球 E（东经）或 W（西经）
	5.UTC 时间：hhmmss（时分秒）
	6.定位状态，A=有效定位，V=无效定位
	7.模式指示（A=自主定位，D=差分，E=估算，N=数据无效）
	*/
/// </summary>

int process_gll(char* buffer, struct GPS* gps)
{
	char* field[20];
	parse_comma_delimited_str(buffer, field, 20);
	if (*field[6] == 'V') //V = ?效定位
		return 0;
	if (*field[6] == 'N') //N=?据?效
		return 0;

	return 1;
}

/// <summary>
///$GNVTG,(1),T,(2),M,(3),N,(4),K,(5)*hh(CR)(LF)
///$GNVTG,005.7,T,,M,000.0,N,000.0,K,A*11
///$GNVTG,100.83,T,,M,2.389,N,4.424,K,A*2F
///0.$GNVTG
///1.以真北??考基准的地面航向（000~359 度，前面的 0 也?被??）
///2.T
///3.以磁北??考基准的地面航向(000~359 度，前面的 0 也?被??)
///4.M
///5.地面速率(000.0~999.9 ?，前面的 0 也?被??
///6.N
///7.地面速率(0000.0~1851.8 公里/小?，前面的 0 也?被??),速度，節，Knots（一節也是1.852千米／小時）
///8.K
///9.模式指示（A=自主定位，D=差分，E=估算，N=?据?效）
/// </summary>

int process_vtg(char* buffer, struct GPS* gps)
{
	char* field[20];

	parse_comma_delimited_str(buffer, field, 20);
	if (*field[9] == 'N') //N=?据?效
		return 0;
	return 1;
}

int process_txt(char* buffer, struct GPS* gps)
{
	char* field[20];
	char *s;


	s = strstr(buffer, "OPEN");

//	parse_comma_delimited_str(buffer, field, 20);
//	if (*field[4] == "ANTENNA OPEN") //N=?据?效
//		return 0;
	return 1;
}


int gps_process(char *buffer)
{
       char *s;


       s = strstr(buffer, "$GPRMC");
       if( s == NULL)
       {
              s = strstr(buffer, "$GNRMC");
       }

       if( s == NULL )
              return 0;
//       if (strncmp(s+3, "RMC", 3) == 0)
//       {

          process_rmc(s, &gps);
          return 1;
//       }

//        return 0;

}

int gps_process1(char *buffer)
{
       char *s;

//       char buf[20];
       s = strstr(buffer, "$GPRMC");
       if( s == NULL)
       {
              s = strstr(buffer, "$GNRMC");
       }

       if( s == NULL )
              return 0;

	if (checksum_valid(s))
	{
//    strcpy(buf, "chk\r\n");
//        LPUART0_Send((uint8_t const*)buf, strlen(buf));

//                if (strncmp(s, "RMC", 3) == 0)
//                {
//    strcpy(buf, "rmc\r\n");
//        LPUART0_Send((uint8_t const*)buf, strlen(buf));

                        process_rmc(buffer, &gps);
                        return 1;
//                }
	}

        return 0;

}
int gps_process_GSA(char *buffer)
{
       char *s;

//       char buf[20];
       s = strstr(buffer, "GPGSA");
       if( s == NULL)
	  {
			 s = strstr(buffer, "$GNGSA");
	  }
       if( s == NULL)
       {
    	   return 0;
       }




	if (checksum_valid(s))
	{
//    strcpy(buf, "chk\r\n");
//        LPUART0_Send((uint8_t const*)buf, strlen(buf));

//                if (strncmp(s, "RMC", 3) == 0)
//                {
//    strcpy(buf, "rmc\r\n");
//        LPUART0_Send((uint8_t const*)buf, strlen(buf));

                        process_gsa(buffer, &gps);
                        return 1;
//                }
	}
        return 0;

}

int gps_process_TXT(char *buffer)
{
       char *s;

//       char buf[20];
       s = strstr(buffer, "OPEN");
       if( s == NULL)
       {
    	   return 1;
       }
       return 0;

}

int gps_process2(char *buffer)
{
       char *s;


       s = strstr(buffer, "$GP");
       if( s == NULL)
       {
              s = strstr(buffer, "$GN");
       }

       if( s == NULL )
              return 0;

	if (checksum_valid(s))
	{
            if ((strncmp(s, "$GP", 3) == 0) | (strncmp(s, "$GN", 3) == 0))
            {
                if (strncmp(&buffer[3], "GGA", 3) == 0)
                {
                        process_gga(buffer, &gps);
                }
                else if (strncmp(&buffer[3], "RMC", 3) == 0)
                {
                        process_rmc(buffer, &gps);
                }

                else if (strncmp(&buffer[3], "GLL", 3) == 0)
                {
                        process_gll(buffer, &gps);
                }

                else if (strncmp(&buffer[3], "VTG", 3) == 0)
                {
                        process_vtg(buffer, &gps);
                }
                else if (strncmp(&buffer[3], "GSA", 3) == 0)
                {
                        process_gsa(buffer, &gps);
                        return 1;
                }
                else if (strncmp(&buffer[3], "GSV", 3) == 0)
                {
                        process_gsv(buffer, &gps);
                }
            }
	}
        return 0;

}


int read_gps( )
{



      unsigned char data_received;
        char buf[20];
        while(1)
        {
          if(0 == RingBuf_Read_8bit(&uart3_rxbuf,&data_received))
          {
            if(data_received == 0x0a)
            {
                 gps_buffer[gps_idx++] =  data_received;
//                 LPUART0_Send((uint8_t const*)gps_buffer, gps_idx);
                 gps_idx = 0;

                 if( gps_process1(gps_buffer) == 1 )
                 {
                    strcpy(buf, "rmc\r\n");
                    //LPUART0_Send((uint8_t const*)buf, strlen(buf));

//                    gps.alt=0;		///< Altitude in 1E-3 meters (millimeters) above MSL
//                    gps.fix_type = 3;	///< 0-1: no fix, 2: 2D fix, 3: 3D fix, 4: RTCM code differential, 5: Real-Time Kinematic
//                    gps.sacc = 0.001;		///< GPS speed accuracy in m/s
//                    gps.vel_ned_valid = 1;	///< GPS ground speed is valid
                   // set_gps( &gps);
                //    return gps_idx;

                }
                 else
                	 gps_process_GSA(gps_buffer);

                 gps.antFlag = gps_process_TXT(gps_buffer);

            }
            else
            {
               gps_buffer[gps_idx++] =  data_received;
            }
            if( gps_idx >= 200 ) // over buffer size , reset gps_idx to zero
              gps_idx = 0;
         //   return gps_idx;
          }
          else{

        	  return -1;
          }

       }
}


/*int read_gps1( float deltaT)
{

      unsigned char data_received;
        //char buf[20];
      if(0 == RingBuf_Read2(&data_received))
      {
  //    sprintf(buf, "%c",data_received);
 //       LPUART0_Send((uint8_t const*)buf, strlen(buf));
        //return 0;
  //      printf("Recved data!!\r\n");
//             gps_buffer[gps_idx++] =  data_received;
        if(data_received == 0x0a)
        {
             gps_buffer[gps_idx++] =  data_received;
  //    sprintf(buf, "%c",data_received);
        LPUART0_Send((uint8_t const*)gps_buffer, gps_idx);

            gps_idx = 0;
#if 1
            if( gps_process1(gps_buffer) == 1 )
            {
         //       strcpy(buf, "process\r\n");
         //       LPUART0_Send((uint8_t const*)buf, strlen(buf));
//    strcpy(buf, "123\r\n");
//        LPUART0_Send((uint8_t const*)buf, strlen(buf));

//                gps.alt=0;		///< Altitude in 1E-3 meters (millimeters) above MSL
//                gps.fix_type = 3;	///< 0-1: no fix, 2: 2D fix, 3: 3D fix, 4: RTCM code differential, 5: Real-Time Kinematic
//                gps.sacc = 0.001;		///< GPS speed accuracy in m/s
//                gps.vel_ned_valid = 1;	///< GPS ground speed is valid


                set_gps( &gps);

            }
#endif
        }
        else
        {
           gps_buffer[gps_idx++] =  data_received;
        }
        if( gps_idx >= 200 ) // over buffer size , reset gps_idx to zero
          gps_idx = 0;
        return gps_idx;
      }
      else
        return -1;


}*/
