//******************************************************************************
//! @ProjectName: V-3000
//! @ModuleName:  asm330lhh.h
//!
//! @Purpose: header file
//! 
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//******************************************************************************

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef ASM330LHH_H
#define ASM330LHH_H

#include "asm330lhh_reg.h"
#include "Sensor_Interface.h"


#ifdef __cplusplus
  extern "C" {
#endif

typedef struct {
  float acceleration_g[3];    // acceletation data [mg]
  float angular_rate_dps[3];  // angular-rate data [mdps]
  float temperature_degC;     // temperature data [degC]
  float timestamp;            // timestamp ns
  uint8_t imu_valid;          // acceletation & angular-rate status: 1-valid 0-not valid
  uint8_t temp_valid;         // temperature status: 1-valid 0-not valid
} asm330lhh_data_t;

void platform_init_asm330(void);
int asm330lhh_initialize(void);
void read_asm_data(asm330lhh_data_t * data);
void read_asm_imu_data(asm330lhh_data_t * data);
void read_asm_temp_data(asm330lhh_data_t * data);

#ifdef __cplusplus
}
#endif

#endif /* QIMU_ASM330LHH_H */
