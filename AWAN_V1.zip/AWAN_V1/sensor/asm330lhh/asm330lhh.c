//*******************************************************************************
//! @Projectname:   QIMU
//! @ModuleName:    asm330lhh.c
//! @Author:
//! @Purpose:
//! This file contains all the functions defination for the asm330lhh-driver using
//! in certain platform.
//!
//! @Attention:
//! nameing conventions in this file use snake_case instead of camelCase in
//! Rec.26 in "VASTSoftware Coding Standards for the C Programing Language"
//!
//! VASTProprietary
//! @copyright 2019 BendixKing. All rights reserved.
//*******************************************************************************

/* Includes ------------------------------------------------------------------*/
#include "asm330lhh.h"
#include <string.h>
#include "gpio.h"
#include "spi.h"
#include "usart.h"
//#include "Sensor_Interface.h"

#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET   1

static asm330lhh_ctx_t dev_ctx;
static int32_t platform_write_asm330(void *handle, uint8_t reg, uint8_t *bufp, uint16_t len);
static int32_t platform_read_asm330(void *handle, uint8_t reg, uint8_t *bufp, uint16_t len);
//void platform_init_asm330(void);
                                    
//*******************************************************************************
//! int32_t platform_write(void *handle, uint8_t reg, uint8_t *bufp, 
//!                              uint16_t len)
//!
//! @description  Write generic device register (platform dependent).
//! @param        handle    customizable argument. In this examples is used in
//!                         order to select the correct sensor I2C address.
//!               reg       register to write
//!               bufp      pointer to data to write in register reg
//!               len       number of consecutive register to write
//! @return       resvered
//*******************************************************************************
static int32_t platform_write_asm330(void *handle, uint8_t Reg, uint8_t *Bufp, uint16_t len)
{
  Reg = Reg & 0x7F;// Indicate write to registers, the address of register
  LSSPI1_CS_Ctrl(0);//LPSPIO_CS0/PTB0 : asm330lhh cs pin
  LPSPI1_Write(&Reg, 1);
  LPSPI1_Write(Bufp, len);
//  LPSPI2_Write(&Reg, 1);
//  LPSPI2_Write(Bufp, len);
  LSSPI1_CS_Ctrl(1);
  return 0;
}

static int32_t platform_read_asm330(void *handle, uint8_t Reg, uint8_t *Bufp, uint16_t len)
{

  Reg |= 0x80;// Indicate read from register
  LSSPI1_CS_Ctrl(0);
  LPSPI1_Write(&Reg, 1);
  LPSPI1_Read(Bufp, len);
//  LPSPI2_Write(&Reg, 1);
//  LPSPI2_Read(Bufp, len);
  LSSPI1_CS_Ctrl(1);
  return 0;
}

//*******************************************************************************
//! int asm330lhh_initialize(void)
//!
//! @description  platform specific initialization (platform dependent)
//! @return       0-success
//! @req          {asm330lhh_initialize condition list below as req}
//*******************************************************************************
int asm330lhh_initialize(void)
{
	
  uint8_t whoamI, rst=0,test,id=255,whoamI2=255;
  char _arr[100];

  dev_ctx.write_reg = platform_write_asm330;
  dev_ctx.read_reg = platform_read_asm330;

	 sprintf(_arr, "2=%d\r\n",whoamI2);
	 LPUART1_Send((uint8_t*)_arr, strlen(_arr));
  //Check device ID
  asm330lhh_device_id_get(&dev_ctx, &whoamI2);
  //printf("ASM_ID:%0x\r\n",whoamI);
  
  if (whoamI2 != ASM330LHH_ID)
  {
    return 1;
  }
	 sprintf(_arr, "2=%d\r\n",whoamI2);
	 LPUART1_Send((uint8_t*)_arr, strlen(_arr));


	    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET);
	    test = 0x0F|0x80;
	    HAL_SPI_Transmit(&hspi1,&test,1,50);
	    HAL_SPI_Receive(&hspi1,&whoamI,1,50);
		 sprintf(_arr, "1=%d\r\n",whoamI);
		 LPUART1_Send((uint8_t*)_arr, strlen(_arr));

	    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);
  HAL_Delay(1000);

  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET);
  test = 0x12|0x80;
  HAL_SPI_Transmit(&hspi1,&test,1,50);
  HAL_SPI_Receive(&hspi1,&id,1,50);
	 sprintf(_arr, ",%d\r\n",id);
	 LPUART1_Send((uint8_t*)_arr, strlen(_arr));

  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);
  //Restore default configuration.
  asm330lhh_reset_set(&dev_ctx, PROPERTY_ENABLE);
  do {
    asm330lhh_reset_get(&dev_ctx, &rst);
  } while (rst);
	 sprintf(_arr, "=%d\r\n",rst);
	 LPUART1_Send((uint8_t*)_arr, strlen(_arr));

  // Enable Block Data Update.
  asm330lhh_block_data_update_set(&dev_ctx, PROPERTY_ENABLE);
  
  asm330lhh_auto_increment_set(&dev_ctx, PROPERTY_ENABLE);

  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET);
  test = 0x12|0x80;
  HAL_SPI_Transmit(&hspi1,&test,1,50);
  HAL_SPI_Receive(&hspi1,&id,1,50);
	 sprintf(_arr, ",%d\r\n",id);
	 LPUART1_Send((uint8_t*)_arr, strlen(_arr));

  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);

  // Set XL Output Data Rate.
  asm330lhh_xl_data_rate_set(&dev_ctx, ASM330LHH_XL_ODR_417Hz);
  //asm330lhh_xl_data_rate_set(&dev_ctx, ASM330LHH_XL_ODR_6667Hz);
  // Set Gy Output Data Rate
  asm330lhh_gy_data_rate_set(&dev_ctx, ASM330LHH_GY_ODR_6667Hz);
  // Set 8g full XL scale.
 // asm330lhh_xl_full_scale_set(&dev_ctx, ASM330LHH_16g);
  asm330lhh_xl_full_scale_set(&dev_ctx, ASM330LHH_16g);
  // Set 500dps full Gy scale
  asm330lhh_gy_full_scale_set(&dev_ctx, ASM330LHH_500dps);
  // Accelerometer - LPF1 + LPF2 path.
  asm330lhh_xl_hp_path_on_out_set(&dev_ctx, ASM330LHH_HP_PATH_DISABLE_ON_OUT);
  asm330lhh_xl_filter_lp2_set(&dev_ctx, PROPERTY_ENABLE);
  
  //gyro LPF1 path
  asm330lhh_gy_filter_lp1_set(&dev_ctx, PROPERTY_ENABLE);
  
  //set LPF1 bandwidth - ultra light 222Hz
 // asm330lhh_gy_lp1_bandwidth_set(&dev_ctx,ASM330LHH_ULTRA_LIGHT);
  
   //set LPF1 bandwidth - ultra light 222Hz 
//  asm330lhh_gy_lp1_bandwidth_set(&dev_ctx,ASM330LHH_STRONG);
//  asm330lhh_gy_lp1_bandwidth_set(&dev_ctx,ASM330LHH_VERY_STRONG);
  asm330lhh_gy_lp1_bandwidth_set(&dev_ctx,ASM330LHH_AGGRESSIVE);  

   /*Shut High Pass Filter Down*/
  //asm330lhh_gy_hp_path_internal_set(&dev_ctx, ASM330LHH_HP_FILTER_16mHz);
  
  //Enable LIR
  asm330lhh_int_notification_set(&dev_ctx, ASM330LHH_ALL_INT_LATCHED);
  // Set Free Fall duration to 3 and 6 samples event duration/
  asm330lhh_ff_dur_set(&dev_ctx, 0x06);
  asm330lhh_ff_threshold_set(&dev_ctx, ASM330LHH_FF_TSH_312mg);
  
  // Enable Timestap
  asm330lhh_timestamp_set(&dev_ctx, 1);

  return 0;
}

//*******************************************************************************
//! void read_asm_data(asm330lhh_data_t * data)
//!
//! @description  Read IMU data and temperature data
//! @param        data    pointer to data to stroe the asm330lhh data
//! @return       None
//*******************************************************************************
void read_asm_data(asm330lhh_data_t * data)
{
    axis3bit16_u data_raw_acceleration;
    axis3bit16_u data_raw_angular_rate;
    axis1bit16_u data_raw_temperature;
    
    uint8_t whoamI=255,test,id;
    char _arr[100];

    asm330lhh_reg_t reg;
    asm330lhh_status_reg_get(&dev_ctx, &reg.status_reg);
    data->imu_valid = 0; 
    data->temp_valid = 0;
        
    if (reg.status_reg.xlda)
    {
      // Read acceleration field data.
      // memset(data_raw_acceleration.u8bit, 0x00, 3 * sizeof(int16_t));
      asm330lhh_acceleration_raw_get(&dev_ctx, data_raw_acceleration.u8bit);
      data->acceleration_g[0] = asm330lhh_from_fs16g_to_g(data_raw_acceleration.i16bit[0]); /* fs: +/-8g */
      data->acceleration_g[1] = asm330lhh_from_fs16g_to_g(data_raw_acceleration.i16bit[1]);
      data->acceleration_g[2] = asm330lhh_from_fs16g_to_g(data_raw_acceleration.i16bit[2]);
//      printf("ASM330_ACCEL---X:%f, Y:%f, Z:%f\r\n", data->acceleration_mg[0],
//             data->acceleration_mg[1],data->acceleration_mg[2]);
    }
    if (reg.status_reg.gda)
    {
      // Read angular rate field data.
      // memset(data_raw_angular_rate.u8bit, 0x00, 3 * sizeof(int16_t));
      asm330lhh_angular_rate_raw_get(&dev_ctx, data_raw_angular_rate.u8bit);
      data->angular_rate_dps[0] = asm330lhh_from_fs500dps_to_dps(data_raw_angular_rate.i16bit[0]);
      data->angular_rate_dps[1] = asm330lhh_from_fs500dps_to_dps(data_raw_angular_rate.i16bit[1]);
      data->angular_rate_dps[2] = asm330lhh_from_fs500dps_to_dps(data_raw_angular_rate.i16bit[2]);
//      printf("ASM330_GYRO---X:%f, Y:%f, Z:%f\r\n", data->angular_rate_mdps[0],
//             data->angular_rate_mdps[1],data->angular_rate_mdps[2]);
    }
	data->imu_valid = 1; 
	
	if (reg.status_reg.tda)
    {
      //Read temperature data.
      // memset(data_raw_temperature.u8bit, 0x00, sizeof(int16_t));
      asm330lhh_temperature_raw_get(&dev_ctx, data_raw_temperature.u8bit);
      data->temperature_degC = asm330lhh_from_lsb_to_celsius(data_raw_temperature.i16bit);
      //printf("ASM330_TEMP---C:%f\r\n",data->temperature_degC);
    }
	data->temp_valid = 1; 
	asm330lhh_device_id_get(&dev_ctx, &whoamI);

//    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET);
//    test = 0x0F|0x80;
//    HAL_SPI_Transmit(&hspi1,&test,1,50);
//    HAL_SPI_Receive(&hspi1,&id,1,50);
//
//    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);

	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);
//
//	 sprintf(_arr, "%d,%d,%d,%d\r\n",whoamI,reg.status_reg,test,id);
//	 LPUART1_Send((uint8_t*)_arr, strlen(_arr));
	
}

//*******************************************************************************
//! void read_asm_imu_data(asm330lhh_data_t * data)
//!
//! @description  Read IMU data
//! @param        data    pointer to data to stroe the lsm9ds1 data
//! @return       None
//*******************************************************************************
void read_asm_imu_data(asm330lhh_data_t * data)
{
	axis3bit16_u data_raw_acceleration;
	axis3bit16_u data_raw_angular_rate;

	asm330lhh_reg_t reg;
    asm330lhh_status_reg_get(&dev_ctx, &reg.status_reg);
    
	data->imu_valid = 0; 
	
    if (reg.status_reg.xlda)
    {
      // Read acceleration field data.
      memset(data_raw_acceleration.u8bit, 0x00, 3 * sizeof(int16_t));
      asm330lhh_acceleration_raw_get(&dev_ctx, data_raw_acceleration.u8bit);
      data->acceleration_g[0] =
    		  asm330lhh_from_fs8g_to_g(data_raw_acceleration.i16bit[0]);
      data->acceleration_g[1] =
    		  asm330lhh_from_fs8g_to_g(data_raw_acceleration.i16bit[1]);
      data->acceleration_g[2] =
    		  asm330lhh_from_fs8g_to_g(data_raw_acceleration.i16bit[2]);
//      printf("ASM330_ACCEL---X:%f, Y:%f, Z:%f\r\n",  data->acceleration_mg[0],
//             data->acceleration_mg[1],data->acceleration_mg[2]);
    }
    if (reg.status_reg.gda)
    {
      // Read angular rate field data.
      memset(data_raw_angular_rate.u8bit, 0x00, 3 * sizeof(int16_t));
      asm330lhh_angular_rate_raw_get(&dev_ctx, data_raw_angular_rate.u8bit);
      data->angular_rate_dps[0] =
    		  asm330lhh_from_fs500dps_to_dps(data_raw_angular_rate.i16bit[0]);
      data->angular_rate_dps[1] =
    		  asm330lhh_from_fs500dps_to_dps(data_raw_angular_rate.i16bit[1]);
      data->angular_rate_dps[2] =
    		  asm330lhh_from_fs500dps_to_dps(data_raw_angular_rate.i16bit[2]);
//      printf("ASM330_GYRO---X:%f, Y:%f, Z:%f\r\n", data->angular_rate_mdps[0],
//             data->angular_rate_mdps[1],data->angular_rate_mdps[2]);
    }
	data->imu_valid = 1; 

}

//*******************************************************************************
//! void read_asm_temp_data(asm330lhh_data_t * data)
//!
//! @description  Read temperature data
//! @param        data    pointer to data to stroe the asm330lhh data
//! @return       None
//*******************************************************************************
void read_asm_temp_data(asm330lhh_data_t * data)
{

	axis1bit16_u data_raw_temperature;
	
	asm330lhh_reg_t reg;
        asm330lhh_status_reg_get(&dev_ctx, &reg.status_reg);
	
	data->temp_valid = 0; 
	
	if (reg.status_reg.tda)
    {
      //Read temperature data.
      memset(data_raw_temperature.u8bit, 0x00, sizeof(int16_t));
      asm330lhh_temperature_raw_get(&dev_ctx, data_raw_temperature.u8bit);
      data->temperature_degC = asm330lhh_from_lsb_to_celsius(data_raw_temperature.i16bit);
//      printf("ASM330_TEMP---C:%f\r\n",data->temperature_degC);
    }
	data->temp_valid = 1; 
}


