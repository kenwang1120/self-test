#ifndef PCT2075_H
#define PCT2075_H


int PCT2075_PowerOn(void);
void PCT2075_ReadTemperature(void);

#endif /* PCT2075_H */
