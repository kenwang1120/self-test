//******************************************************************************
//! @file
//!
//! Module file for PCT2075GV temperature sensor
//!
//! @Copyright 2019 BendixKing. All rights reserved.
//!
//******************************************************************************

//******************************************************************************
//  Include(s) for External Component API(s)
//******************************************************************************


//******************************************************************************
// Include(s) for Common Component API(s)
//******************************************************************************
#include "i2c.h"

//******************************************************************************
// Include(s) for Internal Component API(s)
//******************************************************************************
#include "pct2075.h"

//******************************************************************************
// Defines
//******************************************************************************
// pointer value
#define PCT2075_TEMP_REG 	0
#define PCT2075_CONF_REG 	1
#define PCT2075_THYST_REG       2
#define PCT2075_TOS_REG 	3
#define PCT2075_TIDLE_REG       4

#define PCT2075_OS_F_QUE_OFFSET 3
#define PCT2075_OS_F_QUE_1 	(0x0 << PCT2075_OS_F_QUE_OFFSET)
#define PCT2075_OS_F_QUE_2	(0x1 << PCT2075_OS_F_QUE_OFFSET)
#define PCT2075_OS_F_QUE_4	(0x2 << PCT2075_OS_F_QUE_OFFSET)
#define PCT2075_OS_F_QUE_6	(0x3 << PCT2075_OS_F_QUE_OFFSET)

#define PCT2075_OS_POL_MASK 		(1 << 2)
#define PCT2075_OS_COMP_INT_MASK 	(1 << 1)
#define PCT2075_OS_SHUTDOWN_MASK 	(1 << 0)

#define PCT2075_TEMP_REG_RESOLUTION            0.125f  // unit: degree C
#define PCT2075_TOS_THYST_REG_RESOLUTION       0.5f    // unit: degree C


// device address, A0 = 1, 0b100 1010, see Table6 in data sheet
#define PCT2075_DEVICE_ADRRESS    0x4A  

typedef enum
{
    QUEUE_VALUE_1   = 1,
    QUEUE_VALUE_2   = 2,
    QUEUE_VALUE_4   = 4,
    QUEUE_VALUE_6   = 6,
    
}pct2075_OSFaultQueueValue_e;

typedef enum
{
    OS_COMPARATOR   = 0,
    OS_INTERRUPT    = 1,

}pct2075_OSOperationMode_e;


typedef enum
{
    OS_ACTIVE_LOW   = 0,
    OS_ACTIVE_HIGH  = 1,

}pct2075_OSPolarity_e;


float pct2075ResultTemp;

//******************************************************************************
//! @fn 
//!
//! @description
//!
//!
//! @param  
//! @param  
//!
//! @return
//******************************************************************************
void PCT2075_WriteByte(uint8_t deviceAddr, uint8_t pointer, uint8_t dataByte)
{
    LPI2C3_Write(deviceAddr, pointer, &dataByte, 1);
}

uint8_t PCT2075_ReadByte(uint8_t deviceAddr, uint8_t pointer)
{
    uint8_t retval = 0xFF;
    
    LPI2C3_Read(deviceAddr, pointer, &retval, 1);
      
    return retval;
}

void PCT2075_WriteWord(uint8_t deviceAddr, uint8_t pointer, uint16_t dataWord)
{
  uint8_t txbuff[2];
  
  txbuff[1] = 0xFF & dataWord; // LSB
  txbuff[0] = (0xFF00 & dataWord) >> 8; // MSB
  LPI2C3_Write(deviceAddr, pointer, txbuff, 2);
  //LPI2C3_Write(uint8_t deviceAddress, uint8_t subAddress, uint8_t *txbuff, uint8_t length)
    
}

uint16_t PCT2075_ReadWord(uint8_t deviceAddr, uint8_t pointer)
{
    uint16_t retval = 0xFFFF;
    uint8_t txbuff[2];
    
    LPI2C3_Read(deviceAddr, pointer, txbuff, 2);
//    printf("%0x---%0x \r\n", txbuff[0],txbuff[1]);
    
    retval = (txbuff[0] << 8) | txbuff[1];
//    printf("%0x\r\n", retval);
    
    return retval;
}


//******************************************************************************
//! @fn float PCT2075_ReadTemperature(uint8_t deviceAddr)
//!
//! @description
//! Function to read temperature from the temp register
//!
//! @param  
//!   
//! @return resultTemperature
//******************************************************************************

void PCT2075_ReadTemperature(void)
{
    pct2075ResultTemp = 85;
    
    int16_t tempWord = (int16_t)PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_TEMP_REG);
    
    tempWord >>= 5;
    
    // Make temperature data true negative if it is
    if(tempWord & (1 << 10))
    {
      tempWord |= (0x1F << 11);
    }
    
    // Convert to degrees
    pct2075ResultTemp = (float)tempWord * 0.125;
   // printf("%f\r\n", pct2075ResultTemp);
    
//    if(tempWord & (0x400))
//    {
//      tempWord = ((~tempWord) & 0x3FF) + 1; // convert to positive 
//      resultTemperature = (float)tempWord * -1 * PCT2075_TEMP_REG_RESOLUTION;
//    }
//    else
//    {   
//      // Convert to degrees
//      resultTemperature = (float)tempWord * PCT2075_TEMP_REG_RESOLUTION;
//    }
  #ifdef FAHRENHEIT
    pct2075ResultTemp = pct2075ResultTemp * 1.8 + 32;
  #endif /* FAHRENHEIT */
    
}

//******************************************************************************
//! @fn void PCT2075_SetOSFaultQueue(pct2075_OSFaultQueueValue_e queueValue)
//!
//! @description
//! Function to set the OS fault queue
//!
//! @param  queueValue
//!   
//! @return 
//******************************************************************************
void PCT2075_SetOSFaultQueue(pct2075_OSFaultQueueValue_e queueValue)
{
    uint8_t config = 0;
    config = PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG);
    config &= 0x07; // keep the last 3 bits
    
    switch (queueValue)
    {
        case QUEUE_VALUE_1:
            config |= PCT2075_OS_F_QUE_1;
            break;
        case QUEUE_VALUE_2:
            config |= PCT2075_OS_F_QUE_2;
            break;        
        case QUEUE_VALUE_4:
            config |= PCT2075_OS_F_QUE_4;
            break;               
        case QUEUE_VALUE_6:
            config |= PCT2075_OS_F_QUE_6;
            break;        
    }
    
    PCT2075_WriteByte(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG, config);
}


//******************************************************************************
//! @fn void PCT2075_SetOSPolarity(pct2075_OSPolarity_e polarity)
//!
//! @description
//! Function to set the OS polarity
//!
//! @param  polarity
//!   
//! @return 
//******************************************************************************
void PCT2075_SetOSPolarity(pct2075_OSPolarity_e polarity)
{
    uint8_t config = 0;
    config = PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG);
    
    switch (polarity)
    {
        case OS_ACTIVE_LOW:
            config &= ~PCT2075_OS_POL_MASK;
            break;
        case OS_ACTIVE_HIGH:
            config |= PCT2075_OS_POL_MASK;
            break;               
    }
    
    PCT2075_WriteByte(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG, config);
}


//******************************************************************************
//! @fn void PCT2075_SetOSOperationMode(pct2075_OSOperationMode_e mode)
//!
//! @description
//! Function to set the OS operation mode
//!
//! @param  mode
//!   
//! @return 
//******************************************************************************
void PCT2075_SetOSOperationMode(pct2075_OSOperationMode_e mode)
{
    uint8_t config = 0;
    config = PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG);
    switch (mode)
    {
        case OS_COMPARATOR:
            config &= ~PCT2075_OS_COMP_INT_MASK;
            break;
        case OS_INTERRUPT:
            config |= PCT2075_OS_COMP_INT_MASK;
            break;               
    }
    
    PCT2075_WriteByte(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG, config);
}

//******************************************************************************
//! @fn void PCT2075_ShutDown(uint8_t deviceAddr)
//!
//! @description
//! Function to shudown the teperature sensor
//!
//! @param  
//!   
//! @return 
//******************************************************************************
void PCT2075_ShutDown(void)
{
    uint8_t config = 0;
    config = PCT2075_ReadByte(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG);
    config |= PCT2075_OS_SHUTDOWN_MASK;
    PCT2075_WriteByte(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG, config);
}

//******************************************************************************
//! @fn PCT2075_WakeUp(uint8_t deviceAddr)
//!
//! @description
//! Function to wake up the teperature sensor
//!
//! @param  
//!   
//! @return 
//******************************************************************************
void PCT2075_WakeUp(void)
{
    uint8_t config = 0;
    config = PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG);
    config &= ~PCT2075_OS_SHUTDOWN_MASK;
    PCT2075_WriteByte(PCT2075_DEVICE_ADRRESS, PCT2075_CONF_REG, config);
}


//******************************************************************************
//! @fn void PCT2075_SetShutdownThreshold(float threshold)
//!
//! @description
//! Function to set the shut down threshold value of the teperature sensor
//!
//! @param  threshold    -55.0 degreeC < threshold < 125.0 degreeC 
//!   
//! @return 
//******************************************************************************
void PCT2075_SetShutdownThreshold(float threshold)
{
    uint16_t tempWord;
    
    threshold = threshold / PCT2075_TOS_THYST_REG_RESOLUTION; 
    
    if(threshold < 0)
    {
        tempWord = (~((uint16_t) ((threshold * -1) - 1))) << 7; // Two's complement
    }
    else
    {
        tempWord = (uint16_t) threshold << 7;   
    }

    PCT2075_WriteWord(PCT2075_DEVICE_ADRRESS, PCT2075_TOS_REG, tempWord);   
}

//******************************************************************************
//! @fn float PCT2075_GetShutdownThreshold (uint8_t deviceAddr)
//!
//! @description
//! Function to get the shut down threshold value of the teperature sensor
//!
//! @param 
//!   
//! @return threshold
//******************************************************************************
float PCT2075_GetShutdownThreshold(void)
{  
    float threshold;
    uint16_t thresholdTemp;
    
    thresholdTemp = PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_TOS_REG);
    
    thresholdTemp >>= 7;
    
    // Make threshold data true negative if it is
    if(thresholdTemp & 0x100)
    {
      thresholdTemp = ((~thresholdTemp) & 0x1FF) + 1;
      threshold = (float)thresholdTemp * -1 * PCT2075_TOS_THYST_REG_RESOLUTION;
    }
    else
    {
       threshold = (float)thresholdTemp * PCT2075_TOS_THYST_REG_RESOLUTION;
    }

    return threshold;
}

//******************************************************************************
//! @fn void PCT2075_SetHysteresis (float threshold)
//!
//! @description
//! Function to set hysteresis value of the teperature sensor
//!
//! @param  threshold   -55.0 degreeC < threshold < 125.0 degreeC 
//!   
//! @return 
//******************************************************************************
void PCT2075_SetHysteresis(float threshold)
{
    uint16_t tempWord;
    
    threshold = threshold / PCT2075_TOS_THYST_REG_RESOLUTION; 
    
    if(threshold < 0)
    {
        tempWord = (~((uint16_t) ((threshold * -1) - 1))) << 7; // Two's complement
    }
    else
    {
        tempWord = (uint16_t) threshold << 7;   
    }

    PCT2075_WriteWord(PCT2075_DEVICE_ADRRESS, PCT2075_THYST_REG, tempWord);
}


//******************************************************************************
//! @fn float PCT2075_GetShutdownThreshold (uint8_t deviceAddr)
//!
//! @description
//! Function to get the shut down threshold value of the teperature sensor
//!
//! @param 
//!   
//! @return threshold
//******************************************************************************
float PCT2075_GetHysteresis(void)
{  
    float threshold;
    uint16_t thresholdTemp;
    
    thresholdTemp = PCT2075_ReadWord(PCT2075_DEVICE_ADRRESS, PCT2075_THYST_REG);
    
    thresholdTemp >>= 7;
    
    // Make threshold data true negative if it is
    if(thresholdTemp & 0x100)
    {
      thresholdTemp = ((~thresholdTemp) & 0x1FF) + 1;
      threshold = (float)thresholdTemp * -1 * PCT2075_TOS_THYST_REG_RESOLUTION;
    }
    else
    {
       threshold = (float)thresholdTemp * PCT2075_TOS_THYST_REG_RESOLUTION;
    }

    return threshold;
}


//******************************************************************************
//! @fn void PCT2075_SetSampleRate (uint8_t sampleRate_ms)
//!
//! @description
//! Function to set sample rate in ms
//!
//! @param  sampleRate_ms
//!   
//! @return 
//******************************************************************************
void PCT2075_SetSampleRate (uint16_t sampleRate_ms)
{
    uint8_t divider;
    
    divider = (uint8_t)(sampleRate_ms / 100);
    PCT2075_WriteByte(PCT2075_DEVICE_ADRRESS, PCT2075_TIDLE_REG, divider);
}


//******************************************************************************
//! @fn uint16_t PCT2075_GetSampleRate (void)
//!
//! @description
//! Function to get the sample rate
//!
//! @param 
//!   
//! @return threshold
//******************************************************************************
uint16_t PCT2075_GetSampleRate(void)
{ 
    uint16_t sample;
       
    sample = (uint16_t)PCT2075_ReadByte(PCT2075_DEVICE_ADRRESS, PCT2075_TIDLE_REG);
    sample *= 100;
    
    return sample;
}



int PCT2075_PowerOn(void) 
{
    //set as default value 
    PCT2075_WakeUp();
    PCT2075_SetOSFaultQueue(QUEUE_VALUE_1);
    PCT2075_SetOSPolarity(OS_ACTIVE_LOW);    
    PCT2075_SetOSOperationMode(OS_COMPARATOR);
    
    PCT2075_SetShutdownThreshold(80);
    PCT2075_SetHysteresis(75);
    PCT2075_SetSampleRate(100);
    
    return 0;
    
}



