//*******************************************************************************
//! @Projectname:   QIMU
//! @ModuleName:    lsm9ds1.h
//!
//! @Purpose:
//! This file contains all the functions prototypes for the lsm9ds1-driver using
//! in certain platform.
//!
//! @Attention:
//! nameing conventions in this file use snake_case instead of camelCase in
//! Rec.26 in "BendixKing Software Coding Standards for the C Programing Language"
//!
//! BendixKing Proprietary
//! @copyright 2019 BendixKing. All rights reserved.
//*******************************************************************************

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef LSM9DS1_H
#define LSM9DS1_H

#include "lsm9ds1_reg.h"
#include "Sensor_Interface.h"

#ifdef __cplusplus
  extern "C" {
#endif

typedef struct {
  float acceleration_g[3];        // acceletation data [mg]
  float angular_rate_dps[3];      // angular-rate data [mdps]
  float magnetic_field_mgauss[3];  // magnetic field data [mgauss]
  float temperature_degC;     // temperature data [degC]
  uint8_t imu_valid;               // acceletation & angular-rate status: 
                                   // 1-valid 0-not valid
  uint8_t mag_valid;               // magnetic field status: 1-valid 0-not valid
} lsm9ds1_data_t;

void platform_init_lsm(void);
int lsm9ds1_initialize();
void read_lsm_data(lsm9ds1_data_t * data);
void read_lsm_IMU_data(lsm9ds1_data_t * data);
void read_lsm_mag_data(lsm9ds1_data_t * data);

#ifdef __cplusplus
}
#endif

#endif /* LSM9DS1_BOARD_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
