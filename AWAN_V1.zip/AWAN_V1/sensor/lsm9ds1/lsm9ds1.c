//*******************************************************************************
//! @Projectname:   QIMU
//! @ModuleName:    lsm9ds1.c
//!
//! @Purpose:
//! This file contains all the functions defination for the lsm9ds1-driver using
//! in certain platform.
//!
//! @Attention:
//! nameing conventions in this file use snake_case instead of camelCase in
//! Rec.26 in "BendixKing Software Coding Standards for the C Programing Language"
//!
//! BendixKing Proprietary
//! @copyright 2019 BendixKing. All rights reserved.
//*******************************************************************************

#include "lsm9ds1.h"
#include "string.h"
#include "spi.h"
#include "gpio.h"

#define GPIO_PIN_RESET 0
#define GPIO_PIN_SET 1

#define XG_CS_PIN  9
#define MAG_CS_PIN 8
static lsm9ds1_ctx_t dev_ctx_mag;
static lsm9ds1_ctx_t dev_ctx_imu;

static int32_t platform_write(void *handle, uint8_t reg, uint8_t *bufp,
                              uint16_t len);
static int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp,
                             uint16_t len);

lsm9ds1_data_t lsm9ds1_raw_data = {0};
uint32_t MAG_Type = 1;
uint32_t XG_Type = 0;
//*******************************************************************************
//! @fn   int32_t platform_write(void *handle, uint8_t reg, uint8_t *bufp, 
//!                              uint16_t len)
//!
//! @description
//! Write generic device register (platform dependent).
//!
//! @param  handle    customizable argument. In this examples is used in
//!                   order to select the correct sensor I2C address.
//! @param  reg       register to write
//! @param  bufp      pointer to data to write in register reg
//! @param  len       number of consecutive register to write
//! @return resvered
//*******************************************************************************
static int32_t platform_write(void *handle, uint8_t reg, uint8_t *bufp,
                              uint16_t len)
{
  reg = reg & 0x7F;// Indicate write into device

  uint32_t *Type = (uint32_t*)(handle);
  uint32_t pin=XG_CS_PIN;
  
  if(*Type == MAG_Type )
  {
     pin =MAG_CS_PIN;
     //reg |= 0x40;
  } else{}
  GPIO_PinWrite(GPIOC, pin, GPIO_PIN_RESET);
  LPSPI1_Write(&reg, 1);
  LPSPI1_Write(bufp, len);
  GPIO_PinWrite(GPIOC, pin, GPIO_PIN_SET);
  
  return 0;
}

//*******************************************************************************
//! @fn   int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp, 
//!                              uint16_t len)
//!
//! @description
//! Read generic device register (platform dependent)
//!
//! @param  handle    customizable argument. In this examples is used in
//!                   order to select the correct sensor I2C address.
//! @param  reg       register to read
//! @param  bufp      pointer to data to stroe the data read
//! @param  len       number of consecutive register to read
//! @return resvered
//*******************************************************************************
static int32_t platform_read(void *handle, uint8_t reg, uint8_t *bufp,
                             uint16_t len)
{
   reg |= 0x80;// Indicate read from register
   
  uint32_t *Type = (uint32_t*)(handle);
  uint32_t pin=XG_CS_PIN;
  
  if(*Type == MAG_Type )
  {
     pin =MAG_CS_PIN;
     reg |= 0x40;
  } else{}
  
  GPIO_PinWrite(GPIOC, pin, GPIO_PIN_RESET); 
  LPSPI1_Write(&reg, 1);
  LPSPI1_Read(bufp, len);
  GPIO_PinWrite(GPIOC, pin, GPIO_PIN_SET);

  return 0;
}


//*******************************************************************************
//! @fn   void platform_init_lsm(void)
//!
//! @description
//! platform specific initialization (platform dependent)
//!
//! @return None
//*******************************************************************************
void platform_init_lsm(void)
{
}

//*******************************************************************************
//! @fn   int lsm9ds1_initialize(void)
//!
//! @description
//! platform specific initialization (platform dependent)
//!
//! @return 0-success
//!
//! @req {lsm9ds1_initialize condition list below as req}
//*******************************************************************************
int lsm9ds1_initialize()
{
  // Initialize magnetic sensors driver interface
  dev_ctx_mag.write_reg = platform_write;
  dev_ctx_mag.read_reg = platform_read;
  dev_ctx_mag.handle = &MAG_Type;

  //Initialize inertial sensors (IMU) driver interface
  dev_ctx_imu.write_reg = platform_write;
  dev_ctx_imu.read_reg = platform_read;
  dev_ctx_imu.handle = &XG_Type;

  // Check device ID
  lsm9ds1_id_t whoamI;
  lsm9ds1_dev_id_get(&dev_ctx_mag, &dev_ctx_imu, &whoamI);
//  printf("LSM_IMU_ID:%0x\r\n",whoamI.imu);
//  printf("LSM_MAG_ID:%0x\r\n",whoamI.mag);
  if (whoamI.imu != LSM9DS1_IMU_ID || whoamI.mag != LSM9DS1_MAG_ID){
    return 1;
  }

  // Restore default configuration
  uint8_t rst;
  lsm9ds1_dev_reset_set(&dev_ctx_mag, &dev_ctx_imu, PROPERTY_ENABLE);
  do {
    lsm9ds1_dev_reset_get(&dev_ctx_mag, &dev_ctx_imu, &rst);
  } while (rst);

  // Enable Block Data Update
  lsm9ds1_block_data_update_set(&dev_ctx_mag, &dev_ctx_imu, PROPERTY_ENABLE);

  lsm9ds1_auto_increment_set(&dev_ctx_imu, PROPERTY_ENABLE);
  
  //lsm9ds1_spi_mode_set(&dev_ctx_mag, &dev_ctx_imu,LSM9DS1_SPI_3_WIRE);
  lsm9ds1_spi_mode_set(&dev_ctx_mag, &dev_ctx_imu,LSM9DS1_SPI_4_WIRE);
  
  // Set full scale
  lsm9ds1_xl_full_scale_set(&dev_ctx_imu, LSM9DS1_8g);
  lsm9ds1_gy_full_scale_set(&dev_ctx_imu, LSM9DS1_500dps);
  lsm9ds1_mag_full_scale_set(&dev_ctx_mag, LSM9DS1_8Ga);
  
  // Configure filtering chain - See datasheet for filtering chain details
  // Accelerometer filtering chain
  lsm9ds1_xl_filter_aalias_bandwidth_set(&dev_ctx_imu, LSM9DS1_211Hz);
  lsm9ds1_xl_filter_lp_bandwidth_set(&dev_ctx_imu, LSM9DS1_LP_ODR_DIV_9);
  lsm9ds1_xl_filter_out_path_set(&dev_ctx_imu, LSM9DS1_LP_OUT);
  
  // Gyroscope filtering chain
  //lsm9ds1_gy_filter_lp_bandwidth_set(&dev_ctx_imu, LSM9DS1_LP_ULTRA_LIGHT);
  //lsm9ds1_gy_filter_hp_bandwidth_set(&dev_ctx_imu, LSM9DS1_HP_ULTRA_HIGH);
  //lsm9ds1_gy_filter_out_path_set(&dev_ctx_imu, LSM9DS1_LPF1_HPF_OUT);
  lsm9ds1_gy_filter_out_path_set(&dev_ctx_imu, LSM9DS1_LPF1_LPF2_OUT);

  // Set Output Data Rate / Power mode
  lsm9ds1_imu_data_rate_set(&dev_ctx_imu, LSM9DS1_IMU_119Hz);
  lsm9ds1_mag_data_rate_set(&dev_ctx_mag, LSM9DS1_MAG_UHP_80Hz);
  //lsm9ds1_mag_data_rate_set(&dev_ctx_mag, LSM9DS1_MAG_UHP_155Hz);
  
  return 0;
}

//*******************************************************************************
//! @fn   void read_lsm_data(lsm9ds1_data_t * data)
//!
//! @description
//! Read IMU data and magnetic data
//!
//! @param  data    pointer to data to stroe the lsm9ds1 data
//!
//! @return None
//*******************************************************************************
void read_lsm_data(lsm9ds1_data_t * data)
{
    axis3bit16_u data_raw_acceleration;
    axis3bit16_u data_raw_angular_rate;
    axis3bit16_u data_raw_magnetic_field;
    axis1bit16_u data_raw_temperature;
    // Read device status register
    lsm9ds1_status_t reg;
    lsm9ds1_dev_status_get(&dev_ctx_mag, &dev_ctx_imu, &reg);
    
    data->imu_valid = 0;
    data->mag_valid = 0;

    if ( reg.status_imu.xlda && reg.status_imu.gda && reg.status_imu.tda)
    {
      // Read imu data
      memset(data_raw_acceleration.u8bit, 0x00, 3 * sizeof(int16_t));
      lsm9ds1_acceleration_raw_get(&dev_ctx_imu, data_raw_acceleration.u8bit);
      data->acceleration_g[0] = lsm9ds1_from_fs8g_to_mg(data_raw_acceleration.i16bit[0])*0.001f;
      data->acceleration_g[1] = lsm9ds1_from_fs8g_to_mg(data_raw_acceleration.i16bit[1])*0.001f;
      data->acceleration_g[2] = lsm9ds1_from_fs8g_to_mg(data_raw_acceleration.i16bit[2])*0.001f;
      
      memset(data_raw_angular_rate.u8bit, 0x00, 3 * sizeof(int16_t));
      lsm9ds1_angular_rate_raw_get(&dev_ctx_imu, data_raw_angular_rate.u8bit);
      data->angular_rate_dps[0] = lsm9ds1_from_fs500dps_to_mdps(data_raw_angular_rate.i16bit[0])*0.001f;
      data->angular_rate_dps[1] = lsm9ds1_from_fs500dps_to_mdps(data_raw_angular_rate.i16bit[1])*0.001f;
      data->angular_rate_dps[2] = lsm9ds1_from_fs500dps_to_mdps(data_raw_angular_rate.i16bit[2])*0.001f;
      
      memset(data_raw_temperature.u8bit, 0x00, sizeof(int16_t));
      lsm9ds1_temperature_raw_get(&dev_ctx_imu, data_raw_temperature.u8bit);
      data->temperature_degC = lsm9ds1_from_lsb_to_celsius(data_raw_temperature.i16bit);
//      printf("LSM9DS1_ACCEL---X:%f, Y:%f, Z:%f\r\n", data->acceleration_mg[0],
//             data->acceleration_mg[1],data->acceleration_mg[2]);
//      printf("LSM9DS1_GYRO---X:%f, Y:%f, Z:%f\r\n", data->angular_rate_mdps[0],
//             data->angular_rate_mdps[1],data->angular_rate_mdps[2]);
      data->imu_valid = 1;
    }

    if ( reg.status_mag.zyxda )
    {
      // Read magnetometer data
      memset(data_raw_magnetic_field.u8bit, 0x00, 3 * sizeof(int16_t));
      lsm9ds1_magnetic_raw_get(&dev_ctx_mag, data_raw_magnetic_field.u8bit);

      data->magnetic_field_mgauss[0] = lsm9ds1_from_fs8gauss_to_mG(data_raw_magnetic_field.i16bit[0]);
      data->magnetic_field_mgauss[1] = lsm9ds1_from_fs8gauss_to_mG(data_raw_magnetic_field.i16bit[1]);
      data->magnetic_field_mgauss[2] = lsm9ds1_from_fs8gauss_to_mG(data_raw_magnetic_field.i16bit[2]);
//      printf("LSM9DS1_MAG---X:%f, Y:%f, Z:%f\r\n",data->magnetic_field_mgauss[0],
//             data->magnetic_field_mgauss[1],data->magnetic_field_mgauss[2]);
      data->mag_valid = 1;
    }
}

void read_lsm_IMU_data(lsm9ds1_data_t * data)
{
    axis3bit16_u data_raw_acceleration;
    axis3bit16_u data_raw_angular_rate;
    axis1bit16_u data_raw_temperature;
    // Read device status register
    lsm9ds1_status_t reg;
    lsm9ds1_dev_imu_status_get(&dev_ctx_imu, &reg);
    
    data->imu_valid = 0;

    if ( reg.status_imu.xlda && reg.status_imu.gda && reg.status_imu.tda)
    {
      // Read imu data
      memset(data_raw_acceleration.u8bit, 0x00, 3 * sizeof(int16_t));
      lsm9ds1_acceleration_raw_get(&dev_ctx_imu, data_raw_acceleration.u8bit);
      data->acceleration_g[0] = lsm9ds1_from_fs8g_to_mg(data_raw_acceleration.i16bit[0])*0.001f;
      data->acceleration_g[1] = lsm9ds1_from_fs8g_to_mg(data_raw_acceleration.i16bit[1])*0.001f;
      data->acceleration_g[2] = lsm9ds1_from_fs8g_to_mg(data_raw_acceleration.i16bit[2])*0.001f;
      
      memset(data_raw_angular_rate.u8bit, 0x00, 3 * sizeof(int16_t));
      lsm9ds1_angular_rate_raw_get(&dev_ctx_imu, data_raw_angular_rate.u8bit);
      data->angular_rate_dps[0] = lsm9ds1_from_fs500dps_to_mdps(data_raw_angular_rate.i16bit[0])*0.001f;
      data->angular_rate_dps[1] = lsm9ds1_from_fs500dps_to_mdps(data_raw_angular_rate.i16bit[1])*0.001f;
      data->angular_rate_dps[2] = lsm9ds1_from_fs500dps_to_mdps(data_raw_angular_rate.i16bit[2])*0.001f;
      
      memset(data_raw_temperature.u8bit, 0x00, sizeof(int16_t));
      lsm9ds1_temperature_raw_get(&dev_ctx_imu, data_raw_temperature.u8bit);
      data->temperature_degC = lsm9ds1_from_lsb_to_celsius(data_raw_temperature.i16bit);
//      printf("LSM9DS1_ACCEL---X:%f, Y:%f, Z:%f\r\n", data->acceleration_mg[0],
//              data->acceleration_mg[1],data->acceleration_mg[2]);
//      printf("LSM9DS1_GYRO---X:%f, Y:%f, Z:%f\r\n", data->angular_rate_mdps[0],
//              data->angular_rate_mdps[1],data->angular_rate_mdps[2]);
      data->imu_valid = 1;
    }
}
void read_lsm_mag_data(lsm9ds1_data_t * data)
{
    axis3bit16_u data_raw_magnetic_field;
    
    // Read device status register
    lsm9ds1_status_t reg;
    lsm9ds1_dev_mag_status_get(&dev_ctx_mag, &reg);
    data->mag_valid = 0;

    if ( reg.status_mag.zyxda ) 
    {
      // Read magnetometer data
      memset(data_raw_magnetic_field.u8bit, 0x00, 3 * sizeof(int16_t));
      lsm9ds1_magnetic_raw_get(&dev_ctx_mag, data_raw_magnetic_field.u8bit);

      data->magnetic_field_mgauss[0] = lsm9ds1_from_fs8gauss_to_mG(data_raw_magnetic_field.i16bit[0]);
      data->magnetic_field_mgauss[1] = lsm9ds1_from_fs8gauss_to_mG(data_raw_magnetic_field.i16bit[1]);
      data->magnetic_field_mgauss[2] = lsm9ds1_from_fs8gauss_to_mG(data_raw_magnetic_field.i16bit[2]);
//      printf("LSM9DS1_MAG---X:%f, Y:%f, Z:%f\r\n",data->magnetic_field_mgauss[0],
//              data->magnetic_field_mgauss[1],data->magnetic_field_mgauss[2]);
      data->mag_valid = 1;
    }
}
