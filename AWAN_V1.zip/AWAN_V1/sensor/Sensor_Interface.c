/*
 * Sensor_Interface.c
 *
 *  Created on: May 24, 2022
 *      Author: Macial
 */


