/*
 * Sensor_Interface.h
 *
 *  Created on: May 24, 2022
 *      Author: Macial
 */

#ifndef SENSOR_INTERFACE_H_
#define SENSOR_INTERFACE_H_

#ifdef __cplusplus
  extern "C" {
#endif




  typedef union{
    int16_t i16bit[3];
    uint8_t u8bit[6];
  } axis3bit16_u;    // LSB

  typedef union{
    int16_t i16bit;
    uint8_t u8bit[2];
  } axis1bit16_u;

  typedef union{
    int32_t i32bit[3];
    uint8_t u8bit[12];
  } axis3bit32_u;

  typedef union{
    int32_t i32bit;
    uint8_t u8bit[4];
  } axis1bit32_u;
//
//
//
//
//typedef struct
//{
//	axis3bit16_t Angle;
//	axis3bit16_t Angle_Rate;
//	axis3bit16_t Angle_Rate;
//};

















#ifdef __cplusplus
}
#endif

#endif /* SENSOR_INTERFACE_H_ */
