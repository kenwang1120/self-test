///**************************************************************
// *@Project :  stm32_m4_asm330_.v1.3_release
// *@FileName:  PrintMsg.c
// *@Purpose :
// *
// *-------------------------------------------------------------
// *@Copyright. Create by Macial.    May 30, 2022  2:54:53 PM
// **************************************************************/
///*==========================
//*  Include Files
//*=========================*/
//#include "PrintMsg.h"
//#include <stdarg.h>
//#include "usart.h"
//#include "spi.h"
//
///*==========================
// *  Declare Area Variables
// *=========================*/
//
//
///*==========================
// *  Application Code
// *=========================*/
////!*************************************************************************************************
////! @Function   :
////! @Description:
////! @Param      :
////! @Return     :  None
////! @Create     :  Macial   May 30, 2022,
////!*************************************************************************************************
//void PrintInt(int _input)
//{
//	uint8_t str[11] = {0};  // symbol(1) + maximum number of digits for Integer type(10) = 11 digits
//	int temp = _input;
//	uint32_t num = 0;
//
//	if(temp < 0)
//	{
//		str[0] = '-';
//		if(temp == 0x80000000)
//		{
//			num = (uint32_t)((temp + 1)*(-1)) + 1U;  // minimum value convert
//		}
//		else
//		{
//			num = (uint32_t)(-temp);
//		}
//	}
//	else
//	{
//		num = (uint32_t)(temp);
//	}
//
//
//	while()
//
//
//
//
//
//
//
//	while((temp/10) != 0)
//	{
//		int num = temp - (temp/10)*10;
//		switch(num)
//		{
//		case 0:
//			break;
//
//		}
//	}
//
//}
//
//
//void PrintMsg_(char *str, ...)
//{
//	va_list arg_ptr;
//	va_start(arg_ptr, _text);
//	sprintf(arr, str, i,calResult[i]);
//
//
//}
//
//
//
//
//
//void PrintMsg(const char *_text, ...)
//{
//	/* Display digits */
//	uint8_t int_digit  = 0;
//	uint8_t dec_places = 0;
//	/* Argument variable container */
//	char* string_arg = NULL;
//	int   int_arg    = 0;
//	unsigned long hex_arg = 0U;
//	char ch = '';
//	/* stdarg */
//	unsigned long arg_segment = 0;
//	int arg_segment_count = 0;
//	int ptr_count = 0;
//	va_list arg_ptr;
//	va_start(arg_ptr, _text);
//
//	while((*_text) != '\0')
//	{
//
//		if((*_text) == '%')
//		{
//			/* Get number of Integer display digits */
//			if((*(_text + 1) <= '9') && (*(_text + 1) >= '0'))
//			{
//				int_digit = (uint8_t)(*(_text + 1)) - '0';
//				ptr_count++;
//				_text++;
//			}
//
//			/* Get number of Decimal display places */
//			if((*(_text + 1) == '.'))
//			{
//				if((*(_text + 2) <= '9') && (*(_text + 2) >= '0'))
//				{
//					dec_places = (uint8_t)(*(_text + 2)) - '0';
//					ptr_count++;
//					_text++;
//				}
//				ptr_count++;
//				_text++;
//			}
//
//			/* Output Argument */
//			switch(*(_text+1))
//			{
//			/* String */
//			case 'S':
//			case 's':
//				string_arg = va_arg(arg_ptr, char*);
//				while(*string_arg)
//				{
//					SendOut_Byte((uint8_t*)string_arg, 1);
//					string_arg++;
//				}
//				_text++;
//
//				int_digit = 0;
//				dec_places = 0;
//
//				break;
//
//			/* Hexadecimal */
//			case 'X':
//			case 'x':
//				hex_arg = va_arg(arg_ptr, unsigned long);
//				arg_segment = hex_arg;
//				/* Get digits */
//				while(arg_segment != 0U)
//				{
//					arg_segment = arg_segment >> 4U;
//					arg_segment_count ++;
//				}
//				/* min digits = 2  */
//				if(arg_segment_count < 2)
//				{
//					arg_segment_count = 2;
//				}
//
//				while(arg_segment_count != 0)
//				{
//					if(int_digit > arg_segment_count)
//					{
//						ch = '0';
//						SendOut_Byte(&ch, 1);
//					}
//
//					}
//
//
//					if(arg_segment_count != 0)
//					{
//						arg_segment = hex_arg >> (4 * (arg_segment_count - 1));
//						hex_arg %= (1 << (4 * (arg_segment_count - 1)));
//						arg_segment_count--;
//					}
//					else
//					{
//						if(int_digit != 0)
//						{
//
//						}
//					}
//
//
//					if(arg_segment <= 9)
//					{
//						SendOut_Byte((uint8_t*)string_arg, 1);
//					}
//					else
//					{
//
//					}
//
//
//				}
//
//
//
//
//
//
//
//
//va_arg(arg_ptr, char*);
//				while((*_temp) != '\0')
//				{
////					SendOut_Byte((uint8_t*)_temp, 1);
//					_temp++;
//				}
//				_text += 2; // '%','s' is 2 char
//				break;
//			/* Int */
//			case 'd':
////				int _temp = va_arg(arg_ptr, int);
//
//
//
//				break;
//			}
//		}
////
////
//////		if((*_text == '%') && (*(_text + 1) == 's'))
//////		{
//////			char *_temp = NULL;
//////			_temp = va_arg(arg_ptr, char*);
//////			while((*_temp) != '\0')
//////			{
//////				SendOut_Byte((uint8_t*)_temp, 1);
//////				_temp++;
//////			}
//////			_text += 2; // '%','s' is 2 char
//////		}
////	}
//}
//
//
//void SendOut_Byte(uint8_t *_data, int _length)
//{
//#if defined(UART1_PORT) || (!defined(UART3_PORT) && !defined(UART6_PORT))
//	LPUART1_Send(_data, _length);
//#endif
//
//#if defined(UART3_PORT)
//	LPUART3_Send(_data, _length);
//#endif
//
//#if defined(UART6_PORT)
//	LPUART6_Send(_data, _length);
//#endif
//
//#if defined(SPI_SLAVE_PORT)
//	LPSPI2_Write(uint8_t *buf, uint8_t length);
//#endif
//
//
//}
//
//
//
//
//
//
//
