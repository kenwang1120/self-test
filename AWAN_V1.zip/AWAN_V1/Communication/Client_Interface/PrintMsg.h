//*********************************************************************//
// @ file name : PrintMsg.h
// @ descripe  :
//
// @ Create by Macial Copy right. Create on May 30, 2022  2:45:48 PM.
//*********************************************************************//
#ifndef __PRINTMSG_H_
#define __PRINTMSG_H_

#ifdef __cplusplus
 extern "C" {
#endif
/*------------------------------- include files---------------------------------*/
#include "stm32f4xx_hal.h"

/*------------------------------- definition------------------------------------*/


/*------------------------------- enum declare----------------------------------*/
//typedef enum{
//	/* uart port */
//	UART1_Print = 0x1U,
//	UART3_Print = 0x2U,
//	UART6_Print = 0x4U,
//	/* spi port */
//	SPI1_print  = 0x10u,
//} print_port_e;

/*------------------------------- struct declare--------------------------------*/


/*------------------------------- variable declare------------------------------*/


/*------------------------------- function declare------------------------------*/




#ifdef __cplusplus
 }
#endif

#endif /* INC_PRINTMSG_H_ */
