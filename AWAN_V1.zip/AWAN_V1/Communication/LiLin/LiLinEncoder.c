/**************************************************************
 *@Project :  stm32_m4_asm330_.v1.3_release
 *@FileName:  LiLinEncoder.c
 *@Purpose :  
 *            
 *-------------------------------------------------------------
 *@Copyright. Create by Macial.    2022年6月10日  下午2:48:41
 **************************************************************/
/*==========================
*  Include Files
*=========================*/
#include "LiLinEncoder.h"
#include "usart.h"
#include "ringBuff.h"
#include "scheduler.h"
#include <math.h>


/*==========================
 *  Declare Area Variables
 *=========================*/
lilin_data_t lilin_data;
lilin_data_t vast_data;
//static uint8_t data_collect[7] = {0};
//uint8_t lilin_collect_complete = 0;


//#define PRINTOUT



#ifdef PRINTOUT
#include <string.h>
char _str[50] = {0};
#endif


#if defined LILIN_UART1_RECEIVE
	ringBuffer_t *lilin_rxbuf = &uart1_rxbuf;
#endif

#if defined LILIN_UART3_RECEIVE
	ringBuffer_t *lilin_rxbuf = &uart3_rxbuf;
#endif

#if defined USE_EXT_MAG_SENSOR
	ringBuffer_t *lilin_mag_rxbuf = &uart6_rxbuf;
#endif

	ringBuffer_t *vast_rxbuf = &uart1_rxbuf;//4G module



/*==========================
 *  Application Code
 *=========================*/
////!*************************************************************************************************
////! @Function   :  LiLin_Data_Collect(lilin_data_t *_data)
////! @Description:  Protocol = {Header, FunCode, Encoder_MSB, Encoder_LSB, Command, FF, CRC}
////! @Param      :
////! @Return     :  None
////! @Create     :  Macial   2022年6月10日,
////!*************************************************************************************************
//void LiLin_Data_Collect(uint8_t _data)
//{
//	lilin_collect_complete = 0;
//	uint32_t _crc = 0;
//	switch(_step)
//	{
//	case 0:
//		if(_data == (uint8_t)LILIN_STARTBYTE)
//		{
//			data_collect[0] = _data;
//			_step = 1;
//		}
//		else
//		{
//			memset((void*)data_collect, 0, sizeof(data_collect));
//			_step = 0;
//		}
//		break;
//	case 1:
//		if(_data == (uint8_t)LILIN_FUNCODE)
//		{
//			data_collect[1] = _data;
//			_step = 2;
//		}
//		else
//		{
//			memset((void*)data_collect, 0, sizeof(data_collect));
//			_step = 0;
//		}
//		break;
//	case 2:
//		data_collect[2] = _data;
//		_step = 3;
//		break;
//	case 3:
//		data_collect[3] = _data;
//		_step = 4;
//		break;
//	case 4:
//		data_collect[4] = _data;
//		_step = 5;
//		break;
//	case 5:
//		data_collect[5] = _data;
//		_step = 6;
//		break;
//	case 6:
//		data_collect[6] = _data;
//
//		for(int _idx = 1; _idx < 6; _idx++)
//		{
//			_crc += (uint32_t)data_collect[_idx];
//		}
//
//		if(_crc == (uint32_t)data_collect[6])
//		{
//			lilin_data.angle = (float)((uint16_t)((data_collect[2] << 8) | data_collect[3])) * LILIN_ENCODER_RES;
//			lilin_data.cmd = data_collect[4];
//			lilin_collect_complete = 1;
//		}
//		_step = 0;
//
//		break;
//	default:
//		_step = 0;
//		break;
//	}
//
//	sprintf(_str, "0x%2X ",_data);
//    LPUART1_Send((uint8_t*)_str, strlen(_str));
////	return lilin_collect_complete;
//}


//!*************************************************************************************************
//! @Function   :  LiLin_Data_Get(lilin_data_t *_data)
//! @Description:  Protocol = {Header, FunCode, Encoder_MSB, Encoder_LSB, Command, FF, CRC}
//! @Param      :  
//! @Return     :  None
//! @Create     :
//!*************************************************************************************************
uint8_t LiLin_Data_Get(lilin_data_t *_data)
{
	uint8_t _received = 0;
//	uint32_t _tickstart = 0;
	uint16_t _tick_count = 0U;
	uint32_t _checksum = 0;
	uint8_t _protocol[6] = {0};

	/* Initialize */
//	_data->encoder.u16bit = 0U;
//	_data->angle  = 0.0f;
	_data->cmd    = 0U;
	_data->cmd2   = 0U;
	_data->status = 0U;

	/* Check Data Count big than Protocol Length */
	if(RingBuf_FIFO_Count(lilin_rxbuf) < 7)
	{
#if defined PRINTOUT_LILIN_RAW
		sprintf(_str, " DataLess!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif
		return (uint8_t)LiLin_Operate_DataLess;
	}

	/* Get the Last Frame */
//	_tickstart = HAL_GetTick();
	while(1)
	{
		if(RingBuf_Read_8bit(lilin_rxbuf, &_received) == READ_FAULT)
		{
#if defined PRINTOUT_LILIN_RAW
		sprintf(_str, " Buffer Empty!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif
			return (uint8_t)LiLin_Operate_Empty;
		}
		/* Make sure Data is Latest and Avoid Out of Bounds when Reading Ring-Buffer Data */
		if((RingBuf_FIFO_Count(lilin_rxbuf) < 14) && (RingBuf_FIFO_Count(lilin_rxbuf) >= 6))
		{
			if(_received == LILIN_STARTBYTE)
			{
#if defined PRINTOUT_LILIN_RAW
		sprintf(_str, " Get Header!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif
				_protocol[0] = _received;
				break;
			}
		}

		/* Timeout Determination */
		_tick_count++;
		if(_tick_count >= 1000)
		{
#if defined PRINTOUT_LILIN_RAW
		sprintf(_str, " TimeOut!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif
			return (uint8_t)LiLin_Operate_TimeOut;
		}
//		if((HAL_GetTick() - _tickstart) < LILIN_TIMEOUT_MS)
//		{
//			return (uint8_t)LiLin_Operate_TimeOut;
//		}
	}

	/* Received LiLin Protocol */
	for(int _idx = 1; _idx < 7 ;_idx++)
	{
		RingBuf_Read_8bit(lilin_rxbuf, &_received);
		_protocol[_idx] = _received;
		if(_idx < 6)
		{
			_checksum += _received;
		}

#if defined PRINTOUT_LILIN_RAW
		sprintf(_str, "0x%2X ",_received);
	    LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

	}

	/* Check Function Code and CRC Correct */
	if((_protocol[1] == LILIN_FUNCODE) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */
		_data->encoder.u16bit = (uint16_t)((_protocol[2] << 8) | _protocol[3]);

		if(_data->encoder.u16bit > 36000U)
		{
			_data->encoder.u16bit = 36000U;
		}
		_data->angle = (float)(_data->encoder.u16bit) * LILIN_ENCODER_RES;
//		_data->angle = (float)((uint16_t)((_protocol[2] << 8) | _protocol[3])) * LILIN_ENCODER_RES;
		_data->cmd   = _protocol[4];
		_data->fCalMag = _protocol[4];
		_data->cmd2  = _protocol[5];
		_data->status = 1U;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == LILIN_TILT_ENCODER) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		_data->tilt_Encoder = (int16_t)((_protocol[2] << 8) | _protocol[3]);
		_data->status = LILIN_TILT_ENCODER;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == VAST_FUNCODE_MAG_K) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->fCalMag  = _protocol[2];
		_data->lID   = 0;//_protocol[4];
		_data->hID  = 0;//_protocol[5];
		_data->status = VAST_FUNCODE_MAG_K;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == VAST_FUNCODE_ID) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->hID  = _protocol[2];//hID
		_data->lID   = _protocol[3];//lID
//		_data->hID  = 0;//_protocol[5];
		_data->status = VAST_FUNCODE_ID;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == LILIN_FUNCODE_TILT) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->writeFlashEnable  = _protocol[3];
		_data->pitchKp   = _protocol[4];
//		_data->magWeight  = _protocol[4];
		_data->status = 4U;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == LILIN_FUNCODE_PAN) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->writeFlashEnable  = _protocol[3];
		_data->yawKp  = _protocol[4];
//		_data->magWeight  = _protocol[4];
		_data->status = 5U;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == LILIN_FUNCODE_MAG) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->writeFlashEnable  = _protocol[3];
		_data->magWeight  = _protocol[4];
		_data->magTime  = _protocol[5];
		_data->status = 6U;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == LILIN_FUNCODE_CFG) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->subCmd  = _protocol[2];
		_data->writeFlashEnable  = _protocol[3];
		_data->outputDataRate  = _protocol[4];
		_data->status = LILIN_FUNCODE_CFG;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == LILIN_FUNCODE_REQ) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->subCmd  = _protocol[2];
		if(_protocol[2] == 0)
		{
			_data->rebootEnable   = _protocol[3];//reboot
		}
		else if(_protocol[2] == 1)
		{
			_data->writeFlashEnable   = _protocol[3];//write flash
		}
		else if(_protocol[2] == 2)
		{
			_data->versionEnable   = _protocol[3];//inquiry version
		}
		_data->status = LILIN_FUNCODE_REQ;

#if defined PRINTOUT_LILIN_RAW
//		  sprintf(_str, "Encoder = %d, Encoder = %.2f , Cmd = %d\r\n", test, _data->angle, _data->cmd);
//		  LPUART1_Send((uint8_t*)_str, strlen(_str));
		sprintf(_str, "  CheckSum OK!\r\n");
		LPUART3_Send((uint8_t*)_str, strlen(_str));
#endif

		return (uint8_t)LiLin_Operate_OK;
	}
	else
	{
		return (uint8_t)LiLin_Operate_DecodeError;
	}

}


//!*************************************************************************************************
//! @Function   :  LiLin_Data_Get(lilin_data_t *_data)
//! @Description:  Protocol = {E2, magX_H, magX_L, magY_H, magY_L, magZ_H, magZ_L, CRC}
//! @Param      :
//! @Return     :  None
//! @Create     :  Macial
//!*************************************************************************************************
//#include <string.h>
//char _str[50] = {0};
//static int test_cnt = 0;
//
//uint8_t LiLin_MagData_Get(lilin_data_t *_data)
//{
//	uint8_t  _protocol[8] = {0};
//	uint16_t _tick_count  = 0U;
//	uint8_t  _received    = 0U;
//	uint16_t _checksum    = 0U;
//
//	/* Check Data Count big than Protocol Length */
//	if(RingBuf_FIFO_Count(lilin_mag_rxbuf) < 8)
//	{
//		return (uint8_t)LiLin_Operate_MagDataLess;
//	}
//
//	while(1)
//	{
//		if(RingBuf_Read_8bit(lilin_mag_rxbuf, &_received) == READ_FAULT)
//		{
//			return (uint8_t)LiLin_Operate_Empty;
//		}
//
//		/* Make sure Data is Latest and Avoid Out of Bounds when Reading Ring-Buffer Data */
//		if((RingBuf_FIFO_Count(lilin_mag_rxbuf) < 15) && (RingBuf_FIFO_Count(lilin_mag_rxbuf) >= 7))
//		{
//			if(_received == LILIN_STARTBYTE)
//			{
//				_protocol[0] = _received;
//				break;
//			}
//			else
//			{
//				continue;
//			}
//		}
//
//		/* Timeout Determination */
//		_tick_count++;
//		if(_tick_count >= 1000)
//		{
//			return (uint8_t)LiLin_Operate_TimeOut;
//		}
//	}
//
//
//	test_cnt++;
//	if(test_cnt%1001 == 0)
//	{
//		test_cnt = 1;
//	}
//
//	for(uint8_t _idx = 1; _idx < 8; _idx++)
//	{
//		RingBuf_Read_8bit(lilin_mag_rxbuf, &_received);
//		_protocol[_idx] = _received;
//		if(_idx < 7)
//		{
//			_checksum += _received;
//		}
//	}
//
//	if((uint8_t)(_checksum & 0xFF) == _protocol[7])
//	{
//		_data->Ext_Mag_int[0] = (int16_t)((_protocol[1] << 8) | _protocol[2]);
//		_data->Ext_Mag_int[1] = (int16_t)((_protocol[3] << 8) | _protocol[4]);
//		_data->Ext_Mag_int[2] = (int16_t)((_protocol[5] << 8) | _protocol[6]);
//
//
////		sprintf(_str, "cnt: %d \r\n",test_cnt);
////		LPUART1_Send((uint8_t*)_str, strlen(_str));
//
//
//		return (uint8_t)LiLin_Operate_OK;
//	}
//	else
//	{
////		test_cnt--;
////		sprintf(_str, "LiLin_Operate_DecodeError \r\n");
////		LPUART1_Send((uint8_t*)_str, strlen(_str));
//		return (uint8_t)LiLin_Operate_DecodeError;
//	}
//
//}



float angle_trans(float _magYaw)
{
	float _360_Degree=0;

	if(_magYaw < 0 && _magYaw > -180)
	{
		_360_Degree = _magYaw + 360;
		return _360_Degree;
	}
	else
		return _magYaw;
}
float angle_inverse_trans(float _360_Degree)
{
	float _magYaw=0;

	if(_360_Degree > 180  && _360_Degree < 360)
	{
		_magYaw = _360_Degree - 360;
		return _magYaw;
	}
	else
		return _360_Degree;
}

float magAngle(float magX , float magY)
{
	return atan2(magY,magX)*R2D*(1.0);
}

//!*************************************************************************************************
//! @Function   :  Vast_Data_Get(lilin_data_t *_data)
//! @Description:  Protocol = {Header, FunCode, Encoder_MSB, Encoder_LSB, Command, FF, CRC}
//! @Param      :
//! @Return     :  None
//! @Create     :
//!*************************************************************************************************
uint8_t Vast_Data_Get(lilin_data_t *_data)
{
	uint8_t _received = 0;
//	uint32_t _tickstart = 0;
	uint16_t _tick_count = 0U;
	uint32_t _checksum = 0;
	uint8_t _protocol[6] = {0};

	/* Initialize */
//	_data->encoder.u16bit = 0U;
//	_data->angle  = 0.0f;
	_data->cmd    = 0U;
	_data->cmd2   = 0U;
	_data->status = 0U;

	/* Check Data Count big than Protocol Length */
	if(RingBuf_FIFO_Count(vast_rxbuf) < 7)
	{
		return (uint8_t)LiLin_Operate_DataLess;
	}

	/* Get the Last Frame */
//	_tickstart = HAL_GetTick();
	while(1)
	{
		if(RingBuf_Read_8bit(vast_rxbuf, &_received) == READ_FAULT)
		{
			return (uint8_t)LiLin_Operate_Empty;
		}
		/* Make sure Data is Latest and Avoid Out of Bounds when Reading Ring-Buffer Data */
		if((RingBuf_FIFO_Count(vast_rxbuf) < 14) && (RingBuf_FIFO_Count(vast_rxbuf) >= 6))
		{
			if(_received == LILIN_STARTBYTE)
			{
				_protocol[0] = _received;
				break;
			}
		}

		/* Timeout Determination */
		_tick_count++;
		if(_tick_count >= 1000)
		{
			return (uint8_t)LiLin_Operate_TimeOut;
		}
	}
	/* Received LiLin Protocol */
	for(int _idx = 1; _idx < 7 ;_idx++)
	{
		RingBuf_Read_8bit(vast_rxbuf, &_received);
		_protocol[_idx] = _received;
		if(_idx < 6)
		{
			_checksum += _received;
		}

	}

	/* Check Function Code and CRC Correct */
	if((_protocol[1] == VAST_FUNCODE_MAG_K) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->fCalMag  = _protocol[2];
		_data->lID   = 0;//_protocol[4];
		_data->hID  = 0;//_protocol[5];
		_data->status = VAST_FUNCODE_MAG_K;

		return (uint8_t)LiLin_Operate_OK;
	}
	else if((_protocol[1] == VAST_FUNCODE_ID) && ((uint8_t)(_checksum & 0xFF) == _protocol[6]))
	{
		/* Decode Frame Data */

		_data->hID  = _protocol[2];//hID
		_data->lID   = _protocol[3];//lID
//		_data->hID  = 0;//_protocol[5];
		_data->status = VAST_FUNCODE_ID;

		return (uint8_t)LiLin_Operate_OK;
	}
	else
	{
		return (uint8_t)LiLin_Operate_DecodeError;
	}

}




