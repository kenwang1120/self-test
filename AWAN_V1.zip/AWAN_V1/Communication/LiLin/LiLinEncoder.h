/**************************************************************
 *@Project :  stm32_m4_asm330_.v1.3_release
 *@FileName:  LiLinEncoder.h
 *@Purpose :  
 *            
 *-------------------------------------------------------------
 *@Copyright. Create by Macial.    2022年6月10日  下午2:48:20
 **************************************************************/
#ifndef LILINENCODER_H_
#define LILINENCODER_H_

#if defined(__cplusplus)
extern "C" {
#endif /*_cplusplus*/
/*==========================
*  Include Files
*=========================*/
#include "stm32f4xx_hal.h"

/*==========================
 *  Declare Type
 *=========================*/
/* Define */
#define LILIN_TIMEOUT_MS   1
#define LILIN_ENCODER_RES  0.01f
#define LILIN_STARTBYTE    (uint8_t)0xE2U
#define LILIN_TILT_ENCODER    (uint8_t)0x02U
#define LILIN_FUNCODE      (uint8_t)0x03U
#define LILIN_FUNCODE_TILT      (uint8_t)0x04U
#define LILIN_FUNCODE_PAN      (uint8_t)0x05U
#define LILIN_FUNCODE_MAG      (uint8_t)0x06U
#define LILIN_FUNCODE_CFG      (uint8_t)0x10U
#define LILIN_FUNCODE_REQ      (uint8_t)0x11U
#define VAST_FUNCODE_MAG_K      (uint8_t)0x20U
#define VAST_FUNCODE_ID      (uint8_t)0x21U

/* Enum */
typedef enum
{
	LiLin_Operate_Fail    = 0U,
	LiLin_Operate_OK      = 1U,

	LiLin_Operate_TimeOut      = 2U,
	LiLin_Operate_DataLess     = 3U,
	LiLin_Operate_Empty        = 4U,
	LiLin_Operate_DecodeError  = 5U,

	LiLin_Operate_MagDataLess  = 6U,
} lilin_operate_status_e;

/* Union */
typedef union
{
	uint16_t u16bit;    // u16bit is LowByte First
	uint8_t  u8bit[2];  // [0]:LowByte,[1]:HighByte
} encoder_axis1bit16_u;

/* Struct */
typedef struct
{
	encoder_axis1bit16_u encoder;
	int16_t tilt_Encoder;
	int16_t Ext_Mag_int[3];
	float   Ext_Mag_dec[3];

	float angle;
	uint8_t cmd;
	uint8_t cmd2;
	uint8_t subCmd;
	uint8_t pitchKp;
	uint8_t yawKp;
	uint8_t magWeight;
	uint8_t magTime;
	uint8_t kernelFreq;
	uint8_t baudRate;
	uint8_t outputDataRate;
	uint8_t rebootEnable;
	uint8_t writeFlashEnable;
	uint8_t versionEnable;
	uint8_t hardware;
	uint8_t version;
	uint8_t revision;
	uint8_t status;
	uint32_t magXHigh;
	uint32_t magXLow;
	uint32_t magYHigh;
	uint32_t magYLow;
	uint32_t mdyPosGain;
	uint32_t mdyNegGain;

	uint8_t fCalMag;
	uint8_t hID;
	uint8_t lID;
} lilin_data_t;

/*==========================
 *  Declare Application
 *=========================*/
//void LiLin_Data_Collect(uint8_t _data);
uint8_t LiLin_Data_Get(lilin_data_t *_data);
float angle_trans(float _magYaw);
float angle_inverse_trans(float _360Degree);
float magAngle(float magX,float magY);

uint8_t LiLin_MagData_Get(lilin_data_t *_data);
uint8_t Vast_Data_Get(lilin_data_t *_data);

/*==========================
 *  Declare Global Variables
 *=========================*/
extern lilin_data_t lilin_data;
extern lilin_data_t vast_data;
//extern uint8_t lilin_collect_complete;


#if defined(__cplusplus)
}
#endif /*_cplusplus*/

#endif /* LILINENCODER_H_ */
