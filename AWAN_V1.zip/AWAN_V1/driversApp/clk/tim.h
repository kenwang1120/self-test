/**
  ******************************************************************************
  * @file    tim.h
  * @brief   This file contains all the function prototypes for
  *          the tim.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __TIM_H__
#define __TIM_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "appbase.h"


/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

void MX_TIM2_Init(void);
void MX_TIM3_Init(void);
//void MX_TIM12_Init(void)

/* USER CODE BEGIN Prototypes */
#define TIM3_IRQn                      TIM3_IRQn
#define TIM3_UPCOUNT_IRQHandler        TIM3_IRQHandler
#define TIM2_IRQn                      TIM2_IRQn
#define TIM2_UPCOUNT_IRQHandler        TIM2_IRQHandler
#define TIM8_IRQn                      TIM8_IRQn
#define TIM8_UPCOUNT_IRQHandler        TIM8_IRQHandler





void LPIT0_Init(uint32_t _us);
void LPIT0_START(void);
uint32_t getSysTick(void);
uint32_t getSys2Tick(void);
void wdiFeedWdog(void);
//void delaysTcnt(uint32_t t_count);
uint32_t get_start_timestamp(void);
uint32_t get_timestamp(void);


/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __TIM_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
