//*********************************************************************//
// @ file name : stm_flash.h
// @ descripe  : [Drivers Layer]
// @
// @
// @ Create by Macial Copy right. Create on Nov 18, 2021  6:15:24 PM.
//*********************************************************************//
#ifndef __STM_FLASH_H_
#define __STM_FLASH_H_

#ifdef __cplusplus
 extern "C" {
#endif
 /*------------------------------- include files---------------------------------*/
//#include <stdint.h>
#include <stm32f4xx_hal.h>

 /*------------------------------- definition------------------------------------*/
#define STM_FLASH_SECTOR_0        0x08000000UL                             /* Base @ of Sector 0,  16  Kbytes */
#define STM_FLASH_SECTOR_1        0x08004000UL                             /* Base @ of Sector 1,  16  Kbytes */
#define STM_FLASH_SECTOR_2        0x08008000UL                             /* Base @ of Sector 2,  16  Kbytes */
#define STM_FLASH_SECTOR_3        0x0800C000UL                             /* Base @ of Sector 3,  16  Kbytes */
#define STM_FLASH_SECTOR_4        0x08010000UL                             /* Base @ of Sector 4,  64  Kbytes */
#define STM_FLASH_SECTOR_5        0x08020000UL                             /* Base @ of Sector 5,  128 Kbytes */
#define STM_FLASH_SECTOR_6        0x08040000UL                             /* Base @ of Sector 6,  128 Kbytes */
#define STM_FLASH_SECTOR_7        0x08060000UL                             /* Base @ of Sector 7,  128 Kbytes */
#define STM_FLASH_SECTOR_8        0x08080000UL                             /* Base @ of Sector 8,  128 Kbytes */
#define STM_FLASH_SECTOR_9        0x080A0000UL                             /* Base @ of Sector 9,  128 Kbytes */
#define STM_FLASH_SECTOR_10       0x080C0000UL                             /* Base @ of Sector 10, 128 Kbytes */
#define STM_FLASH_SECTOR_11       0x080E0000UL                             /* Base @ of Sector 11, 128 Kbytes */
#define STM_FLASH_SECTOR_11_END   0x080FFFFFUL                             /* Main Memory boundary */

/* define flash block start address, bootloader */
 /* 48 Kbytes, start 0x08000000 ~ 0x0800BFFF */
#define FLASH_BOOTLOADER_START      STM_FLASH_SECTOR_0
#define FLASH_BOOTLOADER_END       (STM_FLASH_SECTOR_3 - 1UL)


/* define flash block start address, calibration parameter */
/* 1 Kbytes, start 0x0800C000 ~ 0x0800C3FF */
#if defined TEST_VERSION
	#define FLASH_BLOCK_1_START         STM_FLASH_SECTOR_11                        // default:  STM_FLASH_SECTOR_3
#else
	#define FLASH_BLOCK_1_START         STM_FLASH_SECTOR_3                         // default:  STM_FLASH_SECTOR_3
#endif
#define FLASH_BLOCK_1_END          (FLASH_BLOCK_1_START + 0x00000400UL - 1UL)
/* 1 Kbytes, start 0x0800C400 ~ 0x0800C7FF */
#define FLASH_BLOCK_2_START        (FLASH_BLOCK_1_START + 0x00000400UL)
#define FLASH_BLOCK_2_END          (FLASH_BLOCK_1_START + 0x00000800UL - 1UL)
/* 14 Kbytes, start 0x0800C800 ~ 0x0800CFFF */
#define FLASH_BLOCK_3_START        (FLASH_BLOCK_1_START + 0x00000800UL)
#define FLASH_BLOCK_3_END          (FLASH_BLOCK_1_START + 0x00004000UL - 1UL)  /* flash block boundary  */


/*============================================================================================================================*/
/******************************
 *  For Tim.chen Flash Sector *
 ******************************/
#define TIM_BLOCK_START      STM_FLASH_SECTOR_4
#define TIM_BLOCK_END        (STM_FLASH_SECTOR_4 + 0x00010000UL - 1UL)


/*============================================================================================================================*/


#define FLASH_TIMEOUT         5000U                                 /* 5 sec */


 /*------------------------------- enum declare----------------------------------*/
typedef enum
{
	Flash_Operate_Fail  = (uint8_t)0,
	Flash_Operate_OK    = (uint8_t)1,
} flash_operate_statu_e;

//typedef enum
//{
//	IMU_Calibrate_Param_Block = 0,
//	Mag_Calibrate_Param_Block = 1,
//	Product_id_Block          = 2,
//
//	Tim_Block                 = 3,
//} flash_block_e;

/* Old version flash block definition */
typedef enum
{
	Old_Calibrate_Param_Block = 0,
	Old_Gain_Param_Block      = 1,
	Old_Product_id_Block      = 2,

	Old_Tim_Block             = 3,
} flash_block_e;
 /*------------------------------- struct declare--------------------------------*/


 /*------------------------------- variable declare------------------------------*/


 /*------------------------------- function declare------------------------------*/
 uint8_t Erase_Flash_Block(int _block);
 uint8_t Read_Flash(uint32_t _addr, int *_data, uint32_t _data_len);
 uint8_t Write_Flash(uint32_t _addr, int *_data, uint32_t _data_len);
 uint8_t Read_Flash_Block(flash_block_e _block, int *_data, uint32_t _data_len);
// uint8_t Write_Flash_Block(flash_block_e _block, int *_data, uint32_t _data_len);

 void readFromFlashNVM(float* params, int* config, float res_accel, float res_gyro, float res_mag);
 uint8_t write_flash_block(uint32_t *_data, uint8_t _data_len, int _block);
 void initFlashNVM(uint32_t* params, uint8_t msgLen);
 void Flash_Block_Init(int _block);
 void readFromFlashNVM_2(uint32_t* params, int* config);
 void initFlashNVM_para2(uint32_t* params, uint8_t msgLen);




#ifdef __cplusplus
 }
#endif

#endif /* DRIVERAPP_INC_STM_FLASH_H_ */
