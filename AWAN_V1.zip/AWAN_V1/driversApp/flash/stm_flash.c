//*******************************************************************//
// @ file name : stm_flash.c
// @ describe  :
//
// @ Create by Macial Copy right. Create on Nov 18, 2021  11:02:30 AM.
//*******************************************************************//
/*------------------------------- include files----------------------------------*/
//#include "stm32f4xx_hal_def.h"
#include <stm32f4xx_hal.h>
#include "stm_flash.h"


/*------------------------------- declare variable------------------------------*/
#define BUFFER_LEN 32

/*------------------------------- function code---------------------------------*/
/**********************************************************************************
 * @function: uint8_t Erase_Flash_Block(void)
 * @describe:
 *            Erase all flash block(Sector 0) of Calibration parameter.
 *            If fault, try to reboot MCU.
 *
 * @return    0:success / 1:erase fault / 2:unlock fault
 **********************************************************************************/
uint8_t Erase_Flash_Block(int _block)
{
	FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t SectorError = 0;

	__disable_irq();
	/* Start erase */
	if (HAL_FLASH_Unlock() != HAL_OK)
	{
		/* please reboot reset MCU */
		return Flash_Operate_Fail;
	}

	/* Select Erase Sector */
	switch(_block)
	{
//	/* SECTOR[2:0] is Bootloader located */
//	case FLASH_SECTOR_0:
//		EraseInitStruct.Sector = FLASH_SECTOR_0;
//		break;
//	case FLASH_SECTOR_1:
//		EraseInitStruct.Sector = FLASH_SECTOR_1;
//		break;
//	case FLASH_SECTOR_2:
//		EraseInitStruct.Sector = FLASH_SECTOR_2;
//		break;

	/* SECTOR[3] is Parameter located */
	case FLASH_SECTOR_3:
		EraseInitStruct.Sector = FLASH_SECTOR_3;
		break;

	/* SECTOR[4] is Tim defined located */
	case FLASH_SECTOR_4:
		EraseInitStruct.Sector = FLASH_SECTOR_4;
		break;

	/* SECTOR[11:5] is Application located */
	case FLASH_SECTOR_5:
		EraseInitStruct.Sector = FLASH_SECTOR_5;
		break;
	case FLASH_SECTOR_6:
		EraseInitStruct.Sector = FLASH_SECTOR_6;
		break;
	case FLASH_SECTOR_7:
		EraseInitStruct.Sector = FLASH_SECTOR_7;
		break;
	case FLASH_SECTOR_8:
		EraseInitStruct.Sector = FLASH_SECTOR_8;
		break;
	case FLASH_SECTOR_9:
		EraseInitStruct.Sector = FLASH_SECTOR_9;
		break;
	case FLASH_SECTOR_10:
		EraseInitStruct.Sector = FLASH_SECTOR_10;
		break;
	case FLASH_SECTOR_11:
		EraseInitStruct.Sector = FLASH_SECTOR_11;
		break;

	default:
		HAL_FLASH_Lock();
		__enable_irq();
		return Flash_Operate_Fail;
	}

	EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORS;   // set Sector Erase
	EraseInitStruct.VoltageRange = FLASH_VOLTAGE_RANGE_3;  // ref stm32f411_Reference_manual.pdf p.45
	EraseInitStruct.NbSectors = 1u;                        // Number of sectors to be erased

	if(HAL_FLASHEx_Erase(&EraseInitStruct, &SectorError) != HAL_OK)
	{
		/* UART output error code */

		return Flash_Operate_Fail;
	}

	/* Cleared  */
	__HAL_FLASH_DATA_CACHE_DISABLE();
	__HAL_FLASH_INSTRUCTION_CACHE_DISABLE();

	__HAL_FLASH_DATA_CACHE_RESET();
	__HAL_FLASH_INSTRUCTION_CACHE_RESET();

	__HAL_FLASH_INSTRUCTION_CACHE_ENABLE();
	__HAL_FLASH_DATA_CACHE_ENABLE();

	__enable_irq();

	return Flash_Operate_OK;
}

/**********************************************************************************
 * @function: uint8_t Read_Flash(uint32_t block_addr, int *_data, uint32_t _data_len)
 * @describe:
 *            Read stm32 flash block by address
 *
 * @return    0:success/ 1:fault
 **********************************************************************************/
uint8_t Read_Flash(uint32_t _addr, int *_data, uint32_t _data_len)
{
	for(uint32_t _idx=0; _idx < _data_len; _idx++)
	{
		_data[_idx] = *(volatile uint32_t*)(_addr + _idx*4u);
	}

	return Flash_Operate_OK;
}

/**********************************************************************************
 * @function: uint8_t Write_Flash(uint32_t block_addr, int *_data, uint32_t _data_len)
 * @describe:
 *            Read stm32 flash block by address
 *
 * @return    0:success/ 1:fault
 **********************************************************************************/
uint8_t Write_Flash(uint32_t _addr, int *_data, uint32_t _data_len)
{
	uint8_t status;

	/* Bootloader can't write */
	if((_addr >= (uint32_t)FLASH_BOOTLOADER_START) && (_addr <= (uint32_t)FLASH_BOOTLOADER_END))
	{
		return Flash_Operate_Fail;
	}

	/*Program word (32-bit) at a specified address.*/
	for(uint32_t _idx=0; _idx < _data_len; _idx++)
	{
		status = (uint8_t)HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, (_addr + _idx*4u), _data[_idx]);
		if(status != (uint8_t)HAL_OK) return status;
	}

	return Flash_Operate_OK;
}

/**********************************************************************************
 * @function: uint8_t Read_Flash_Block(flash_block_e _block , int *_data,
 *                                                            uint32_t _data_len)
 * @describe:
 *            Read stm32 flash block
 *
 * @return    0:success/ 1:block not found / 2:data out of range
 **********************************************************************************/
uint8_t Read_Flash_Block(flash_block_e _block, int *_data, uint32_t _data_len)
{
	switch(_block)
	{
		case Old_Calibrate_Param_Block:
//		case IMU_Calibrate_Param_Block:
			if((FLASH_BLOCK_1_START +_data_len*4u - 1u) > FLASH_BLOCK_1_END) return 2u;   // 0x08008000 ~ 0x080083FF
			return Read_Flash(FLASH_BLOCK_1_START, _data, _data_len);

		case Old_Gain_Param_Block:
//		case Mag_Calibrate_Param_Block:
			if((FLASH_BLOCK_2_START +_data_len*4u - 1u) > FLASH_BLOCK_2_END) return 2u;  // 0x08000100 ~ 0x080001FF
			return Read_Flash(FLASH_BLOCK_2_START, _data, _data_len);

		case Old_Product_id_Block:
//		case Product_id_Block:
			if((FLASH_BLOCK_3_START +_data_len*4u - 1u) > FLASH_BLOCK_3_END) return 2u;     // 0x08000200 ~ 0x080000FF
			return Read_Flash(FLASH_BLOCK_3_START, _data, _data_len);

		case Old_Tim_Block:
			if((TIM_BLOCK_START +_data_len*4u - 1u) > TIM_BLOCK_END) return 2u;     // 0x08000200 ~ 0x080000FF
			return Read_Flash(TIM_BLOCK_START, _data, _data_len);

		default:
			return 1u;
	}
}
//void readFromFlashNVM_2(int* params, int* config)
//{
//    uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
//    uint32_t destAdrss = (uint32_t)STM_FLASH_SECTOR_4;                /* Address of the target location */
//    uint32_t symbol;
//    for (uint32_t i = 0; i < 10; i++)
//    {
//        s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
//      //  symbol = s_buffer_rbc[i] & 0x80000000;
//       params[i] = (int)(s_buffer_rbc[i]) ;
//
//
//
//    }
//}//replace by line 568

void readFromFlashNVM(float* params, int* config, float res_accel, float res_gyro, float res_mag)
{
    uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
    uint32_t destAdrss = (uint32_t)FLASH_BLOCK_1_START;                /* Address of the target location */
    uint32_t symbol;
    for (uint32_t i = 0; i < 28; i++)
    {
        s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
        symbol = s_buffer_rbc[i] & 0x80000000;
        if(i <12)
        {
          params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_accel;
          if(symbol != 0)
            params[i] = -params[i];
          //printf("params[%d]: %.4f \r\n", i, params[i]);
        }
        else if((i >=12) && (i < 15))/*12 - 14*/
        {
          params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_gyro;
          if(symbol != 0 )
            params[i] = -params[i];
          //printf("params[%d]: %.4f \r\n", i, params[i]);
        } else if((i >=15) && (i < 27))/*15 - 26*/
        {
          params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_mag;
          if(symbol != 0 )
            params[i] = -params[i];
          //printf("params[%d]: %.4f \r\n", i, params[i]);
        }else{//Read config param
          *config = s_buffer_rbc[27];
        }
//            if (s_buffer_rbc[i] != s_buffer[i])
//            {
//                error_trap();
//            }
//        printf("s_buffer_rbc[%d]: %d \r\n", (int)i, (int)s_buffer_rbc[i]);

    }
}








/**********************************************************************************
 * @function: uint8_t Write_Flash_Block(flash_block_e _block, int *_data)
 * @describe:
 *            Write stm32 flash block
 *
 * @return    0:success / 1:block not found / 2:write error
 *            3:erase fault / 4:unlock fault / 5:read error
 **********************************************************************************/
uint8_t write_flash_block(uint32_t *_data, uint8_t _data_len, int _block)
{
	uint8_t _statu = 0u;

	/* Get all flash block data */
	int block1_data[256] = {0};
	int block2_data[256] = {0};
	int block3_data[256] = {0};

	/* Disable all interrupt */
	__disable_irq();

//	if(Read_Flash_Block(IMU_Calibrate_Param_Block,block1_data, 256) != (uint8_t)HAL_OK)
//		return Flash_Operate_Fail;
//	if(Read_Flash_Block(Mag_Calibrate_Param_Block,block2_data, 256) != (uint8_t)HAL_OK)
//		return Flash_Operate_Fail;
//	if(Read_Flash_Block(Product_id_Block,block3_data, 256) != (uint8_t)HAL_OK)
//		return Flash_Operate_Fail;

	if(Read_Flash_Block(Old_Calibrate_Param_Block,block1_data, 256) != (uint8_t)HAL_OK)
		return Flash_Operate_Fail;
	if(Read_Flash_Block(Old_Gain_Param_Block,block2_data, 256) != (uint8_t)HAL_OK)
		return Flash_Operate_Fail;
	if(Read_Flash_Block(Old_Product_id_Block,block3_data, 256) != (uint8_t)HAL_OK)
		return Flash_Operate_Fail;

	/* Unlock the Flash to enable the flash control register access */
	if(HAL_FLASH_Unlock() != (uint8_t)HAL_OK ) _statu = Flash_Operate_Fail;

	/* Erase Select Flash Block in Sector, set 0 -> 1 */
	switch(_block)
	{
	case Old_Tim_Block:
//	case Tim_Block:
		if((_statu == (uint8_t)HAL_OK) && (Erase_Flash_Block(FLASH_SECTOR_4) != (uint8_t)HAL_OK))
		{
			_statu = Flash_Operate_Fail;
		}
		break;

	case Old_Calibrate_Param_Block:
	case Old_Gain_Param_Block:
	case Old_Product_id_Block:
//	case IMU_Calibrate_Param_Block:
//	case Mag_Calibrate_Param_Block:
//	case Product_id_Block:
	default:
		if((_statu == (uint8_t)HAL_OK) && (Erase_Flash_Block(FLASH_SECTOR_3) != (uint8_t)HAL_OK))
		{
			_statu = Flash_Operate_Fail;
		}
		break;
	}

	/* Write Data in Flash block */
	if(_statu == (uint8_t)HAL_OK)
	{
		switch(_block)
		{
			case Old_Calibrate_Param_Block:
//			case IMU_Calibrate_Param_Block:
				/* write data in block */
				if(Write_Flash(FLASH_BLOCK_1_START, (int*)_data, _data_len) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				if(Write_Flash(FLASH_BLOCK_2_START, block2_data, 64u) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				if(Write_Flash(FLASH_BLOCK_3_START, block3_data, 64u) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				break;

			case Old_Gain_Param_Block:
//			case Mag_Calibrate_Param_Block:
				/* write data in block */
				if(Write_Flash(FLASH_BLOCK_1_START, block1_data, 64u) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				if(Write_Flash(FLASH_BLOCK_2_START, (int*)_data, _data_len) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				if(Write_Flash(FLASH_BLOCK_3_START, block3_data, 64u) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				break;

			case Old_Product_id_Block:
//			case Product_id_Block:
				/* write data in block */
				if(Write_Flash(FLASH_BLOCK_1_START, block1_data, 64u) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				if(Write_Flash(FLASH_BLOCK_2_START, block2_data, 64u) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				if(Write_Flash(FLASH_BLOCK_3_START, (int*)_data, _data_len) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				break;

			case Old_Tim_Block:
//			case Tim_Block:
				/* write data in block */
				if(Write_Flash(TIM_BLOCK_START, (int*)_data, _data_len) != Flash_Operate_OK) _statu = Flash_Operate_Fail;
				break;

			default:
				_statu = Flash_Operate_Fail;
				break;
		}
	}

	HAL_FLASH_Lock();
	/* Enable all interrupt */
	__enable_irq();

	return _statu;

}

//uint8_t Write_Flash_Block(flash_block_e _block, int *_data, uint32_t _data_len)
//{
//	uint8_t _statu = 0u;
//
//	/* Get all flash block data */
//	int block1_data[64] = {0};
//	int block2_data[64] = {0};
//	int block3_data[64] = {0};
//
//	/* Disable all interrupt */
//	__disable_irq();
//
//	if(Read_Flash_Block(IMU_Calibrate_Param_Block,block1_data, 64u) != (uint8_t)HAL_OK)
//		return 5u;
//	if(Read_Flash_Block(Mag_Calibrate_Param_Block,block2_data, 64u) != (uint8_t)HAL_OK)
//		return 5u;
//	if(Read_Flash_Block(Product_id_Block,block3_data, 64u) != (uint8_t)HAL_OK)
//		return 5u;
//
//	/* Unlock the Flash to enable the flash control register access */
//	if(HAL_FLASH_Unlock() != (uint8_t)HAL_OK ) _statu = 4u;
//	/* Erase all Flash Block, set 0 -> 1 */
//	if((_statu == (uint8_t)HAL_OK) && (Erase_Flash_Block() != (uint8_t)HAL_OK)) _statu = 3u;
//
//	/* Write Data in Flash block */
//	if(_statu == (uint8_t)HAL_OK)
//	{
//		switch(_block)
//		{
//			case IMU_Calibrate_Param_Block:
//				/* write data in block */
//				if(Write_Flash(FLASH_BLOCK_1, _data, _data_len) != Flash_Operate_OK) _statu = 2u;
//				if(Write_Flash(FLASH_BLOCK_2, block2_data, 64u) != Flash_Operate_OK) _statu = 2u;
//				if(Write_Flash(FLASH_BLOCK_3, block3_data, 64u) != Flash_Operate_OK) _statu = 2u;
//				break;
//
//			case Mag_Calibrate_Param_Block:
//				/* write data in block */
//				if(Write_Flash(FLASH_BLOCK_1, block1_data, 64u) != Flash_Operate_OK) _statu = 2u;
//				if(Write_Flash(FLASH_BLOCK_2, _data, _data_len) != Flash_Operate_OK) _statu = 2u;
//				if(Write_Flash(FLASH_BLOCK_3, block3_data, 64u) != Flash_Operate_OK) _statu = 2u;
//				break;
//
//			case Product_id_Block:
//				/* write data in block */
//				if(Write_Flash(FLASH_BLOCK_1, block1_data, 64u) != Flash_Operate_OK) _statu = 2u;
//				if(Write_Flash(FLASH_BLOCK_2, block2_data, 64u) != Flash_Operate_OK) _statu = 2u;
//				if(Write_Flash(FLASH_BLOCK_3, _data, _data_len) != Flash_Operate_OK) _statu = 2u;
//				break;;
//
//			default:
//				_statu = 1u;
//				break;
//		}
//	}
//
//	HAL_FLASH_Lock();
//	/* Enable all interrupt */
//	__enable_irq();
//
//	return _statu;
//
//}

//void initFlashNVM_para2(uint32_t* params, uint8_t msgLen)
//{
//    uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
//    //uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
//    uint32_t destAdrss = (uint32_t)STM_FLASH_SECTOR_4;                /* Address of the target location */
//
//#if defined TEST_VERSION
//    Erase_Flash_Block(FLASH_SECTOR_11);
//#else
//    Erase_Flash_Block(FLASH_SECTOR_4);
//#endif
//
//    for (uint32_t i = 0; i < BUFFER_LEN; i++)
//    {
//        //s_buffer[i] = i;
//      if(i < msgLen)
//      {
//        s_buffer[i] = params[i];
////             sprintf(arr, "i=%d, %d,",i,params[i]);
////             LPUART1_Send((uint8_t const*)arr, strlen(arr));
//      }
//      else
//      {
//        s_buffer[i] = 0;
////            sprintf(arr, "i=%d,==>0 %d,",i,params[i]);
////            LPUART1_Send((uint8_t const*)arr, strlen(arr));
//
//      }
//    }
//
//    Write_Flash(destAdrss, (int*)s_buffer, sizeof(s_buffer));
//}//move to line 580

void initFlashNVM(uint32_t* params, uint8_t msgLen)
{
    uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
    //uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
    uint32_t destAdrss = (uint32_t)FLASH_BLOCK_1_START;                /* Address of the target location */

#if defined TEST_VERSION
    Erase_Flash_Block(FLASH_SECTOR_11);
#else
    Erase_Flash_Block(FLASH_SECTOR_3);
#endif

    for (uint32_t i = 0; i < BUFFER_LEN; i++)
    {
        //s_buffer[i] = i;
      if(i < msgLen)
      {
        s_buffer[i] = params[i];
//             sprintf(arr, "i=%d, %d,",i,params[i]);
//             LPUART1_Send((uint8_t const*)arr, strlen(arr));
      }
      else
      {
        s_buffer[i] = 0;
//            sprintf(arr, "i=%d,==>0 %d,",i,params[i]);
//            LPUART1_Send((uint8_t const*)arr, strlen(arr));

      }
    }

    Write_Flash(destAdrss, (int*)s_buffer, sizeof(s_buffer));
}


/*  */
void Flash_Block_Init(int _block)
{

	int _init_data[27] = {1000, 0, 0, 0, 1000, 0, 0, 0, 1000,
			              0, 0, 0, 0, 0, 0,
						  1000, 0, 0, 0, 1000, 0, 0, 0, 1000,
						  0, 0, 0};

#if defined TEST_VERSION
	Erase_Flash_Block(FLASH_SECTOR_11);
#else
	Erase_Flash_Block(FLASH_SECTOR_3);
#endif

	/* write data in block */
	Write_Flash(FLASH_BLOCK_1_START, _init_data, 27U);

//	switch(_block)
//	{
//		case Old_Calibrate_Param_Block:
////		case IMU_Calibrate_Param_Block:
//			Erase_Flash_Block(FLASH_SECTOR_2);
//			/* write data in block */
//			if(Write_Flash(FLASH_BLOCK_1_START, _init_data, 27) != Flash_Operate_OK)
//			{
//			}
//			break;
//
//		case Old_Gain_Param_Block:
////		case Mag_Calibrate_Param_Block:
//			Erase_Flash_Block(FLASH_SECTOR_2);
//			/* write data in block */
//			if(Write_Flash(FLASH_BLOCK_2_START, _init_data, 27) != Flash_Operate_OK)
//			{
//			}
//			break;
//
//		case Old_Product_id_Block:
////		case Product_id_Block:
//			Erase_Flash_Block(FLASH_SECTOR_2);
//			/* write data in block */
//			if(Write_Flash(FLASH_BLOCK_3_START, _init_data, 27) != Flash_Operate_OK)
//			{
//			}
//			break;
//
//		case Old_Tim_Block:
////		case Tim_Block:
//			Erase_Flash_Block(FLASH_SECTOR_3);
//			/* write data in block */
//			if(Write_Flash(TIM_BLOCK_START, _init_data, 27) != Flash_Operate_OK)
//			{
//			}
//			break;
//
//		default:
//			Erase_Flash_Block(FLASH_SECTOR_2);
//			if(Write_Flash(FLASH_BLOCK_1_START, _init_data, 27) != Flash_Operate_OK)
//			{
//			}
//			break;
//	}

}


void readFromFlashNVM_2(uint32_t* params, int* config)
{
    uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
    uint32_t destAdrss = (uint32_t)STM_FLASH_SECTOR_4;                /* Address of the target location */
//    uint32_t symbol;
    for (uint32_t i = 0; i < 32; i++)
    {
        s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
       params[i] = (int)(s_buffer_rbc[i]) ;
    }
}

void initFlashNVM_para2(uint32_t* params, uint8_t msgLen)
{
    uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
    //uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
    uint32_t destAdrss = (uint32_t)STM_FLASH_SECTOR_4;                /* Address of the target location */

#if defined TEST_VERSION
    Erase_Flash_Block(FLASH_SECTOR_11);
#else
    Erase_Flash_Block(FLASH_SECTOR_4);
#endif

    for (uint32_t i = 0; i < BUFFER_LEN; i++)
    {
        //s_buffer[i] = i;
      if(i < msgLen)
      {
        s_buffer[i] = params[i];
//             sprintf(arr, "i=%d, %d,",i,params[i]);
//             LPUART1_Send((uint8_t const*)arr, strlen(arr));
      }
      else
      {
        s_buffer[i] = 0;
//            sprintf(arr, "i=%d,==>0 %d,",i,params[i]);
//            LPUART1_Send((uint8_t const*)arr, strlen(arr));

      }
    }

    Write_Flash(destAdrss, (int*)s_buffer, sizeof(s_buffer));
}




