/**
  ******************************************************************************
  * @file    i2c.h
  * @brief   This file contains all the function prototypes for
  *          the i2c.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __I2C_H__
#define __I2C_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "appbase.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */
extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c3;



/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */


/* USER CODE BEGIN Prototypes */
//void HAL_I2C_MspInit(I2C_HandleTypeDef* i2cHandle);
//void HAL_I2C_MspDeInit(I2C_HandleTypeDef* i2cHandle);

void LPI2C1_Init(void);
void LPI2C3_Init(void);
uint8_t LPI2C1_Write(uint8_t deviceAddress, uint8_t subAddress, uint8_t *txbuff, uint8_t length);
uint8_t LPI2C1_Read(uint8_t deviceAddress, uint8_t subAddress, uint8_t *rxbuff, uint8_t length);
uint8_t LPI2C3_Write(uint8_t deviceAddress, uint8_t subAddress, uint8_t *txbuff, uint8_t length);
uint8_t LPI2C3_Read(uint8_t deviceAddress, uint8_t subAddress, uint8_t *rxbuff, uint8_t length);






/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __I2C_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
