/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "appbase.h"
#include "ringBuff.h"

#define USART1_IRQn                   USART1_IRQn
#define USART1_RX_IRQHandler          USART1_IRQHandler
#define USART3_IRQn                   USART3_IRQn
#define USART3_RX_IRQHandler          USART3_IRQHandler
#define USART6_IRQn                   USART6_IRQn
#define USART6_RX_IRQHandler          USART6_IRQHandler

extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart6;

extern ringBuffer_t uart1_rxbuf;
extern ringBuffer_t uart3_rxbuf;
extern ringBuffer_t uart6_rxbuf;



/* USER CODE BEGIN Prototypes */
//void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle);
//void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle);


void LPUART1_Init(uint32_t _baudrate);
void LPUART3_Init(uint32_t _baudrate);
void LPUART6_Init(uint32_t _baudrate);
void LPUART1_RTS_CTS_CTRL(int _status);
void LPUART1_Send(uint8_t *_data, int _length);
void LPUART1_Receive(uint8_t *_data, int _length);
void LPUART3_Send(uint8_t *_data, int _length);
void LPUART3_Receive(uint8_t *_data, int _length);
void LPUART6_Send(uint8_t *_data, int _length);
void LPUART6_Receive(uint8_t *_data, int _length);


/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
