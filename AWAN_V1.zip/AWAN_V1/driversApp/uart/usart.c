/**
  ******************************************************************************
  * @file    usart.c
  * @brief   This file provides code for the configuration
  *          of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"
#include "ringBuff.h"
#include "LiLinEncoder.h"


UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;
UART_HandleTypeDef huart6;

ringBuffer_t uart1_rxbuf;
ringBuffer_t uart3_rxbuf;
ringBuffer_t uart6_rxbuf;

static uint8_t receive_uart1_data = 0;
static uint8_t receive_uart3_data = 0;
static uint8_t receive_uart6_data = 0;
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspInit 0 */

  /* USER CODE END USART1_MspInit 0 */
    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART1 interrupt Init */
    HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspInit 1 */

  /* USER CODE END USART1_MspInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspInit 0 */

  /* USER CODE END USART6_MspInit 0 */
    /* USART6 clock enable */
    __HAL_RCC_USART6_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF8_USART6;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART6 interrupt Init */
    HAL_NVIC_SetPriority(USART6_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspInit 1 */

  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART6_MspInit 0 */

  /* USER CODE END USART6_MspInit 0 */
    /* USART6 clock enable */
    __HAL_RCC_USART3_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**USART6 GPIO Configuration
    PC10     ------> USART6_TX
    PC11     ------> USART6_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USART6 interrupt Init */
    HAL_NVIC_SetPriority(USART3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART3_IRQn);

  /* USER CODE END USART6_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART1)
  {
  /* USER CODE BEGIN USART1_MspDeInit 0 */

  /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PA9     ------> USART1_TX
    PA10     ------> USART1_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

    /* USART1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART1_IRQn);
  /* USER CODE BEGIN USART1_MspDeInit 1 */

  /* USER CODE END USART1_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART6)
  {
  /* USER CODE BEGIN USART6_MspDeInit 0 */

  /* USER CODE END USART6_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART6_CLK_DISABLE();

    /**USART6 GPIO Configuration
    PC6     ------> USART6_TX
    PC7     ------> USART6_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6|GPIO_PIN_7);

    /* USART6 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART6_IRQn);
  /* USER CODE BEGIN USART6_MspDeInit 1 */

  }
  else if(uartHandle->Instance==USART3)
  {
    /* Peripheral clock disable */
    __HAL_RCC_USART3_CLK_DISABLE();

    /**USART6 GPIO Configuration
    PC10     ------> USART6_TX
    PC11     ------> USART6_RX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_10|GPIO_PIN_11);

    /* USART6 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART3_IRQn);

  /* USER CODE END USART6_MspDeInit 1 */
  }
}



void LPUART1_Init(uint32_t _baudrate)
{
	huart1.Instance = USART1;
	huart1.Init.BaudRate = _baudrate;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart1) != HAL_OK)
	{
		Error_Handler();
	}
	LPUART1_RTS_CTS_CTRL(0);    // Received
	HAL_UART_Receive_IT(&huart1,&receive_uart1_data,1);

}

void LPUART6_Init(uint32_t _baudrate)
{
	huart6.Instance = USART6;
	huart6.Init.BaudRate = _baudrate;
	huart6.Init.WordLength = UART_WORDLENGTH_8B;
	huart6.Init.StopBits = UART_STOPBITS_1;
	huart6.Init.Parity = UART_PARITY_NONE;
	huart6.Init.Mode = UART_MODE_TX_RX;
	huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart6.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart6) != HAL_OK)
	{
		Error_Handler();
	}
	HAL_UART_Receive_IT(&huart6,&receive_uart6_data,1);
}

void LPUART3_Init(uint32_t _baudrate)
{
  huart3.Instance = USART3;
  huart3.Init.BaudRate = _baudrate;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_UART_Receive_IT(&huart3,&receive_uart3_data,1);
}


void LPUART1_RTS_CTS_CTRL(int _status)
{
	if(_status == 0){
		HAL_GPIO_WritePin(UART1_RTS_GPIO_Port, UART1_RTS_Pin, GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(UART1_RTS_GPIO_Port, UART1_RTS_Pin, GPIO_PIN_SET);
	}
}

void LPUART1_Send(uint8_t *_data, int _length)
{
	LPUART1_RTS_CTS_CTRL(1);

	if(HAL_UART_Transmit(&huart1, _data, _length, 3000u) != HAL_OK)
	{

		uint8_t _ErrorCode[13] = {'u','a','r','t','1',' ','e','r','r','o','r','\r','\n'};
		LPUART6_Send(_ErrorCode, 13);

//		asm("BKPT #0");
	}
	__DSB();
	LPUART1_RTS_CTS_CTRL(0);
}

void LPUART1_Receive(uint8_t *_data, int _length)
{
	LPUART1_RTS_CTS_CTRL(0);
	if(HAL_UART_Receive_IT(&huart1, _data, _length) != HAL_OK)
	{
//		asm("BKPT #0");
	}

//	if(HAL_UART_Receive(&huart1, _data, _length, 3000u) != HAL_OK)
//	{
////		asm("BKPT #0");
//	}
	LPUART1_RTS_CTS_CTRL(1);
}

void LPUART3_Send(uint8_t *_data, int _length)
{

	if((huart3.gState == HAL_UART_STATE_READY) && (huart3.Lock == HAL_LOCKED))
	{
		__HAL_UNLOCK(&huart1);
	}

	if(HAL_UART_Transmit(&huart3, _data, _length, 3000u) != HAL_OK)
	{
    		uint8_t _ErrorCode[13] = {'u','a','r','t','3',' ','e','r','r','o','r','\r','\n'};
    		LPUART6_Send(_ErrorCode, 13);
//		asm("BKPT #0");
	}
}

void LPUART3_Receive(uint8_t *_data, int _length)
{
	if(HAL_UART_Receive(&huart3, _data, _length, 3000u) != HAL_OK)
	{
//		asm("BKPT #0");
	}
}

void LPUART6_Send(uint8_t *_data, int _length)
{
    if((huart6.gState == HAL_UART_STATE_READY) && (huart6.Lock == HAL_LOCKED))
    {
        __HAL_UNLOCK(&huart1);
    }
	if(HAL_UART_Transmit(&huart6, _data, _length, 3000u) != HAL_OK)
	{
//		asm("BKPT #0");
	}
}

void LPUART6_Receive(uint8_t *_data, int _length)
{
	if(HAL_UART_Receive(&huart6, _data, _length, 3000u) != HAL_OK)
	{
//		asm("BKPT #0");
	}
}




void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{

	if(huart->ErrorCode & HAL_UART_ERROR_ORE)
	{
		__HAL_UART_CLEAR_OREFLAG(huart);
	}

}


void USART1_RX_IRQHandler(void)
{
	HAL_UART_IRQHandler(&huart1);
}

void USART6_RX_IRQHandler(void)
{

  HAL_UART_IRQHandler(&huart6);

}

/* USER CODE BEGIN 1 */
void USART3_RX_IRQHandler(void)
{

  HAL_UART_IRQHandler(&huart3);

}



void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if((huart->RxState == HAL_UART_STATE_READY) &&(huart->Lock == HAL_LOCKED))
	{
		__HAL_UNLOCK(huart);
	}

	if(huart == &huart1)
	{
		HAL_UART_Receive_IT(&huart1,&receive_uart1_data,1);
		RingBuf_Write_8bit(&uart1_rxbuf,receive_uart1_data);
	}
	else if(huart == &huart3)
	{
		HAL_UART_Receive_IT(&huart3,&receive_uart3_data,1);
//		LPUART1_Send(&receive_uart3_data, 1);
////		LiLin_Data_Collect(receive_uart3_data);
		RingBuf_Write_8bit(&uart3_rxbuf,receive_uart3_data);
	}
	else if(huart == &huart6)
	{
		HAL_UART_Receive_IT(&huart6,&receive_uart6_data,1);
		RingBuf_Write_8bit(&uart6_rxbuf,receive_uart6_data);
	}
	else{}

}


/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
