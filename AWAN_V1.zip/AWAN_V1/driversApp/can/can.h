/**
  ******************************************************************************
  * @file    can.h
  * @brief   This file contains all the function prototypes for
  *          the can.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CAN_H__
#define __CAN_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "appbase.h"
#include "ringBuff.h"

#define CAN2_IRQn                   CAN2_RX0_IRQn
#define CAN2_RX_IRQHandler          CAN2_RX0_IRQHandler

#ifndef STANDARD_ID
 #define STANDARD_ID    0x01U
#endif
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern CAN_HandleTypeDef hcan2;

extern ringBuffer_t can2_rxbuf;

/* USER CODE BEGIN Private defines */
typedef enum
{
	CAN_Operate_Fail  = 0U,
	CAN_Operate_OK    = 1U,

	CAN_Read_ByteLess = 2U,
} can_operate_status_e;

typedef enum
{
	/* Model-Type IMU Device ID */
	MT_IMU_Raw = (uint8_t)0x17,
	MT_IMU1001 = (uint8_t)0x9A,
	MT_IMU1101 = (uint8_t)0x9B,
	MT_IMU2001 = (uint8_t)0xA1,
	MT_IMU2101 = (uint8_t)0xA2,
	MT_IMU3001 = (uint8_t)0xB1,
	MT_IMU3101 = (uint8_t)0xB2,
	/* Model-Type AHRS Device ID */
	MT_AHRS1301 = (uint8_t)0x9C,
	MT_AHRS2001 = (uint8_t)0xA5,
	MT_AHRS2101 = (uint8_t)0xA6,
	MT_AHRS2301 = (uint8_t)0xA7,
	MT_AHRS2501 = (uint8_t)0xA8,
	MT_AHRS3001 = (uint8_t)0xB3,
	MT_AHRS3101 = (uint8_t)0xB4,
	MT_AHRS3301 = (uint8_t)0xB5,
	MT_AHRS3501 = (uint8_t)0xB6,
	MT_AHRS3601 = (uint8_t)0xB9,
	MT_AHRS5001 = (uint8_t)0xD1,
	MT_AHRS5101 = (uint8_t)0xD2,
	MT_AHRS5301 = (uint8_t)0xD3,
	MT_AHRS5501 = (uint8_t)0xD4,
	MT_AHRS5601 = (uint8_t)0xD5,
	/* Model-Type GA Device ID */
	MT_GA2501 = (uint8_t)0xAC,
	MT_GA3001 = (uint8_t)0xC1,
	MT_GA5001 = (uint8_t)0xE1,
	/* Model-Type MAG Device ID */
	MT_MAG3001 = (uint8_t)0xCA,

} model_device_id_e;

typedef enum
{
	CAN_ID_Attitude      = 0x501U, /* unit: deg             */
	CAN_ID_Gyroscope     = 0x502U, /* Angle-Rate, unit: dsp */
	CAN_ID_Acceleration  = 0x503U, /* unit: m/s2            */
	CAN_ID_Magnetism     = 0x504U, /* unit: m-Gauss         */
	CAN_ID_AHRS_Position = 0x505U, /* unit: m               */
	CAN_ID_AHRS_Velocity = 0x506U, /* unit: m/s             */
	CAN_ID_Magnetism_Raw = 0x507U, /* unit: m-Gauss         */
	CAN_ID_Magnetism_RLS = 0x508U, /* unit: m-Gauss         */
	CAN_ID_Magnetism_CAL = 0x509U, /* unit: m-Gauss         */

} can_std_id_e;


/* USER CODE END Private defines */

void MX_CAN2_Init(void);

/* USER CODE BEGIN Prototypes */



void CAN2_Init(void);
uint8_t CAN_Send(CAN_HandleTypeDef* canHandle, uint32_t _std_id, uint8_t *_data);
uint8_t CAN_Receive(CAN_HandleTypeDef* canHandle, uint32_t _std_id, uint8_t *_data, uint8_t _length);
void stm_sendCanMessage(uint32_t _std_id, uint8_t _dev_id, uint8_t _data_id, float _dataFloatX, float _dataFloatY, float _dataFloatZ, float _resolution);





/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __CAN_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
