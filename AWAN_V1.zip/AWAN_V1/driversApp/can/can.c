/**************************************************************
 *@Project :  stm32_m4_asm330_v1.0_beta
 *@FileName:  can.c
 *@Purpose :
 *
 *-------------------------------------------------------------
 *@Copyright. Create by Macial.    June 1, 2022  2:54:53 PM
 **************************************************************/
/*==========================
*  Include Files
*=========================*/
#include "can.h"
#include "iis2mdc.h"
#include "ringBuff.h"


/*==========================
 *  Declare Area Variables
 *=========================*/
CAN_HandleTypeDef hcan2;

CAN_TxHeaderTypeDef txframe;
CAN_RxHeaderTypeDef rxframe;

ringBuffer_t can2_rxbuf;

/*==================================
 *  Application Code - Internal
 *==================================*/
void MX_CAN2_Init(void)
{
  hcan2.Instance = CAN2;
  hcan2.Init.Prescaler = 12;
  hcan2.Init.Mode = CAN_MODE_NORMAL;
  hcan2.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan2.Init.TimeSeg1 = CAN_BS1_3TQ;
  hcan2.Init.TimeSeg2 = CAN_BS2_3TQ;
  hcan2.Init.TimeTriggeredMode = DISABLE;
  hcan2.Init.AutoBusOff = ENABLE;
  hcan2.Init.AutoWakeUp = ENABLE;
  hcan2.Init.AutoRetransmission = DISABLE;
  hcan2.Init.ReceiveFifoLocked = DISABLE;
  hcan2.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan2) != HAL_OK)
  {
    Error_Handler();
  }
}

void HAL_CAN_MspInit(CAN_HandleTypeDef* canHandle)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(canHandle->Instance==CAN2)
  {
    /* CAN2 clock enable */
    __HAL_RCC_CAN2_CLK_ENABLE();
    __HAL_RCC_CAN1_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /*
     * CAN2 GPIO Configuration
     * PB5  ------> CAN2_RX
     * PB13 ------> CAN2_TX
     */
    GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_13;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_CAN2;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* CAN2 interrupt Init */
    HAL_NVIC_SetPriority(CAN2_RX0_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(CAN2_RX0_IRQn);
  }
}

void HAL_CAN_MspDeInit(CAN_HandleTypeDef* canHandle)
{

  if(canHandle->Instance==CAN2)
  {
    /* Peripheral clock disable */
    __HAL_RCC_CAN2_CLK_DISABLE();
    __HAL_RCC_CAN1_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_5|GPIO_PIN_13);

    /* CAN2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(CAN2_RX0_IRQn);
  }
}


/*==================================
 *  Application Code - External
 *==================================*/
//!*************************************************************************************************
//! @Function   :  CAN_Filter_Configure(CAN_HandleTypeDef *_canHandle)
//! @Description:
//! @Param      :  None
//! @Return     :  None
//! @Create     :  Macial   May 30, 2022,
//!*************************************************************************************************
void CAN_Filter_Configure(void)
{
	CAN_FilterTypeDef filter ={0};
	filter.FilterActivation = ENABLE;
	filter.FilterMode = CAN_FILTERMODE_IDMASK;
	filter.FilterScale = CAN_FILTERSCALE_32BIT;
	filter.FilterBank = 0;
	filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	filter.FilterIdLow = 0;
	filter.FilterMaskIdHigh = 0;
	filter.FilterMaskIdLow = 0;
	filter.FilterMaskIdHigh = 0;
	HAL_CAN_ConfigFilter(&hcan2, &filter);
}

//!*************************************************************************************************
//! @Function   :  CAN_Init(CAN_HandleTypeDef *_canHandle)
//! @Description:  Can2 Initialize
//! @Param      :  None
//! @Return     :  None
//! @Create     :  Macial   May 30, 2022,
//!*************************************************************************************************
void CAN2_Init(void)
{
	MX_CAN2_Init();
	CAN_Filter_Configure();
	HAL_CAN_Start(&hcan2);
	HAL_CAN_ActivateNotification(&hcan2,CAN_IT_RX_FIFO0_MSG_PENDING);
}

//!*************************************************************************************************
//! @Function   :  CAN_Send(CAN_HandleTypeDef* canHandle, uint32_t _std_id, uint8_t *_data)
//! @Description:
//! @Param      :  canHandle - hcan2
//!                _std_id   - Standard ID (Client define)
//!                *_data    - 8 bytes data array.
//! @Return     :  0:CAN_Operate_Fail / 1:CAN_Operate_OK
//! @Create     :  Macial   May 17, 2022,
//!*************************************************************************************************
uint8_t CAN_Send(CAN_HandleTypeDef* canHandle, uint32_t _std_id, uint8_t *_data)
{
	uint32_t free_level = 0U;
	uint8_t  retry_count = 100U;

	txframe.IDE   = CAN_ID_STD;
	txframe.StdId = _std_id;
	txframe.DLC   = 8U;
	txframe.RTR   = CAN_RTR_DATA;
	while(free_level == 0)
	{
		free_level=HAL_CAN_GetTxMailboxesFreeLevel(canHandle);
		if(retry_count != 0U)
		{
			retry_count--;
		}else
		{
			return (uint8_t)CAN_Operate_Fail;
		}
	}

	if(canHandle == &hcan2)
	{
		if(HAL_CAN_AddTxMessage(canHandle, &txframe, _data, (uint32_t*)CAN_TX_MAILBOX0) == HAL_OK)
		{
			return (uint8_t)CAN_Operate_OK;
		}
	}

	return (uint8_t)CAN_Operate_Fail;
}

uint8_t CAN_Receive(CAN_HandleTypeDef* canHandle, uint32_t _std_id, uint8_t *_data, uint8_t _length)
{
	int ret;
	if(canHandle == & hcan2)
	{
		if(RingBuf_FIFO_Count(&can2_rxbuf) < _length) return CAN_Read_ByteLess;
		while(_length--)
		{
			ret = RingBuf_Read_8bit(&can2_rxbuf, (_data++));
			if(ret == READ_FAULT) return CAN_Operate_Fail;
		}
		__DSB();
		return CAN_Operate_OK;
	}

	return CAN_Operate_Fail;
}





//!*************************************************************************************************
//! @Description:  Interrupt Function
//! @Create     :  Macial   May 30, 2022,
//!*************************************************************************************************
void CAN2_RX_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan2);
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *canHandle)
{
	uint8_t _data[8] = {0};
	if(canHandle == &hcan2)
	{
		if(HAL_CAN_GetRxMessage(&hcan2, CAN_RX_FIFO0, &rxframe, _data) == HAL_OK)
		{
			for(int _idx = 0; _idx < 8U; _idx++)
			{
				RingBuf_Write_8bit(&can2_rxbuf, _data[_idx]);
			}
		}
	}
}



/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
