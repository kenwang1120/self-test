/**
  ******************************************************************************
  * @file    spi.h
  * @brief   This file contains all the function prototypes for
  *          the spi.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SPI_H__
#define __SPI_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "appbase.h"
#include "ringBuff.h"


/*==========================
 *  Declare Global Variables
 *=========================*/
/* Define */
#define SPI2_IRQn                      SPI2_IRQn
#define SPI2_SLAVE_IRQHandler          SPI2_IRQHandler

/* Global Variables */
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;

extern ringBuffer_t spi2_rxbuf;

/* Enum */
typedef enum{
	SPI_Operate_Fail  = 0U,
	SPI_Operate_OK    = 1U,
} spi_operate_status_e;


/*==================================
 *  Application Code - Internal
 *==================================*/


/*==================================
 *  Application Code - External
 *==================================*/
void LPSPI1_Init(void);
void LPSPI2_Init(void);
void LSSPI1_CS_Ctrl(int _status);
void LPSPI1_Write(uint8_t *buf, uint8_t length);
void LPSPI1_Read(uint8_t *buf, uint8_t length);
void LPSPI2_Write(uint8_t *buf, uint8_t length);
void LPSPI2_Read(uint8_t *buf, uint8_t length);



/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __SPI_H__ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
