#ifndef _DATAPROCESS_H_
#define _DATAPROCESS_H_

typedef struct
{
    float rtu_f2;
    float rtu_f1;
    float rtu_T;
    
}filterP_t;


typedef struct
{
    float X;
    float Y;
    float Z;
    float T;
    
}data_t;

void GPAhrsSendout(float* vel,double lon ,double lat);

void RLS_dataProcess_Init(void);
void dataProcessAutoTrimInit(void);

void iis2mdc_RLS_DataProcess(void);
void asm330_Acc_RLS_DataProcess(void);
void asm330_Gyro_RLS_DataProcess(void);

void asm330_AccelGyro_AutoTrim_DataProcess(void);

void Iis2mdc_Mag_Compensation(void);
void Asm330_Accel_Compensation(void);
void Asm330_Gyro_Compensation(void);

void Iis2mdc_Mag_Sendout(void);
void Asm330_Accel_Sendout(void);
void Asm330_Gyro_Sendout(void);

void AHRS_Sendout(void);
void AHRS_Debug_Sendout(void);
void allTemperatureCanSendout(void);

void allTemperatureRS485Sendout(void);
void Gyro_Acc_Mag_AHRS_sendout(void);

void Asm330_Accel_485_Sendout(void);
void Asm330_Gyro_485_Sendout(void);

void AttitudeSendout(void);
void AccGyroMagSendoutAT(void);
void AccGyroMagSendoutRLS(void);
void AttitudeSendout_Redman(void);

void AccGyroMagSendoutCal(void);

void AHRS_ALL_SEND(void);
void QSendout(void);
#endif
