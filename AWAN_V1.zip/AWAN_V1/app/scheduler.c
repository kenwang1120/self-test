//******************************************************************************
//! @ProjectName: AWAN_V1
//! @ModuleName:  schedluer
//!
//! @Purpose:
//! Functions for schedluer.
//!
//! AWAN Proprietary
//!
//! @AWAN All rights reserved.
//******************************************************************************

//******************************************************************************
// Included Files
//**************************************************************************************************
#include "appbase.h"
//#include "common.h"
#include "scheduler.h"
#include "can.h"
#include "dataprocess.h"
#include "dataout.h"

#include "iis2mdc.h"
#include "asm330lhh.h"
#include "pct2075.h"

#include "calibration.h"

#include "ahrs_ecf.h"
#include "attitude_estimator_q.h"
#include "attitude_ekf.h"
#include "geo.h"
#include "ahrs_ecf.h"
#include "EKF_HDG_Gain_Sched_V0.h"
#include "LiLinEncoder.h"
#include "stm_flash.h"

#include "tim.h"
#include "usart.h"
#include "gps1.h"
#include<gps_cal_vel.h>

uint32_t Test_Tick = 0;


#define CAN_OUTOUT          0
#define RS422_RS485_OUTPUT  1
#define SPI_OUTPUT          2

//#define AHRS_ATTITUDE_ECF
//#define AHRS_ATTITUDE_EST
//#define AHRS_ATTITUDE_EKF


//******************************************************************************
// Global Data
//******************************************************************************

iis2mdc_data_t   iis2mdc_raw_data   = {0};
asm330lhh_data_t asm330lhh_raw_data = {0};

extern iis2mdc_data_t   iis2mdc_rls_data;
extern asm330lhh_data_t asm330llh_autotrim_data;
extern asm330lhh_data_t asm330lhh_rls_data;

extern uint8_t freqOutputRatio;
extern float freqFactor;
extern float bias,bias_y,accn_variance;
extern uint16_t cntGPSDelay;
extern int zputFlag;
extern uint32_t lilinParamInt[32];
extern float vn_kal_mag;
extern float vn_kal_Pmag;
extern float vn_kal_Nmag;
extern float bw,dT,coef;
extern float errRoll,errPitch;
extern float gyPitchBias,gyPitch;
extern float mag_earth_x,mag_earth_y,magAtan,yaw_0,yaw_1,yaw_2,yaw_3,yaw_4,_spinRate;

float cal_Avg(float* data);
// float gyro_bias[3] = { -7.64027E-06,- 1.53329E-06,4.56622E-06 };
// static const float dt = SCHEDULER_PERIOD/1000000.0f;
struct COMPASS mag = { 0 };
struct ACCEL acc   = { 0 };
struct GYRO gy     = { 0 };
struct RATE rate   = { 0 };


float phi;  //roll angle
float theta;//pitch angle
float psi;  //yaw angle

float angles[3]    = {0};

float att_out[3]   = {0};
float rate_out[3]  = {0};
float accel_out[3] = {0};
float Q[4] = {1,0,0,0};

int redundancyState = 0;
uint32_t timerCount = 0,gps_cnt=0,psuedo_cnt=0;
uint16_t realignTick=0;
uint16_t fadingCount=0;
float ekfRateDiff = 0;
float angleDiff = 0;

float angles_redundy[3] = {0};
float rate_redundy[3] = {0};
int ekfValid = 1;
int mgsInvalidCount =0;
float failAngle = 0;
float rdnYaw = 0;
float mdyYaw = 0;
float rdnZRate = 0;
float realignEST = 0;
float angles_est[3] = {0};
float rate_out_est[3] = {0};
float angles_ekf[3] = {0};
float rate_out_ekf[3] = {0};
float acc_rls[3] = {0};
float acc_rls_remove_G[3] = {0};
float accX_last=0;
float accY_last=0;
float accZ_last=0;
float acc_bias[3]={0};
float acc_bias_total[3]={0};
int acc_bias_count=0;
float acc_thresold=0.1;
float mags[3] = {0};
float rawMags[3] = {0};
float psiOffsetArr[10] = {0};


float psiOffset = 0;
int count=0;
int mgsValidCount = 0;
int EKFGainSched=0;
int test=0;
int oneSecond = (1000000/SCHEDULER_PERIOD);


float yawNegGain=1.0f;
float yawPosGain=1.0f;
float yawSteadyGain=1.0f;
float yawPosThreshold = 3.0f;
float yawNegThreshold = -3.0f;
float yawRateDegree = 0;

int counterkk=0;

double acc_buffer[100];
float initMagYaw=0,posMagYaw=0,negMagYaw=0,rawMagYaw=0;
float magX=0,magY=0;
float magXHigh = -5.0f;
float magXLow = 5.0f;
float magYHigh = -5.0f;
float magYLow = 5.0f;
float offsetX=0,offsetY=0,factor_X_Y=1;
float kMagX = 0,kMagY = 0;
uint8_t fReadFlash = 0,ftest=0,fMagDef=0;
float sumATYaw = 0,sumATYaw2 = 0,sumATYaw3=0;
double rlsGZ = 0,sumRlsYaw=0,rawGZ=0,sumRlsYawLast=0,sumRlsBiasYaw=0,avgRlsGZ=0;
double rlsGX = 0,sumRlsRoll=0,rawGX=0,sumRlsRollLast=0,sumRlsBiasRoll=0;
double rlsGY = 0,sumRlsPitch=0,rawGY=0,sumRlsPitchLast=0,sumRlsBiasPitch=0;
double gZFac=0,gZBias=0,gZBiasIni=0,gXBias=0,gYBias=0;
double rlsGZLast =0, rlsGZLpf=0;
uint8_t fDelay=0,cnt=0,fOneScd=0,fMagDir=0;
double rateZ = 0,rateZGain=1;
double zIntYaw=0,sumRlsBiasYawIni;
double sumRawBiasYaw=0,gZRawBias=0,sumRawYaw=0;
double sumAvgRlsBiasYaw = 0;
float magLast =0, magLpf=0,kalMag=0,rlsX=0,rlsY=0,rlsZ=0;
float magYaw_buffer[200]={0};
float magX_buffer[200]={0};
float magY_buffer[200]={0};
float magZ_buffer[200]={0};
float magXAvg=0,magYAvg=0,magZAvg=0,initMagYawAvg=0;
float magAvg=0;
int mag_counter=0;
float yawCF=0,gyroZCF=0;
float yawInit=0,gyroZInit=0;
float yawComp=0,gyroZComp=0;
float cf_buffer[200]={0};
uint8_t mag_yaw_flag=0;
float yaw0=0,yaw1=0,yaw2=0,yaw3=0,dYaw=0,magInit=0;
float noKRlsGX=0,noKRlsGY=0,noKRlsGZ=0;
double sumCalRlsYaw=0;
double sumCalRlsRoll=0;
double sumCalRlsPitch=0;
float rlsCalRlsYaw=0;

//double nDis = 0,eDis=0,lastLat=0,lastLon=0;
//double lastGPSLat=0,lastGPSLon=0;
//uint8_t flagGPS=0;
//**************************************************************************************************
// Exported Function Implementation
//**************************************************************************************************

//!*************************************************************************************************
//! void appBaseOnSchedulerTimer(void)
//!
//! @description
//! System scheduler
//!
//! @param    None
//!
//! @return   None
//!
//! @req      
//!*************************************************************************************************
#define COMPASS_UPDATE_PERIOD_MS 10000u
//read mag data
static int schedulerCount = 0;
static int magUpdateCount = 0;
int gps_count=0;

volatile uint32_t timestamp[10] = {0};

void scheduler (float delta_t)
{




//                magUpdateCount++;
                schedulerCount++;
count++;
  //if(imuOrAhrs==0x00){   // calibration mode
#if defined IMU_Raw
    

                redundancyState = 1;
//timestamp[1] = get_timestamp();
//                if(magUpdateCount>=(COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD))
				if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
//                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
//timestamp[2] = get_timestamp();
                       if(iis2mdc_raw_data.mag_valid == 1)
                       {
                    	   iis2mdc_RLS_DataProcess();
                       }

                     //  Cal_RLSMagData();
//timestamp[3] = get_timestamp();

                }
//timestamp[4] = get_timestamp();
                read_asm_data(&asm330lhh_raw_data);
//timestamp[5] = get_timestamp();
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                //CalRlsGyroAccelData();
                //asm330_AccelGyro_AutoTrim_DataProcess();
                
//timestamp[6] = get_timestamp();
                //AccGyroMagSendoutCal();
                if(freqOutputRatio == 0)
                {
                	freqOutputRatio = 1;
                }

                if((timerCount%freqOutputRatio) == 0)
                {
                	AccGyroMagSendoutCal();
                }

                if(timerCount > 999999)
                {
                	timerCount = 0;
                }

                timerCount++;

//timestamp[7] = get_timestamp();
  //delaysTcnt(20);
  //allTemperatureCanSendout();
  
  //}
  //else if(imuOrAhrs==0x01){ //IMU RLS mode
  #elif defined IMU3001
    

                redundancyState = 1;  
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                //asm330_AccelGyro_AutoTrim_DataProcess();
                
                //AccGyroMagSendoutRLS();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
                if((timerCount%freqOutputRatio) == 0)
                  AccGyroMagSendoutRLS();
                if(timerCount > 999999)
                  timerCount = 0;
                timerCount++;
    
    
    
  //}
  //else if(imuOrAhrs==0x02){ //IMU AT mode
  #elif defined IMU3101
    

                redundancyState = 1;  
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                asm330_AccelGyro_AutoTrim_DataProcess();
                
                //AccGyroMagSendoutAT();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
                if((timerCount%freqOutputRatio) == 0)
                  AccGyroMagSendoutAT();
                if(timerCount > 999999)
                  timerCount = 0;
                timerCount++;
    
    
    
  //}
  //else if(imuOrAhrs==0x03){//AHRS - EKF_RLS
  #elif defined AHRS3001

                redundancyState = 1;  
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                //asm330_AccelGyro_AutoTrim_DataProcess();
                
                gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330lhh_rls_data.angular_rate_dps[2]*D2R;
                yawRateDegree = (gy.z/D2R);
                yawNegGain=1.0f;
                yawPosGain=1.0f;
                yawSteadyGain = 1.0f;
                yawPosThreshold = 3.0f;
                yawNegThreshold = -3.0f;
                if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
                {
                  gy.z  = gy.z*yawSteadyGain;
                }
                else if(yawRateDegree < yawNegThreshold)
                {
                  gy.z  = gy.z*yawNegGain;
                }  
                else if(yawRateDegree > yawPosThreshold)
                {
                  gy.z  = gy.z*yawPosGain;
                } 
                acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                
                mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;//timchen 0302 new orient
                mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
                //mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;
                //mag.y = -iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                //mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f; // asm330 & mag definition
                //mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
                //mag.y =  iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                //mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; // Jack Test
                //mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
               // mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                //mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
                
                float gyros[3] = { gy.x,gy.y,gy.z }; 
                float accels[3] = { acc.x,acc.y,acc.z};
                float mags[3] = { mag.x,mag.y,mag.z}; 
                //    extern unsigned int ekf_runtime;
                //    unsigned int start = getSysTick();
                do_attitude_ekf(gyros, accels, mags,delta_t,att_out, rate_out,accel_out);
                //    extern unsigned int ekf_epoch_runtime;
                //    ekf_epoch_runtime = (getSysTick()-start)*SCHEDULER_PERIOD;
                //    ekf_runtime += (getSysTick()-start);
                accel_out[0] = accel_out[0]/CONSTANTS_ONE_G;
                accel_out[1] = accel_out[1]/CONSTANTS_ONE_G;
                accel_out[2] = accel_out[2]/CONSTANTS_ONE_G;
                angles[0] = att_out[0]* R2D;
                angles[1] = att_out[1]* R2D;
                angles[2] = att_out[2]* R2D;

                rate_out[0] = rate_out[0] * R2D;
                rate_out[1] = rate_out[1] * R2D;
                rate_out[2] = rate_out[2] * R2D;
                //note improve calibration heading angle output only . Shall not intercept EKF functions 20210203
                float attz = angles[2];
                EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In = attz;
                EKF_HDG_Gain_Sched_V0_step();
                angles[2] = EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out;
                read_gps(delta_t, accel_out[0]*CONSTANTS_ONE_G, accel_out[1]*CONSTANTS_ONE_G, accel_out[2]*CONSTANTS_ONE_G,angles[0],angles[1],angles[2]);

                /*Lag_Filter_SISO_U.Ang_In = angles[2];
                Lag_Filter_SISO_step();
                angles[2] = Lag_Filter_SISO_Y.Filtered_Ang_Out;*/
                //doLagFilter();
                read_gps();
                gps_cal_vel(delta_t, acc_rls,angles,rate_out,vel,dis);
                //AttitudeSendout();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
                if((timerCount%freqOutputRatio) == 0)
                  AttitudeSendout();
                if(timerCount > 999999)
                  timerCount = 0;
                timerCount++;
      
  //}
  //else if(imuOrAhrs==0x04){//AHRS - EKF_AT
  #elif defined AHRS3101
                
                redundick = getSys2Tick();
	if(Test_Tick != getSys2Tick())
	{ancyState = 1;
                Test_T
		asm("BKPT #0");
	}

//                if(magUpdateCount>=(COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD))
//                {
//                       magUpdateCount=0;
//                       read_iis_data(&iis2mdc_raw_data);
//                       iis2mdc_RLS_DataProcess();
//                       Cal_RLSMagData();
//                }
                
	if(Test_Tick != getSys2Tick())
	{
		asm("BKPT #0");
	}


                read_asm_data(&asm330lhh_raw_data);
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
//                CalRlsGyroAccelData();
                asm330_AccelGyro_AutoTrim_DataProcess();
                


	if(Test_Tick != getSys2Tick())
	{
		asm("BKPT #0");
	}



                //gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                //gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                //gy.z  = asm330lhh_rls_data.angular_rate_dps[2]*D2R;
                gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
                yawRateDegree = (gy.z/D2R);
                yawNegGain=1.0f;
                yawPosGain=1.0f;
                yawSteadyGain = 1.0f;
                yawPosThreshold = 3.0f;
                yawNegThreshold = -3.0f;
                if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
                {
                  gy.z  = gy.z*yawSteadyGain;
                }
                else if(yawRateDegree < yawNegThreshold)
                {
                  gy.z  = gy.z*yawNegGain;
                }  
                else if(yawRateDegree > yawPosThreshold)
                {
                  gy.z  = gy.z*yawPosGain;
                } 
                
                acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                
                mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;//timchen 0302 new orient
                mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
                //mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;
                //mag.y = -iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                //mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f; // asm330 & mag definition
                //mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
                //mag.y =  iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                //mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; // Jack Test
                //mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
               // mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                //mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
                
                float gyros[3] = { gy.x,gy.y,gy.z }; 
                float accels[3] = { acc.x,acc.y,acc.z};
                float mags[3] = { mag.x,mag.y,mag.z}; 
                //    extern unsigned int ekf_runtime;
                //    unsigned int start = getSysTick();

	if(Test_Tick != getSys2Tick()){
		asm("BKPT #0");
	}


                do_attitude_ekf(gyros, accels, mags,delta_t,att_out, rate_out,accel_out);
                //    extern unsigned int ekf_epoch_runtime;
                //    ekf_epoch_runtime = (getSysTick()-start)*SCHEDULER_PERIOD;
                //    ekf_runtime += (getSysTick()-start);
                accel_out[0] = accel_out[0]/CONSTANTS_ONE_G;
                accel_out[1] = accel_out[1]/CONSTANTS_ONE_G;
                accel_out[2] = accel_out[2]/CONSTANTS_ONE_G;
                angles[0] = att_out[0]* R2D;
                angles[1] = att_out[1]* R2D;
                angles[2] = att_out[2]* R2D;
                rate_out[0] = rate_out[0] * R2D;
                rate_out[1] = rate_out[1] * R2D;
                rate_out[2] = rate_out[2] * R2D;
                //note improve calibration heading angle output only . Shall not intercept EKF functions 20210203
                float attz = angles[2];
                EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In = attz;
                EKF_HDG_Gain_Sched_V0_step();
                angles[2] = EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out;

	if(Test_Tick != getSys2Tick()){
		asm("BKPT #0");
	}

                /*Lag_Filter_SISO_U.Ang_In = angles[2];
                Lag_Filter_SISO_step();
                angles[2] = Lag_Filter_SISO_Y.Filtered_Ang_Out;*/
                //doLagFilter();

                //AttitudeSendout();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
                if((timerCount%freqOutputRatio) == 0)
                  AttitudeSendout();
                if(timerCount > 999999)
                  timerCount = 0;
                timerCount++;
  //}
  //else if(imuOrAhrs==0x05){//ARHS - EST
  //AHRS - EST
  #elif defined AHRS3301
              
                redundancyState = 1;
                  
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
//                	LPUART1_Send((uint8_t*)&magUpdateCount,1);

                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       //Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data);
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
//                asm330_AccelGyro_AutoTrim_DataProcess();
                
                
               gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
               gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
               gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
              // gy.z  = asm330lhh_rls_data.angular_rate_dps[2]*D2R;

               rlsGX = asm330lhh_rls_data.angular_rate_dps[0];
               rlsGY = asm330lhh_rls_data.angular_rate_dps[1];
               rlsGZ = asm330lhh_rls_data.angular_rate_dps[2];

               if(timerCount < 200 && fDelay==0)
               {
            	   sumRlsYaw = 0;
            	   sumRlsRoll = 0;
            	   sumRlsPitch = 0;
            	   sumRawYaw=0;
               }
               else if(timerCount >= 600 && timerCount < 800 && fDelay==0)
               {
            	   sumRlsRoll += rlsGX*0.005;
            	   sumRlsPitch += rlsGY*0.005;
            	   sumRlsYaw += rlsGZ*0.005;
               }
               else if(timerCount >= 1400 && fDelay==0)
               {
            	   fDelay = 1;
            	   gXBias = sumRlsRoll;
            	   gYBias = sumRlsPitch;
            	   gZBias = sumRlsYaw;
            	   timerCount = 0;
            	   sumRlsYaw = 0;
            	   sumRlsRoll = 0;
            	   sumRlsPitch = 0;
            	   yawInit=initMagYawAvg;
            	   magInit = initMagYawAvg;
               }

//               rlsGZLpf =  LPF_oneOrder(rlsGZ,rlsGZLast, 20, 0.005);//1，10，100
//               rlsGZLast = rlsGZLpf;

               if(fDelay==1)
               {
//sprintf(_arr, "L=%7.3f,S=%7.3f,s=%d,=%ld,=%7.3f,=%7.3f\r\n",rlsGZ,sumRlsYaw,cnt,timerCount,sumRlsBiasYaw,gZBias);
//            	   rateZ = fabs(rlsGZ - gZBias);
///////////////////mMatrix hard_code//////////////////////////////////////////////////////////////////////////
//        		   rlsCalRlsYaw = (asm330lhh_rls_data.angular_rate_dps[0] - gXBias) * 0.019966162+
//        				   (asm330lhh_rls_data.angular_rate_dps[1] - gYBias) * (-0.027316941)+
//        				   (asm330lhh_rls_data.angular_rate_dps[2] - gZBias) * 0.999541426;
//        		   sumCalRlsYaw += rlsCalRlsYaw*0.005;
//        		   rlsCalRlsYaw = (asm330lhh_rls_data.angular_rate_dps[0] - 1.118243349) * 0.019930832+
//        				   (asm330lhh_rls_data.angular_rate_dps[1] - -1.451358501) * (-0.028152497)+
//        				   (asm330lhh_rls_data.angular_rate_dps[2] - -0.348588069) * 1.001212419;
//        		   sumCalRlsYaw += rlsCalRlsYaw*0.005;
///////////////////mMatrix hard_code/////////////////////////////////////////////////////////////////////////

///////////////////integrate calculation and dynamic bias calculation////////////////////////////////////////
            	   sumRlsBiasYaw += (rlsGZ - gZBias)*0.005;
            	   sumRlsBiasRoll += (rlsGX - gXBias)*0.005;
            	   sumRlsBiasPitch += (rlsGY - gYBias)*0.005;

            	   if((rlsGZ - gZBias > -0.3) && (rlsGZ - gZBias<0.3) && (rlsGX - gXBias > -0.3) && (rlsGX - gXBias<0.3) && (rlsGY - gYBias > -0.3) && (rlsGY - gYBias<0.3))
            	   {
            		   sumRlsYaw += rlsGZ*0.005;
            		   sumRlsRoll += rlsGX*0.005;
            		   sumRlsPitch += rlsGY*0.005;

            		   cnt += 1;
            		   if(cnt == 200)
            		   {
            			   cnt = 0;
            			   gZBias = sumRlsYaw;
            			   gXBias = sumRlsRoll;
            			   gYBias = sumRlsPitch;
            			   sumRlsYaw = 0;
            			   sumRlsRoll=0;
            			   sumRlsPitch = 0;
            		   }
            	   }
            	   else
            	   {
            		   sumRlsYaw = 0;
            		   sumRawYaw = 0;
            		   sumRlsRoll=0;
            		   sumRlsPitch=0;
            		   cnt = 0;
            	   }
               }


///////////////////set X axis gain////////////////////////////////////////
               yawRateDegree = (gy.z/D2R);
               yawNegGain=1.0f;
               yawPosGain=1.0f;
               yawSteadyGain = 1.0f;
               yawPosThreshold = 3.0f;
               yawNegThreshold = -3.0f;
               if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
               {
            	   gy.z  = gy.z*yawSteadyGain;
               }
               else if(yawRateDegree < yawNegThreshold)
               {
            	   gy.z  = gy.z*yawNegGain;
               }
               else if(yawRateDegree > yawPosThreshold)
               {
            	   gy.z  = gy.z*yawPosGain;
               }
///////////////////set X axis gain////////////////////////////////////////


               acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
               acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
               acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
               acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
               acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
               acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];

///////////////////mag_yaw calculation////////////////////////////////////////
               mag.x = iis2mdc_rls_data.magnetic_mG[1]*(-0.001f);
			   mag.y = iis2mdc_rls_data.magnetic_mG[0]*(0.001f);
			   mag.z = iis2mdc_rls_data.magnetic_mG[2]*(0.001f);
			   rawMagYaw = atan2(mag.y,mag.x)*R2D*(-1.0);
			   initMagYaw = atan2(kMagY,kMagX)*R2D*(-1.0);
			   magLpf =  LPF_oneOrder(initMagYaw,magLast, 50, 0.005);
			   magLast = magLpf;//magLast =0; magLpf=0;

			   kMagX = mag.x - offsetX;
			   kMagY = mag.y - offsetY;
			   kMagY = (kMagY * factor_X_Y);

			   float kMagX3 = ((mag.x + 0.124942621)/0.502770312);
			   float kMagY3 = ((mag.y - 0.043283738)/0.484365959);
			   float kMagZ3 = ((mag.z + 0.077654568)/0.478556265);
			   float initMagYaw3 = atan2(kMagY3,kMagX3)*R2D*(-1.0);
			   float norm3 = sqrt(kMagX3*kMagX3 + kMagY3*kMagY3 + kMagZ3+kMagZ3);

               magYaw_buffer[mag_counter] = initMagYaw;
               magX_buffer[mag_counter] = kMagX;
               magY_buffer[mag_counter] = kMagY;
//               magZ_buffer[mag_counter] = kMagZ;
               mag_counter++;
               magAvg = cal_Avg(magYaw_buffer);

               magXAvg = cal_Avg(magX_buffer);
               magYAvg = cal_Avg(magY_buffer);
//               magZAvg = cal_Avg(magZ_buffer);
               initMagYawAvg = atan2(magYAvg,magXAvg)*R2D*(-1.0);
               if(mag_counter>199)
               {
            	   mag_counter = 0;
               }
///////////////////mag_yaw calculation////////////////////////////////////////
               
///////////////////rx command////////////////////////////////////////
               if(lilin_data.status == VAST_FUNCODE_MAG_K)
			   {
//            	   ftest = lilin_data.fCalMag;
			   }
               else if(lilin_data.status == VAST_FUNCODE_ID)
               {
            	   gps.id = lilin_data.hID*256 + lilin_data.lID;
//            	   lilinParamInt[14] = ((uint32_t))(lilin_data.hID*256 + lilin_data.lID);
            	   lilin_data.fCalMag = 2;

               }
               else if(lilin_data.status == LILIN_FUNCODE_REQ)
               {
            	   if(lilin_data.subCmd == 0 && lilin_data.rebootEnable == 1)
            	   {
            		   __NVIC_SystemReset();
            	   }
            	   else if(lilin_data.subCmd == 1 && lilin_data.writeFlashEnable == 1)
            	   {
            	   }
            	   else if(lilin_data.subCmd == 2 && lilin_data.versionEnable == 1)
            	   {
//					   lilinParamInt[7];
            	   }
               }
               //fCalMag: 1:calibration , 2: write flash and reboot , 0:normal mode
               if(lilin_data.fCalMag == 1 || vast_data.fCalMag == 1)
               {
            	   if(fMagDef == 0)
            	   {
            		   fMagDef = 1;
                	   magXHigh = -5.0f;
                	   magXLow = 5.0f;
                	   magYHigh = -5.0f;
                	   magYLow = 5.0f;
            	   }
            	   calMag(mag.x, mag.y);
               }
               else if(lilin_data.fCalMag == 2 || vast_data.fCalMag == 2)
               {
            	   magToFlash();
            	   initFlashNVM_para2(lilinParamInt,32);
            	   delaysTcnt(5000000);
            	   __NVIC_SystemReset();
               }
               else if(lilin_data.fCalMag == 0)
               {
            	   if(fReadFlash == 0)
            	   {
            		   fReadFlash = 1;
            		   magFromFlash();
            		   gps.id = lilinParamInt[14];
            	   }
                   offsetX = (magXHigh + magXLow)*0.5f;
                   offsetY = (magYHigh + magYLow)*0.5f;

                   if((magXHigh - magXLow) == 0 || (magYHigh - magYLow) == 0)
                     factor_X_Y = 1.0f;
                   else
                     factor_X_Y = (float)(magXHigh - magXLow)/(magYHigh - magYLow);
                   factor_X_Y = fabsf(factor_X_Y);
               }
///////////////////rx command////////////////////////////////////////
///////////////////gyro - dynamic_bias////////////////////////////////////////
               gy.x = (rlsGX - gXBias)*D2R;
               gy.y = (rlsGY - gYBias)*D2R;
               if(fDelay ==0)
            	   gy.z = 0;
               else
            	   gy.z = (rlsGZ - gZBias)*D2R;
///////////////////gyro - dynamic_bias////////////////////////////////////////
    
                
                do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                                      mag.x,mag.y,mag.z, delta_t,&phi, &theta, &psi,rate_out);  
                
                 rate_out[0] = rate_out[0] * R2D;
                 rate_out[1] = rate_out[1] * R2D;
                 rate_out[2] = rate_out[2] * R2D;

                 angles[0] = phi * R2D;           // Roll
                 angles[1] = theta * R2D;         // Pitch
                 angles[2] = psi * R2D;           // Yaw



                //AttitudeSendout();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
//                if((timerCount%freqOutputRatio) == 0)
//                  AttitudeSendout();
                if(timerCount > 99999999)
                  timerCount = 0;
                timerCount++;

                char _arr[100];
                sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f\r\n",rlsGX,rlsGY,rlsGZ,gXBias,gYBias,gZBias,sumRlsBiasRoll,sumRlsBiasPitch,sumRlsBiasYaw);
                LPUART3_Send((uint8_t*)_arr, strlen(_arr));
  
  //}
#elif defined AHRS1301

                redundancyState = 1;

                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
//                	LPUART1_Send((uint8_t*)&magUpdateCount,1);

                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }

                read_asm_data(&asm330lhh_raw_data);
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                asm330_AccelGyro_AutoTrim_DataProcess();



              // The following are for autotrim Gz only but not in Gx and Gy but none Acc autotrim
              //Jack setting
               /*gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
               gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
               gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;*/
               //Tim setting
               gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
               gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
               gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;





yawRateDegree = (gy.z/D2R);
yawNegGain=1.0f;
yawPosGain=1.0f;
yawSteadyGain = 1.0f;
yawPosThreshold = 3.0f;
yawNegThreshold = -3.0f;
if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
{
  gy.z  = gy.z*yawSteadyGain;
}
else if(yawRateDegree < yawNegThreshold)
{
  gy.z  = gy.z*yawNegGain;
}
else if(yawRateDegree > yawPosThreshold)
{
  gy.z  = gy.z*yawPosGain;
}
               acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
               acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
               acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
               acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
               acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
               acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];

               //Jack setting
               /*mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
               mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
               mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f;*/
               //Tim setting
               mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;//timchen 0302 new orient 0.001f
               mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;//timchen 0303 0.0001f 0.01f 0.1f
               mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f;

               //YuChen setting
                /*gy.x  = asm330lhh_raw_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_raw_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330lhh_raw_data.angular_rate_dps[2]*D2R;
                acc.x = CONSTANTS_ONE_G*asm330lhh_raw_data.acceleration_g[0];
                acc.y = CONSTANTS_ONE_G*asm330lhh_raw_data.acceleration_g[1];
                acc.z = CONSTANTS_ONE_G*asm330lhh_raw_data.acceleration_g[2];
                mag.x = -iis2mdc_raw_data.magnetic_mG[0]*0.001f;
                mag.y = iis2mdc_raw_data.magnetic_mG[1]*0.001f;
                mag.z = -iis2mdc_raw_data.magnetic_mG[2]*0.001f; */


                do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                                      mag.x,mag.y,mag.z, delta_t,&phi, &theta, &psi,rate_out);

                 rate_out[0] = rate_out[0] * R2D;
                 rate_out[1] = rate_out[1] * R2D;
                 rate_out[2] = rate_out[2] * R2D;

                 angles[0] = phi * R2D;           // Roll
                 angles[1] = theta * R2D;         // Pitch
                 angles[2] = psi * R2D;           // Yaw


                //AttitudeSendout();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
                if((timerCount%freqOutputRatio) == 0)
                  AttitudeSendout();
                if(timerCount > 999999)
                  timerCount = 0;
                timerCount++;

  //}
  //else if(imuOrAhrs==0x06){ //REDMAN
  #elif defined AHRS2501
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                asm330_AccelGyro_AutoTrim_DataProcess();
                
                acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;//timchen 0302 new orient
                mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f;      
                //EST
                gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;// Test using RLS on x,y angle
yawRateDegree = (gy.z/D2R);
yawNegGain=1.001f;
yawPosGain=1.0f;
yawSteadyGain = 1.0f;
yawPosThreshold = 3.0f;
yawNegThreshold = -3.0f;
if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
{
  gy.z  = gy.z*yawSteadyGain;
}
else if(yawRateDegree < yawNegThreshold)
{
  gy.z  = gy.z*yawNegGain;
}  
else if(yawRateDegree > yawPosThreshold)
{
  gy.z  = gy.z*yawPosGain;
} 
                do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                                                      mag.x,mag.y,mag.z, delta_t,&phi, &theta, &psi,rate_out);  
                                
                rate_out_est[0] = rate_out[0] * R2D;
                rate_out_est[1] = rate_out[1] * R2D;
                rate_out_est[2] = rate_out[2] * R2D;
                angles_est[0] = phi * R2D;
                angles_est[1] = theta * R2D;
                angles_est[2] = psi * R2D;

                //EKF
                gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
                float gyros[3] = { gy.x,gy.y,gy.z }; 
                float accels[3] = { acc.x,acc.y,acc.z};
                //float mags[3] = { mag.x,mag.y,mag.z}; 
                mags[0] = mag.x;
                mags[1] = mag.y;
                mags[2] = mag.z;
                do_attitude_ekf(gyros, accels, mags,delta_t,att_out, rate_out,accel_out);
                //acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                //acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                //acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                accel_out[0] = accel_out[0]/CONSTANTS_ONE_G;
                accel_out[1] = accel_out[1]/CONSTANTS_ONE_G;
                accel_out[2] = accel_out[2]/CONSTANTS_ONE_G;
                angles_ekf[0] = att_out[0]* R2D;
                angles_ekf[1] = att_out[1]* R2D;
                angles_ekf[2] = att_out[2]* R2D;
                rate_out_ekf[0] = rate_out[0] * R2D;
                rate_out_ekf[1] = rate_out[1] * R2D;
                rate_out_ekf[2] = rate_out[2] * R2D;
                //note improve calibration heading angle output only . Shall not intercept EKF functions 20210203
                float attz = angles_ekf[2];
                EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In = attz;
                EKF_HDG_Gain_Sched_V0_step();
                angles_ekf[2] = EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out;
                //EKF gain

                /////////////////////////rate & angle difference/////////////////
                if(rate_out_ekf[2] >= asm330lhh_rls_data.angular_rate_dps[2])
                  ekfRateDiff = (rate_out_ekf[2] - asm330lhh_rls_data.angular_rate_dps[2]);
                else
                  ekfRateDiff = (asm330lhh_rls_data.angular_rate_dps[2] - rate_out_ekf[2]);
mdyYaw = angles_est[2]+psiOffset;
if(mdyYaw > 180.0f)
  mdyYaw = mdyYaw -360.0f;
if(mdyYaw < -180.0f)
  mdyYaw = mdyYaw + 360.0f;
if(angles_ekf[2] > 0 && mdyYaw > 0)
{
  angleDiff = angles_ekf[2] - mdyYaw;
  test =1;
}
else if(angles_ekf[2] > 0 && mdyYaw < 0)
{
  angleDiff = 360.0f + mdyYaw - angles_ekf[2];
  test =2;
}
else if(angles_ekf[2] < 0 && mdyYaw > 0)
{
  angleDiff = 360.0f + angles_ekf[2] - mdyYaw;
  test =3;
}
else if(angles_ekf[2] < 0 && mdyYaw < 0)
{
  angleDiff = angles_ekf[2] - mdyYaw;
  test =4;
}  
if(angleDiff < 0)
  angleDiff = angleDiff*(-1.0f);
if(angleDiff > 180.0f)
  angleDiff = 360 - angleDiff;
                //if(angles_ekf[2] >= (angles_est[2]+psiOffset))
                //  angleDiff = angles_ekf[2] - (angles_est[2]+psiOffset);
                //else
                //  angleDiff = (angles_est[2]+psiOffset) - angles_ekf[2];
                //*************************state machine**********************//
if(redundancyState >= 1)
{
//redundancyState = 2,follow(EKF or EST)
if(ekfValid == 1 && ekfRateDiff <= 1.0f)
{
  redundancyState = 2;
  //ekfValid = 1;
}
//redundancyState = 3,EKF to EST
if(ekfRateDiff > 2.0f && angleDiff > 10.0f)
{
  failAngle = angleDiff;
  mgsInvalidCount++;  
}
//else
//  mgsInvalidCount = 0;

if(mgsInvalidCount >= 10)
{
  ekfValid = 0;
  mgsInvalidCount = 10;
  redundancyState = 3;
}
//redundancyState = 4,EST to EKF
if(ekfValid == 0 && ekfRateDiff <= 1.0f && angleDiff < 5.0f)
{
  mgsInvalidCount--;
  redundancyState = 4;
  ekfValid = 1;
}
//redundancyState = 5, realignment in static state
}
//time sequence
if(redundancyState == 0 && timerCount < 811)
{
  if(timerCount <= 800)
  {
    angles_est[2] = 0;
    angles_ekf[2] = 0;
  }
  else if(timerCount > 800)
  {
    psiOffsetArr[timerCount-801] = angles_ekf[2] - angles_est[2];
    if(timerCount >= 810)
    {
      psiOffset = ((psiOffsetArr[0]+psiOffsetArr[1]+psiOffsetArr[2]+psiOffsetArr[3]+psiOffsetArr[4]+psiOffsetArr[5]+psiOffsetArr[6]+psiOffsetArr[7]+psiOffsetArr[8]+psiOffsetArr[9])/10.0f);
      redundancyState = 1;
      freqFactor = 1;
      magUpdateCount = 0;
    }
  }
}
else if(redundancyState == 1)
{
  rdnYaw = angles_ekf[2] ; 
  rdnZRate = rate_out_ekf[2];
}
else if(redundancyState == 2)
{
  rdnYaw = angles_ekf[2] ; 
  rdnZRate = rate_out_ekf[2];
  
}
else if(redundancyState == 3)
{
  //rdnYaw = angles_est[2]+psiOffset ; 
  rdnYaw = mdyYaw;//20210428 modify +-180 issue
  rdnZRate = rate_out_est[2];
  
}
else if(redundancyState == 4)
{
  rdnYaw = angles_ekf[2] ; 
  rdnZRate = rate_out_ekf[2];
  
}
else if(redundancyState == 5)
{
  rdnYaw = angles_ekf[2] ;
  rdnZRate = rate_out_ekf[2];
}
//angles_ekf[2] >= (angles_est[2]+psiOffset)
angles_redundy[0]=angles_est[0];
angles_redundy[1]=angles_est[1];
angles_redundy[2]=rdnYaw;
rate_redundy[0] = rate_out_est[0];
rate_redundy[1] = rate_out_est[1];
rate_redundy[2] = rdnZRate;

if(freqOutputRatio == 0)
  freqOutputRatio = 1;
if((timerCount%freqOutputRatio) == 0)
  AttitudeSendout_Redman();
if(timerCount > 999999)
  timerCount = 0;
timerCount++;

mgsValidCount++;
//AttitudeSendout_Redman();
    
  //}
//else if(imuOrAhrs==0x08){ //REDMAN_EST
#elif defined AHRS3501
              if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
              {
                     magUpdateCount=0;
                     read_iis_data(&iis2mdc_raw_data);
                     iis2mdc_RLS_DataProcess();
                     Cal_RLSMagData();
              }

              read_asm_data(&asm330lhh_raw_data);
              asm330_Gyro_RLS_DataProcess();
              asm330_Acc_RLS_DataProcess();
              CalRlsGyroAccelData();
              asm330_AccelGyro_AutoTrim_DataProcess();

              acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
              acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
              acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
              mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;//timchen 0302 new orient
              mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
              mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f;
              //EST
              gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
              gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
              gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;// Test using RLS on x,y angle
yawRateDegree = (gy.z/D2R);
yawNegGain=1.001f;
yawPosGain=1.0f;
yawSteadyGain = 1.0f;
yawPosThreshold = 3.0f;
yawNegThreshold = -3.0f;
if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
{
gy.z  = gy.z*yawSteadyGain;
}
else if(yawRateDegree < yawNegThreshold)
{
gy.z  = gy.z*yawNegGain;
}
else if(yawRateDegree > yawPosThreshold)
{
gy.z  = gy.z*yawPosGain;
}
              do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                                                    mag.x,mag.y,mag.z, delta_t,&phi, &theta, &psi,rate_out);

              rate_out_est[0] = rate_out[0] * R2D;
              rate_out_est[1] = rate_out[1] * R2D;
              rate_out_est[2] = rate_out[2] * R2D;
              angles_est[0] = phi * R2D;
              angles_est[1] = theta * R2D;
              angles_est[2] = psi * R2D;

              //EKF
              gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
              gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
              gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
              float gyros[3] = { gy.x,gy.y,gy.z };
              float accels[3] = { acc.x,acc.y,acc.z};
              //float mags[3] = { mag.x,mag.y,mag.z};
              mags[0] = mag.x;
              mags[1] = mag.y;
              mags[2] = mag.z;
              do_attitude_ekf(gyros, accels, mags,delta_t,att_out, rate_out,accel_out);
              //acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
              //acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
              //acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
              acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
              acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
              acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
              accel_out[0] = accel_out[0]/CONSTANTS_ONE_G;
              accel_out[1] = accel_out[1]/CONSTANTS_ONE_G;
              accel_out[2] = accel_out[2]/CONSTANTS_ONE_G;
              angles_ekf[0] = att_out[0]* R2D;
              angles_ekf[1] = att_out[1]* R2D;
              angles_ekf[2] = att_out[2]* R2D;
              rate_out_ekf[0] = rate_out[0] * R2D;
              rate_out_ekf[1] = rate_out[1] * R2D;
              rate_out_ekf[2] = rate_out[2] * R2D;
              //note improve calibration heading angle output only . Shall not intercept EKF functions 20210203
              float attz = angles_ekf[2];
              EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In = attz;
              EKF_HDG_Gain_Sched_V0_step();
              angles_ekf[2] = EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out;
              //EKF gain

              /////////////////////////rate & angle difference/////////////////
              if(rate_out_ekf[2] >= asm330lhh_rls_data.angular_rate_dps[2])
                ekfRateDiff = (rate_out_ekf[2] - asm330lhh_rls_data.angular_rate_dps[2]);
              else
                ekfRateDiff = (asm330lhh_rls_data.angular_rate_dps[2] - rate_out_ekf[2]);
mdyYaw = angles_est[2]+psiOffset;
if(mdyYaw > 180.0f)
mdyYaw = mdyYaw -360.0f;
if(mdyYaw < -180.0f)
mdyYaw = mdyYaw + 360.0f;
if(angles_ekf[2] > 0 && mdyYaw > 0)
{
angleDiff = angles_ekf[2] - mdyYaw;
test =1;
}
else if(angles_ekf[2] > 0 && mdyYaw < 0)
{
angleDiff = 360.0f + mdyYaw - angles_ekf[2];
test =2;
}
else if(angles_ekf[2] < 0 && mdyYaw > 0)
{
angleDiff = 360.0f + angles_ekf[2] - mdyYaw;
test =3;
}
else if(angles_ekf[2] < 0 && mdyYaw < 0)
{
angleDiff = angles_ekf[2] - mdyYaw;
test =4;
}
if(angleDiff < 0)
angleDiff = angleDiff*(-1.0f);
if(angleDiff > 180.0f)
angleDiff = 360 - angleDiff;
              //if(angles_ekf[2] >= (angles_est[2]+psiOffset))
              //  angleDiff = angles_ekf[2] - (angles_est[2]+psiOffset);
              //else
              //  angleDiff = (angles_est[2]+psiOffset) - angles_ekf[2];
              //*************************state machine**********************//
if(redundancyState >= 1)
{
//redundancyState = 2,follow(EKF or EST)
if(ekfValid == 1 && ekfRateDiff <= 1.0f)
{
redundancyState = 2;
//ekfValid = 1;
}
//redundancyState = 3,EKF to EST
if(ekfRateDiff > 2.0f && angleDiff > 10.0f)
{
failAngle = angleDiff;
mgsInvalidCount++;
}
//else
//  mgsInvalidCount = 0;

if(mgsInvalidCount >= 10)
{
ekfValid = 0;
mgsInvalidCount = 10;
redundancyState = 3;
}
//redundancyState = 4,EST to EKF
if(ekfValid == 0 && ekfRateDiff <= 1.0f && angleDiff < 5.0f)
{
mgsInvalidCount--;
redundancyState = 4;
ekfValid = 1;
}
//redundancyState = 5, realignment in static state
}
//time sequence
if(redundancyState == 0 && timerCount < 811)
{
if(timerCount <= 800)
{
  angles_est[2] = 0;
  angles_ekf[2] = 0;
}
else if(timerCount > 800)
{
  psiOffsetArr[timerCount-801] = angles_ekf[2] - angles_est[2];
  if(timerCount >= 810)
  {
    psiOffset = ((psiOffsetArr[0]+psiOffsetArr[1]+psiOffsetArr[2]+psiOffsetArr[3]+psiOffsetArr[4]+psiOffsetArr[5]+psiOffsetArr[6]+psiOffsetArr[7]+psiOffsetArr[8]+psiOffsetArr[9])/10.0f);
    redundancyState = 1;
    freqFactor = 1;
    magUpdateCount = 0;
  }
}
}
else if(redundancyState == 1)
{
rdnYaw = angles_ekf[2] ;
rdnZRate = rate_out_ekf[2];
}
else if(redundancyState == 2)
{
rdnYaw = angles_ekf[2] ;
rdnZRate = rate_out_ekf[2];

}
else if(redundancyState == 3)
{
//rdnYaw = angles_est[2]+psiOffset ;
rdnYaw = mdyYaw;//20210428 modify +-180 issue
rdnZRate = rate_out_est[2];

}
else if(redundancyState == 4)
{
rdnYaw = angles_ekf[2] ;
rdnZRate = rate_out_ekf[2];

}
else if(redundancyState == 5)
{
rdnYaw = angles_ekf[2] ;
rdnZRate = rate_out_ekf[2];
}
//angles_ekf[2] >= (angles_est[2]+psiOffset)
angles_redundy[0]=angles_est[0];
angles_redundy[1]=angles_est[1];
angles_redundy[2]=rdnYaw;
rate_redundy[0] = rate_out_est[0];
rate_redundy[1] = rate_out_est[1];
rate_redundy[2] = rdnZRate;

if(freqOutputRatio == 0)
freqOutputRatio = 1;
if((timerCount%freqOutputRatio) == 0)
AttitudeSendout_Redman();
if(timerCount > 999999)
timerCount = 0;
timerCount++;

mgsValidCount++;
//AttitudeSendout_Redman();

//}
//else if(imuOrAhrs==0x08){ //REDMAN_EST
#elif defined AHRS3601
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                asm330_AccelGyro_AutoTrim_DataProcess();
                
                acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                mag.x = iis2mdc_rls_data.magnetic_mG[0]*0.001f;//timchen 0302 new orient
                mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
                mag.z = iis2mdc_rls_data.magnetic_mG[2]*0.001f;      
                //EST
                gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;// Test using RLS on x,y angle
yawRateDegree = (gy.z/D2R);
yawNegGain=1.001f;
yawPosGain=1.0f;
yawSteadyGain = 1.0f;
yawPosThreshold = 3.0f;
yawNegThreshold = -3.0f;
if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
{
  gy.z  = gy.z*yawSteadyGain;
}
else if(yawRateDegree < yawNegThreshold)
{
  gy.z  = gy.z*yawNegGain;
}  
else if(yawRateDegree > yawPosThreshold)
{
  gy.z  = gy.z*yawPosGain;
}  
                do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                                                      mag.x,mag.y,mag.z, delta_t,&phi, &theta, &psi,rate_out);  
                                
                rate_out_est[0] = rate_out[0] * R2D;
                rate_out_est[1] = rate_out[1] * R2D;
                rate_out_est[2] = rate_out[2] * R2D;
                angles_est[0] = phi * R2D;
                angles_est[1] = theta * R2D;
                angles_est[2] = psi * R2D;

                //EKF
                gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
                gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
                gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
                float gyros[3] = { gy.x,gy.y,gy.z }; 
                float accels[3] = { acc.x,acc.y,acc.z};
                //float mags[3] = { mag.x,mag.y,mag.z}; 
                mags[0] = mag.x;
                mags[1] = mag.y;
                mags[2] = mag.z;
                if(redundancyState == 0)
                {
                  do_attitude_ekf(gyros, accels, mags,delta_t,att_out, rate_out,accel_out);
                  accel_out[0] = accel_out[0]/CONSTANTS_ONE_G;
                  accel_out[1] = accel_out[1]/CONSTANTS_ONE_G;
                  accel_out[2] = accel_out[2]/CONSTANTS_ONE_G;
                  angles_ekf[0] = att_out[0]* R2D;
                  angles_ekf[1] = att_out[1]* R2D;
                  angles_ekf[2] = att_out[2]* R2D;
                  rate_out_ekf[0] = rate_out[0] * R2D;
                  rate_out_ekf[1] = rate_out[1] * R2D;
                  rate_out_ekf[2] = rate_out[2] * R2D;
                }
                
                //acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                //acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                //acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
                acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
                acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
                
                //note improve calibration heading angle output only . Shall not intercept EKF functions 20210203
                float attz = angles_ekf[2];
                EKF_HDG_Gain_Sched_V0_U.Yaw_Ang_In = attz;
                EKF_HDG_Gain_Sched_V0_step();
                angles_ekf[2] = EKF_HDG_Gain_Sched_V0_Y.Cal_Yaw_Ang_Out;
                //EKF gain

                /////////////////////////rate & angle difference/////////////////
                if(rate_out_ekf[2] >= asm330lhh_rls_data.angular_rate_dps[2])
                  ekfRateDiff = (rate_out_ekf[2] - asm330lhh_rls_data.angular_rate_dps[2]);
                else
                  ekfRateDiff = (asm330lhh_rls_data.angular_rate_dps[2] - rate_out_ekf[2]);
mdyYaw = angles_est[2]+psiOffset;
if(mdyYaw > 180.0f)
  mdyYaw = mdyYaw -360.0f;
if(mdyYaw < -180.0f)
  mdyYaw = mdyYaw + 360.0f;
if(angles_ekf[2] > 0 && mdyYaw > 0)
{
  angleDiff = angles_ekf[2] - mdyYaw;
  test =1;
}
else if(angles_ekf[2] > 0 && mdyYaw < 0)
{
  angleDiff = 360.0f + mdyYaw - angles_ekf[2];
  test =2;
}
else if(angles_ekf[2] < 0 && mdyYaw > 0)
{
  angleDiff = 360.0f + angles_ekf[2] - mdyYaw;
  test =3;
}
else if(angles_ekf[2] < 0 && mdyYaw < 0)
{
  angleDiff = angles_ekf[2] - mdyYaw;
  test =4;
}  
if(angleDiff < 0)
  angleDiff = angleDiff*(-1.0f);
if(angleDiff > 180.0f)
  angleDiff = 360 - angleDiff;
                //if(angles_ekf[2] >= (angles_est[2]+psiOffset))
                //  angleDiff = angles_ekf[2] - (angles_est[2]+psiOffset);
                //else
                //  angleDiff = (angles_est[2]+psiOffset) - angles_ekf[2];
                //*************************state machine**********************//
if(redundancyState >= 1)
{
//redundancyState = 2,follow(EKF or EST)
if(ekfValid == 1 && ekfRateDiff <= 1.0f)
{
  redundancyState = 2;
  //ekfValid = 1;
}
//redundancyState = 3,EKF to EST
if(ekfRateDiff > 2.0f && angleDiff > 10.0f)
{
  failAngle = angleDiff;
  mgsInvalidCount++;  
}
//else
//  mgsInvalidCount = 0;

if(mgsInvalidCount >= 10)
{
  ekfValid = 0;
  mgsInvalidCount = 10;
  redundancyState = 3;
}
//redundancyState = 4,EST to EKF
if(ekfValid == 0 && ekfRateDiff <= 1.0f && angleDiff < 5.0f)
{
  mgsInvalidCount--;
  redundancyState = 4;
  ekfValid = 1;
}
//redundancyState = 5, realignment in static state
}
//time sequence
if(redundancyState == 0 && timerCount < 811)
{
  if(timerCount <= 800)
  {
    angles_est[2] = 0;
    angles_ekf[2] = 0;
  }
  else if(timerCount > 800)
  {
    psiOffsetArr[timerCount-801] = angles_ekf[2] - angles_est[2];
    if(timerCount >= 810)
    {
      psiOffset = ((psiOffsetArr[0]+psiOffsetArr[1]+psiOffsetArr[2]+psiOffsetArr[3]+psiOffsetArr[4]+psiOffsetArr[5]+psiOffsetArr[6]+psiOffsetArr[7]+psiOffsetArr[8]+psiOffsetArr[9])/10.0f);
      redundancyState = 1;
      freqFactor = 1;
      magUpdateCount = 0;
    }
  }
}
else if(redundancyState == 1)
{
  rdnYaw = mdyYaw;
  rdnZRate = rate_out_est[2];
}
else if(redundancyState == 2)
{
  rdnYaw = mdyYaw;
  rdnZRate = rate_out_est[2];
}
else if(redundancyState == 3)
{
  rdnYaw = mdyYaw;
  rdnZRate = rate_out_est[2];
}
else if(redundancyState == 4)
{
  rdnYaw = mdyYaw;
  rdnZRate = rate_out_est[2];
}
else if(redundancyState == 5)
{
  rdnYaw = mdyYaw;
  rdnZRate = rate_out_est[2];
}
redundancyState=0;
//angles_ekf[2] >= (angles_est[2]+psiOffset)
angles_redundy[0]=angles_est[0];
angles_redundy[1]=angles_est[1];
angles_redundy[2]=rdnYaw;
rate_redundy[0] = rate_out_est[0];
rate_redundy[1] = rate_out_est[1];
rate_redundy[2] = rdnZRate;

if(freqOutputRatio == 0)
  freqOutputRatio = 1;
if((timerCount%freqOutputRatio) == 0)
  AttitudeSendout_Redman(); 
if(timerCount > 999999)
  timerCount = 0;
timerCount++;

mgsValidCount++;
//AttitudeSendout_Redman();    
  //}
  //else if(imuOrAhrs==0x07){//AHRS - ECF
  //AHRS - ECF
  #elif AHRS_ECF  
    

                  
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                asm330_AccelGyro_AutoTrim_DataProcess();

               //AHRS data
               gy.x  = asm330llh_autotrim_data.angular_rate_dps[0]*D2R;
               gy.y  = asm330llh_autotrim_data.angular_rate_dps[1]*D2R;
               gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
               acc.x = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[0];
               acc.y = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[1];
               acc.z = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[2];
               mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
               mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
               mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
                
               
               fahrs_ecf(&mag, &acc, &gy, delta_t, &phi, &theta, &psi, &rate);
               
               rate_out[0] = rate.x * R2D;
               rate_out[1] = rate.y * R2D;
               rate_out[2] = rate.z * R2D;
 

               angles[0] = phi * R2D;
               angles[1] = theta * R2D;
               angles[2] = psi * R2D;
    
    
               
               
            //  AttitudeSendout();
           //    QSendout();
               AHRS_ALL_SEND();
           
#elif defined GPAHRS

                redundancyState = 1;

                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
//                	LPUART1_Send((uint8_t*)&magUpdateCount,1);

                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                       rlsX = iis2mdc_rls_data.magnetic_mG[1]*(-0.001f);//stm32 setting
                       rlsY = iis2mdc_rls_data.magnetic_mG[0]*(0.001f);
                       rlsZ = iis2mdc_rls_data.magnetic_mG[2]*(0.001f);
//                       Cal_RLSMagData();
                }

                read_asm_data(&asm330lhh_raw_data);
//                float rawKAccX = asm330lhh_raw_data.acceleration_g[0];
//                float rawKAccY = asm330lhh_raw_data.acceleration_g[1];
//                float rawKAccZ = asm330lhh_raw_data.acceleration_g[2];
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
//                float rlsAccX = asm330lhh_rls_data.acceleration_g[0];
//                float rlsAccY = asm330lhh_rls_data.acceleration_g[1];
//                float rlsAccZ = asm330lhh_rls_data.acceleration_g[2];
//                rlsGY = asm330lhh_rls_data.angular_rate_dps[1];
                noKRlsGX = asm330lhh_rls_data.angular_rate_dps[0];
				noKRlsGY = asm330lhh_rls_data.angular_rate_dps[1];
				noKRlsGZ = asm330lhh_rls_data.angular_rate_dps[2];

                CalRlsGyroAccelData();
//                asm330_AccelGyro_AutoTrim_DataProcess();


              // The following are for autotrim Gz only but not in Gx and Gy but none Acc autotrim
              //Jack setting
               gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
               gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
               gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
               rawGZ = asm330lhh_raw_data.angular_rate_dps[2];
               rlsGZ = asm330lhh_rls_data.angular_rate_dps[2];

               rawGX = asm330lhh_raw_data.angular_rate_dps[0];
               rlsGX = asm330lhh_rls_data.angular_rate_dps[0];

               rawGY = asm330lhh_raw_data.angular_rate_dps[1];
               rlsGY = asm330lhh_rls_data.angular_rate_dps[1];
               if(timerCount < 200 && fDelay==0)
               {
            	   sumRlsYaw = 0;
            	   sumRlsRoll = 0;
            	   sumRlsPitch = 0;
            	   sumRawYaw=0;
            	   //return;
               }
               if(timerCount >= 1200 && timerCount < 1400 && fDelay==0)
               {
            	   sumRlsYaw += rlsGZ*0.005;
            	   sumRlsRoll += rlsGX*0.005;
            	   sumRlsPitch += rlsGY*0.005;
            	   sumRawYaw += rawGZ*0.005;
               }
               if(timerCount >= 1400 && fDelay==0)
               {
            	   fOneScd = 1;
            	   fDelay = 1;
            	   sumRlsYawLast = sumRlsYaw;
            	   sumRlsRollLast = sumRlsRoll;
            	   sumRlsPitchLast = sumRlsPitch;
            	   gZBias = sumRlsYaw;
            	   gZRawBias = sumRawYaw;
            	   gXBias = sumRlsRollLast;
            	   gYBias = sumRlsPitchLast;
            	   gZBiasIni = sumRlsYaw;
            	   avgRlsGZ = sumRlsYaw;
            	   timerCount = 0;
            	   sumRlsYaw = 0;
            	   sumRlsRoll = 0;
            	   sumRlsPitch = 0;
            	   sumRawYaw = 0;
            	   sumRlsBiasYaw=0;
            	   sumRawBiasYaw=0;
            	   yawInit=magAvg;
            	   gyroZInit=magAvg;
            	   magInit = magAvg;
               }

//               rlsGZ = rlsGZ*gZFac - gZBias;

//               rlsGZLpf =  LPF_oneOrder(rlsGZ,rlsGZLast, 20, 0.005);//1，10，100
//               rlsGZLast = rlsGZLpf;
//               if(rlsGZ > -0.1 && rlsGZ < 0.1)
//            	   rlsGZ = 0;
               if(fDelay==1)
               {
//sprintf(_arr, "L=%7.3f,S=%7.3f,s=%d,=%ld,=%7.3f,=%7.3f\r\n",rlsGZ,sumRlsYaw,cnt,timerCount,sumRlsBiasYaw,gZBias);
//            	   rateZ = fabs(rlsGZ - gZBias);
///////////////////mMatrix//////////////////////////////////////////////////////////////////////////
        		   rlsCalRlsYaw = (asm330lhh_rls_data.angular_rate_dps[0] - gXBias) * 0.019966162+
        				   (asm330lhh_rls_data.angular_rate_dps[1] - gYBias) * (-0.027316941)+
        				   (asm330lhh_rls_data.angular_rate_dps[2] - gZBias) * 0.999541426;
        		   sumCalRlsYaw += rlsCalRlsYaw*0.005;
//        		   rlsCalRlsYaw = (asm330lhh_rls_data.angular_rate_dps[0] - 1.118243349) * 0.019930832+
//        				   (asm330lhh_rls_data.angular_rate_dps[1] - -1.451358501) * (-0.028152497)+
//        				   (asm330lhh_rls_data.angular_rate_dps[2] - -0.348588069) * 1.001212419;
//        		   sumCalRlsYaw += rlsCalRlsYaw*0.005;
///////////////////mMatrix/////////////////////////////////////////////////////////////////////////
            	   sumRlsBiasYaw += (rlsGZ - gZBias)*0.005;//sumRlsBiasYaw += (rlsGZ - gZBias)*0.005*rateZGain;
            	   sumAvgRlsBiasYaw += (rlsGZ - avgRlsGZ)*0.005;

            	   sumRlsBiasRoll += (rlsGX - gXBias)*0.005;
            	   sumRlsBiasPitch += (rlsGY - gYBias)*0.005;

            	   zIntYaw += (rlsGZ - 0)*0.005;
            	   sumRlsBiasYawIni += (rlsGZ - gZBiasIni)*0.005;//gZBiasIni
            	   if(zIntYaw > 10000000 || zIntYaw < -10000000)
            		   zIntYaw = 0;
//            	   sumRlsYaw += rlsGZ*0.005;
            	   if((rlsGZ - gZBias > -0.3) && (rlsGZ - gZBias<0.3) && (rlsGX - gXBias > -0.3) && (rlsGX - gXBias<0.3) && (rlsGY - gYBias > -0.3) && (rlsGY - gYBias<0.3))
            	   {
            		   sumRlsYaw += rlsGZ*0.005;
            		   sumRlsRoll += rlsGX*0.005;
            		   sumRlsPitch += rlsGY*0.005;

                	   sumRawYaw += rawGZ*0.005;
            		   cnt += 1;
            		   if(cnt == 200)
            		   {
            			   fOneScd = 1;
            			   cnt = 0;
            			   gZBias = sumRlsYaw;
                    	   gZRawBias = sumRawYaw;
                    	   avgRlsGZ = avgRlsGZ*0.8 + sumRlsYaw*0.2;
            			   gXBias = sumRlsRoll;
            			   gYBias = sumRlsPitch;
            			   sumRlsYaw = 0;
            			   sumRawYaw = 0;
            			   sumRlsRoll=0;
            			   sumRlsPitch = 0;
            		   }
            	   }
            	   else
            	   {
            		   sumRlsYaw = 0;
            		   sumRawYaw = 0;
            		   sumRlsRoll=0;
            		   sumRlsPitch=0;
            		   cnt = 0;
            	   }
               }

//               if(sumRlsYaw > 180)
//            	   sumRlsYaw = sumRlsYaw - 360;
//               else if(sumRlsYaw < -180)
//            	   sumRlsYaw = sumRlsYaw + 360;
//               if((timerCount%200) == 0)
//               {
//            	   gZBias = (sumRlsYaw + sumRlsYawLast)*0.5;
//            	   sumRlsYawLast = sumRlsYaw;
//            	   sumRlsYaw = 0;
//               }




				yawRateDegree = (gy.z/D2R);
				yawNegGain=1.0f;
				yawPosGain=1.0f;
				yawSteadyGain = 1.0f;
				yawPosThreshold = 3.0f;
				yawNegThreshold = -3.0f;
				if(yawRateDegree>=yawNegThreshold &&  yawRateDegree <= yawPosThreshold)
				{
				  gy.z  = gy.z*yawSteadyGain;
				}
				else if(yawRateDegree < yawNegThreshold)
				{
				  gy.z  = gy.z*yawNegGain;
				}
				else if(yawRateDegree > yawPosThreshold)
				{
				  gy.z  = gy.z*yawPosGain;
				}
               acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
               acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
               acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
               acc_rls[0] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
               acc_rls[1] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
               acc_rls[2] = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];


               mag.x = iis2mdc_rls_data.magnetic_mG[1]*(-0.001f);//stm32 setting
               mag.y = iis2mdc_rls_data.magnetic_mG[0]*(0.001f);
               mag.z = iis2mdc_rls_data.magnetic_mG[2]*(0.001f);
               iinitMagYaw = atan2(mag.y,mag.x)*R2D*(-1.0);//cvgMag = atan2(kMagY,kMagX)*R2D*(1.0);

               if(lilin_data.status == VAST_FUNCODE_MAG_K)
			   {
//            	   ftest = lilin_data.fCalMag;
			   }
               else if(lilin_data.status == VAST_FUNCODE_ID)
               {
            	   gps.id = lilin_data.hID*256 + lilin_data.lID;
//            	   lilinParamInt[14] = ((uint32_t))(lilin_data.hID*256 + lilin_data.lID);
            	   lilin_data.fCalMag = 2;

               }
               else if(lilin_data.status == LILIN_FUNCODE_REQ)
               {
            	   if(lilin_data.subCmd == 0 && lilin_data.rebootEnable == 1)
            	   {
            		   __NVIC_SystemReset();
            	   }
            	   else if(lilin_data.subCmd == 1 && lilin_data.writeFlashEnable == 1)
            	   {
            	   }
            	   else if(lilin_data.subCmd == 2 && lilin_data.versionEnable == 1)
            	   {
//					   lilinParamInt[7];
            	   }
               }
               //fCalMag: 1:calibration , 2: write flash and reboot , 0:normal mode
               if(lilin_data.fCalMag == 1 || vast_data.fCalMag == 1)
               {
            	   if(fMagDef == 0)
            	   {
            		   fMagDef = 1;
                	   magXHigh = -5.0f;
                	   magXLow = 5.0f;
                	   magYHigh = -5.0f;
                	   magYLow = 5.0f;
            	   }
            	   calMag(mag.x, mag.y);
               }
               else if(lilin_data.fCalMag == 2 || vast_data.fCalMag == 2)
               {
            	   magToFlash();
            	   initFlashNVM_para2(lilinParamInt,32);
            	   delaysTcnt(5000000);
            	   __NVIC_SystemReset();
               }
               else if(lilin_data.fCalMag == 0)
               {
            	   if(fReadFlash == 0)
            	   {
            		   fReadFlash = 1;
            		   magFromFlash();
            		   gps.id = lilinParamInt[14];
            	   }
                   offsetX = (magXHigh + magXLow)*0.5f;
                   offsetY = (magYHigh + magYLow)*0.5f;

                   if((magXHigh - magXLow) == 0 || (magYHigh - magYLow) == 0)
                     factor_X_Y = 1.0f;
                   else
                     factor_X_Y = (float)(magXHigh - magXLow)/(magYHigh - magYLow);
                   factor_X_Y = fabsf(factor_X_Y);
               }
			   kMagX = mag.x - offsetX;
			   kMagY = mag.y - offsetY;
			   kMagY = (kMagY * factor_X_Y);

			   float kMagX2 = (mag.x +0.14093694)/0.4583282;
			   float kMagY2 = (mag.y - 0.0204919706)/0.4400605;
			   float kMagZ2 = (mag.z + -0.05073546)/0.420097606;
			   float initMagYaw2 = atan2(kMagY2,kMagX2)*R2D*(-1.0);

			   float kMagX3 = ((mag.x + 0.124942621)/0.502770312);
			   float kMagY3 = ((mag.y - 0.043283738)/0.484365959);
			   float kMagZ3 = ((mag.z + 0.077654568)/0.478556265);
			   float initMagYaw3 = atan2(kMagY3,kMagX3)*R2D*(-1.0);
			   float norm3 = sqrt(kMagX3*kMagX3 + kMagY3*kMagY3 + kMagZ3+kMagZ3);

			   float kMagX4 = ((mag.x + 0.124942621)/0.502770312);
			   float kMagY4 = ((mag.y - 0.043283738)/0.484365959);
			   float kMagZ4 = ((mag.z + 0.077654568)/0.478556265);
			   float initMagYaw4 = atan2(kMagY4,kMagX4)*R2D*(-1.0);
			   float norm4 = sqrt(kMagX4*kMagX4 + kMagY4*kMagY4 + kMagZ4+kMagZ4);

			   initMagYaw = atan2(kMagY,kMagX)*R2D*(-1.0);//initMagYaw = atan2(magY,magX)*R2D*(-1.0);//cvgMag = atan2(kMagY,kMagX)*R2D*(1.0);
			   magLpf =  LPF_oneOrder(initMagYaw,magLast, 50, 0.005);
			   magLast = magLpf;//magLast =0; magLpf=0;
			   if(initMagYaw<0)
			   {
				   posMagYaw = initMagYaw + 360;
				   negMagYaw = initMagYaw;
			   }
			   else
			   {
				   posMagYaw = initMagYaw;
				   negMagYaw = initMagYaw;
			   }
			   if(initMagYaw>-90 && initMagYaw < 90)
			   {
				   fMagDir = 1;
			   }
			   else
				   fMagDir = 0;
			   if(fMagDir == 1)
			   {
				   kalMag = vn_kal_Pmag;
			   }
			   else
			   {
				   if(vn_kal_Nmag >180)
					   kalMag = vn_kal_Nmag - 360;
				   else if(vn_kal_Nmag <-180)
					   kalMag = vn_kal_Nmag + 360;
				   else
					   kalMag = vn_kal_Nmag;
			   }
//			   if(initMagYaw<0)
//			   {
//				   posMagYaw = initMagYaw + 360;
//				   negMagYaw = initMagYaw;
//			   }
//			   else
//			   {
//				   posMagYaw = initMagYaw;
//				   negMagYaw = initMagYaw;
//			   }
//			   if(initMagYaw>-90 || initMagYaw < 90)
//			   {
//				   fMagDir = 1;
//			   }
//			   else
//				   fMagDir = 0;

               if(counterkk>=500 && gps.gps_headingAlign == 0){
//            	   set_heading(initMagYaw*D2R);
            	   counterkk=0;
            	   gps.gps_headingAlign = 1;
               }

               if(gps.gps_headingAlign == 2)
               {
            	   counterkk=0;
            	   gps.gps_headingAlign = 3;
               }
               else if(gps.gps_headingAlign == 3 && counterkk>=1000)
               {
            	   gps.gps_headingAlign = 4;
            	   counterkk=1100;
//            	   set_heading(gps.heading);
               }

               gy.x = (rlsGX - gXBias)*D2R;
               gy.y = (rlsGY - gYBias)*D2R;
               if(fDelay ==0)
            	   gy.z = 0;
               else
            	   gy.z = (rlsGZ - gZBias)*D2R;

               magYaw_buffer[mag_counter] = initMagYaw;
               magX_buffer[mag_counter] = kMagX;
               magY_buffer[mag_counter] = kMagY;
//               magZ_buffer[mag_counter] = kMagZ;
               mag_counter++;
               magAvg = cal_Avg(magYaw_buffer);

               magXAvg = cal_Avg(magX_buffer);
               magYAvg = cal_Avg(magY_buffer);
//               magZAvg = cal_Avg(magZ_buffer);
               initMagYawAvg = atan2(magYAvg,magXAvg)*R2D*(-1.0);
               if(mag_counter>199)
               {
            	   mag_counter = 0;
               }

               if(counterkk<1000)
            	   counterkk++;
                do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                		kMagX,kMagY,0, delta_t,&phi, &theta, &psi,rate_out);


                //1=kMagX , 2=kMagX3,3=magXAvg
                 rate_out[0] = initMagYaw;//bias;//rate_out[0] * R2D;
                 rate_out[1] = kMagX;//rate_out[1] * R2D;//accn_variance;//bias_y;//rate_out[1] * R2D;
                 rate_out[2] = kMagY;//rate_out[2] * R2D;//zputFlag;//rate_out[2] * R2D;
//                 sumATYaw += rate_out[2]*0.005;
//                 if(sumATYaw > 180)
//                	 sumATYaw = sumATYaw - 360;
//                 else if(sumATYaw < -180)
//                	 sumATYaw = sumATYaw + 360;
//                 if((timerCount%4) == 0)
//                 {
//                     sumATYaw2 += rate_out[2]*0.05;
//                     if(sumATYaw2 > 180)
//                    	 sumATYaw2 = sumATYaw2 - 360;
//                     else if(sumATYaw2 < -180)
//                    	 sumATYaw2 = sumATYaw2 + 360;
//                 }


                 angles[0] = mag.x;//gps.rGPSHeading;//gps.heading*57.2957795;//initMagYaw;//phi * R2D;           // Roll
                 angles[1] = mag.y;//theta * R2D;//gps.heading;         // Pitch
                 angles[2] = psi * R2D;           // Yaw


//                 yawCF = (yawInit + psi * R2D)*0.99 + magAvg * 0.01;
//                 gyroZCF = (gyroZInit + sumRlsBiasYawIni)*0.99 + magAvg * 0.01;
//
//                 yawComp = (magAvg - yawCF);
//                 yawCF = magAvg - (yawInit + psi * R2D);
//                 gyroZComp = (magAvg - gyroZCF);


                 double lon;//degree
                 double lat;//degree
                 float vel[7];//kal,gps,fu,bias,lpfPitch
                 //float dis[3];


                 read_gps();
                 gps_cal_vel(delta_t, acc_rls,angles,rate_out,vel,&lon,&lat);

//                 nDis = (lat - lastLat)*111300;
//                 eDis = (lon - lastLon)*100000;
//                 lastLat = lat;
//                 lastLon = lon;
//                 if(gps.valid==true)
//                 {
//                	 nDis=0;
//                	 eDis=0;
//                	 flagGPS = 1 ;
//                	 lastGPSLat = lat;
//                	 lastGPSLon = lon;
//                 }

                 if(gps.gps_timeValid == 1)
                 {
                	 gps.gps_timeValid = 0;
                	 gps_cnt=0;
                 }
                 if(gps.gps_timeValid == 0 && gps_cnt > DATA_RATE*1.3)
                 {
                	 gps.gps_timeValid = 2;//gps lost
             		 gps.valid=0;
             		 gps.state=0;
             		 gps.heading_valid=INVALID_GPS_HEADING;
             		 gps.gps_lost = 1;
             		 cntGPSDelay=0;
//             		 flagGPS = 0;
                 }


                 gps.distance+=gps.vel*delta_t;

                //AttitudeSendout();
                if(freqOutputRatio == 0)
                 freqOutputRatio = 1;
//                if((timerCount%freqOutputRatio) == 0)
//                  GPAhrsSendout(vel,lon,lat);
                if(timerCount > 999999999)
                  timerCount = 0;
                timerCount++;

//                gps.id = timerCount;// - 200;
//                if(timerCount >= 200 && timerCount <10200)
//                	GPAhrsSendout(vel,lon,lat);



                gps_cnt++;
                if(gps.gps_headingAlign >= 4)
                {
                	psuedo_cnt++;
                    if(psuedo_cnt < 2000)
                    {
                    	gps.gps_psuedoLost = 0;//gps valid
                    }
                    else if(psuedo_cnt >= 2000)
                    {
                    	gps.gps_psuedoLost = 0;//gps always valid
//                    	gps.gps_psuedoLost = 1;//gps invalid
                    }

                    if(psuedo_cnt > 2600)
                    {
                    	psuedo_cnt=0;
                    	gps.gps_psuedoLost = 0;
                    }
                }
/*                char _arr[100];
                if((timerCount%200) == 0){//if(fMagDef == 0 && ((timerCount%200) == 0))
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%d,%7.3f,%7.3f\r\n",rlsGX,rlsGY,rlsGZ,gXBias,gYBias,gZBias,sumRlsBiasYaw,cnt,errRoll,errPitch);//corr(2)=0
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f\r\n",rlsGX,rlsGY,rlsGZ,gXBias,gYBias,gZBias,sumRlsBiasRoll,sumRlsBiasPitch,sumRlsBiasYaw);
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%d,%7.3f,%7.3f,%d\r\n",rlsGZ,gZBias,psi * R2D,sumRlsBiasYaw,cnt,magAvg,initMagYaw,mag_counter);
//                  sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f\r\n",iis2mdc_rls_data.magnetic_mG[1]*(-0.001f),iis2mdc_rls_data.magnetic_mG[0]*(0.001f),iis2mdc_rls_data.magnetic_mG[2]*(0.001f),magXHigh,magXLow,magYHigh,magYLow,kMagX,kMagY,sumRlsBiasYaw);
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f\r\n",yaw0,psi * R2D,sumRlsBiasYaw,magAvg,mag_earth_x,mag_earth_y,magAtan* R2D);
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%d,%7.3f\r\n",rlsGX,rlsGY,rlsGZ,sumRlsBiasRoll,sumRlsBiasPitch,sumRlsBiasYaw,cnt,acc.z);
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f\r\n",rlsGX-gXBias,rlsGY-gYBias,rlsGZ-gZBias,phi * R2D,theta * R2D,psi * R2D,asm330lhh_rls_data.angular_rate_dps[0]*D2R,asm330lhh_rls_data.angular_rate_dps[1]*D2R,asm330lhh_rls_data.angular_rate_dps[2]*D2R,asm330llh_autotrim_data.angular_rate_dps[2]*D2R);
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%d,%7.3f,%7.3f,%7.3f\r\n",phi * R2D,theta * R2D,psi * R2D,sumRlsBiasRoll,sumRlsBiasPitch,sumRlsBiasYaw,cnt,gyPitchBias*R2D,gyPitch*R2D,errPitch);//corr(2)=0
                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%d,%7.3f\r\n",phi * R2D,theta * R2D,psi * R2D,sumRlsBiasRoll,sumRlsBiasPitch,sumRlsBiasYaw,cnt,gyPitchBias);//corr(2)=0
//                	sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%d\r\n",noKRlsGZ,rlsGZ,gy.z,gZBias,cnt);//corr(2)=0
                //else
                	//sprintf(_arr, "%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%7.3f,%d\r\n",rlsGX - gXBias,rlsGY - gYBias,rlsGZ - gZBias,phi * R2D,theta * R2D,psi * R2D,fMagDef);
				LPUART3_Send((uint8_t*)_arr, strlen(_arr));}
*/
//                if(timerCount >500)//if(timerCount == 100 || timerCount == 5000 || timerCount == 10000 || timerCount == 15000 || timerCount == 20000 || timerCount <= 25000)
//				{
//					sprintf(_arr, "2=%7.3f,w=%7.3f,r=%7.3f,S=%7.3f,R=%7.3f,P=%7.3f,=%ld\r\n",angles[2],rawGZ,rlsGZ,sumRlsYaw,phi * R2D,theta * R2D,timerCount-500);
//					LPUART3_Send((uint8_t*)_arr, strlen(_arr));
//				}
    
  //}
  //else{
  #else
   // default mode calibration data mode, only calibrated data not AT


                  
                if(magUpdateCount++ % (COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD) == 0)
                {
                       magUpdateCount=0;
                       read_iis_data(&iis2mdc_raw_data);
                       iis2mdc_RLS_DataProcess();
                     //  Cal_RLSMagData();
                }
                
                read_asm_data(&asm330lhh_raw_data); 
                asm330_Gyro_RLS_DataProcess();
                asm330_Acc_RLS_DataProcess();
                CalRlsGyroAccelData();
                //asm330_AccelGyro_AutoTrim_DataProcess();
                
                AccGyroMagSendoutCal();
  //}

  #endif
}//scheduler
  
/*
  
  //    uint8_t ouput_mode = CAN_OUTOUT;   // default CAN ouput mode
  uint8_t ouput_mode = RS422_RS485_OUTPUT;   // RS422/RS485 ouput mode
  
  //read mag data
  static int schedulerCount =0;
  static int magUpdateCount = 0;
  magUpdateCount++;
  schedulerCount++;
  if(magUpdateCount>=(COMPASS_UPDATE_PERIOD_MS/SCHEDULER_PERIOD))
    //      if(1)
  {
    magUpdateCount=0;
    read_iis_data(&iis2mdc_raw_data);
    iis2mdc_RLS_DataProcess();
    Cal_RLSMagData();
  }
  //read accel+gryo data
  //  if(schedulerCount %3 != 0)
  if(1)
  {
    read_asm_data(&asm330lhh_raw_data); 
    asm330_Gyro_RLS_DataProcess();
    asm330_Acc_RLS_DataProcess();
    CalRlsGyroAccelData();
    //asm330_AccelGyro_AutoTrim_DataProcess();
  }
  
  if(1){
    //AHRS algorithm
#ifdef AHRS_ATTITUDE_ECF
    //asm330_AccelGyro_AutoTrim_DataProcess();
    //AHRS data
    gy.x  = asm330llh_autotrim_data.angular_rate_dps[0]*D2R;
    gy.y  = asm330llh_autotrim_data.angular_rate_dps[1]*D2R;
    gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
    acc.x = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[0];
    acc.y = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[1];
    acc.z = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[2];
    mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
    mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
    mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
    
    fahrs_ecf(&mag, &acc, &gy, delta_t, &phi, &theta, &psi, &rate);
    rate_out[0] = rate.x;
    rate_out[1] = rate.y;
    rate_out[2] = rate.z;
#endif
    
#ifdef AHRS_ATTITUDE_EST
    //asm330_AccelGyro_AutoTrim_DataProcess();
    //AHRS data
    gy.x  = asm330llh_autotrim_data.angular_rate_dps[0]*D2R;
    gy.y  = asm330llh_autotrim_data.angular_rate_dps[1]*D2R;
    gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
    acc.x = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[0];
    acc.y = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[1];
    acc.z = CONSTANTS_ONE_G*asm330llh_autotrim_data.acceleration_g[2];
    mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
    mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
    mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
    
    do_attitude_estimator(gy.x,gy.y,gy.z,acc.x,acc.y,acc.z,
                          mag.x,mag.y,mag.z, delta_t,&phi, &theta, &psi,rate_out);
#endif
    
#ifdef AHRS_ATTITUDE_EKF
    //    //AHRS data  
    //    gy.x  = asm330llh_autotrim_data.angular_rate_dps[0]*D2R;
    //    gy.y  = asm330llh_autotrim_data.angular_rate_dps[1]*D2R;
    //    gy.z  = asm330llh_autotrim_data.angular_rate_dps[2]*D2R;
    //    acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
    //    acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
    //    acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
    //    mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
    //    mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
    //    mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
    
    gy.x  = asm330lhh_rls_data.angular_rate_dps[0]*D2R;
    gy.y  = asm330lhh_rls_data.angular_rate_dps[1]*D2R;
    gy.z  = asm330lhh_rls_data.angular_rate_dps[2]*D2R;
    acc.x = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[0];
    acc.y = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[1];
    acc.z = CONSTANTS_ONE_G*asm330lhh_rls_data.acceleration_g[2];
    mag.x = -iis2mdc_rls_data.magnetic_mG[0]*0.001f;
    mag.y = iis2mdc_rls_data.magnetic_mG[1]*0.001f;
    mag.z = -iis2mdc_rls_data.magnetic_mG[2]*0.001f; 
    
    float gyros[3] = { gy.x,gy.y,gy.z }; 
    float accels[3] = { acc.x,acc.y,acc.z};
    float mags[3] = { mag.x,mag.y,mag.z}; 
    //    extern unsigned int ekf_runtime;
    //    unsigned int start = getSysTick();
    do_attitude_ekf(gyros, accels, mags,delta_t,att_out, rate_out,accel_out);
    //    extern unsigned int ekf_epoch_runtime;
    //    ekf_epoch_runtime = (getSysTick()-start)*SCHEDULER_PERIOD;
    //    ekf_runtime += (getSysTick()-start);
    accel_out[0] = accel_out[0]/CONSTANTS_ONE_G;
    accel_out[1] = accel_out[1]/CONSTANTS_ONE_G;
    accel_out[2] = accel_out[2]/CONSTANTS_ONE_G;
    angles[0] = att_out[0];
    angles[1] = att_out[1];
    angles[2] = att_out[2];
#endif
    
    //convert rad to deg
    angles[0] = att_out[0]* R2D;
    angles[1] = att_out[1]* R2D;
    angles[2] = att_out[2]* R2D;
    rate_out[0] = rate_out[0] * R2D;
    rate_out[1] = rate_out[1] * R2D;
    rate_out[2] = rate_out[2] * R2D;
  }
  //printf("%.2f,%.2f,%.2f\r\n",iis2mdc_rls_data.magnetic_mG[0],iis2mdc_rls_data.magnetic_mG[1],iis2mdc_rls_data.magnetic_mG[2]);
  //Sendout original rate data
  if(imuOrAhrs){
    switch (ouput_mode)
    {
    case CAN_OUTOUT:
      Asm330_Gyro_Sendout();
      Asm330_Accel_Sendout();
      Iis2mdc_Mag_Sendout();
      //AHRS_Debug_Sendout();
      break;
      
    case RS422_RS485_OUTPUT:
      AccGyroMagSendout();
      break;
      
    case SPI_OUTPUT:
      
      break;      
    }
  } else{
    //Sendout ahrs data
    //schedulerCount = 0;
    switch (ouput_mode)
    {
    case CAN_OUTOUT:
      AHRS_Sendout();
      break;
      
    case RS422_RS485_OUTPUT:
      AttitudeSendout();
      break;
      
    case SPI_OUTPUT:
      
      break;      
    } 
  }
  
}*/



float cal_Avg(float* data) {
	float total = 0;
	for (int i = 0; i < 200; i++)
	{
		total += data[i];

	}
	return  total / 200;
}
