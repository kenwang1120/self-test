//******************************************************************************
//! @file
//!
//! header file for dataOut module
//!
//! @Copyright 2019 BendixKing. All rights reserved.
//!
//******************************************************************************
#ifndef DATAOUT_H_
#define DATAOUT_H_

#include "stdint.h"
#include "can.h"


/* IMU */
#if defined IMU_Raw
	#define DEVICE_ID        0x17U
#elif defined IMU1001
	#define DEVICE_ID        0x9AU
#elif defined IMU1101
	#define DEVICE_ID        0x9BU
#elif defined IMU2001
	#define DEVICE_ID        0xA1U
#elif defined IMU2101
	#define DEVICE_ID        0xA2U
#elif defined IMU3001
	#define DEVICE_ID        0xB1U
#elif defined IMU3101
	#define DEVICE_ID        0xB2U
/* AHRS */
#elif defined AHRS1301
	#define DEVICE_ID        0x9CU
#elif defined AHRS2001
	#define DEVICE_ID        0xA5U
#elif defined AHRS2101
	#define DEVICE_ID        0xA6U
#elif defined AHRS2301
	#define DEVICE_ID        0xA7U
#elif defined AHRS2501
	#define DEVICE_ID        0xA8U
#elif defined AHRS3001
	#define DEVICE_ID        0xB3U
#elif defined AHRS3101
	#define DEVICE_ID        0xB4U
#elif defined AHRS3301
	#define DEVICE_ID        0xB5U
#elif defined AHRS3501
	#define DEVICE_ID        0xB6U
#elif defined AHRS3601
	#define DEVICE_ID        0xB9U
#elif defined AHRS1301
	#define DEVICE_ID        0x9cU
#elif defined AHRS2501
	#define DEVICE_ID        0x98U
#elif defined AHRS5001
	#define DEVICE_ID        0xD1U
#elif defined AHRS5101
	#define DEVICE_ID        0xD2U
#elif defined AHRS5301
	#define DEVICE_ID        0xD3U
#elif defined AHRS5501
	#define DEVICE_ID        0xD4U
#elif defined AHRS5601
	#define DEVICE_ID        0xD5U
/* GA */
#elif defined GA2501
	#define DEVICE_ID        0xACU
#elif defined GA3001
	#define DEVICE_ID        0xC1U
#elif defined GA5001
	#define DEVICE_ID        0xE1U
/* Mag */
#elif defined MAG3001
	#define DEVICE_ID        0xCAU
#elif defined GPAHRS
	#define DEVICE_ID        0xC1U
#else
	#define DEVICE_ID        0xFFU
#endif



//asm330lhh defines
#define ASM330LHH_FS2G_G              0.000061f  /* fs:+/-2g */
#define ASM330LHH_FS4G_G              0.000122f  /* fs:+/-4g */
#define ASM330LHH_FS8G_G              0.000244f  /* fs:+/-8g */
#define ASM330LHH_FS16G_G             0.000488f  /* fs:+/-16g */

#define ASM330LHH_FS125DPS_DPS        0.00437f
#define ASM330LHH_FS250DPS_DPS        0.00875f
#define ASM330LHH_FS500DPS_DPS        0.01750f
#define ASM330LHH_FS1000DPS_DPS       0.0350f
#define ASM330LHH_FS2000DPS_DPS       0.0700f
#define ASM330LHH_FS4000DPS_DPS       0.1400f

#define ASM330LHH_LSB_C                256.0f

//iis2mdc
#define IIS2MDC_LSB_MG                 1.5f
#define IIS2MDC_LSB_C                  8.0f
//lsm9ds1
#define LSM9DS1_FS8GAUSS2MG            0.29f

typedef struct outputDataCan
{
  uint8_t dataId;
  uint8_t dataLength;
  uint8_t data[8];
}outputDataCan_t;

typedef enum _uart
{
	 UART1_Print = 1,
	 UART3_Print = 3,
	 UART6_Print = 6,
} print_port_e;


void delaysTcnt(uint32_t t_count);
void UART_Text_Print(print_port_e _uart_port, const char *_text);
void sendGPAhrs1(float* vel,double lon,double lat  ,float resolution_pdop,float resolution_eph,float resolution_epv, float resolution_vel);
void sendGPAhrs2(float* angle, float* rate, float* rlsAcc, float resolution_angle, float resolution_rate, float resolution_accel);
void sendGPAhrs3(float* vel,double lon,double lat,float resolution_pdop,float resolution_eph,float resolution_epv, float resolution_vel,float* angle, float* rate, float* rlsAcc, float resolution_angle, float resolution_rate, float resolution_accel);
void sendCanMessage(can_std_id_e _std_id, float _dataFloatX, float _dataFloatY, float _dataFloatZ, float _resolution);
void sendRS485Message(uint8_t ID, float dataFloatX, float dataFloatY, float dataFloatZ, float resolution);
void sendRS485Temp(uint8_t ID, float temp, float resolution);
void sendOriMsg(float* accel, float* gyro, float* mag, float temp, float resAccel, float resGyro,float resMag, float resTemp);
void sendAhrsAllMsg(uint8_t ID, float* angle, float* rate, float resolution_angle, float resolution_rate);
void sendAhrsAllMsg9axis(float* angle, float* rate,float* rlsAcc, float resolution_angle, float resolution_rate, float resolution_accel);
unsigned short CheckSum(char *addr, int count);
uint8_t getCheckSumByte(uint8_t *addr, int start_idx, int end_idx);
void sendAhrsQMsg(uint8_t ID, float* q, float resolution_q);
void  sendAhrsAllDataRS485Msg(uint8_t ID, float* angle, float* rate, float* acc_g, float* q, float degC,float resolution_angle, float resolution_rate, float resolution_acc, float resolution_q, float resolution_T);
#endif /* DATAOUT_H_ */
