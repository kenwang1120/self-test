/*******************************************************************
* @Project:   MKE18F16_SPI_Test_Project
* @file name: ringbuff.h
* 
*===================================================================
* @Copy Right. Create by Macial.       Feb 8, 2022  10:00:27 AM
*******************************************************************/
#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#if defined(__cplusplus)
extern "C" {
#endif /*_cplusplus*/
/*==========================
*  Include Files
*=========================*/
#include <stdio.h>
#include <stdint.h>


/*==========================
 *  Declare Variables
 *=========================*/
#define BUFFER_SIZE  (uint32_t)350               //缓冲区大小

typedef enum
{
  READ_SUCCESS = (uint8_t)0,
  READ_FAULT   = (uint8_t)1,
} buffer_status_e;

typedef struct{
  uint32_t head;                 //缓冲区头部位置
  uint32_t tail;                 //缓冲区尾部位置
  uint8_t  ringBuf[BUFFER_SIZE]; //缓冲区数组
}ringBuffer_t;



/*==========================
 *  Declare Application
 *=========================*/
//!=========================================================
//! @ uint32_t RingBuf_FIFO_Count(*buf)
//! @ Return  number of data bytes in (*buf).
//!=========================================================
uint32_t RingBuf_FIFO_Count(ringBuffer_t* buf);

//!=========================================================
//! @ RingBuf_Write_xbit(*buf, data);
//! @ Put xbits of data in (*buf).
//!=========================================================
void RingBuf_Write_8bit(ringBuffer_t* buf, uint8_t data);
void RingBuf_Write_32Bit(ringBuffer_t* buf, uint32_t data);

//!=========================================================
//! @ int RingBuf_Read_xbit(*buf, *pData);
//! @ Take xbits of data out from (*buf).
//!=========================================================
int RingBuf_Read_8bit(ringBuffer_t* buf, uint8_t* pData);
int RingBuf_Read_32bit(ringBuffer_t* buf, uint32_t* pData);
int RingBuf_Read(ringBuffer_t *buf, uint8_t *pData, int _length);

//void RingBuf_Write(unsigned char data);
//
//uint8_t RingBuf_Read(unsigned char* pData);
//
//void RingBuf_Write2(unsigned char data);
//
//uint8_t RingBuf_Read2(unsigned char* pData);











#if defined(__cplusplus)
}
#endif /*_cplusplus*/

#endif
