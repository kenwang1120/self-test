/*******************************************************************
* @Project:   MKE18F16_SPI_Test_Project
* @file name: ringbuff.c
* 
*===================================================================
* @Copy Right. Create by Macial.       Feb 8, 2022  10:00:27 AM
*******************************************************************/
/*==========================
 *  Include Files
 *=========================*/
#include "ringBuff.h"
#include <string.h>  // for memset()


/*==========================
 *  Declare Variables
 *=========================*/


/*==========================
 *  Application Code
 *=========================*/
//!*************************************************************************************************
//! uint32_t RingBuf_FIFO_Count(ringBuffer_t* buf)
//!
//! @description  Get number of bytes in Ring-Buffer.
//! @param        ringBuffer_t *buf
//! @return       number of bytes
//! @req      
//!*************************************************************************************************
uint32_t RingBuf_FIFO_Count(ringBuffer_t* buf)
{
  if(buf->head > buf->tail)
  {
    return (uint32_t)(buf->head - buf->tail);
  }
  else if(buf->head < buf->tail)
  {
    return (uint32_t)(buf->head + (BUFFER_SIZE - buf->tail));
  }
  else
  {
    return 0;           // RingBuf is Empty
  }
}

//!*************************************************************************************************
//! void RingBuf_Write_8bit(ringBuffer_t* ringbuf, uint8_t data)
//! void RingBuf_Write_32Bit(ringBuffer_t* ringbuf, uint32_t data)
//!
//! @description  Put Data in Ring-Buffer
//! @param        ringbuf: 环形缓冲区結構體
//!               data:    待写入的数据
//! @return       None
//! @req      
//!*************************************************************************************************
void RingBuf_Write_8bit(ringBuffer_t* buf, uint8_t data)
{
  buf->ringBuf[++buf->head] = data;       // add data in head
  if(buf->head >= BUFFER_SIZE)            // 頭节点偏移
  {
    buf->head = 0U;                       // 大于数组最大长度 归零 形成环形队列
  }
  
  if(buf->head == buf->tail)              // 如果頭部节点追到尾部节点，则修改尾节点偏移位置丢弃早期数据
  { 
    buf->ringBuf[++buf->tail] = 0U;
    if(buf->tail >= BUFFER_SIZE)
    {
      buf->tail = 0U;
    }
  }
}

void RingBuf_Write_32Bit(ringBuffer_t* buf, uint32_t data)
{
  for(int _idx=0; _idx < 4; _idx++)
  {
    buf->ringBuf[++buf->head] = (uint8_t)(data >> ((3 - _idx)*8));      // add data in head
    if(buf->head >= BUFFER_SIZE)          // 大于数组最大长度 归零 形成环形队列
    {
      buf->head = 0U;
    }
    
    if(buf->head == buf->tail)            // 如果頭部节点追到尾部节点，则修改尾节点偏移位置丢弃早期数据
    { 
      buf->ringBuf[++buf->tail] = 0U;
      if(buf->tail >= BUFFER_SIZE)
      {
        buf->tail = 0U;
      }
    }
  }
}

//!*************************************************************************************************
//! void RingBuf_Write_8bit(ringBuffer_t* ringbuf, uint8_t data)
//! void RingBuf_Write_32bit(ringBuffer_t* ringbuf, uint32_t data)
//!
//! @description  Get data from Ring-Buffer.
//! @param        ringbuf: 环形缓冲区結構體
//!               *pData:  指针，用于保存读取到的数据
//! @return       1表示缓冲区是空的读取数据失敗，0表示读取数据成功
//! @req      
//!*************************************************************************************************
int RingBuf_Read_8bit(ringBuffer_t *buf, uint8_t *pData)
{
  memset((void*)pData, 0, sizeof(uint8_t));
//  if(buf->tail == buf->head)               // 如果头尾接触表示缓冲区为空
//  {
//    return READ_FAULT;                     // 返回1，环形缓冲区是空的
//  }
  if(RingBuf_FIFO_Count(buf) == 0)
  {
	  return READ_FAULT;
  }
  else
  {
    *pData = buf->ringBuf[++buf->tail];    //如果缓冲区非空则取头节点值并偏移头节点
    if(buf->tail >= BUFFER_SIZE)
    {
      buf->tail = 0U;
    }
    return READ_SUCCESS;                   //返回0，表示读取数据成功
  }

}

int RingBuf_Read_32bit(ringBuffer_t *buf, uint32_t *pData)
{
  memset((void*)pData, 0, sizeof(uint32_t));
  if(RingBuf_FIFO_Count(buf) < sizeof(uint32_t))
  {
    return READ_FAULT;
  }
  
  for(int _idx=0; _idx < sizeof(uint32_t); _idx++)
  {    
    *pData |= (uint32_t)(buf->ringBuf[++buf->tail] << ((3 - _idx)*8));        //如果缓冲区非空则取头节点值并偏移头节点
    
    if(buf->tail >= BUFFER_SIZE)
    {
      buf->tail = 0U;
    }
  }
  
  return READ_SUCCESS;                                                        //返回0，表示读取数据成功
  
}

int RingBuf_Read(ringBuffer_t *buf, uint8_t *pData, int _length)
{
	if(RingBuf_FIFO_Count(buf) < _length)
	{
		return READ_FAULT;
	}

	for(int _idx = 0; _idx < _length; _idx++)
	{
		pData[_idx] = buf->ringBuf[++buf->tail];    //如果缓冲区非空则取头节点值并偏移头节点
	    if(buf->tail >= BUFFER_SIZE)
	    {
	      buf->tail = 0U;
	    }
	}
    return READ_SUCCESS;                   //返回0，表示读取数据成功
}

