/**************************************************************************************************/
//! @ProjectName: AIMU
//! @ModuleName:  facModeInit
//!
//! @Purpose:
//! Functions for facModeInit.
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//**************************************************************************************************
#include <stdint.h>

//**************************************************************************************************
// Internal Function Prototypes
//**************************************************************************************************
void error_trap(void);
void app_finalize(void);
void facModeGPIO_init(void);
//void initFlashNVM(uint32_t *params, uint8_t msgLen);
//void facModeGPIO_init(void);
//uint32_t getFlag(void);
//void readFromFlashNVM(float* params, int* config, float res_accel, float res_gyro, float res_mag);
//void readFromFlashNVM2(float* params, int* config, float res_accel, float res_gyro, float res_mag);
//void readFromFlashNVM3(uint32_t* params);
uint32_t serialChar2Int(uint8_t* bytesIn, float resolution);
uint32_t serialChar2IntMag(uint8_t* bytesIn, float resolution);
uint32_t serialChar2IntConfig(uint8_t* bytesIn);
//void read_flash_block(uint32_t*, int , int);
//void write_flash_block(uint32_t* params, uint8_t msgLen, int block);
//void write_flash_block3(uint32_t* params, uint8_t msgLen, int block);
