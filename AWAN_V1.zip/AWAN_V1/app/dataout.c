//******************************************************************************
//! @ProjectName: AWAN_V1
//! @ModuleName:  dataout
//! @Purpose:  Functions for dataout.
//!
//! AWAN Proprietary
//!
//! @AWAN All rights reserved.
//******************************************************************************
//******************************************************************************
// Included Files
//******************************************************************************
#include <string.h>
#include "can.h"
#include "usart.h"
#include "dataout.h"
#include "LiLinEncoder.h"
#include "timestamp.h"
#include "scheduler.h"

//******************************************************************************
// Declare Variables
int interr=0;
int kkk=0;
extern int zputFlag;
extern int biasFlag;
extern uint16_t cntGPSDelay;
//******************************************************************************
void delaysTcnt(uint32_t t_count)
{
	do {
		asm volatile("nop;nop;nop;nop;nop;nop;nop;nop;nop;nop;");
	} while (t_count-- > 0);
}


//******************************************************************************
// Exported Function Implementation
//******************************************************************************
//!*************************************************************************************************
//! void Text_Print(const char *_text)
//!
//! @description  Print out Text 
//! @param        const char *_text
//! @return       None
//! @req      
//!*************************************************************************************************
void UART_Text_Print(print_port_e _uart_port, const char *_text)
{
	char str[100];
	memset(str, 0, strlen(str));
	strcpy(str, _text);

	switch(_uart_port)
	{
	case UART3_Print:
		LPUART3_Send((uint8_t*)str, (int)strlen(str));
		break;

	case UART6_Print:
		LPUART6_Send((uint8_t*)str, (int)strlen(str));
		break;

	case UART1_Print:
	default:
		LPUART3_Send((uint8_t*)str, (int)strlen(str));
		LPUART1_Send((uint8_t*)str, (int)strlen(str));
		break;
	}
//	__DSB();
}


//!*************************************************************************************************
//! void LPSPI0_Master_Init()
//! void LPSPI1_Slave_Init()
//!
//! @description  LPSPI0_Master_Init is Master Mode for Sensor. 
//!               LPSPI1_Slave_Init is Slave Mode for Client Communicate Interface
//! @param        None
//! @return       None
//! @req      
//!*************************************************************************************************
void sendAhrsAllDataRS485Msg(uint8_t ID, float* angle, float* rate, float* acc_g, float* q, float degC
                          ,float resolution_angle, float resolution_rate, float resolution_acc, float resolution_q, float resolution_T)
{
  uint8_t dataRS485Msg[31];
  int16_t tempW, tempX, tempY, tempZ;
  int16_t tempQ0, tempQ1, tempQ2, tempQ3;
  int16_t temperatureTemp;
//  uint16_t checkSumBytes; 
  uint8_t checkSumByte; 
  
  dataRS485Msg[0] = 0xAA;
  dataRS485Msg[1] = ID;
  
  tempX = (int16_t)(angle[0] / resolution_angle);
  tempY = (int16_t)(angle[1] / resolution_angle);
  tempZ = (int16_t)(angle[2] / resolution_angle);
  
  dataRS485Msg[2] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[3] = tempX & 0x00FF; 
  
  dataRS485Msg[4] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[5] = tempY & 0x00FF;  
  
  dataRS485Msg[6] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[7] = tempZ & 0x00FF;  
  
  tempX = (int16_t)(rate[0] / resolution_rate);
  tempY = (int16_t)(rate[1] / resolution_rate);
  tempZ = (int16_t)(rate[2] / resolution_rate);
  
  dataRS485Msg[8] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[9] = tempX & 0x00FF; 
  
  dataRS485Msg[10] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[11] = tempY & 0x00FF;  
  
  dataRS485Msg[12] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[13] = tempZ & 0x00FF;  
  
  
  tempX = (int16_t)(acc_g[0] / resolution_acc);
  tempY = (int16_t)(acc_g[1] / resolution_acc);
  tempZ = (int16_t)(acc_g[2] / resolution_acc);
  
  dataRS485Msg[14] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[15] = tempX & 0x00FF; 
  
  dataRS485Msg[16] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[17] = tempY & 0x00FF;  
  
  dataRS485Msg[18] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[19] = tempZ & 0x00FF;  
  
  tempQ0 = (int16_t)(q[0] / resolution_q);
  tempQ1 = (int16_t)(q[1] / resolution_q);
  tempQ2 = (int16_t)(q[2] / resolution_q);
  tempQ3 = (int16_t)(q[2] / resolution_q);
  
  dataRS485Msg[20] = (tempQ0 & 0xFF00) >> 8;
  dataRS485Msg[21] = tempQ0 & 0x00FF; 
  
  dataRS485Msg[22] = (tempQ1 & 0xFF00) >> 8;
  dataRS485Msg[23] = tempQ1 & 0x00FF;  
  
  dataRS485Msg[24] = (tempQ2 & 0xFF00) >> 8;
  dataRS485Msg[25] = tempQ2 & 0x00FF;  
  
  dataRS485Msg[26] = (tempQ3 & 0xFF00) >> 8;
  dataRS485Msg[27] = tempQ3 & 0x00FF;  

  tempW = (int)degC;
  
  temperatureTemp = (int16_t)(tempW / resolution_T);
  temperatureTemp = temperatureTemp << 5;
  
  dataRS485Msg[28] = (temperatureTemp & 0xFF00) >> 8;
  dataRS485Msg[29] = temperatureTemp & 0x00FF;

  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 29);
  dataRS485Msg[30] = checkSumByte;
  
  
#if defined USE_RS485_INTERFACE
  LPUART1_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
//  delaysTcnt(100);
  __DSB();
}


void sendAhrsQMsg(uint8_t ID, float* q, float resolution_q)
{
  
  uint8_t dataRS485Msg[11];
  int16_t tempQ0, tempQ1, tempQ2, tempQ3;
//  uint16_t checkSumBytes; 
  uint8_t checkSumByte; 
  
  dataRS485Msg[0] = 0xAA;
  dataRS485Msg[1] = ID;
  
  tempQ0 = (int16_t)(q[0] / resolution_q);
  tempQ1 = (int16_t)(q[1] / resolution_q);
  tempQ2 = (int16_t)(q[2] / resolution_q);
  tempQ3 = (int16_t)(q[2] / resolution_q);
  
  dataRS485Msg[2] = (tempQ0 & 0xFF00) >> 8;
  dataRS485Msg[3] = tempQ0 & 0x00FF; 
  
  dataRS485Msg[4] = (tempQ1 & 0xFF00) >> 8;
  dataRS485Msg[5] = tempQ1 & 0x00FF;  
  
  dataRS485Msg[6] = (tempQ2 & 0xFF00) >> 8;
  dataRS485Msg[7] = tempQ2 & 0x00FF;  
  
  dataRS485Msg[8] = (tempQ3 & 0xFF00) >> 8;
  dataRS485Msg[9] = tempQ3 & 0x00FF;  
  
//  checkSumBytes = CheckSum(dataRS485Msg, 8);
//  dataRS485Msg[8] = (checkSumBytes & 0xFF00) >> 8;
//  dataRS485Msg[9] = checkSumBytes & 0x00FF;
  
  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 9);
  dataRS485Msg[10] = checkSumByte;
  
#if defined USE_RS485_INTERFACE
  LPUART1_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
//  delaysTcnt(100);
  __DSB();
  
  
}



//******************************************************************************
//! @fn void sendCanMessage(uint32_t _std_id, uint8_t _dev_id, uint8_t _data_id,
//!                     float _dataFloatX, float _dataFloatY, float _dataFloatZ,
//!                     float _resolution)
//!
//! @description  CAN interface output layer.
//! @param        _std_id   CAN ID
//!               _dev_id
//!               _data_id  0x1:Angle/ 0x2:Gyro / 0x3:Accel.....ref manual_v1.5
//!               _dataFloatX   X axis data
//!               _dataFloatY   Y axis data
//!               _dataFloatZ   Z axis data
//!               _resolution   x,y,z resolution
//! @return       void
//! @req 
//******************************************************************************
void sendCanMessage(can_std_id_e _std_id, float _dataFloatX, float _dataFloatY, float _dataFloatZ, float _resolution)
{
	uint8_t _output[8] = {0};
	int16_t tempX, tempY, tempZ;
	uint8_t checkSumByte = 0;

	tempX = (int16_t)(_dataFloatX / _resolution);
	tempY = (int16_t)(_dataFloatY / _resolution);
	tempZ = (int16_t)(_dataFloatZ / _resolution);

	_output[0] = (uint8_t)DEVICE_ID;
	/* data */
	_output[1] = (uint8_t)((tempX & 0xFF00) >> 8);
	_output[2] = (uint8_t)((tempX & 0x00FF));
	_output[3] = (uint8_t)((tempY & 0xFF00) >> 8);
	_output[4] = (uint8_t)((tempY & 0x00FF));
	_output[5] = (uint8_t)((tempZ & 0xFF00) >> 8);
	_output[6] = (uint8_t)((tempZ & 0x00FF));
	/* checksum */
	checkSumByte = getCheckSumByte(_output, 1, 6);
	_output[7] = checkSumByte;


	CAN_Send(&hcan2, (uint32_t)_std_id, _output);
	__DSB();
}


//******************************************************************************
//! @fn void sendRS485Message(float dataFloatX, float dataFloatY,float dataFloatZ)
//!
//! @description
//!  CAN interface output layer.
//!
//! @param    dataFloatX   X axis data
//!           dataFloatY   Y axis data
//!           dataFloatZ   Z axis data
//!           
//! @return   void
//!
//! @req 
//******************************************************************************
void sendRS485Message(uint8_t ID, float dataFloatX, float dataFloatY, float dataFloatZ, float resolution)
{
  
  uint8_t dataRS485Msg[9];
  int16_t tempX, tempY, tempZ;
//  uint16_t checkSumBytes; 
  uint8_t checkSumByte; 
  
  tempX = (int16_t)(dataFloatX / resolution);
  tempY = (int16_t)(dataFloatY / resolution);
  tempZ = (int16_t)(dataFloatZ / resolution);
  
  
  dataRS485Msg[0] = 0xAA;
  dataRS485Msg[1] = ID;
  
  dataRS485Msg[2] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[3] = tempX & 0x00FF; 
  
  dataRS485Msg[4] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[5] = tempY & 0x00FF;  
  
  dataRS485Msg[6] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[7] = tempZ & 0x00FF;  
  
  
//  checkSumBytes = CheckSum(dataRS485Msg, 8);
//  dataRS485Msg[8] = (checkSumBytes & 0xFF00) >> 8;
//  dataRS485Msg[9] = checkSumBytes & 0x00FF;
  
  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 7);
  dataRS485Msg[8] = checkSumByte;
  
  
#if defined USE_RS485_INTERFACE
  LPUART1_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
//  delaysTcnt(100);
  __DSB();
  
  
}

//******************************************************************************
//! @fn void sendAhrsAllRS485Msg(uint8_t ID, float* angle, float* rate, float resolution, float resolution_rate)
//!
//! @description
//!  CAN interface output layer.
//!
//! @param    dataFloatX   X axis data
//!           dataFloatY   Y axis data
//!           dataFloatZ   Z axis data
//!           
//! @return   void
//!
//! @req 
//******************************************************************************
void sendAhrsAllMsg(uint8_t ID, float* angle, float* rate, float resolution_angle, float resolution_rate)
{
  
  uint8_t dataRS485Msg[15];
  int16_t tempX, tempY, tempZ;
//  uint16_t checkSumBytes; 
  uint8_t checkSumByte; 
  
  dataRS485Msg[0] = 0xAA;
  dataRS485Msg[1] = ID;
  
  tempX = (int16_t)(angle[0] / resolution_angle);
  tempY = (int16_t)(angle[1] / resolution_angle);
  tempZ = (int16_t)(angle[2] / resolution_angle);
  
  dataRS485Msg[2] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[3] = tempX & 0x00FF; 
  
  dataRS485Msg[4] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[5] = tempY & 0x00FF;  
  
  dataRS485Msg[6] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[7] = tempZ & 0x00FF;  
  
  tempX = (int16_t)(rate[0] / resolution_rate);
  tempY = (int16_t)(rate[1] / resolution_rate);
  tempZ = (int16_t)(rate[2] / resolution_rate);
  
  dataRS485Msg[8] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[9] = tempX & 0x00FF; 
  
  dataRS485Msg[10] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[11] = tempY & 0x00FF;  
  
  dataRS485Msg[12] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[13] = tempZ & 0x00FF;  
  
  
//  checkSumBytes = CheckSum(dataRS485Msg, 8);
//  dataRS485Msg[8] = (checkSumBytes & 0xFF00) >> 8;
//  dataRS485Msg[9] = checkSumBytes & 0x00FF;
  
  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 13);
  dataRS485Msg[14] = checkSumByte;
  
  
#if defined USE_RS485_INTERFACE
  LPUART1_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
//  delaysTcnt(100);
  __DSB();
  
  
}

//******************************************************************************
//! @fn void sendRS485Temp(uint8_t ID, float temp, float resolution)
//!
//! @description
//!  CAN interface output layer.
//!
//! @param    dataFloatX   X axis data
//!           dataFloatY   Y axis data
//!           dataFloatZ   Z axis data
//!           
//! @return   void
//!
//! @req 
//******************************************************************************
void sendRS485Temp(uint8_t ID, float temp, float resolution)
{
  
  uint8_t dataRS485Msg[5];
  int16_t temperatureTemp; 
  uint8_t checkSumByte; 
  
  dataRS485Msg[0] = 0xAA;
  dataRS485Msg[1] = ID;
  temperatureTemp = (int16_t)(temp / resolution);
  temperatureTemp = temperatureTemp << 5;
  
  dataRS485Msg[2] = (temperatureTemp & 0xFF00) >> 8;
  dataRS485Msg[3] = temperatureTemp & 0x00FF;
  
  
//  checkSumBytes = CheckSum(dataRS485Msg, 8);
//  dataRS485Msg[8] = (checkSumBytes & 0xFF00) >> 8;
//  dataRS485Msg[9] = checkSumBytes & 0x00FF;
  
  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 3);
  dataRS485Msg[4] = checkSumByte;
  
  
#if defined USE_RS485_INTERFACE
  LPUART1_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send(dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
#endif
//  delaysTcnt(100);
  __DSB();
  
  
}

//******************************************************************************
//! @fn void sendOriMsg(uint8_t ID, float* accel, float* gyro, float* mag, float temp, float resolution)
//!
//! @description
//!  CAN interface output layer.
//!
//! @param    dataFloatX   X axis data
//!           dataFloatY   Y axis data
//!           dataFloatZ   Z axis data
//!           
//! @return   void
//!
//! @req 
//******************************************************************************
void sendOriMsg(float* accel, float* gyro, float* mag, float temp, float resAccel, float resGyro, float resMag, float resTemp)
{
  uint8_t dataRS485Msg[23];
  int16_t tempX, tempY, tempZ, temperatureTemp;
//  uint16_t checkSumBytes; 
  int _len = 0;
  uint8_t checkSumByte; 

  dataRS485Msg[0] = 0xAA;
  dataRS485Msg[1] = (uint8_t)DEVICE_ID;
  
  switch(DEVICE_ID)
  {
  case 0x17:
	  _len = 23;
	  tempX = (int16_t)(accel[0] / resAccel);
	  tempY = (int16_t)(accel[1] / resAccel);
	  tempZ = (int16_t)(accel[2] / resAccel);
	  dataRS485Msg[2] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[3] = tempX & 0x00FF;

	  dataRS485Msg[4] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[5] = tempY & 0x00FF;
	  dataRS485Msg[6] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[7] = tempZ & 0x00FF;

	  tempX = (int16_t)(gyro[0] / resGyro);
	  tempY = (int16_t)(gyro[1] / resGyro);
	  tempZ = (int16_t)(gyro[2] / resGyro);
	  dataRS485Msg[8] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[9] = tempX & 0x00FF;
	  dataRS485Msg[10] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[11] = tempY & 0x00FF;
	  dataRS485Msg[12] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[13] = tempZ & 0x00FF;

	  tempX = (int16_t)(mag[1] / resMag); // for IMU only axis align to ACC and gyro
	  tempY = (int16_t)(mag[0] / resMag);
	  tempZ = (int16_t)(mag[2] / resMag);
	  dataRS485Msg[14] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[15] = tempX & 0x00FF;
	  dataRS485Msg[16] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[17] = tempY & 0x00FF;
	  dataRS485Msg[18] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[19] = tempZ & 0x00FF;

	  temperatureTemp = (int16_t)(temp / resTemp);
	  temperatureTemp = temperatureTemp << 5;

	  dataRS485Msg[20] = (temperatureTemp & 0xFF00) >> 8;
	  dataRS485Msg[21] = temperatureTemp & 0x00FF;

	  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 21);
	  dataRS485Msg[22] = checkSumByte;
	  break;

  case 0x9A:
  case 0x9B:
	  _len = 15;
	  /* Gyro */
	  tempX = (int16_t)(gyro[0] / resGyro);
	  tempY = (int16_t)(gyro[1] / resGyro);
	  tempZ = (int16_t)(gyro[2] / resGyro);
	  dataRS485Msg[2] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[3] = tempX & 0x00FF;
	  dataRS485Msg[4] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[5] = tempY & 0x00FF;
	  dataRS485Msg[6] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[7] = tempZ & 0x00FF;

	  /* Acc */
	  tempX = (int16_t)(accel[0] / resAccel);
	  tempY = (int16_t)(accel[1] / resAccel);
	  tempZ = (int16_t)(accel[2] / resAccel);
	  dataRS485Msg[8] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[9] = tempX & 0x00FF;
	  dataRS485Msg[10] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[11] = tempY & 0x00FF;
	  dataRS485Msg[12] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[13] = tempZ & 0x00FF;

	  checkSumByte = getCheckSumByte(dataRS485Msg, 2, 13);
	  dataRS485Msg[14] = checkSumByte;
	  break;

  case 0xA1:
  case 0xA2:
  case 0xB1:
  case 0xB2:
	  _len = 21;
	  /* Gyro */
	  tempX = (int16_t)(gyro[0] / resGyro);
	  tempY = (int16_t)(gyro[1] / resGyro);
	  tempZ = (int16_t)(gyro[2] / resGyro);
	  dataRS485Msg[2] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[3] = tempX & 0x00FF;
	  dataRS485Msg[4] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[5] = tempY & 0x00FF;
	  dataRS485Msg[6] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[7] = tempZ & 0x00FF;

	  /* Acc */
	  tempX = (int16_t)(accel[0] / resAccel);
	  tempY = (int16_t)(accel[1] / resAccel);
	  tempZ = (int16_t)(accel[2] / resAccel);
	  dataRS485Msg[8] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[9] = tempX & 0x00FF;
	  dataRS485Msg[10] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[11] = tempY & 0x00FF;
	  dataRS485Msg[12] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[13] = tempZ & 0x00FF;

	  /* Mag */
	  tempX = (int16_t)(mag[1] / resMag); // for IMU only axis align to ACC and gyro
	  tempY = (int16_t)(mag[0] / resMag);
	  tempZ = (int16_t)(mag[2] / resMag);
	  dataRS485Msg[14] = (tempX & 0xFF00) >> 8;
	  dataRS485Msg[15] = tempX & 0x00FF;
	  dataRS485Msg[16] = (tempY & 0xFF00) >> 8;
	  dataRS485Msg[17] = tempY & 0x00FF;
	  dataRS485Msg[18] = (tempZ & 0xFF00) >> 8;
	  dataRS485Msg[19] = tempZ & 0x00FF;

	  checkSumByte = getCheckSumByte(dataRS485Msg, 2,19);
	  dataRS485Msg[20] = checkSumByte;
	  break;

  }
  
  
  

  
//  checkSumBytes = CheckSum(dataRS485Msg, 8);
//  dataRS485Msg[22] = (checkSumBytes & 0xFF00) >> 8;
//  dataRS485Msg[23] = checkSumBytes & 0x00FF;
  
#if defined USE_RS485_INTERFACE
  LPUART1_Send(dataRS485Msg, _len);
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send(dataRS485Msg, _len);
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send(dataRS485Msg, _len);
#endif
//  LPUART1_Send(dataRS485Msg, _len);
//  LPUART3_Send(dataRS485Msg, _len);
  __DSB();
//  LPUART0_Send((uint8_t const*)dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
  
  
}

unsigned short CheckSum(char *addr, int count)
{
  register int sum = 0;
  
  while( count > 1 ) 
  {
    sum =sum + *(unsigned short*)addr;
    addr+=2;
    count -= 2;
  }
  
  if( count > 0 )//=1,˵��countΪ����
    sum += *addr;
  
  while (sum>>16)//���͵ĸ�16λ��Ϊ0���Ѹ�16λ��ΪУ��͵�һ������ͣ�
    sum = (sum & 0xffff) + (sum >> 16);
  
  return (short)~sum;
}

uint8_t getCheckSumByte(uint8_t *addr, int start_idx, int end_idx)  // No Length Byte
{
  register uint32_t sum = 0;
  uint8_t checkSum;
  
  for(int _idx = start_idx; _idx <= end_idx; _idx++){
    sum += addr[_idx];
  }
  
  checkSum = (uint8_t)(sum & 0xff); // Take lower 8 bits
  //checkSum = sum % 256; // Take lower 8 bits
   return checkSum;
}


//******************************************************************************
//! @fn void sendAhrsAllMsg9axis(uint8_t ID, float* angle, float* rate,float* rlsAcc, float resolution, float resolution_rate)
//!
//! @description
//!  CAN interface output layer.
//!
//! @param    dataFloatX   X axis data
//!           dataFloatY   Y axis data
//!           dataFloatZ   Z axis data
//!           
//! @return   void
//!
//! @req 
//******************************************************************************
void sendAhrsAllMsg9axis(float* angle, float* rate, float* rlsAcc, float resolution_angle, float resolution_rate, float resolution_accel)
{
  uint8_t dataRS485Msg[31];
  int16_t tempX, tempY, tempZ;
  uint8_t checkSumByte;
  uint8_t total_length = 33;
  int _idx = 0;
  int _shift_idx = 2;
  
  dataRS485Msg[_idx] = 0xAA;
  dataRS485Msg[_idx+1] = (uint8_t)DEVICE_ID;
  
#if defined LILIN_MODULE
  total_length = 22;
  dataRS485Msg[_idx+2] = 19U;
  _idx = 1;
  _shift_idx = 3;
#endif

  tempX = (int16_t)(gps.vel / resolution_angle);
  tempY = (int16_t)(gps.distance / resolution_angle);
 // tempZ = (int16_t)(vel[1] / resolution_angle);
//
//  tempX = (int16_t)(gps.vel_n_rG / resolution_angle);
//    tempY = (int16_t)(gps.vel_e_rG / resolution_angle);
//    tempZ = (int16_t)(gps.vel / resolution_angle);

    tempX = (int16_t)(angle[0] / resolution_angle);
    tempY = (int16_t)(angle[1] / resolution_angle);
    tempZ = (int16_t)(angle[2]/ resolution_angle);

//  /* Encoder */
//  dataRS485Msg[_idx++] = lilin_data.encoder.u8bit[1];
//  dataRS485Msg[_idx++] = lilin_data.encoder.u8bit[0];
  /* Roll */
    dataRS485Msg[_idx + 2] = (tempX & 0xFF00) >> 8;
    dataRS485Msg[_idx + 3] = tempX & 0x00FF;
    dataRS485Msg[_idx + 4] = (tempY & 0xFF00) >> 8;
    dataRS485Msg[_idx + 5] = tempY & 0x00FF;
    dataRS485Msg[_idx + 6] = (tempZ & 0xFF00) >> 8;
    dataRS485Msg[_idx + 7] = tempZ & 0x00FF;



  tempX = (int16_t)(rate[0] / resolution_rate);
  tempY = (int16_t)(rate[1] / resolution_rate);
  tempZ = (int16_t)(rate[2] / resolution_rate);


  dataRS485Msg[_idx + 8 ] = (tempX & 0xFF00) >> 8;
  dataRS485Msg[_idx + 9 ] = tempX & 0x00FF;
  dataRS485Msg[_idx + 10] = (tempY & 0xFF00) >> 8;
  dataRS485Msg[_idx + 11] = tempY & 0x00FF;
  dataRS485Msg[_idx + 12] = (tempZ & 0xFF00) >> 8;
  dataRS485Msg[_idx + 13] = tempZ & 0x00FF;



    tempX = (int16_t)(rlsAcc[0] / resolution_accel);
    tempY = (int16_t)(rlsAcc[1] / resolution_accel);
    tempZ = (int16_t)(rlsAcc[2] / resolution_accel);

    dataRS485Msg[_idx + 14] = (tempX & 0xFF00) >> 8;
    dataRS485Msg[_idx + 15] = tempX & 0x00FF;
    dataRS485Msg[_idx + 16] = (tempY & 0xFF00) >> 8;
    dataRS485Msg[_idx + 17] = tempY & 0x00FF;
    dataRS485Msg[_idx + 18] = (tempZ & 0xFF00) >> 8;
    dataRS485Msg[_idx + 19] = tempZ & 0x00FF;
    checkSumByte = getCheckSumByte(dataRS485Msg, _shift_idx, (_shift_idx + (18 - 1)));
    dataRS485Msg[_idx + 20] = checkSumByte;
   // LPUART3_Send((uint8_t*)dataRS485Msg, (int)21);

//     tempX = (int16_t)(angle[0] / resolution_angle);
//     tempY = (int16_t)(angle[1] / resolution_angle);
//     tempZ = (int16_t)(angle[2] / resolution_angle);
//     dataRS485Msg[_idx + 2] = (tempX & 0xFF00) >> 8;
//     dataRS485Msg[_idx + 3] = tempX & 0x00FF;
//     dataRS485Msg[_idx + 4] = (tempY & 0xFF00) >> 8;
//     dataRS485Msg[_idx + 5] = tempY & 0x00FF;
//     dataRS485Msg[_idx + 6] = (tempZ & 0xFF00) >> 8;
//     dataRS485Msg[_idx + 7] = tempZ & 0x00FF;
//
//
//      tempX = (int16_t)(rate[0] / resolution_rate);
//      tempY = (int16_t)(rate[1] / resolution_rate);
//      tempZ = (int16_t)(rate[2] / resolution_rate);
//      dataRS485Msg[_idx + 8 ] = (tempX & 0xFF00) >> 8;
//      dataRS485Msg[_idx + 9 ] = tempX & 0x00FF;
//      dataRS485Msg[_idx + 10] = (tempY & 0xFF00) >> 8;
//      dataRS485Msg[_idx + 11] = tempY & 0x00FF;
//      dataRS485Msg[_idx + 12] = (tempZ & 0xFF00) >> 8;
//      dataRS485Msg[_idx + 13] = tempZ & 0x00FF;
    //   dataRS485Msg[_idx + 14] = (gps.lat& 0xff000000)>>24;
    //   dataRS485Msg[_idx + 15] = (gps.lat& 0x00ff0000)>>16;
    //   dataRS485Msg[_idx + 16] = (gps.lat& 0x0000ff00)>>8;
    //   dataRS485Msg[_idx + 17] = (gps.lat & 0x000000ff);
    //   dataRS485Msg[_idx + 18] = (gps.lon& 0xff000000)>>24;
    //   dataRS485Msg[_idx + 19] = (gps.lon& 0x00ff0000)>>16;
    //   dataRS485Msg[_idx + 20] = (gps.lon& 0x0000ff00)>>8;
    //   dataRS485Msg[_idx + 21] = (gps.lon& 0x000000ff);
    //
    //   uint32_t time_usec = timestamp_usec;
    //   uint32_t time_sec = get_timestamp_sec();
    //   dataRS485Msg[_idx + 22] = (time_usec & 0xff000000)>>24;
    //   dataRS485Msg[_idx + 23] = (time_usec & 0x00ff0000)>>16;
    //   dataRS485Msg[_idx + 24] = (time_usec & 0x0000ff00)>>8;
    //   dataRS485Msg[_idx + 25] = (time_usec & 0x000000ff);
    //   dataRS485Msg[_idx + 26] = (time_sec & 0xff000000)>>24;
    //   dataRS485Msg[_idx + 27] = (time_sec & 0x00ff0000)>>16;
    //   dataRS485Msg[_idx + 28] = (time_sec & 0x0000ff00)>>8;
    //   dataRS485Msg[_idx + 29] = (time_sec & 0x000000ff);
    //
    //  checkSumByte = getCheckSumByte(dataRS485Msg, _shift_idx, (_shift_idx + (27 - 1)));
    //  dataRS485Msg[_idx + 30] = checkSumByte;
      //dataRS485Msg[_idx + 31] = 0xff






   //  tempX = (int16_t)(vel[0]/resolution_rate);
	// tempY = (int16_t)(dis[0]/resolution_rate);
	 tempZ = (int16_t)(gps.pdop/resolution_rate);


	// tempZ = (int16_t)(gps.heading / resolution_angle);


	 dataRS485Msg[_idx + 2] = (gps.lon& 0xff000000)>>24;
	 dataRS485Msg[_idx + 3] = (gps.lon& 0x00ff0000)>>16;
	 dataRS485Msg[_idx + 4] = (gps.lon& 0x0000ff00)>>8;
	 dataRS485Msg[_idx + 5] = (gps.lon& 0x000000ff);
	 dataRS485Msg[_idx + 6] = (tempZ & 0xFF00) >> 8;
	 dataRS485Msg[_idx + 7] = tempZ & 0x00FF;
//   uint32_t yaw_acc1=yaw_acc*10000000;
//   dataRS485Msg[_idx + 9] = (yaw_acc1 & 0xff000000)>>24;
//   dataRS485Msg[_idx + 10 ] = (yaw_acc1 & 0x00ff0000)>>16;
//   dataRS485Msg[_idx + 11 ] = (yaw_acc1 & 0x0000ff00)>>8;
//   dataRS485Msg[_idx + 12] = (yaw_acc1 & 0x000000ff);
//
//   dataRS485Msg[_idx + 13] = 0xff;
//   uint32_t dis=gps.distance*10000000;
//   dataRS485Msg[_idx + 14] = (dis& 0xff000000)>>24;
//   dataRS485Msg[_idx + 15] = (dis& 0x00ff0000)>>16;
//   dataRS485Msg[_idx + 16] = (dis& 0x0000ff00)>>8;
//   dataRS485Msg[_idx + 17] = (dis & 0x000000ff);
//   dataRS485Msg[_idx + 18] = (gps.lon& 0xff000000)>>24;
//   dataRS485Msg[_idx + 19] = (gps.lon& 0x00ff0000)>>16;
//   dataRS485Msg[_idx + 20] = (gps.lon& 0x0000ff00)>>8;
//   dataRS485Msg[_idx + 21] = (gps.lon& 0x000000ff);



    tempX = (int16_t)(rate[0] / resolution_rate);
	tempY = (int16_t)(rate[1] / resolution_rate);
	tempZ = (int16_t)(rate[2] / resolution_rate);

	dataRS485Msg[_idx + 8 ] = (tempX & 0xFF00) >> 8;
	dataRS485Msg[_idx + 9 ] = tempX & 0x00FF;
	dataRS485Msg[_idx + 10] = (tempY & 0xFF00) >> 8;
	dataRS485Msg[_idx + 11] = tempY & 0x00FF;
	dataRS485Msg[_idx + 12] = (tempZ & 0xFF00) >> 8;
	dataRS485Msg[_idx + 13] = tempZ & 0x00FF;





   tempX = (int16_t)(angle[0]  /resolution_angle);
   tempY = (int16_t)(angle[1]/resolution_angle );
   tempZ = (int16_t)(angle[2] /resolution_angle);


   dataRS485Msg[_idx + 14] = (tempX & 0xFF00) >> 8;
   dataRS485Msg[_idx + 15] = tempX & 0x00FF;
   dataRS485Msg[_idx + 16] = (tempY & 0xFF00) >> 8;
   dataRS485Msg[_idx + 17] = tempY & 0x00FF;
   dataRS485Msg[_idx + 18] = (tempZ & 0xFF00) >> 8;
   dataRS485Msg[_idx + 19] = tempZ & 0x00FF;


//   tempX = (int16_t)((float)(gps.lon/10000000)/resolution_rate);
//   tempY = (int16_t)((float)(gps.lat/10000000)/resolution_rate);
   tempX = (int16_t)(gps.lon /resolution_rate);
   tempY = (int16_t)(gps.lat/resolution_rate );
	dataRS485Msg[_idx + 20] = (gps.lat& 0xff000000)>>24;
	dataRS485Msg[_idx + 21] = (gps.lat& 0x00ff0000)>>16;
	dataRS485Msg[_idx + 22] = (gps.lat& 0x0000ff00)>>8;
	dataRS485Msg[_idx + 23] = (gps.lat& 0x000000ff);

   tempX = (int16_t)(rlsAcc[0] / resolution_accel);
   tempY = (int16_t)(rlsAcc[1] / resolution_accel);
   tempZ = (int16_t)(rlsAcc[2] / resolution_accel);

   dataRS485Msg[_idx + 24] = (tempX & 0xFF00) >> 8;
   dataRS485Msg[_idx + 25] = tempX & 0x00FF;
   dataRS485Msg[_idx + 26] = (tempY & 0xFF00) >> 8;
   dataRS485Msg[_idx + 27] = tempY & 0x00FF;
   dataRS485Msg[_idx + 28] = (tempZ & 0xFF00) >> 8;
   dataRS485Msg[_idx + 29] = tempZ & 0x00FF;


   tempX = (int16_t)(gps.vel / resolution_accel);
   dataRS485Msg[_idx + 30] = (tempX & 0xFF00) >> 8;
   dataRS485Msg[_idx + 31] = tempX & 0x00FF;

   tempX = (int16_t)(gps.eph / resolution_accel);
   tempY = (int16_t)(gps.epv / resolution_accel);


   dataRS485Msg[_idx + 32] = (tempX & 0xFF00) >> 8;
   dataRS485Msg[_idx + 33] = tempX & 0x00FF;
   dataRS485Msg[_idx + 34] = (tempY & 0xFF00) >> 8;
   dataRS485Msg[_idx + 35] = tempY & 0x00FF;
   dataRS485Msg[_idx + 36] = gps.valid;

#if defined USE_RS485_INTERFACE
  LPUART1_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
  __DSB();
}
void sendGPAhrs1(float* vel,double lon,double lat  ,float resolution_pdop,float resolution_eph,float resolution_epv, float resolution_vel)
{
  uint8_t dataRS485Msg[30];
  int16_t tempX, tempY, tempZ;
  uint8_t checkSumByte;
  uint8_t total_length = 30;
  int _idx = 0;
  int _shift_idx = 2;

  dataRS485Msg[_idx] = 0xAA;
  dataRS485Msg[_idx+1] = (uint8_t)DEVICE_ID;

//gps state

  dataRS485Msg[_idx + 2] = gps.state;//0:*field[2] != 'A' || gps->gps_timeValid==2 , 1:*field[2] == 'A' , 2:_ext_hdg_mode == EXT_GPS
//  dataRS485Msg[_idx + 3] = gps.valid;
  dataRS485Msg[_idx + 3] =  gps.gps_timeValid;//biasFlag;//gps.heading_valid;//biasFlag
  dataRS485Msg[_idx + 4] =  zputFlag;//gps.gps_psuedoLost;//gps.gps_headingAlign;//zputFlag;//cntGPSDelay;//gps.antFlag;
//  dataRS485Msg[_idx + 5] = biasFlag;
//  dataRS485Msg[_idx + 6] = cntGPSDelay;


//gps timestamp
    uint32_t time_usec = get_usec();
   uint32_t time_sec = get_timestamp_sec();
   uint64_t time=time_sec*1000000+time_usec;
//   dataRS485Msg[_idx + 3] = (time & 0xff00000000000000)>>56;
//   dataRS485Msg[_idx + 4] = (time & 0x00ff000000000000)>>48;
//   dataRS485Msg[_idx + 5] = (time & 0x0000ff0000000000)>>40;
//   dataRS485Msg[_idx + 6] = (time & 0x000000ff00000000)>>32;
//   dataRS485Msg[_idx + 7] = (time & 0x00000000ff000000)>>24;
//   dataRS485Msg[_idx + 8] = (time & 0x0000000000ff0000)>>16;
//   dataRS485Msg[_idx + 9] = (time & 0x000000000000ff00)>>8;
//   dataRS485Msg[_idx + 10] = (time & 0x00000000000000ff);
	 tempX = (int16_t)(vel[3] / resolution_vel);
	 tempY = (int16_t)(vel[4] / resolution_vel);
	 tempZ = (int16_t)(vel[5] / resolution_vel);
	 dataRS485Msg[_idx + 5] = (tempX & 0xFF00) >> 8;
	 dataRS485Msg[_idx + 6] = tempX & 0x00FF;
	dataRS485Msg[_idx + 7] = (tempY & 0xFF00) >> 8;
	dataRS485Msg[_idx + 8] = tempY & 0x00FF;
	dataRS485Msg[_idx + 9] = (tempZ & 0xFF00) >> 8;
	dataRS485Msg[_idx + 10] = tempZ & 0x00FF;

// longitude latitude
   int32_t tempX_32 = (int32_t)(lon * 1000000);
   int32_t tempY_32 = (int32_t)(lat * 1000000);
//   int32_t tempY_32 = (int32_t)(gps_lon_lat.lat * 1000000);

	dataRS485Msg[_idx + 11] = (tempX_32 & 0xff000000)>>24;
	dataRS485Msg[_idx + 12] = (tempX_32 & 0x00ff0000)>>16;
	dataRS485Msg[_idx + 13] = (tempX_32 & 0x0000ff00)>>8;
	dataRS485Msg[_idx + 14] = (tempX_32 & 0x000000ff);
	dataRS485Msg[_idx + 15] = (tempY_32 & 0xff000000)>>24;
	dataRS485Msg[_idx + 16] = (tempY_32 & 0x00ff0000)>>16;
	dataRS485Msg[_idx + 17] = (tempY_32 & 0x0000ff00)>>8;
	dataRS485Msg[_idx + 18] = (tempY_32 & 0x000000ff);



//accuracy

//	tempX = (int16_t)(gps.pdop / resolution_pdop);
	tempY = (int16_t)(gps.gps_lost / resolution_epv);//(int16_t)(gps.epv / resolution_epv);
	tempZ = (int16_t)(zputFlag / resolution_eph);//(int16_t)(gps.eph / resolution_eph);//
//	dataRS485Msg[_idx + 19] = (tempX & 0xFF00) >> 8;
//	dataRS485Msg[_idx + 20] = tempX & 0x00FF;
	dataRS485Msg[_idx + 21] = tempY;
	dataRS485Msg[_idx + 22] = tempZ;

	 tempX = (int16_t)(vel[6] / resolution_vel);
	 dataRS485Msg[_idx + 19] = (tempX & 0xFF00) >> 8;
	 dataRS485Msg[_idx + 20] = tempX & 0x00FF;

	//velocity
	 tempX = (int16_t)(vel[0] / resolution_vel);
	 tempY = (int16_t)(vel[1] / resolution_vel);
	 tempZ = (int16_t)(vel[2] / resolution_vel);
	dataRS485Msg[_idx + 23] = (tempX & 0xFF00) >> 8;
	dataRS485Msg[_idx + 24] = tempX & 0x00FF;
	dataRS485Msg[_idx + 25] = (tempY & 0xFF00) >> 8;
	dataRS485Msg[_idx + 26] = tempY & 0x00FF;
	dataRS485Msg[_idx + 27] = (tempZ & 0xFF00) >> 8;
	dataRS485Msg[_idx + 28] = tempZ & 0x00FF;


    checkSumByte = getCheckSumByte(dataRS485Msg, _shift_idx, total_length-_shift_idx);
    dataRS485Msg[_idx + 29] = checkSumByte;


#if defined USE_RS485_INTERFACE
  LPUART1_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART_INTERFACE
  LPUART1_Send((uint8_t*)dataRS485Msg, (int)total_length);//LPUART3_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
  __DSB();
}
void sendGPAhrs2(float* angle, float* rate, float* rlsAcc, float resolution_angle, float resolution_rate, float resolution_accel)
{
  uint8_t dataRS485Msg[30];
  int16_t tempX, tempY, tempZ;
  uint8_t checkSumByte;
  uint8_t total_length = 30;
  int _idx = 0;
  int _shift_idx = 2;

  dataRS485Msg[_idx] = 0xAA;
  dataRS485Msg[_idx+1] = (uint8_t)DEVICE_ID+1;

//gps state

  dataRS485Msg[_idx + 2] = cntGPSDelay;//gps.state;
//  dataRS485Msg[_idx + 3] = biasFlag;
//  dataRS485Msg[_idx + 4] = cntGPSDelay;

//  timestamp
  uint32_t time_usec = get_usec();
    uint32_t time_sec = get_timestamp_sec();
    uint64_t time=time_sec*1000000+time_usec;
//    dataRS485Msg[_idx + 3] = (time & 0xff00000000000000)>>56;
//    dataRS485Msg[_idx + 4] = (time & 0x00ff000000000000)>>48;
//    dataRS485Msg[_idx + 5] = (time & 0x0000ff0000000000)>>40;
//    dataRS485Msg[_idx + 6] = (time & 0x000000ff00000000)>>32;
//    dataRS485Msg[_idx + 7] = (time & 0x00000000ff000000)>>24;
//    dataRS485Msg[_idx + 8] = (time & 0x0000000000ff0000)>>16;
//    dataRS485Msg[_idx + 9] = (time & 0x000000000000ff00)>>8;
//    dataRS485Msg[_idx + 10] = (time & 0x00000000000000ff);

    // longitude latitude
       int32_t tempX_32 = (int32_t)(gps_lon_lat.lon * 1000000);
       int32_t tempY_32 = (int32_t)(gps_lon_lat.lat * 1000000);

    	dataRS485Msg[_idx + 3] = (tempX_32 & 0xff000000)>>24;
    	dataRS485Msg[_idx + 4] = (tempX_32 & 0x00ff0000)>>16;
    	dataRS485Msg[_idx + 5] = (tempX_32 & 0x0000ff00)>>8;
    	dataRS485Msg[_idx + 6] = (tempX_32 & 0x000000ff);
    	dataRS485Msg[_idx + 7] = (tempY_32 & 0xff000000)>>24;
    	dataRS485Msg[_idx + 8] = (tempY_32 & 0x00ff0000)>>16;
    	dataRS485Msg[_idx + 9] = (tempY_32 & 0x0000ff00)>>8;
    	dataRS485Msg[_idx + 10] = (tempY_32 & 0x000000ff);



	tempX = (int16_t)(angle[0] / resolution_angle);
	tempY = (int16_t)(angle[1] / resolution_angle);
	tempZ = (int16_t)(angle[2]/ resolution_angle);

	/* Roll */
	dataRS485Msg[_idx + 11] = (tempX & 0xFF00) >> 8;
	dataRS485Msg[_idx + 12] = tempX & 0x00FF;
	dataRS485Msg[_idx + 13] = (tempY & 0xFF00) >> 8;
	dataRS485Msg[_idx + 14] = tempY & 0x00FF;
	dataRS485Msg[_idx + 15] = (tempZ & 0xFF00) >> 8;
	dataRS485Msg[_idx + 16] = tempZ & 0x00FF;



	tempX = (int16_t)(rate[0] / resolution_rate);
	tempY = (int16_t)(rate[1] / resolution_rate);
	tempZ = (int16_t)(rate[2] / resolution_rate);


	dataRS485Msg[_idx + 17 ] = (tempX & 0xFF00) >> 8;
	dataRS485Msg[_idx + 18 ] = tempX & 0x00FF;
	dataRS485Msg[_idx + 19] = (tempY & 0xFF00) >> 8;
	dataRS485Msg[_idx + 20] = tempY & 0x00FF;
	dataRS485Msg[_idx + 21] = (tempZ & 0xFF00) >> 8;
	dataRS485Msg[_idx + 22] = tempZ & 0x00FF;


	tempX = (int16_t)(rlsAcc[0] / resolution_accel);
	tempY = (int16_t)(rlsAcc[1] / resolution_accel);
	tempZ = (int16_t)(rlsAcc[2] / resolution_accel);

	dataRS485Msg[_idx + 23] = (tempX & 0xFF00) >> 8;
	dataRS485Msg[_idx + 24] = tempX & 0x00FF;
	dataRS485Msg[_idx + 25] = (tempY & 0xFF00) >> 8;
	dataRS485Msg[_idx + 26] = tempY & 0x00FF;
	dataRS485Msg[_idx + 27] = (tempZ & 0xFF00) >> 8;
	dataRS485Msg[_idx + 28] = tempZ & 0x00FF;


    checkSumByte = getCheckSumByte(dataRS485Msg, _shift_idx, total_length-_shift_idx);
    dataRS485Msg[_idx + 29] = checkSumByte;


#if defined USE_RS485_INTERFACE
  LPUART1_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART_INTERFACE
  LPUART1_Send((uint8_t*)dataRS485Msg, (int)total_length);//LPUART3_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
  __DSB();
}

void sendGPAhrs3(float* vel,double lon,double lat  ,float resolution_pdop,float resolution_eph,float resolution_epv, float resolution_vel,
		float* angle, float* rate, float* rlsAcc, float resolution_angle, float resolution_rate, float resolution_accel)
{
  uint8_t dataRS485Msg[48];
  int16_t tempX, tempY, tempZ;
  int32_t tempX_32,tempY_32;
  uint8_t checkSumByte;
  uint8_t total_length = 48;
  int _idx = 0;
  int _shift_idx = 2;
  static uint8_t testCnt=0;

  dataRS485Msg[_idx] = 0xAA;
  dataRS485Msg[_idx+1] = (uint8_t)DEVICE_ID;

//gps state

    dataRS485Msg[_idx + 2] = gps.state;//0,1,2//gps.test;//gps.gps_timeValid;//testCnt++;//GPAHRS mode

//  dataRS485Msg[_idx + 2] = cntGPSDelay;//gps.state;
//  dataRS485Msg[_idx + 3] = biasFlag;
//  dataRS485Msg[_idx + 4] = cntGPSDelay;

//  timestamp
  uint32_t time_usec = get_usec();
    uint32_t time_sec = get_timestamp_sec();
    uint64_t time=time_sec*1000000+time_usec;
//    dataRS485Msg[_idx + 3] = (time & 0xff00000000000000)>>56;
//    dataRS485Msg[_idx + 4] = (time & 0x00ff000000000000)>>48;
//    dataRS485Msg[_idx + 5] = (time & 0x0000ff0000000000)>>40;
//    dataRS485Msg[_idx + 6] = (time & 0x000000ff00000000)>>32;
//    dataRS485Msg[_idx + 7] = (time & 0x00000000ff000000)>>24;
//    dataRS485Msg[_idx + 8] = (time & 0x0000000000ff0000)>>16;
//    dataRS485Msg[_idx + 9] = (time & 0x000000000000ff00)>>8;
//    dataRS485Msg[_idx + 10] = (time & 0x00000000000000ff);
//  timestamp

    // longitude latitude
       tempX_32 = (int32_t)(gps_lon_lat.lon * 1000000);
       tempY_32 = (int32_t)(gps_lon_lat.lat * 1000000);

    	dataRS485Msg[_idx + 3] = (tempX_32 & 0xff000000)>>24;
    	dataRS485Msg[_idx + 4] = (tempX_32 & 0x00ff0000)>>16;
    	dataRS485Msg[_idx + 5] = (tempX_32 & 0x0000ff00)>>8;
    	dataRS485Msg[_idx + 6] = (tempX_32 & 0x000000ff);
    	dataRS485Msg[_idx + 7] = (tempY_32 & 0xff000000)>>24;
    	dataRS485Msg[_idx + 8] = (tempY_32 & 0x00ff0000)>>16;
    	dataRS485Msg[_idx + 9] = (tempY_32 & 0x0000ff00)>>8;
    	dataRS485Msg[_idx + 10] = (tempY_32 & 0x000000ff);
//use time output row to present GPS lon lat

    //calculated IMU lon lat
	// longitude latitude
	   tempX_32 = (int32_t)(lon * 1000000);
	   tempY_32 = (int32_t)(lat * 1000000);

		dataRS485Msg[_idx + 11] = (tempX_32 & 0xff000000)>>24;
		dataRS485Msg[_idx + 12] = (tempX_32 & 0x00ff0000)>>16;
		dataRS485Msg[_idx + 13] = (tempX_32 & 0x0000ff00)>>8;
		dataRS485Msg[_idx + 14] = (tempX_32 & 0x000000ff);
		dataRS485Msg[_idx + 15] = (tempY_32 & 0xff000000)>>24;
		dataRS485Msg[_idx + 16] = (tempY_32 & 0x00ff0000)>>16;
		dataRS485Msg[_idx + 17] = (tempY_32 & 0x0000ff00)>>8;
		dataRS485Msg[_idx + 18] = (tempY_32 & 0x000000ff);
	//calculated IMU lon lat

	//height (vel[6]=vn_fuse;)
		 tempX = (int16_t)(vel[6] / resolution_vel);//reserved for height
		 dataRS485Msg[_idx + 19] = (tempX & 0xFF00) >> 8;
		 dataRS485Msg[_idx + 20] = tempX & 0x00FF;
	//height

	//epv & eph //gps_split
//	tempY = gps.id;//(uint8_t)(gps.gps_headingAlign / resolution_epv);//(int16_t)(gps.epv / resolution_epv);//gps.gps_headingAlign
//	tempZ = gps.test;//(uint8_t)(zputFlag / resolution_eph);//(int16_t)(gps.eph / resolution_eph);//gps.gps_psuedoLost
	tempY = (gps.id & 0xFF00) >> 8;
	tempZ = gps.id & 0x00FF;

	dataRS485Msg[_idx + 21] = tempY;
	dataRS485Msg[_idx + 22] = tempZ;
	//epv & eph

	//GPS vel ,vel[4],vel[5]
	 tempX = (int16_t)(vel[4] / resolution_vel);//vel[4]=gps.vel_n;
	 tempY = (int16_t)(vel[5] / resolution_vel);//vel[5]=gps.vel_e;
	 tempZ = (int16_t)(vel[3] / resolution_vel);//gps.vel;
	 dataRS485Msg[_idx + 23] = (tempX & 0xFF00) >> 8;
	 dataRS485Msg[_idx + 24] = tempX & 0x00FF;
	 dataRS485Msg[_idx + 25] = (tempY & 0xFF00) >> 8;
	 dataRS485Msg[_idx + 26] = tempY & 0x00FF;
	 dataRS485Msg[_idx + 27] = (tempZ & 0xFF00) >> 8;
	 dataRS485Msg[_idx + 28] = tempZ & 0x00FF;
	//GPS vel

	 //angle
		tempX = (int16_t)(angle[0] / resolution_angle);
		tempY = (int16_t)(angle[1] / resolution_angle);
		tempZ = (int16_t)(angle[2]/ resolution_angle);

		/* Roll */
		dataRS485Msg[_idx + 29] = (tempX & 0xFF00) >> 8;
		dataRS485Msg[_idx + 30] = tempX & 0x00FF;
		dataRS485Msg[_idx + 31] = (tempY & 0xFF00) >> 8;
		dataRS485Msg[_idx + 32] = tempY & 0x00FF;
		dataRS485Msg[_idx + 33] = (tempZ & 0xFF00) >> 8;
		dataRS485Msg[_idx + 34] = tempZ & 0x00FF;

	 //rate
		tempX = (int16_t)(rate[0] / resolution_rate);
		tempY = (int16_t)(rate[1] / resolution_rate);
		tempZ = (int16_t)(rate[2] / resolution_rate);

		dataRS485Msg[_idx + 35] = (tempX & 0xFF00) >> 8;
		dataRS485Msg[_idx + 36] = tempX & 0x00FF;
		dataRS485Msg[_idx + 37] = (tempY & 0xFF00) >> 8;
		dataRS485Msg[_idx + 38] = tempY & 0x00FF;
		dataRS485Msg[_idx + 39] = (tempZ & 0xFF00) >> 8;
		dataRS485Msg[_idx + 40] = tempZ & 0x00FF;

	 //acc
		tempX = (int16_t)(rlsAcc[0] / resolution_accel);
		tempY = (int16_t)(rlsAcc[1] / resolution_accel);//(int16_t)(vel[0] / resolution_accel);//vel[0]=gpsBias;
		tempZ = (int16_t)(rlsAcc[2] / resolution_accel);//(int16_t)(vel[1] / resolution_accel);//vel[1]=accXLpf;

		dataRS485Msg[_idx + 41] = (tempX & 0xFF00) >> 8;
		dataRS485Msg[_idx + 42] = tempX & 0x00FF;
		dataRS485Msg[_idx + 43] = (tempY & 0xFF00) >> 8;
		dataRS485Msg[_idx + 44] = tempY & 0x00FF;
		dataRS485Msg[_idx + 45] = (tempZ & 0xFF00) >> 8;
		dataRS485Msg[_idx + 46] = tempZ & 0x00FF;


    checkSumByte = getCheckSumByte(dataRS485Msg, _shift_idx, total_length-_shift_idx);
    dataRS485Msg[_idx + 47] = checkSumByte;


#if defined USE_RS485_INTERFACE
  LPUART1_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART_INTERFACE
  LPUART3_Send((uint8_t*)dataRS485Msg, (int)total_length);//LPUART3_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
#if defined USE_UART6_INTERFACE
  LPUART6_Send((uint8_t*)dataRS485Msg, (int)total_length);
#endif
  __DSB();
}

