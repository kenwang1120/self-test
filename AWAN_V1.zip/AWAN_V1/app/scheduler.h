//**************************************************************************************************
//! @ProjectName: V-3000
//! @ModuleName:  scheduler
//!
//! @Purpose:
//! Functions for scheduler.
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//**************************************************************************************************

#ifndef _SCHEDULER_H_
#define _SCHEDULER_H_
//**************************************************************************************************
// Included Files
//**************************************************************************************************
//#include "datatype.h"
#include "appbase.h"
#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif
#define D2R  (M_PI/180.0)
#define R2D  (180.0/M_PI)


#if DATA_RATE > 0
	#define SCHEDULER_PERIOD (1000000U/DATA_RATE)
#else
	#if BAUD_RATE == 921600
		#if defined IMU_Raw
		  #define SCHEDULER_PERIOD 1250   // default:1250 , 921600bps, 800hz;
		#elif defined IMU3001
		  #define SCHEDULER_PERIOD 1250   // default:1250 , 921600bps, 800hz;
		#elif defined IMU3101
		  #define SCHEDULER_PERIOD 1250   // default:1250 , 921600bps, 800hz;
		#elif defined AHRS3001
		  #define SCHEDULER_PERIOD 5000   // default:5000 , 921600bps, 200hz;
		#elif defined AHRS3101
		  #define SCHEDULER_PERIOD 5000   // default:5000 , 921600bps, 200hz;
		#elif defined AHRS3301
		  #define SCHEDULER_PERIOD 5000   // default:5000 , 921600bps, 200hz;
		#elif defined AHRS3501
		  #define SCHEDULER_PERIOD 5000   // default:5000 , 921600bps, 200hz;
		#elif defined AHRS3601
		  #define SCHEDULER_PERIOD 5000   // default:5000 , 921600bps, 200hz;
		#elif defined GA3001
		  #define SCHEDULER_PERIOD 3333   // default:3333 , 300hz
		#elif defined MAG3001
		  #define SCHEDULER_PERIOD 1000   // default:1000 , 1000hz
		#else
		  #define SCHEDULER_PERIOD 5000   // default:3333 , 200hz
		#endif

    #else
		#if defined IMU_Raw
		  #define SCHEDULER_PERIOD 3333   // default:3333  , 115200bps, 300hz;
		#elif defined IMU3001
		  #define SCHEDULER_PERIOD 3333   // default:3333  , 115200bps, 300hz;
		#elif defined IMU3101
		  #define SCHEDULER_PERIOD 3333   // default:3333  , 115200bps, 300hz;
		#elif defined AHRS3001
		  #define SCHEDULER_PERIOD 5000   // default:5000  , 115200bps, 200hz;
		#elif defined AHRS3101
		  #define SCHEDULER_PERIOD 5000   // default:5000  , 115200bps, 200hz;
		#elif defined AHRS3301
		  #define SCHEDULER_PERIOD 5000   // default:5000  , 115200bps, 200hz;
		#elif defined AHRS3501
		  #define SCHEDULER_PERIOD 10000  // default:10000 , 115200bps, 100hz;
		#elif defined AHRS3601
		  #define SCHEDULER_PERIOD 10000  // default:10000 , 115200bps, 100hz;
		#elif defined GA3001
		  #define SCHEDULER_PERIOD 3333   // default:3333  , 300hz
		#elif defined MAG3001
		  #define SCHEDULER_PERIOD 1000   // default:1000  , 1000hz
		#else
		  #define SCHEDULER_PERIOD 5000   // default:3333  , 200hz
		#endif
	#endif
#endif
//#define SCHEDULER_PERIOD 100     //10000hz
//#define SCHEDULER_PERIOD 400     //2500Hz
//#define SCHEDULER_PERIOD 500     //2000Hz
//#define SCHEDULER_PERIOD 555     //1800Hz
//#define SCHEDULER_PERIOD 625     //1600Hz
//#define SCHEDULER_PERIOD 666     //1500Hz
//#define SCHEDULER_PERIOD 833     //1200Hz
//#define SCHEDULER_PERIOD 1000    //1000Hz
//#define SCHEDULER_PERIOD 1250     //800Hz
//#define SCHEDULER_PERIOD 1666     //600Hz
//#define SCHEDULER_PERIOD 2000     //500Hz
//#define SCHEDULER_PERIOD 2500     //400Hz ECF pass
//#define SCHEDULER_PERIOD 3333    //300Hz EKF/EST pass
//#define SCHEDULER_PERIOD 5000     //200Hz 
//#define SCHEDULER_PERIOD 6667     //150Hz
//#define SCHEDULER_PERIOD 10000    //100Hz
//#define SCHEDULER_PERIOD 100000    //10Hz



// superfast periodic execution time, 10 milliseconds
static const uint32_t kSuperFastPeriodicTime = 10;
// fast periodic execution time, 100 milliseconds
static const uint32_t kFastPeriodicTime = 100;
// normal periodic execution time, 1 second
static const uint32_t kNormalPeriodicTime = 1000;
// maximum expected delta between two periodic executions
static const uint32_t kDeltaPeriodicMax = 500;
// maximum expected processing time
static const uint32_t kProcTimeMax = 5000;


//**************************************************************************************************
// Exported Function Prototypes
//**************************************************************************************************
void appBaseOnSchedulerTimer(void);
float fading(float,uint32_t);
//**************************************************************************************************

void scheduler (float delta_t);

#endif //_SCHEDULER_H_
