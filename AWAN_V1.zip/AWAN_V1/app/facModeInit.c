/**************************************************************************************************/
//! @ProjectName: AIMU
//! @ModuleName:  facModeInit
//!
//! @Purpose:
//! Functions for facModeInit.
//!
//! VAST Proprietary
//!
//! @VAST All rights reserved.
//**************************************************************************************************

//**************************************************************************************************
// Included Files
//**************************************************************************************************
#include "facModeInit.h"
#include "stm_flash.h"

#include "gpio.h"
#include "stdio.h"
#include "usart.h"
//char arrr[20];
/*******************************************************************************
 * Definitions
 ******************************************************************************/
   
#define BUFFER_LEN 32

/*! @brief Flash driver Structure */
//static flexnvm_config_t s_flashDriver;

/*
 * @brief Gets called when an error occurs.
 *
 * @details Print error message and trap forever.
 */
void error_trap(void)
{
    //printf("\r\n\r\n\r\n\t---- HALTED DUE TO FLASH ERROR! ----");
    while (1)
    {
    }
}

/*
 * @brief Gets called when the app is complete.
 *
 * @details Print finshed message and trap forever.
 */
void app_finalize(void)
{
    /* Print finished message. */
    //printf("\r\n End of FlexNVM Dflash Example \r\n");
    while (1)
    {
    }
}

//void initFlashNVM(uint32_t* params, uint8_t msgLen)
//{
//  //char arr[30];
//      ftfx_security_state_t securityStatus = kFTFx_SecurityStateNotSecure; /* Return protection status */
//    status_t result; /* Return code from each flash driver function */
//
//    /* Clean up Flash driver Structure*/
//    memset(&s_flashDriver, 0, sizeof(flexnvm_config_t));
//
//    /* print welcome message */
//    //printf("\r\n FlexNVM DFlash Example Start \r\n");
//
//#if defined(SIM_FCFG2_PFLSH_MASK)
//    if (SIM->FCFG2 & SIM_FCFG2_PFLSH_MASK)
//    {
//        PRINTF("\r\n Current device doesn't support FlexNVM feature \r\n");
//        app_finalize();
//    }
//#endif
//
//    /* Setup flash driver structure for device and initialize variables. */
//    result = FLEXNVM_Init(&s_flashDriver);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//
//    /* Check security status. */
//    result = FLEXNVM_GetSecurityState(&s_flashDriver, &securityStatus);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//    /* Print security status. */
//    switch (securityStatus)
//    {
//        case kFTFx_SecurityStateNotSecure:
//            //printf("\r\n Flash is UNSECURE!");
//            break;
//        case kFTFx_SecurityStateBackdoorEnabled:
//            //printf("\r\n Flash is SECURE, BACKDOOR is ENABLED!");
//            break;
//        case kFTFx_SecurityStateBackdoorDisabled:
//            //printf("\r\n Flash is SECURE, BACKDOOR is DISABLED!");
//            break;
//        default:
//            break;
//    }
//    PRINTF("\r\n");
//
//    /* Debug message for user. */
//    /* Test flexnvm dflash feature only if flash is unsecure. */
//    if (kFTFx_SecurityStateNotSecure != securityStatus)
//    {
//        //printf("\r\n Data Flash opeation will not be executed, as Flash is SECURE!");
//        app_finalize();
//    }
//    else
//    {
//        uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
//        //uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
//        uint32_t destAdrss;                /* Address of the target location */
//        uint32_t i, failAddr, failDat;
//
//        uint32_t dflashBlockBase  = 0;
//        uint32_t dflashTotalSize  = 0;
//        uint32_t dflashSectorSize = 0;
//
//        /* Get flash properties*/
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashBlockBaseAddr, &dflashBlockBase);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashTotalSize, &dflashTotalSize);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashSectorSize, &dflashSectorSize);
//
//        /* Print flash information - DFlash. */
//        //printf("\r\n DFlash Information: ");
//        if (dflashTotalSize)
//        {
//            //printf("\r\n Data Flash Base Address: (0x%x) ", dflashBlockBase);
//            //printf("\r\n Data Flash Total Size:\t%d KB, Hex: (0x%x)", (dflashTotalSize / 1024), dflashTotalSize);
//            //printf("\r\n Data Flash Sector Size:\t%d KB, Hex: (0x%x) ", (dflashSectorSize / 1024), dflashSectorSize);
//        }
//        else
//        {
//            //printf("\r\n There is no D-Flash (FlexNVM) on this Device.");
//            app_finalize();
//        }
//
//        /* Erase several sectors on upper pflash block where there is no code */
//        //printf("\r\n Erase a sector of Data Flash");
//
//        /* Erase a sector from destAdrss. */
//        destAdrss = dflashBlockBase + (dflashTotalSize - dflashSectorSize);
//        result    = FLEXNVM_DflashErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_ApiEraseKey);
//        if (kStatus_FTFx_Success != result)
//        {
//            error_trap();
//        }
//
//        /* Verify sector if it's been erased. */
//        result = FLEXNVM_DflashVerifyErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_MarginValueUser);
//        if (kStatus_FTFx_Success != result)
//        {
//            error_trap();
//        }
//
//        /* Print message for user. */
//        //printf("\r\n Successfully Erased Sector 0x%x -> 0x%x\r\n", destAdrss, (destAdrss + dflashSectorSize));
//
//        /* Print message for user. */
//        //printf("\r\n Program a buffer to a sector of Data Flash ");
//        /* Prepare user buffer. */
//        for (i = 0; i < BUFFER_LEN; i++)
//        {
//            //s_buffer[i] = i;
//          if(i < msgLen)
//          {
//            s_buffer[i] = params[i];
////             sprintf(arr, "i=%d, %d,",i,params[i]);
////             LPUART1_Send((uint8_t const*)arr, strlen(arr));
//          }
//          else
//          {
//            s_buffer[i] = 0;
////            sprintf(arr, "i=%d,==>0 %d,",i,params[i]);
////            LPUART1_Send((uint8_t const*)arr, strlen(arr));
//
//          }
//        }
////        strcpy(arr, " Got all parameters \r\n");
////        LPUART1_Send((uint8_t const*)arr, strlen(arr));
//
//        /* Program user buffer into flash*/
//        destAdrss = dflashBlockBase + (dflashTotalSize - dflashSectorSize);
//        result    = FLEXNVM_DflashProgram(&s_flashDriver, destAdrss, (uint8_t *)s_buffer, sizeof(s_buffer));
//        if (kStatus_FTFx_Success != result)
//        {
//            error_trap();
//        }
//
//        /* Verify programming by Program Check command with user margin levels */
//        result = FLEXNVM_DflashVerifyProgram(&s_flashDriver, destAdrss, sizeof(s_buffer), (const uint8_t *)s_buffer,
//                                             kFTFx_MarginValueUser, &failAddr, &failDat);
//        if (kStatus_FTFx_Success != result)
//        {
//            error_trap();
//        }
//
////#if defined(__DCACHE_PRESENT) && __DCACHE_PRESENT
////        /* Clean the D-Cache before reading the flash data*/
////        SCB_CleanInvalidateDCache();
////#endif
////        /* Verify programming by reading back from flash directly*/
////        for (uint32_t i = 0; i < BUFFER_LEN; i++)
////        {
////            s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
////            if (s_buffer_rbc[i] != s_buffer[i])
////            {
////              PRINTF("error occured in if");
////                error_trap();
////            }
////            PRINTF("s_buffer_rbc[%d]: %d \r\n", i, s_buffer_rbc[i]);
////        }
////
////        printf("\r\n Successfully Programmed and Verified Location 0x%x -> 0x%x \r\n", destAdrss,
////               (destAdrss + sizeof(s_buffer)));
//    }
//
////    app_finalize();
//}

//void facModeGPIO_init(void)
//{
//      /* Define the init structure for the trigger for factory mode */
//    gpio_pin_config_t init_config = {
//        kGPIO_DigitalInput, 0,
//    };
//        /* Clock Control: 0x01u */
//    CLOCK_EnableClock(kCLOCK_PortC);
//
//    /* PORTC0 is configured as Entry of factory mode */
//    PORT_SetPinMux(PORTC, 0, kPORT_MuxAsGpio);
//    /* Init output SPI CS0*/
//    GPIO_PinInit(GPIOC, 0, &init_config);
//
//}

//uint32_t getFlag(void)
//{
//  uint32_t flag = GPIO_PinRead(GPIOC, 0);
//  return flag;
//}

//void readFromFlashNVM(float* params, int* config, float res_accel, float res_gyro, float res_mag)
//{
//  ftfx_security_state_t securityStatus = kFTFx_SecurityStateNotSecure; /* Return protection status */
//    status_t result; /* Return code from each flash driver function */
//
//    /* Clean up Flash driver Structure*/
//    memset(&s_flashDriver, 0, sizeof(flexnvm_config_t));
//
//    /* print welcome message */
//    PRINTF("\r\n FlexNVM DFlash Example Start \r\n");
//
//#if defined(SIM_FCFG2_PFLSH_MASK)
//    if (SIM->FCFG2 & SIM_FCFG2_PFLSH_MASK)
//    {
//        PRINTF("\r\n Current device doesn't support FlexNVM feature \r\n");
//        app_finalize();
//    }
//#endif
//
//    /* Setup flash driver structure for device and initialize variables. */
//    result = FLEXNVM_Init(&s_flashDriver);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//
//    /* Check security status. */
//    result = FLEXNVM_GetSecurityState(&s_flashDriver, &securityStatus);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//    /* Print security status. */
//    switch (securityStatus)
//    {
//        case kFTFx_SecurityStateNotSecure:
//            PRINTF("\r\n Flash is UNSECURE!");
//            break;
//        case kFTFx_SecurityStateBackdoorEnabled:
//            PRINTF("\r\n Flash is SECURE, BACKDOOR is ENABLED!");
//            break;
//        case kFTFx_SecurityStateBackdoorDisabled:
//            PRINTF("\r\n Flash is SECURE, BACKDOOR is DISABLED!");
//            break;
//        default:
//            break;
//    }
//    PRINTF("\r\n");
//
//    /* Debug message for user. */
//    /* Test flexnvm dflash feature only if flash is unsecure. */
//    if (kFTFx_SecurityStateNotSecure != securityStatus)
//    {
//        PRINTF("\r\n Data Flash opeation will not be executed, as Flash is SECURE!");
//        app_finalize();
//    }
//    else
//    {
////        uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
//        uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
//        uint32_t destAdrss;                /* Address of the target location */
//        uint32_t symbol;
////        uint32_t i, failAddr, failDat;
//
//        uint32_t dflashBlockBase  = 0;
//        uint32_t dflashTotalSize  = 0;
//        uint32_t dflashSectorSize = 0;
//
//        /* Get flash properties*/
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashBlockBaseAddr, &dflashBlockBase);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashTotalSize, &dflashTotalSize);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashSectorSize, &dflashSectorSize);
//
//        /* Print flash information - DFlash. */
//        PRINTF("\r\n DFlash Information: ");
//        if (dflashTotalSize)
//        {
//            PRINTF("\r\n Data Flash Base Address: (0x%x) ", dflashBlockBase);
//            PRINTF("\r\n Data Flash Total Size:\t%d KB, Hex: (0x%x)", (dflashTotalSize / 1024), dflashTotalSize);
//            PRINTF("\r\n Data Flash Sector Size:\t%d KB, Hex: (0x%x) ", (dflashSectorSize / 1024), dflashSectorSize);
//        }
//        else
//        {
//            PRINTF("\r\n There is no D-Flash (FlexNVM) on this Device.");
//            app_finalize();
//        }
//
////        /* Erase several sectors on upper pflash block where there is no code */
////        PRINTF("\r\n Erase a sector of Data Flash");
////
////        /* Erase a sector from destAdrss. */
//        destAdrss = dflashBlockBase + (dflashTotalSize - dflashSectorSize);
////        result    = FLEXNVM_DflashErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_ApiEraseKey);
////        if (kStatus_FTFx_Success != result)
////        {
////            error_trap();
////        }
////
////        /* Verify sector if it's been erased. */
////        result = FLEXNVM_DflashVerifyErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_MarginValueUser);
////        if (kStatus_FTFx_Success != result)
////        {
////            error_trap();
////        }
////
////        /* Print message for user. */
////        PRINTF("\r\n Successfully Erased Sector 0x%x -> 0x%x\r\n", destAdrss, (destAdrss + dflashSectorSize));
////
////        /* Print message for user. */
////        PRINTF("\r\n Program a buffer to a sector of Data Flash ");
//
//#if defined(__DCACHE_PRESENT) && __DCACHE_PRESENT
//        /* Clean the D-Cache before reading the flash data*/
//        SCB_CleanInvalidateDCache();
//#endif
//        /* Verify programming by reading back from flash directly*/
//       // for (uint32_t i = 0; i < BUFFER_LEN; i++)
//        for (uint32_t i = 0; i < 28; i++)
//        {
//            s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
//            symbol = s_buffer_rbc[i] & 0x80000000;
//            if(i <12)
//            {
//              params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_accel;
//              if(symbol != 0)
//                params[i] = -params[i];
//              //printf("params[%d]: %.4f \r\n", i, params[i]);
//            }
//            else if((i >=12) && (i < 15))/*12 - 14*/
//            {
//              params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_gyro;
//              if(symbol != 0 )
//                params[i] = -params[i];
//              //printf("params[%d]: %.4f \r\n", i, params[i]);
//            } else if((i >=15) && (i < 27))/*15 - 26*/
//            {
//              params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_mag;
//              if(symbol != 0 )
//                params[i] = -params[i];
//              //printf("params[%d]: %.4f \r\n", i, params[i]);
//            }else{//Read config param
//              *config = s_buffer_rbc[27];
//            }
////            if (s_buffer_rbc[i] != s_buffer[i])
////            {
////                error_trap();
////            }
//            PRINTF("s_buffer_rbc[%d]: %d \r\n", i, s_buffer_rbc[i]);
//
//        }
//
//
////        PRINTF("\r\n Successfully Programmed and Verified Location 0x%x -> 0x%x \r\n", destAdrss,
////               (destAdrss + sizeof(s_buffer)));
//    }
//
//    //app_finalize();
//}

uint32_t serialChar2Int(uint8_t* bytesIn, float resolution)
{
  float integer = (float)(bytesIn[1] - '0');
  float decimal = (float)(bytesIn[3]-'0') * 0.1f + (float)(bytesIn[4] - '0') * 0.01f + (float)(bytesIn[5] - '0') * 0.001f \
    + (float)(bytesIn[6] - '0') * 0.0001f;
  uint32_t value;
  value = (uint32_t)((integer + decimal) / resolution);
  /*Set symbol BIT cuz value is unsigned*/
  if(bytesIn[0] == '+')
    value &= 0x7fffffff;
  else if(bytesIn[0] == '-')
    value |= 0x80000000;
  return value;  
}

uint32_t serialChar2IntMag(uint8_t* bytesIn, float resolution)
{
  float integer = (float)(bytesIn[1] - '0') * 100 + (float)(bytesIn[2] - '0') * 10 + (float)(bytesIn[3] - '0');
  float decimal = (float)(bytesIn[5]-'0') * 0.1f + (float)(bytesIn[6] - '0') * 0.01f + (float)(bytesIn[7] - '0') * 0.001f \
    + (float)(bytesIn[8] - '0') * 0.0001f;
  uint32_t value;
  value = (uint32_t)((integer + decimal) / resolution);
  /*Set symbol BIT cuz value is unsigned*/
  if(bytesIn[0] == '+')
    value &= 0x7fffffff;
  else if(bytesIn[0] == '-')
    value |= 0x80000000;
  return value;  
}

uint32_t serialChar2IntConfig(uint8_t* bytesIn)
{
    uint32_t configNumber = (uint32_t)(*bytesIn - '0');
    return configNumber;
}

//void readFromFlashNVM2(float* params, int* config, float res_accel, float res_gyro, float res_mag)
//{
//  ftfx_security_state_t securityStatus = kFTFx_SecurityStateNotSecure; /* Return protection status */
//    status_t result; /* Return code from each flash driver function */
//
//    /* Clean up Flash driver Structure*/
//    memset(&s_flashDriver, 0, sizeof(flexnvm_config_t));
//
//    /* print welcome message */
//    PRINTF("\r\n FlexNVM DFlash Example Start \r\n");
//
//#if defined(SIM_FCFG2_PFLSH_MASK)
//    if (SIM->FCFG2 & SIM_FCFG2_PFLSH_MASK)
//    {
//        PRINTF("\r\n Current device doesn't support FlexNVM feature \r\n");
//        app_finalize();
//    }
//#endif
//
//    /* Setup flash driver structure for device and initialize variables. */
//    result = FLEXNVM_Init(&s_flashDriver);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//
//    /* Check security status. */
//    result = FLEXNVM_GetSecurityState(&s_flashDriver, &securityStatus);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//    /* Print security status. */
//    switch (securityStatus)
//    {
//        case kFTFx_SecurityStateNotSecure:
//            PRINTF("\r\n Flash is UNSECURE!");
//            break;
//        case kFTFx_SecurityStateBackdoorEnabled:
//            PRINTF("\r\n Flash is SECURE, BACKDOOR is ENABLED!");
//            break;
//        case kFTFx_SecurityStateBackdoorDisabled:
//            PRINTF("\r\n Flash is SECURE, BACKDOOR is DISABLED!");
//            break;
//        default:
//            break;
//    }
//    PRINTF("\r\n");
//
//    /* Debug message for user. */
//    /* Test flexnvm dflash feature only if flash is unsecure. */
//    if (kFTFx_SecurityStateNotSecure != securityStatus)
//    {
//        PRINTF("\r\n Data Flash opeation will not be executed, as Flash is SECURE!");
//        app_finalize();
//    }
//    else
//    {
////        uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
//        uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
//        uint32_t destAdrss;                /* Address of the target location */
//        uint32_t symbol;
////        uint32_t i, failAddr, failDat;
//
//        uint32_t dflashBlockBase  = 0;
//        uint32_t dflashTotalSize  = 0;
//        uint32_t dflashSectorSize = 0;
//
//        /* Get flash properties*/
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashBlockBaseAddr, &dflashBlockBase);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashTotalSize, &dflashTotalSize);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashSectorSize, &dflashSectorSize);
//
//        /* Print flash information - DFlash. */
//        PRINTF("\r\n DFlash Information: ");
//        if (dflashTotalSize)
//        {
//            PRINTF("\r\n Data Flash Base Address: (0x%x) ", dflashBlockBase);
//            PRINTF("\r\n Data Flash Total Size:\t%d KB, Hex: (0x%x)", (dflashTotalSize / 1024), dflashTotalSize);
//            PRINTF("\r\n Data Flash Sector Size:\t%d KB, Hex: (0x%x) ", (dflashSectorSize / 1024), dflashSectorSize);
//        }
//        else
//        {
//            PRINTF("\r\n There is no D-Flash (FlexNVM) on this Device.");
//            app_finalize();
//        }
//
////        /* Erase several sectors on upper pflash block where there is no code */
////        PRINTF("\r\n Erase a sector of Data Flash");
////
////        /* Erase a sector from destAdrss. */
//        destAdrss = dflashBlockBase + (dflashTotalSize - dflashSectorSize*2);
////        result    = FLEXNVM_DflashErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_ApiEraseKey);
////        if (kStatus_FTFx_Success != result)
////        {
////            error_trap();
////        }
////
////        /* Verify sector if it's been erased. */
////        result = FLEXNVM_DflashVerifyErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_MarginValueUser);
////        if (kStatus_FTFx_Success != result)
////        {
////            error_trap();
////        }
////
////        /* Print message for user. */
////        PRINTF("\r\n Successfully Erased Sector 0x%x -> 0x%x\r\n", destAdrss, (destAdrss + dflashSectorSize));
////
////        /* Print message for user. */
////        PRINTF("\r\n Program a buffer to a sector of Data Flash ");
//
//#if defined(__DCACHE_PRESENT) && __DCACHE_PRESENT
//        /* Clean the D-Cache before reading the flash data*/
//        SCB_CleanInvalidateDCache();
//#endif
//        /* Verify programming by reading back from flash directly*/
//       // for (uint32_t i = 0; i < BUFFER_LEN; i++)
//        for (uint32_t i = 0; i < 28; i++)
//        {
//            s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
//            symbol = s_buffer_rbc[i] & 0x80000000;
//            if(i <12)
//            {
//              params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_accel;
//              if(symbol != 0)
//                params[i] = -params[i];
//              //printf("params[%d]: %.4f \r\n", i, params[i]);
//            }
//            else if((i >=12) && (i < 15))/*12 - 14*/
//            {
//              params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_gyro;
//              if(symbol != 0 )
//                params[i] = -params[i];
//              //printf("params[%d]: %.4f \r\n", i, params[i]);
//            } else if((i >=15) && (i < 27))/*15 - 26*/
//            {
//              params[i] = (float)(s_buffer_rbc[i]&0x7fffffff) * res_mag;
//              if(symbol != 0 )
//                params[i] = -params[i];
//              //printf("params[%d]: %.4f \r\n", i, params[i]);
//            }else{//Read config param
//              *config = s_buffer_rbc[27];
//            }
////            if (s_buffer_rbc[i] != s_buffer[i])
////            {
////                error_trap();
////            }
//            PRINTF("s_buffer_rbc[%d]: %d \r\n", i, s_buffer_rbc[i]);
//
//        }
//
//
////        PRINTF("\r\n Successfully Programmed and Verified Location 0x%x -> 0x%x \r\n", destAdrss,
////               (destAdrss + sizeof(s_buffer)));
//    }
//
//    //app_finalize();
//}
//
//void readFromFlashNVM3(uint32_t* params)
//{
//  ftfx_security_state_t securityStatus = kFTFx_SecurityStateNotSecure; /* Return protection status */
//    status_t result; /* Return code from each flash driver function */
//
//    /* Clean up Flash driver Structure*/
//    memset(&s_flashDriver, 0, sizeof(flexnvm_config_t));
//
//    /* print welcome message */
//    PRINTF("\r\n FlexNVM DFlash Example Start \r\n");
//
//#if defined(SIM_FCFG2_PFLSH_MASK)
//    if (SIM->FCFG2 & SIM_FCFG2_PFLSH_MASK)
//    {
//        PRINTF("\r\n Current device doesn't support FlexNVM feature \r\n");
//        app_finalize();
//    }
//#endif
//
//    /* Setup flash driver structure for device and initialize variables. */
//    result = FLEXNVM_Init(&s_flashDriver);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//
//    /* Check security status. */
//    result = FLEXNVM_GetSecurityState(&s_flashDriver, &securityStatus);
//    if (kStatus_FTFx_Success != result)
//    {
//        error_trap();
//    }
//    /* Print security status. */
//    switch (securityStatus)
//    {
//        case kFTFx_SecurityStateNotSecure:
//            PRINTF("\r\n Flash is UNSECURE!");
//            break;
//        case kFTFx_SecurityStateBackdoorEnabled:
//            PRINTF("\r\n Flash is SECURE, BACKDOOR is ENABLED!");
//            break;
//        case kFTFx_SecurityStateBackdoorDisabled:
//            PRINTF("\r\n Flash is SECURE, BACKDOOR is DISABLED!");
//            break;
//        default:
//            break;
//    }
//    PRINTF("\r\n");
//
//    /* Debug message for user. */
//    /* Test flexnvm dflash feature only if flash is unsecure. */
//    if (kFTFx_SecurityStateNotSecure != securityStatus)
//    {
//        PRINTF("\r\n Data Flash opeation will not be executed, as Flash is SECURE!");
//        app_finalize();
//    }
//    else
//    {
////        uint32_t s_buffer[BUFFER_LEN];     /* Buffer for program */
//        uint32_t s_buffer_rbc[BUFFER_LEN]; /* Buffer for readback */
//        uint32_t destAdrss;                /* Address of the target location */
//        //uint32_t symbol;
////        uint32_t i, failAddr, failDat;
//
//        uint32_t dflashBlockBase  = 0;
//        uint32_t dflashTotalSize  = 0;
//        uint32_t dflashSectorSize = 0;
//
//        /* Get flash properties*/
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashBlockBaseAddr, &dflashBlockBase);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashTotalSize, &dflashTotalSize);
//        FLEXNVM_GetProperty(&s_flashDriver, kFLEXNVM_PropertyDflashSectorSize, &dflashSectorSize);
//
//        /* Print flash information - DFlash. */
//        PRINTF("\r\n DFlash Information: ");
//        if (dflashTotalSize)
//        {
//            PRINTF("\r\n Data Flash Base Address: (0x%x) ", dflashBlockBase);
//            PRINTF("\r\n Data Flash Total Size:\t%d KB, Hex: (0x%x)", (dflashTotalSize / 1024), dflashTotalSize);
//            PRINTF("\r\n Data Flash Sector Size:\t%d KB, Hex: (0x%x) ", (dflashSectorSize / 1024), dflashSectorSize);
//        }
//        else
//        {
//            PRINTF("\r\n There is no D-Flash (FlexNVM) on this Device.");
//            app_finalize();
//        }
//
////        /* Erase several sectors on upper pflash block where there is no code */
////        PRINTF("\r\n Erase a sector of Data Flash");
////
////        /* Erase a sector from destAdrss. */
//        destAdrss = dflashBlockBase + (dflashTotalSize - dflashSectorSize*3);
////        result    = FLEXNVM_DflashErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_ApiEraseKey);
////        if (kStatus_FTFx_Success != result)
////        {
////            error_trap();
////        }
////
////        /* Verify sector if it's been erased. */
////        result = FLEXNVM_DflashVerifyErase(&s_flashDriver, destAdrss, dflashSectorSize, kFTFx_MarginValueUser);
////        if (kStatus_FTFx_Success != result)
////        {
////            error_trap();
////        }
////
////        /* Print message for user. */
////        PRINTF("\r\n Successfully Erased Sector 0x%x -> 0x%x\r\n", destAdrss, (destAdrss + dflashSectorSize));
////
////        /* Print message for user. */
////        PRINTF("\r\n Program a buffer to a sector of Data Flash ");
//
//#if defined(__DCACHE_PRESENT) && __DCACHE_PRESENT
//        /* Clean the D-Cache before reading the flash data*/
//        SCB_CleanInvalidateDCache();
//#endif
//        /* Verify programming by reading back from flash directly*/
//       // for (uint32_t i = 0; i < BUFFER_LEN; i++)
//        for (uint32_t i = 0; i < 8; i++)
//        {
//            s_buffer_rbc[i] = *(volatile uint32_t *)(destAdrss + i * 4);
//            params[i] = s_buffer_rbc[i];
//
//              //sprintf(arrr, "params[%d]=%d\r\n",i,params[i]);
//              //LPUART1_Send((uint8_t const*)arrr, strlen(arrr));
//
////            if (s_buffer_rbc[i] != s_buffer[i])
////            {
////                error_trap();
////            }
//            PRINTF("s_buffer_rbc[%d]: %d \r\n", i, s_buffer_rbc[i]);
//
//        }
//
//
////        PRINTF("\r\n Successfully Programmed and Verified Location 0x%x -> 0x%x \r\n", destAdrss,
////               (destAdrss + sizeof(s_buffer)));
//    }
//
//    //app_finalize();
//}
















