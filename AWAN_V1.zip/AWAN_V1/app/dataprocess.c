#include <stdio.h>
#include "dataprocess.h"
#include "dataout.h"

#include "iis2mdc.h"
#include "asm330lhh.h"
#include "pct2075.h"
#include "can.h"
#include "usart.h"

#include <math.h>
#include "scheduler.h"

#include "geo.h"
#include "Auto_Trim.h"
#include "Auto_Trim_Fcn.h"
#include "compensationAccel.h"
#include "compensationRate.h"
#include "filter_Imu_data.h"
#include "rtwtypes.h"
#include "RLS_Filter_Process.h"
#include "RLS_Filter_Process.h"

#define RAW_DATA_TYPE 0
#define RLS_DATA_TYPE 1
#define AUTOTRIM_DATA_TYPE 2
#define EKF_DATA_TYPE 3

#define ASM330LHH_ACCEL_RESOLUTION  ASM330LHH_FS8G_G
#define ASM330LHH_GYRO_RESOLUTION   ASM330LHH_FS500DPS_DPS
#define IIS2MDC_MAG_RESOLUTION      IIS2MDC_LSB_MG
//180/(2 ^ 15 -1) = 0.0055
#define AHRS_RESOLUTION             0.0055f
#define ACCEL_RESOLUTION            0.00479f
#define resolution_q                0.00006f

extern iis2mdc_data_t iis2mdc_raw_data;
extern asm330lhh_data_t asm330lhh_raw_data;
extern float pct2075ResultTemp;
//extern float phi,theta,psi;
extern float rate_out[3];
extern float accel_out[3];
extern float att_out[3];
extern float Q[4];
iis2mdc_data_t iis2mdc_rls_data;
asm330lhh_data_t asm330lhh_rls_data,asm330llh_autotrim_data,asm330llh_calibrated_data;

static DW_RLS_Filter_Process_RLS_Fli_T iis2mdc_Mag_RLS_DW;
//= {.rtu_Lxy = {200.0, 200.0, 200.0}, .rtu_Dxy = {10.0 ,   1.0,   0.5}, .rtu_Lz  = {200.0, 200.0, 200.0}, .rtu_Dz  = {10.0 ,   1.0,   0.5}};
static DW_RLS_Filter_Process_RLS_Fli_T asm330_Accel_RLS_DW, asm330_Gyro_RLS_DW;
//DW_RLS_Filter_Process_RLS_Fli_T iis2mdc_Mag_RLS_DW;
//DW_RLS_Filter_Process_RLS_Fli_T asm330_Accel_RLS_DW, asm330_Gyro_RLS_DW;

static RT_MODEL_Auto_Trim_Fcn_T Auto_Trim_Fcn_M_;
static RT_MODEL_Auto_Trim_Fcn_T *const Auto_Trim_Fcn_M = &Auto_Trim_Fcn_M_;
static B_Auto_Trim_Fcn_T Auto_Trim_Fcn_B;
static DW_Auto_Trim_Fcn_T Auto_Trim_Fcn_DW;
static int count = 0;
real32_T rtu_INIT_IC;

float xyheading_deg,zxheading_deg,tiltheading_deg,heading_output;
float Mx_Cal,My_Cal,Mz_Cal;
float Ax_Cal,Ay_Cal,Az_Cal;
float normAcc = 0;
bool send_GPAhrs1=true;
extern float angles[3];
extern float rate_out[3];
extern float angles_ekf[3];
extern float rate_out_ekf[3];
extern float angles_redundy[3];
extern float angles_est[3];
extern float rate_out_est[3];
extern float rate_redundy[3];
extern float mags[3];
extern float rawMags[3];
extern float acc_rls[3];
extern void lag_filter(float*, float*, float*,float*, float, float);

//struct P_Auto_Trim_Fcn_T_{A_f0;A_f1; A_f2;A_f3;A_f4;A_low_limit;A_up_limit;
//                          G_f0;G_f1;G_f2;G_f3;G_f4;G_low_limit; G_up_limit; K_A1; K_G1; SIMTIME_DT;};
//static P_Auto_Trim_Fcn_T Auto_Trim_Fcn_P = {480.0F,300.0F,220.0F,160.0F,25.0F,0.05F,0.1F,
//                                            480.0F,300.0F,220.0F,160.0F,25.0F,1.0F,2.0F,80.0F,80.0F,0.00125F}; 
//static P_Auto_Trim_Fcn_T Auto_Trim_Fcn_P = {0.5f, 0.5f, 1/300.0f, 1.0f}; 

static P_Auto_Trim_Fcn_T Auto_Trim_Fcn_P = {0.5f, 0.5f, 1/30.0f, 1.0f, SCHEDULER_PERIOD/1000000.0};//Macial 20220329




//static P_Auto_Trim_Fcn_T Auto_Trim_Fcn_P = {0.5f, 0.5f, 1/30.0f, 1.0f};//timchen 20210107


void QSendout(void)
{ 
//  sendRS485Message(0x0B, phi, theta, psi, AHRS_RESOLUTION);
  
 sendAhrsQMsg(0x0E,  Q,  resolution_q);

}


//******************************************************************************
//! @fn void RLS_dataProcess_Init(void)
//!
//! @description
//!  Initialize parameters for RLS algorithm.
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void RLS_dataProcess_Init(void)
{

	/* Mag Parameter */
	iis2mdc_Mag_RLS_DW.rtu_Lxy[0] = 200.0;
	iis2mdc_Mag_RLS_DW.rtu_Lxy[1] = 200.0;
	iis2mdc_Mag_RLS_DW.rtu_Lxy[2] = 200.0;
	iis2mdc_Mag_RLS_DW.rtu_Dxy[0] =  10.0;
	iis2mdc_Mag_RLS_DW.rtu_Dxy[1] =   1.0;
	iis2mdc_Mag_RLS_DW.rtu_Dxy[2] =   0.5;
	iis2mdc_Mag_RLS_DW.rtu_Lz[0]  = 200.0;
	iis2mdc_Mag_RLS_DW.rtu_Lz[1]  = 200.0;
	iis2mdc_Mag_RLS_DW.rtu_Lz[2]  = 200.0;
	iis2mdc_Mag_RLS_DW.rtu_Dz[0]  =  10.0;
	iis2mdc_Mag_RLS_DW.rtu_Dz[1]  =   1.0;
	iis2mdc_Mag_RLS_DW.rtu_Dz[2]  =   0.5;
    RLS_Fli_RLS_Filter_Process_Init(&iis2mdc_Mag_RLS_DW);

    /* Accel Parameter */
    asm330_Accel_RLS_DW.rtu_Lxy[0] = 1600.0;
    asm330_Accel_RLS_DW.rtu_Lxy[1] =  160.0;
    asm330_Accel_RLS_DW.rtu_Lxy[2] =   16.0;
    asm330_Accel_RLS_DW.rtu_Dxy[0] =  100.0;
    asm330_Accel_RLS_DW.rtu_Dxy[1] =   20.0;
    asm330_Accel_RLS_DW.rtu_Dxy[2] =    6.0;
    asm330_Accel_RLS_DW.rtu_Lz[0]  = 1600.0;
    asm330_Accel_RLS_DW.rtu_Lz[1]  =  160.0;
    asm330_Accel_RLS_DW.rtu_Lz[2]  =   16.0;
    asm330_Accel_RLS_DW.rtu_Dz[0]  =  100.0;
    asm330_Accel_RLS_DW.rtu_Dz[1]  =   20.0;
    asm330_Accel_RLS_DW.rtu_Dz[2]  =    6.0;
    RLS_Fli_RLS_Filter_Process_Init(&asm330_Accel_RLS_DW);

    /* Gyro Parameter */
    asm330_Gyro_RLS_DW.rtu_Lxy[0] = 1600.0;
    asm330_Gyro_RLS_DW.rtu_Lxy[1] =  160.0;
    asm330_Gyro_RLS_DW.rtu_Lxy[2] =   16.0;
    asm330_Gyro_RLS_DW.rtu_Dxy[0] =  100.0;
    asm330_Gyro_RLS_DW.rtu_Dxy[1] =   20.0;
    asm330_Gyro_RLS_DW.rtu_Dxy[2] =    6.0;
    asm330_Gyro_RLS_DW.rtu_Lz[0]  = 1600.0;
    asm330_Gyro_RLS_DW.rtu_Lz[1]  =  160.0;
    asm330_Gyro_RLS_DW.rtu_Lz[2]  =   16.0;
    asm330_Gyro_RLS_DW.rtu_Dz[0]  =  100.0;
    asm330_Gyro_RLS_DW.rtu_Dz[1]  =   20.0;
    asm330_Gyro_RLS_DW.rtu_Dz[2]  =    6.0;
    RLS_Fli_RLS_Filter_Process_Init(&asm330_Gyro_RLS_DW);
}

//******************************************************************************
//! @fn void dataProcessAutoTrimInit(void)
//!
//! @description
//!  Initialize parameters for AutoTrim algorithm.
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void dataProcessAutoTrimInit(void)
{    
  Auto_Trim_Fcn_M->ModelData.defaultParam = &Auto_Trim_Fcn_P; 
  Auto_Trim_Fcn_M->ModelData.blockIO = &Auto_Trim_Fcn_B;
  Auto_Trim_Fcn_M->ModelData.dwork = &Auto_Trim_Fcn_DW;   
}

//******************************************************************************
//! @fn void iss2mdc_RLS_DataProcess(void)
//!
//! @description
//!  RLS algorithm for iis2mdc magnetometer.
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void iis2mdc_RLS_DataProcess(void)
{
    B_RLS_Filter_Process_RLS_Flit_T iss_Mag_newdata;
   
//        RLS_Fliter_A_RLS_Filter_Process(100, 10, 2, 10, 1, 0.5,
//                                      100, 10, 2, 10, 1, 0.5,
//                                iis2mdc_raw_data.magnetic_mG[0], 
//                                iis2mdc_raw_data.magnetic_mG[1],
//                                iis2mdc_raw_data.magnetic_mG[2],
//                                &iss_Mag_newdata, &iis2mdc_Mag_RLS_DW);

//    RLS_Fliter_A_RLS_Filter_Process(200, 200, 200, 10, 1, 0.5,
//                                  200, 200, 200, 10, 1, 0.5,
//                            iis2mdc_raw_data.magnetic_mG[0],
//                            iis2mdc_raw_data.magnetic_mG[1],
//                            iis2mdc_raw_data.magnetic_mG[2],
//                            &iss_Mag_newdata, &iis2mdc_Mag_RLS_DW);

    RLS_Fliter_A_RLS_Filter_Process(iis2mdc_raw_data.magnetic_mG[0],
    		                        iis2mdc_raw_data.magnetic_mG[1],
									iis2mdc_raw_data.magnetic_mG[2],
									&iss_Mag_newdata, &iis2mdc_Mag_RLS_DW);

     rawMags[0] = iis2mdc_raw_data.magnetic_mG[0]*0.001f;;
     rawMags[1] = iis2mdc_raw_data.magnetic_mG[1]*0.001f;;
     rawMags[2] = iis2mdc_raw_data.magnetic_mG[2]*0.001f;;
     iis2mdc_rls_data.magnetic_mG[0] = iss_Mag_newdata.Xout;
     iis2mdc_rls_data.magnetic_mG[1] = iss_Mag_newdata.Yout;
     iis2mdc_rls_data.magnetic_mG[2] = iss_Mag_newdata.Zout;
}

//******************************************************************************
//! @fn void asm330_Acc_RLS_DataProcess(void)
//!
//! @description
//!  RLS algorithm for ASM330 Accel.
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void asm330_Acc_RLS_DataProcess(void)
{
    B_RLS_Filter_Process_RLS_Flit_T asm_Accel_newdata;

//    RLS_Fliter_A_RLS_Filter_Process(1600,160,16,100,20,6,1600,160,16,100,20,6,
//    		asm330lhh_raw_data.acceleration_g[0],
//                                    asm330lhh_raw_data.acceleration_g[1],
//                                    asm330lhh_raw_data.acceleration_g[2],
//                                    &asm_Accel_newdata, &asm330_Accel_RLS_DW);

    RLS_Fliter_A_RLS_Filter_Process(asm330lhh_raw_data.acceleration_g[0],
                                    asm330lhh_raw_data.acceleration_g[1],
                                    asm330lhh_raw_data.acceleration_g[2],
                                    &asm_Accel_newdata, &asm330_Accel_RLS_DW);

   #ifdef IMU_Raw     
     //asm330lhh_rls_data.acceleration_g[0] = asm_Accel_newdata.Xout*CONSTANTS_ONE_G;
     //asm330lhh_rls_data.acceleration_g[1] = asm_Accel_newdata.Yout*CONSTANTS_ONE_G;
     //asm330lhh_rls_data.acceleration_g[2] = asm_Accel_newdata.Zout*CONSTANTS_ONE_G;
    normAcc = sqrt(asm_Accel_newdata.Xout*asm_Accel_newdata.Xout+asm_Accel_newdata.Yout*asm_Accel_newdata.Yout+asm_Accel_newdata.Zout*asm_Accel_newdata.Zout);
    asm330lhh_rls_data.acceleration_g[0] = (asm_Accel_newdata.Xout/normAcc);//*CONSTANTS_ONE_G;
    asm330lhh_rls_data.acceleration_g[1] = (asm_Accel_newdata.Yout/normAcc);//*CONSTANTS_ONE_G;
    asm330lhh_rls_data.acceleration_g[2] = (asm_Accel_newdata.Zout/normAcc);//*CONSTANTS_ONE_G;
   #else
    asm330lhh_rls_data.acceleration_g[0] = asm_Accel_newdata.Xout;//*CONSTANTS_ONE_G;
    asm330lhh_rls_data.acceleration_g[1] = asm_Accel_newdata.Yout;//*CONSTANTS_ONE_G;
    asm330lhh_rls_data.acceleration_g[2] = asm_Accel_newdata.Zout;//*CONSTANTS_ONE_G;
   #endif 
}

//******************************************************************************
//! @fn void asm330_Gyro_RLS_DataProcess(void)
//!
//! @description
//!  RLS algorithm for ASM330 Gyro.
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void asm330_Gyro_RLS_DataProcess(void)
{
    B_RLS_Filter_Process_RLS_Flit_T asm_Gyro_newdata;

//    RLS_Fliter_A_RLS_Filter_Process(1600,160,16,100,20,6,1600,160,16,100,20,6,
//    		asm330lhh_raw_data.angular_rate_dps[0],
//                                    asm330lhh_raw_data.angular_rate_dps[1],
//                                    asm330lhh_raw_data.angular_rate_dps[2],
//                                    //asm330lhh_raw_data.angular_rate_dps[2]*1.023,
//                                    &asm_Gyro_newdata, &asm330_Gyro_RLS_DW);

    RLS_Fliter_A_RLS_Filter_Process(asm330lhh_raw_data.angular_rate_dps[0],
                                    asm330lhh_raw_data.angular_rate_dps[1],
                                    asm330lhh_raw_data.angular_rate_dps[2],
                                    //asm330lhh_raw_data.angular_rate_dps[2]*1.023,
                                    &asm_Gyro_newdata, &asm330_Gyro_RLS_DW);
   
  asm330lhh_rls_data.angular_rate_dps[0] = asm_Gyro_newdata.Xout;
  asm330lhh_rls_data.angular_rate_dps[1] = asm_Gyro_newdata.Yout;
  asm330lhh_rls_data.angular_rate_dps[2] = asm_Gyro_newdata.Zout;
}

//******************************************************************************
//! @fn void asm330_AccelGyro_AutoTrim_DataProcess(void)
//!
//! @description
//!  AutoTrim algorithm for ASM330 Gyro&Accel.
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void asm330_AccelGyro_AutoTrim_DataProcess(void)
{
  B_IMU_Auto_Trim_T asm330_Accel_Gyro_AutoTrim_data;
  if(count < 800)
  {
    count++;
    rtu_INIT_IC = 1;
  }
  else
  {
    rtu_INIT_IC = 0;
        
  }
  
    DW_Auto_Trim_Fcn_T *Auto_Trim_Fcn_DW = ((DW_Auto_Trim_Fcn_T *) Auto_Trim_Fcn_M->ModelData.dwork);
  
IMU_Auto_Trim(rtu_INIT_IC, asm330lhh_rls_data.angular_rate_dps[0], 
                asm330lhh_rls_data.angular_rate_dps[1], asm330lhh_rls_data.angular_rate_dps[2],
                &asm330_Accel_Gyro_AutoTrim_data, &Auto_Trim_Fcn_DW->Auto_Trim, &Auto_Trim_Fcn_P); //skip RLS 

  /*IMU_Auto_Trim(rtu_INIT_IC, asm330lhh_raw_data.angular_rate_dps[0], 
                asm330lhh_raw_data.angular_rate_dps[1], asm330lhh_raw_data.angular_rate_dps[2],
                &asm330_Accel_Gyro_AutoTrim_data, &Auto_Trim_Fcn_DW->Auto_Trim, &Auto_Trim_Fcn_P);*/
  
  
  
    asm330llh_autotrim_data.angular_rate_dps[0]=asm330_Accel_Gyro_AutoTrim_data.S_GX;
    asm330llh_autotrim_data.angular_rate_dps[1]=asm330_Accel_Gyro_AutoTrim_data.S_GY;
    asm330llh_autotrim_data.angular_rate_dps[2]=asm330_Accel_Gyro_AutoTrim_data.S_GZ;
}

//void Asm330_Accel_Compensation(void)
//{
//    compensationAccel(asm330lhh_rls_data.acceleration_mg[0], 
//                      asm330lhh_rls_data.acceleration_mg[1], 
//                      asm330lhh_rls_data.acceleration_mg[2], 
//                      asm330lhh_raw_data.temperature_degC, 
//                      BiasCoefAccel1, BiasCoefAccel2,BiasCoefAccel3, 
//                      ScaleFactorCoefAccel1, ScaleFactorCoefAccel2,ScaleFactorCoefAccel3,
//                      AligFactorAccel1, AligFactorAccel2, AligFactorAccel3, 
//                      &asm330lhh_output_data.acceleration_mg[0],
//                      &asm330lhh_output_data.acceleration_mg[1], 
//                      &asm330lhh_output_data.acceleration_mg[2]);
//}
//void Asm330_Gyro_Compensation(void)
//{
//     RateTemp[0] = asm330lhh_raw_data.temperature_degC;
//     RateTemp[1] = asm330lhh_raw_data.temperature_degC;
//     RateTemp[2] = asm330lhh_raw_data.temperature_degC;
//    
//     compensationRate(asm330lhh_rls_data.angular_rate_mdps[0], 
//                      asm330lhh_rls_data.angular_rate_mdps[1], 
//                      asm330lhh_rls_data.angular_rate_mdps[2], 
//                      RateTemp, 
//                      BiasCoefRate1, BiasCoefRate2,BiasCoefRate3, 
//                      ScaleFactorCoefRate1, ScaleFactorCoefRate2,ScaleFactorCoefRate3,
//                      AligFactorRate1, AligFactorRate2, AligFactorRate3, RateLookup,
//                      &asm330lhh_output_data.angular_rate_mdps[0],
//                      &asm330lhh_output_data.angular_rate_mdps[1], 
//                      &asm330lhh_output_data.angular_rate_mdps[2]);
//}

//******************************************************************************
//! @fn void Iis2mdc_Mag_Sendout(void)
//!
//! @description
//!  send XYZ data of iis2mdc magnetometer out through CAN port
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void Iis2mdc_Mag_Sendout(void)
{
//    uint8_t data_type = RLS_DATA_TYPE;
//
//    switch (data_type)
//    {
//      case RAW_DATA_TYPE:
//    	  sendCanMessage(STANDARD_ID, 0x17, 0x07,
//    			  	  	 iis2mdc_raw_data.magnetic_mG[0],iis2mdc_raw_data.magnetic_mG[1], iis2mdc_raw_data.magnetic_mG[2],
//						 IIS2MDC_MAG_RESOLUTION);
////        sendCanMessage(0x04, iis2mdc_raw_data.magnetic_mG[0],iis2mdc_raw_data.magnetic_mG[1],
////                       iis2mdc_raw_data.magnetic_mG[2], IIS2MDC_MAG_RESOLUTION);
//    	  break;
//      case RLS_DATA_TYPE:
//    	  sendCanMessage(STANDARD_ID, 0x17, 0x08,
//    			  	  	 iis2mdc_rls_data.magnetic_mG[0],iis2mdc_rls_data.magnetic_mG[1], iis2mdc_rls_data.magnetic_mG[2],
//						 IIS2MDC_MAG_RESOLUTION);
//
////        sendCanMessage(0x04, iis2mdc_rls_data.magnetic_mG[0],iis2mdc_rls_data.magnetic_mG[1],
////                       iis2mdc_rls_data.magnetic_mG[2], IIS2MDC_MAG_RESOLUTION);
//    	  break;
//      default:
//        break;
//    }
//    //delayTcnt(100);
}

//******************************************************************************
//! @fn void Asm330_Accel_Sendout(void)
//!
//! @description
//!  send XYZ data of asm330 accel out through CAN port
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void Asm330_Accel_Sendout(void)
{
//    uint8_t data_type = AUTOTRIM_DATA_TYPE;
//    //uint8_t data_type = EKF_DATA_TYPE;
//    switch (data_type)
//    {
//      case RAW_DATA_TYPE:
//    	  sendCanMessage(STANDARD_ID, 0x17, 0x03,
//						 asm330lhh_raw_data.acceleration_g[0], asm330lhh_raw_data.acceleration_g[1], asm330lhh_raw_data.acceleration_g[2],
//						 ASM330LHH_ACCEL_RESOLUTION);
////          sendCanMessage(0x03, asm330lhh_raw_data.acceleration_g[0], asm330lhh_raw_data.acceleration_g[1],
////                         asm330lhh_raw_data.acceleration_g[2], ASM330LHH_ACCEL_RESOLUTION);
//          break;
//
//      case RLS_DATA_TYPE:
//          sendCanMessage(0x03, asm330lhh_rls_data.acceleration_g[0],  asm330lhh_rls_data.acceleration_g[1],
//                          asm330lhh_rls_data.acceleration_g[2], ASM330LHH_ACCEL_RESOLUTION);
//          break;
//
//      case AUTOTRIM_DATA_TYPE:
//           sendCanMessage(0x03, asm330llh_autotrim_data.acceleration_g[0],  asm330llh_autotrim_data.acceleration_g[1],
//                          asm330llh_autotrim_data.acceleration_g[2], ASM330LHH_ACCEL_RESOLUTION);
//           break;
//      case EKF_DATA_TYPE:
//           sendCanMessage(0x03, accel_out[0],  accel_out[1],accel_out[2], ASM330LHH_ACCEL_RESOLUTION);
//           break;
//      default:
//           break;
//    }
//    __DSB();
}

//******************************************************************************
//! @fn void Asm330_Gyro_Sendout(void)
//!
//! @description
//!  send XYZ data of asm330 Gyro out through CAN port
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void Asm330_Gyro_Sendout(void)
{
//    uint8_t data_type = EKF_DATA_TYPE;
//    switch (data_type)
//    {
//      case RAW_DATA_TYPE:
//          sendCanMessage(0x02, asm330lhh_raw_data.angular_rate_dps[0],asm330lhh_raw_data.angular_rate_dps[1],
//                         asm330lhh_raw_data.angular_rate_dps[2], ASM330LHH_GYRO_RESOLUTION);
//          break;
//
//      case RLS_DATA_TYPE:
//          sendCanMessage(0x02, asm330lhh_rls_data.angular_rate_dps[0],asm330lhh_rls_data.angular_rate_dps[1],
//                       asm330lhh_rls_data.angular_rate_dps[2], ASM330LHH_GYRO_RESOLUTION);
//          break;
//
//      case AUTOTRIM_DATA_TYPE:
//          sendCanMessage(0x02, asm330llh_autotrim_data.angular_rate_dps[0],asm330llh_autotrim_data.angular_rate_dps[1],
//                       asm330llh_autotrim_data.angular_rate_dps[2], ASM330LHH_GYRO_RESOLUTION);
//          break;
//      case EKF_DATA_TYPE:
//          sendCanMessage(0x02, rate_out[0],rate_out[1], rate_out[2], ASM330LHH_GYRO_RESOLUTION);
//          break;
//      default:
//          break;
//    }
//    __DSB();
}
//******************************************************************************
//! @fn void AHRS_Sendout(void)
//!
//! @description
//!  send  angle data of AHRS alg through CAN port
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void AHRS_Sendout(void)
{
//    send ahrs data
//    sendCanMessage(0x01,phi,theta,psi,AHRS_RESOLUTION);
//  sendCanMessage(0x0B,att_out[0],att_out[1],att_out[2],AHRS_RESOLUTION);
//  __DSB();
}

void AHRS_Debug_Sendout(void)
{
////    sendCanMessage(0x01, asm330lhh_rls_data.angular_rate_dps[0],asm330lhh_rls_data.angular_rate_dps[1],
////                   asm330lhh_rls_data.angular_rate_dps[2], ASM330LHH_GYRO_RESOLUTION);
//    sendCanMessage(0x01, asm330llh_autotrim_data.angular_rate_dps[0],asm330llh_autotrim_data.angular_rate_dps[1],
//                   asm330llh_autotrim_data.angular_rate_dps[2], ASM330LHH_GYRO_RESOLUTION);
//    delaysTcnt(100);
//    sendCanMessage(0x02, rate_out[0],rate_out[1], rate_out[2], ASM330LHH_GYRO_RESOLUTION);
//    delaysTcnt(100);
////    sendCanMessage(0x03, asm330lhh_rls_data.acceleration_g[0],  asm330lhh_rls_data.acceleration_g[1],
////                   asm330lhh_rls_data.acceleration_g[2], ASM330LHH_ACCEL_RESOLUTION);
//    sendCanMessage(0x03, asm330llh_autotrim_data.acceleration_g[0],  asm330llh_autotrim_data.acceleration_g[1],
//                   asm330llh_autotrim_data.acceleration_g[2], ASM330LHH_ACCEL_RESOLUTION);
//    delaysTcnt(100);
//    sendCanMessage(0x04, accel_out[0],  accel_out[1],accel_out[2], ASM330LHH_ACCEL_RESOLUTION);
//    delaysTcnt(100);
//    sendCanMessage(0x05, iis2mdc_rls_data.magnetic_mG[0],iis2mdc_rls_data.magnetic_mG[1],
//                   iis2mdc_rls_data.magnetic_mG[2], IIS2MDC_MAG_RESOLUTION);
//    delaysTcnt(100);
//    //send ahrs data
//    sendCanMessage(0x06,att_out[0],att_out[1],att_out[2],AHRS_RESOLUTION);
}
//******************************************************************************
//! @fn void allTemperatureCanSendout(void)
//!
//! @description
//!  send  temperature data of all sensor & board temperature through CAN port
//!
//! @param    void
//!
//! @return   void
//!
//! @req 
//******************************************************************************
void allTemperatureCanSendout(void)
{
//
//  uint16_t pct2075temp;
//  uint16_t asm330_temp;
//  uint16_t iis2mdc_temp;
//  static uint16_t testCount;
//
//  uint8_t allTempData[8];
//
//  pct2075temp = (uint16_t)(pct2075ResultTemp / 0.125f);
//  pct2075temp = pct2075temp << 5;
//
//  asm330_temp = (uint16_t)(asm330lhh_raw_data.temperature_degC / 0.125f);
//  asm330_temp = asm330_temp << 5;
//
//  iis2mdc_temp = (uint16_t)(iis2mdc_raw_data.temperature_degC / 0.125f);
//  iis2mdc_temp = iis2mdc_temp << 5;
//
//  allTempData[2] = (pct2075temp & 0xFF00) >> 8;
//  allTempData[3] = pct2075temp & 0x00FF;
//
//  allTempData[4] = (asm330_temp & 0xFF00) >> 8;
//  allTempData[5] = asm330_temp & 0x00FF;
//
//  allTempData[0] = (iis2mdc_temp & 0xFF00) >> 8;
//  allTempData[1] = iis2mdc_temp & 0x00FF;
//
//  //CAN0_Send(STANDARD_ID, 0xCC, 6, allTempData);
//  if(testCount > 100)
//  testCount=0;
//
//  CAN1_Send(STANDARD_ID, testCount, 6, allTempData);
}

void allTemperatureRS485Sendout(void)
{
  char dataRS485Msg[150] = {""};  
  char string[20];
  strcat(dataRS485Msg, "\r\n");
  sprintf(string,"%.4f",pct2075ResultTemp); // keep 4 decimals
  strcat(dataRS485Msg, string);
  
  strcat(dataRS485Msg, "  ");
  sprintf(string,"%.4f",iis2mdc_raw_data.temperature_degC);  
  strcat(dataRS485Msg, string);
  
  strcat(dataRS485Msg, "  ");
  sprintf(string,"%.4f",asm330lhh_raw_data.temperature_degC);   
  strcat(dataRS485Msg, string);
 
//  LPUART1_Send((uint8_t const*)dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
  LPUART1_Send((uint8_t*)dataRS485Msg, sizeof(dataRS485Msg)/ sizeof(dataRS485Msg[0]));
}


void AttitudeSendout(void)
{
#if defined USE_UART_INTERFACE || defined USE_RS485_INTERFACE
	sendAhrsAllMsg9axis(angles, rate_out, acc_rls, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS, ACCEL_RESOLUTION);
#endif

#if defined USE_CAN_INTERFACE
	sendCanMessage((uint32_t)CAN_ID_Attitude    , angles[0]  , angles[1]  , angles[2]  , AHRS_RESOLUTION);
	sendCanMessage((uint32_t)CAN_ID_Gyroscope   , rate_out[0], rate_out[1], rate_out[2], ASM330LHH_FS500DPS_DPS);
	sendCanMessage((uint32_t)CAN_ID_Acceleration, acc_rls[0] , acc_rls[1] , acc_rls[2] , ACCEL_RESOLUTION);
#endif
//  sendCanMessage(0x01, 0x17, 0x01, 1.0f, 2.0f, 3.0f, 1.0f);

}

void GPAhrsSendout(float* vel,double lon ,double lat)
{
#if defined USE_UART_INTERFACE || defined USE_RS485_INTERFACE
//	if(send_GPAhrs1==true){
//		sendGPAhrs1(vel,lon,lat, 0.3, 0.1, 0.1, 0.01);
//		send_GPAhrs1=false;
//	}
//	else {
//		sendGPAhrs2(angles, rate_out, acc_rls, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS, ACCEL_RESOLUTION);
//		send_GPAhrs1=true;
//	}

	if(send_GPAhrs1==true)
	{
		sendGPAhrs3(vel,lon,lat, 0.3, 0.1, 0.1, 0.01,angles, rate_out, acc_rls, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS, ACCEL_RESOLUTION);
//		sendGPAhrs3();
	}

#endif

#if defined USE_CAN_INTERFACE
	sendCanMessage((uint32_t)CAN_ID_Attitude    , angles[0]  , angles[1]  , angles[2]  , AHRS_RESOLUTION);
	sendCanMessage((uint32_t)CAN_ID_Gyroscope   , rate_out[0], rate_out[1], rate_out[2], ASM330LHH_FS500DPS_DPS);
	sendCanMessage((uint32_t)CAN_ID_Acceleration, acc_rls[0] , acc_rls[1] , acc_rls[2] , ACCEL_RESOLUTION);
#endif
//  sendCanMessage(0x01, 0x17, 0x01, 1.0f, 2.0f, 3.0f, 1.0f);

}

void AttitudeSendout_Redman(void)
{
//  sendRS485Message(0x0B, phi, theta, psi, AHRS_RESOLUTION);
  //sendAhrsAllMsg(0x0B, angles, rate_out, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
  //sendAhrsAllMsg(0x0B, angles_ekf, angles_est, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);//0305 mag & ekf
  //sendAhrsAllMsg(0x0B, rawMags, mags, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
  //sendAhrsAllMsg(0x0B, angles_ekf, rate_out_ekf, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
  //sendAhrsAllMsg(0x0B, acc_raw, accel_out, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
  //sendAhrsAllMsg(0x0B, rate_out_ekf, rate_out_est, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
  //sendAhrsAllMsg(0x0B, angles_redundy, rate_redundy, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
#if defined USE_UART_INTERFACE || defined USE_RS485_INTERFACE
	sendAhrsAllMsg9axis(angles_redundy, rate_redundy, acc_rls, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS, ACCEL_RESOLUTION);
#endif

#if defined USE_CAN_INTERFACE
	sendCanMessage((uint32_t)CAN_ID_Attitude    , angles_redundy[0], angles_redundy[1], angles_redundy[2], AHRS_RESOLUTION);
	sendCanMessage((uint32_t)CAN_ID_Gyroscope   , rate_redundy[0]  , rate_redundy[1]  , rate_redundy[2]  , ASM330LHH_FS500DPS_DPS);
	sendCanMessage((uint32_t)CAN_ID_Acceleration, acc_rls[0]       , acc_rls[1]       , acc_rls[2]       , ACCEL_RESOLUTION);
#endif

}

void AccGyroMagSendoutAT(void)
{
#if defined USE_UART_INTERFACE || defined USE_RS485_INTERFACE
  sendOriMsg(asm330lhh_rls_data.acceleration_g, asm330llh_autotrim_data.angular_rate_dps, iis2mdc_rls_data.magnetic_mG,
             asm330lhh_raw_data.temperature_degC, ASM330LHH_FS16G_G, ASM330LHH_FS500DPS_DPS, IIS2MDC_LSB_MG, 0.125f);//acc rate mag
#endif

#if defined USE_CAN_INTERFACE
  sendCanMessage((uint32_t)CAN_ID_Gyroscope,
		  	  	  asm330llh_autotrim_data.angular_rate_dps[0], asm330llh_autotrim_data.angular_rate_dps[1], asm330llh_autotrim_data.angular_rate_dps[2], ASM330LHH_FS500DPS_DPS);
  sendCanMessage((uint32_t)CAN_ID_Acceleration,
		  	  	  asm330lhh_rls_data.acceleration_g[0], asm330lhh_rls_data.acceleration_g[1], asm330lhh_rls_data.acceleration_g[2], ASM330LHH_FS16G_G);
  sendCanMessage((uint32_t)CAN_ID_Magnetism,
		  	  	  iis2mdc_rls_data.magnetic_mG[0], iis2mdc_rls_data.magnetic_mG[1], iis2mdc_rls_data.magnetic_mG[2], IIS2MDC_LSB_MG);
#endif
  //  sendOriMsg(0x17,asm330llh_autotrim_data.angular_rate_dps , asm330lhh_rls_data.acceleration_g, iis2mdc_rls_data.magnetic_mG,
//             asm330lhh_raw_data.temperature_degC,ASM330LHH_FS500DPS_DPS , ASM330LHH_FS16G_G, IIS2MDC_LSB_MG, 0.125f);//rate acc mag 
//  sendRS485Message(0x0A, asm330lhh_rls_data.acceleration_g[0], asm330lhh_rls_data.acceleration_g[1], asm330lhh_rls_data.acceleration_g[2], ASM330LHH_FS16G_G);
//  sendRS485Message(0x0C, asm330lhh_rls_data.angular_rate_dps[0], asm330lhh_rls_data.angular_rate_dps[1], asm330lhh_rls_data.angular_rate_dps[2], ASM330LHH_FS500DPS_DPS);
//  sendRS485Message(0x0D, iis2mdc_rls_data.magnetic_mG[0], iis2mdc_rls_data.magnetic_mG[1], iis2mdc_rls_data.magnetic_mG[2], IIS2MDC_LSB_MG);
//  sendRS485Temp(0x0E, asm330lhh_raw_data.temperature_degC, 0.125f);
  
}
void AccGyroMagSendoutRLS(void)
{
#if defined USE_UART_INTERFACE || defined USE_RS485_INTERFACE
  sendOriMsg(asm330lhh_rls_data.acceleration_g, asm330lhh_rls_data.angular_rate_dps, iis2mdc_rls_data.magnetic_mG,
             asm330lhh_raw_data.temperature_degC, ASM330LHH_FS16G_G, ASM330LHH_FS500DPS_DPS, IIS2MDC_LSB_MG, 0.125f);//acc rate mag  RLS
#endif

#if defined USE_CAN_INTERFACE
  sendCanMessage((uint32_t)CAN_ID_Gyroscope,
		  	  	  	 asm330lhh_rls_data.angular_rate_dps[0], asm330lhh_rls_data.angular_rate_dps[1], asm330lhh_rls_data.angular_rate_dps[2], ASM330LHH_FS500DPS_DPS);
  sendCanMessage((uint32_t)CAN_ID_Acceleration,
		  	  	  	 asm330lhh_rls_data.acceleration_g[0], asm330lhh_rls_data.acceleration_g[1], asm330lhh_rls_data.acceleration_g[2], ASM330LHH_FS16G_G);
  sendCanMessage((uint32_t)CAN_ID_Magnetism,
		  	  	  	 iis2mdc_rls_data.magnetic_mG[0], iis2mdc_rls_data.magnetic_mG[1], iis2mdc_rls_data.magnetic_mG[2], IIS2MDC_LSB_MG);
#endif
  //  sendOriMsg(0x17, asm330lhh_rls_data.acceleration_g, asm330llh_autotrim_data.angular_rate_dps, iis2mdc_rls_data.magnetic_mG,
//             asm330lhh_raw_data.temperature_degC, ASM330LHH_FS16G_G, ASM330LHH_FS500DPS_DPS, IIS2MDC_LSB_MG, 0.125f);//acc rate mag  AT
//  sendOriMsg(0x17,asm330lhh_rls_data.angular_rate_dps , asm330lhh_rls_data.acceleration_g, iis2mdc_rls_data.magnetic_mG,
//             asm330lhh_raw_data.temperature_degC,ASM330LHH_FS500DPS_DPS , ASM330LHH_FS16G_G, IIS2MDC_LSB_MG, 0.125f);//rate acc mag 
  
}


//void AccGyroMagSendoutCal(void)
//{
//	UART_Text_Print(UART1_Print, "1 2 3 4 5 6 7 8 9 8 7 6 5 4 3 2 1 0\r\n");
//}




void AccGyroMagSendoutCal(void)
{
#if defined USE_UART_INTERFACE || defined USE_RS485_INTERFACE
  sendOriMsg(asm330lhh_rls_data.acceleration_g, asm330lhh_rls_data.angular_rate_dps, iis2mdc_rls_data.magnetic_mG,
             asm330lhh_raw_data.temperature_degC, ASM330LHH_FS16G_G, ASM330LHH_FS500DPS_DPS, IIS2MDC_LSB_MG, 0.125f);//rate acc mag
#endif

#if defined USE_CAN_INTERFACE
  sendCanMessage((uint32_t)CAN_ID_Acceleration,
		  	  	  asm330lhh_rls_data.acceleration_g[0], asm330lhh_rls_data.acceleration_g[1], asm330lhh_rls_data.acceleration_g[2], ASM330LHH_FS16G_G);
  sendCanMessage((uint32_t)CAN_ID_Gyroscope,
		  	  	  asm330lhh_rls_data.angular_rate_dps[0], asm330lhh_rls_data.angular_rate_dps[1], asm330lhh_rls_data.angular_rate_dps[2], ASM330LHH_FS500DPS_DPS);
  sendCanMessage((uint32_t)CAN_ID_Magnetism,
		  	      iis2mdc_rls_data.magnetic_mG[0], iis2mdc_rls_data.magnetic_mG[1], iis2mdc_rls_data.magnetic_mG[2], IIS2MDC_LSB_MG);
//  sendRS485Temp(0x0E, asm330lhh_raw_data.temperature_degC, 0.125f);
#endif
  //	sendOriMsg(0x17, asm330lhh_rls_data.acceleration_g, asm330lhh_rls_data.angular_rate_dps, iis2mdc_rls_data.magnetic_mG, asm330lhh_raw_data.temperature_degC, ASM330LHH_FS16G_G, ASM330LHH_FS500DPS_DPS, IIS2MDC_LSB_MG, 0.125f);//acc rate mag

//	UART_Text_Print(UART1_Print, "1 2 3 4 5 6 7 8 9 8 7 6 5 4 3 2 1 0\r\n");
}




void AHRS_ALL_SEND(void)
{ 
//  sendRS485Message(0x0B, phi, theta, psi, AHRS_RESOLUTION);
 // sendAhrsAllMsg(0x0B, angles, rate_out, AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS);
  
  sendAhrsAllDataRS485Msg(0x0B, angles, rate_out,asm330lhh_rls_data.acceleration_g, Q,asm330lhh_raw_data.temperature_degC
                          ,AHRS_RESOLUTION, ASM330LHH_FS500DPS_DPS, ASM330LHH_FS16G_G, resolution_q, 0.125f);
  
}

